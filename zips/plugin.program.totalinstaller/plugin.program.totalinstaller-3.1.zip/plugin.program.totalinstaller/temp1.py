import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon
import os , sys , time , xbmcvfs , glob , shutil , datetime , zipfile , ntpath
import subprocess , threading
import yt , downloader , checkPath
import binascii
import hashlib
import speedtest
import extract
try :
 from sqlite3 import dbapi2 as database
except :
 from pysqlite2 import dbapi2 as database
 if 64 - 64: i11iIiiIii
from addon . common . addon import Addon
from addon . common . net import Net
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
######################################################
o0OO00 = 'plugin.program.totalinstaller'
oo = 'The Community Portal'
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = xbmcaddon . Addon ( id = o0OO00 )
zip = i1IiI1I11 . getSetting ( 'zip' )
IIiIiII11i = i1IiI1I11 . getSetting ( 'localcopy' )
o0oOOo0O0Ooo = i1IiI1I11 . getSetting ( 'private' )
I1ii11iIi11i = i1IiI1I11 . getSetting ( 'openelec' )
I1IiI = i1IiI1I11 . getSetting ( 'favourites' )
o0OOO = i1IiI1I11 . getSetting ( 'sources' )
iIiiiI = i1IiI1I11 . getSetting ( 'repositories' )
Iii1ii1II11i = i1IiI1I11 . getSetting ( 'enablekeyword' )
iI111iI = i1IiI1I11 . getSetting ( 'keywordpath' )
IiII = i1IiI1I11 . getSetting ( 'keywordname' )
iI1Ii11111iIi = i1IiI1I11 . getSetting ( 'mastercopy' )
i1i1II = i1IiI1I11 . getSetting ( 'username' ) . replace ( ' ' , '%20' )
O0oo0OO0 = i1IiI1I11 . getSetting ( 'password' )
I1i1iiI1 = i1IiI1I11 . getSetting ( 'versionoverride' )
iiIIIII1i1iI = i1IiI1I11 . getSetting ( 'debug' )
o0oO0 = i1IiI1I11 . getSetting ( 'login' )
oo00 = i1IiI1I11 . getSetting ( 'addonportal' )
o00 = i1IiI1I11 . getSetting ( 'maintenance' )
Oo0oO0ooo = i1IiI1I11 . getSetting ( 'hardwareportal' )
o0oOoO00o = i1IiI1I11 . getSetting ( 'maintenance' )
i1 = i1IiI1I11 . getSetting ( 'latestnews' )
oOOoo00O0O = i1IiI1I11 . getSetting ( 'tutorialportal' )
i1111 = i1IiI1I11 . getSetting ( 'startupvideo' )
i11 = i1IiI1I11 . getSetting ( 'startupvideopath' )
I11 = i1IiI1I11 . getSetting ( 'wizard' )
Oo0o0000o0o0 = i1IiI1I11 . getSetting ( 'wizardurl1' )
oOo0oooo00o = i1IiI1I11 . getSetting ( 'wizardname1' )
oO0o0o0ooO0oO = i1IiI1I11 . getSetting ( 'wizardurl2' )
oo0o0O00 = i1IiI1I11 . getSetting ( 'wizardname2' )
oO = i1IiI1I11 . getSetting ( 'wizardurl3' )
i1iiIIiiI111 = i1IiI1I11 . getSetting ( 'wizardname3' )
oooOOOOO = i1IiI1I11 . getSetting ( 'wizardurl4' )
i1iiIII111ii = i1IiI1I11 . getSetting ( 'wizardname4' )
i1iIIi1 = i1IiI1I11 . getSetting ( 'wizardurl5' )
ii11iIi1I = i1IiI1I11 . getSetting ( 'wizardname5' )
iI111I11I1I1 = xbmcgui . Dialog ( )
OOooO0OOoo = xbmcgui . DialogProgress ( )
iIii1 = xbmc . translatePath ( 'special://home/' )
oOOoO0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
O0OoO000O0OO = os . path . join ( oOOoO0 , 'addon_data' )
iiI1IiI = os . path . join ( iIii1 , 'CP_Profiles' )
II = os . path . join ( iiI1IiI , 'Master' )
ooOoOoo0O = os . path . join ( oOOoO0 , 'Database' )
OooO0 = os . path . join ( oOOoO0 , 'Thumbnails' )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
OO0o = xbmc . translatePath ( os . path . join ( 'special://xbmc' , 'addons' ) )
Ooo = os . path . join ( II11iiii1Ii , o0OO00 , 'default.py' )
O0o0Oo = os . path . join ( II11iiii1Ii , o0OO00 , 'fanart.jpg' )
Oo00OOOOO = os . path . join ( II11iiii1Ii , o0OO00 , 'resources' , 'addonxml' )
O0O = os . path . join ( II11iiii1Ii , o0OO00 , 'resources' , 'skins' , 'DefaultSkin' , 'media' , 'ttm' )
O00o0OO = os . path . join ( II11iiii1Ii , o0OO00 , 'resources' , 'backup' )
I11i1 = os . path . join ( oOOoO0 , 'guisettings.xml' )
iIi1ii1I1 = os . path . join ( oOOoO0 , 'guifix.xml' )
o0 = 'http://www.noobsandnerds.com/TI/artwork/'
I11II1i = os . path . join ( II11iiii1Ii , o0OO00 , 'icon_menu.png' )
IIIII = os . path . join ( oOOoO0 , 'favourites.xml' )
ooooooO0oo = os . path . join ( oOOoO0 , 'sources.xml' )
IIiiiiiiIi1I1 = os . path . join ( oOOoO0 , 'advancedsettings.xml' )
I1IIIii = os . path . join ( oOOoO0 , 'profiles.xml' )
oOoOooOo0o0 = os . path . join ( oOOoO0 , 'RssFeeds.xml' )
OOOO = os . path . join ( oOOoO0 , 'keymaps' , 'keyboard.xml' )
OOO00 = xbmc . translatePath ( os . path . join ( zip ) )
iiiiiIIii = os . path . join ( OOO00 , 'Community_Builds' , '' )
O000OO0 = os . path . join ( O0OoO000O0OO , o0OO00 , 'startup.xml' )
I11iii1Ii = os . path . join ( O0OoO000O0OO , o0OO00 , 'temp.xml' )
I1IIiiIiii = os . path . join ( O0OoO000O0OO , o0OO00 , 'id.xml' )
O000oo0O = os . path . join ( II11iiii1Ii , 'repository.totalinstaller' )
OOOOi11i1 = os . path . join ( II11iiii1Ii , 'repository.totalrevolution' )
IIIii1II1II = os . path . join ( II11iiii1Ii , 'plugin.program.totalrevolution' )
i1I1iI = os . path . join ( O0OoO000O0OO , o0OO00 , 'idtemp.xml' )
oo0OooOOo0 = os . path . join ( O0OoO000O0OO , o0OO00 , 'temp' )
o0O = os . path . join ( O0OoO000O0OO , o0OO00 , 'ascii_results' )
O00oO = os . path . join ( O0OoO000O0OO , o0OO00 , 'ascii_results1' )
I11i1I1I = os . path . join ( O0OoO000O0OO , o0OO00 , 'ascii_results2' )
oO0Oo = os . path . join ( O0OoO000O0OO , o0OO00 , 'guizip' )
oOOoo0Oo = os . path . join ( II11iiii1Ii , o0OO00 , 'resources/' )
o00OO00OoO = os . path . join ( II11iiii1Ii , o0OO00 , 'default.py' )
OOOO0OOoO0O0 = xbmc . getSkinDir ( )
O0Oo000ooO00 = xbmc . translatePath ( 'special://logpath/' )
oO0 = '/storage/backup'
Ii1iIiII1ii1 = '/storage/.restore/'
ooOooo000oOO = Net ( )
Oo0oOOo = os . path . join ( O0OoO000O0OO , o0OO00 )
Oo0OoO00oOO0o = os . path . join ( Oo0oOOo , 'guinew.xml' )
OOO00O = os . path . join ( Oo0oOOo , 'guitemp' )
OOoOO0oo0ooO = os . path . join ( O0OoO000O0OO , o0OO00 , 'scripts' )
O0o0O00Oo0o0 = os . path . join ( OOO00 , 'Database' )
O00O0oOO00O00 = os . path . join ( II11iiii1Ii , 'packages' )
i1Oo00 = os . path . join ( oOOoO0 , 'addontemp' )
i1i = os . path . join ( oOOoO0 , '.cbcfg' )
iiI111I1iIiI = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' ]
IIIi1I1IIii1II = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' , 'guisettings.xml' , 'CP_Profiles' , 'temp' ]
O0ii1ii1ii = 0.0
oooooOoo0ooo = 0.0
I1I1IiI1 = '0'
III1iII1I1ii = [ '/storage/.kodi' , '/storage/.cache' , '/storage/.config' , '/storage/.ssh' ]
oOOo0 = '1889903'
if 54 - 54: II11iIiIIIiI - ii1ii11IIIiiI - O00OOOoOoo0O
def O000OOo00oo ( ) :
 OOooO0OOoo . create ( 'Checking dependencies' , '' , 'Please Wait...' )
 oo0OOo = [ ]
 if 64 - 64: oOO00Oo
 for i1iIIIi1i in os . listdir ( II11iiii1Ii ) :
  if i1iIIIi1i != 'packages' :
   try :
    iI1iIIiiii = os . path . join ( II11iiii1Ii , i1iIIIi1i , 'addon.xml' )
    i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
    OOooo0O00o = i1iI11i1ii11 . read ( )
    i1iI11i1ii11 . close ( )
    oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
    if 51 - 51: OoooO0Oo0O0 + III1IiiI % iiIi1i11 / o00O0OoO - iI1IiiIIIiIi . i1Iii1i1I
    for OOoO00 in oOOoOooOo :
     if 40 - 40: i11111IIIII * Iiii1i1 / o0oOo0 * iI1IiiIIIiIi
     if not 'xbmc.python' in OOoO00 and not OOoO00 in oo0OOo :
      oo0OOo . append ( OOoO00 )
      if debug == 'true' :
       print 'Script Requires --- ' + OOoO00
   except :
    pass
    if 81 - 81: ii1ii11IIIiiI
 return oo0OOo
 if 42 - 42: ii1ii11IIIiiI / o00O0OoO / oOO00Oo + i1Iii1i1I / O00OOOoOoo0O
 if 84 - 84: o0oOo0 * oO0OooOoO + II11iIiIIIiI
class O0ooO0Oo00o ( xbmcgui . WindowXMLDialog ) :
 if 77 - 77: iIii1I11I1II1 * ii1ii11IIIiiI
 def __init__ ( self , * args , ** kwargs ) :
  self . shut = kwargs [ 'close_time' ]
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
  if 95 - 95: o0Oo + i11iIiiIii
 def onFocus ( self , controlID ) :
  pass
  if 6 - 6: o0oOo0 / i11iIiiIii + i1Iii1i1I * III1IiiI
 def onClick ( self , controlID ) :
  if controlID == 12 :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 80 - 80: oO0OooOoO
 def onAction ( self , action ) :
  if action in [ 5 , 6 , 7 , 9 , 10 , 92 , 117 ] or action . getButtonCode ( ) in [ 275 , 257 , 261 ] :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 83 - 83: o00O0OoO . i11iIiiIii + oO0OooOoO . oOO00Oo * o00O0OoO
 def _close_dialog ( self ) :
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  time . sleep ( .4 )
  self . close ( )
  if 53 - 53: oO0OooOoO
  if 31 - 31: ii1ii11IIIiiI
def o0OIiII ( name , url , mode , iconimage , fanart , video , description , skins , guisettingslink , artpack ) :
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 ii1iII1II += "&skins=" + urllib . quote_plus ( skins )
 ii1iII1II += "&guisettingslink=" + urllib . quote_plus ( guisettingslink )
 ii1iII1II += "&artpack=" + urllib . quote_plus ( artpack )
 if 48 - 48: oO0OooOoO * iI1IiiIIIiIi . o00O0OoO + III1IiiI
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 94 - 94: oOO00Oo * iI1IiiIIIiIi / II11iIiIIIiI / iI1IiiIIIiIi
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 if 87 - 87: II11iIiIIIiI . i11111IIIII
 if ( mode == None ) or ( mode == 'restore_option' ) or ( mode == 'backup_option' ) or ( mode == 'cb_root_menu' ) or ( mode == 'genres' ) or ( mode == 'grab_builds' ) or ( mode == 'community_menu' ) or ( mode == 'instructions' ) or ( mode == 'countries' ) or ( mode == 'update_build' ) or ( url == None ) or ( len ( url ) < 1 ) :
  if 75 - 75: o0oOo0 + O00OOOoOoo0O + oOO00Oo * o00O0OoO % III1IiiI . i1Iii1i1I
  OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = True )
  if 55 - 55: iiIi1i11 . o0Oo
 else :
  OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
  if 61 - 61: II11iIiIIIiI % i11111IIIII . II11iIiIIIiI
 return OoO0o
 if 100 - 100: Iiii1i1 * O0
 if 64 - 64: iiIi1i11 % iIii1I11I1II1 * III1IiiI
def o0iI11I1II ( handle , url , listitem , isFolder ) :
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 40 - 40: iIii1I11I1II1 / O00OOOoOoo0O % OoooO0Oo0O0 + oO0OooOoO
 if 27 - 27: oO0OooOoO * O00OOOoOoo0O * iIii1I11I1II1
def oOo00oOoO000 ( name , url , mode , iconimage , fanart , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 if 93 - 93: oOO00Oo % i1IIi . iI1IiiIIIiIi . i11iIiiIii
 iconimage = I11II1i
 if 56 - 56: OoooO0Oo0O0 % O0 - o0Oo
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&author=" + urllib . quote_plus ( author )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 ii1iII1II += "&version=" + urllib . quote_plus ( version )
 ii1iII1II += "&buildname=" + urllib . quote_plus ( buildname )
 ii1iII1II += "&updated=" + urllib . quote_plus ( updated )
 ii1iII1II += "&skins=" + urllib . quote_plus ( skins )
 ii1iII1II += "&videoaddons=" + urllib . quote_plus ( videoaddons )
 ii1iII1II += "&audioaddons=" + urllib . quote_plus ( audioaddons )
 ii1iII1II += "&buildname=" + urllib . quote_plus ( buildname )
 ii1iII1II += "&programaddons=" + urllib . quote_plus ( programaddons )
 ii1iII1II += "&pictureaddons=" + urllib . quote_plus ( pictureaddons )
 ii1iII1II += "&sources=" + urllib . quote_plus ( sources )
 ii1iII1II += "&adult=" + urllib . quote_plus ( adult )
 if 100 - 100: iI1IiiIIIiIi - O0 % III1IiiI * iiIi1i11 + o0Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 88 - 88: OoooooooOO - ii1ii11IIIiiI * O0 * OoooooooOO . OoooooooOO
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , I111iI )
 if 56 - 56: o0Oo
 OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
 if 54 - 54: Iiii1i1 / iiIi1i11 . III1IiiI % i1Iii1i1I
 return OoO0o
 if 57 - 57: i11iIiiIii . OoooO0Oo0O0 - iI1IiiIIIiIi - III1IiiI + O00OOOoOoo0O
def oO00oooOOoOo0 ( title , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' , zip_link = '' , repo_link = '' , repo_id = '' , addon_id = '' , provider_name = '' , forum = '' , data_path = '' ) :
 if len ( iconimage ) > 0 :
  if 74 - 74: iIii1I11I1II1 * OoooO0Oo0O0 + O00OOOoOoo0O / i1IIi / oO0OooOoO . II11iIiIIIiI
  iconimage = iconimage
 else :
  iconimage = 'DefaultFolder.png'
  if 62 - 62: OoooooooOO * o0Oo
 if fanart == '' :
  fanart = O0o0Oo
  if 58 - 58: O00OOOoOoo0O % oOO00Oo
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&zip_link=" + urllib . quote_plus ( zip_link )
 ii1iII1II += "&repo_link=" + urllib . quote_plus ( repo_link )
 ii1iII1II += "&data_path=" + urllib . quote_plus ( data_path )
 ii1iII1II += "&provider_name=" + str ( provider_name )
 ii1iII1II += "&forum=" + str ( forum )
 ii1iII1II += "&repo_id=" + str ( repo_id )
 ii1iII1II += "&addon_id=" + str ( addon_id )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 if 50 - 50: Iiii1i1 . oOO00Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( title , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 97 - 97: O0 + O00OOOoOoo0O
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 if 89 - 89: oOO00Oo + ii1ii11IIIiiI * o00O0OoO * iI1IiiIIIiIi
 o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
 if 37 - 37: OoooooooOO - O0 - oOO00Oo
 if 77 - 77: iiIi1i11 * iIii1I11I1II1
def oO00oOOoooO ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if not 'addon' in type :
  if 46 - 46: o0Oo - OoooooooOO - o00O0OoO * oO0OooOoO
  if len ( iconimage ) > 0 :
   iconimage = o0 + iconimage
   if 34 - 34: o00O0OoO - i1Iii1i1I / iiIi1i11 + OoooO0Oo0O0 * iI1IiiIIIiIi
  else :
   iconimage = I11II1i
   if 73 - 73: O00OOOoOoo0O . iI1IiiIIIiIi * OoooO0Oo0O0 % OoooO0Oo0O0 % OoooooooOO
 if 'addon' in type :
  if 63 - 63: iIii1I11I1II1 * i11iIiiIii % iIii1I11I1II1 * i11iIiiIii
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'DefaultFolder.png'
   if 32 - 32: iiIi1i11
   if 42 - 42: i11111IIIII * O0 % i1IIi . iiIi1i11 / oOO00Oo
   if 32 - 32: o0Oo * II11iIiIIIiI
 if fanart == '' :
  fanart = O0o0Oo
  if 78 - 78: iiIi1i11 - OoooooooOO - OoooO0Oo0O0 / o0oOo0 / oO0OooOoO
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 if 29 - 29: o0Oo % o0Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 94 - 94: iIii1I11I1II1 / II11iIiIIIiI % i1Iii1i1I * i1Iii1i1I * oO0OooOoO
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 oO0o0Ooooo . addContextMenuItems ( [ ( 'Reset Add-on' , 'XBMC.RunScript(special://home/addons/plugin.program.totalinstaller/resetAddon.py)' ) ] , replaceItems = True )
 if 'folder' in type :
  OoO0o = o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = True )
  if 29 - 29: ii1ii11IIIiiI + O00OOOoOoo0O / oOO00Oo / iiIi1i11 * iIii1I11I1II1
 else :
  OoO0o = o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
  if 62 - 62: iiIi1i11 / III1IiiI - ii1ii11IIIiiI . o00O0OoO
 return OoO0o
 if 11 - 11: OoooO0Oo0O0 . ii1ii11IIIiiI * i11111IIIII * OoooooooOO + o0oOo0
 if 33 - 33: O0 * oOO00Oo - Iiii1i1 % Iiii1i1
def I11I ( name ) :
 import base64
 I11iIi1i1II11 = os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) )
 iiI = os . path . join ( I11iIi1i1II11 , 'addon.xml' )
 if 26 - 26: iI1IiiIIIiIi % OoooO0Oo0O0
 if not os . path . exists ( I11iIi1i1II11 ) :
  os . makedirs ( I11iIi1i1II11 )
  if 76 - 76: i11111IIIII * i1Iii1i1I
 if not os . path . exists ( os . path . join ( I11iIi1i1II11 , 'addon.xml' ) ) :
  shutil . copyfile ( O0O , iiI )
  if 52 - 52: iiIi1i11
  if 19 - 19: o0Oo
 i11i = "import xbmcgui, xbmc;xbmcgui.Dialog().ok('Message from " + name + " (Build Author)','If you paid for this build I regret to inform you that you may have been conned. This build is not available for resale.','You can get it for [COLOR=gold]FREE[/COLOR] @ [COLOR=dodgerblue]www.noobsandnerds.com[/COLOR]');xbmc.sleep(10000);xbmc.executebuiltin('XBMC.Notification(THIS BUILD IS NOT FOR RESALE!!!,If you paid contact the seller - its FREE,40000)')"
 o0oooOO00 = open ( os . path . join ( I11iIi1i1II11 , 'default.py' ) , 'w+' )
 o0oooOO00 . write ( "import base64;exec base64.b64decode('" )
 iiIiii1IIIII = base64 . b64encode ( i11i )
 o0oooOO00 . write ( iiIiii1IIIII )
 o0oooOO00 . write ( "')" )
 o0oooOO00 . close ( )
 if 67 - 67: iI1IiiIIIiIi / i11111IIIII
 o0oooOO00 = open ( os . path . join ( I11iIi1i1II11 , 'tag.cfg' ) , 'w+' )
 o0oooOO00 . write ( binascii . hexlify ( name ) )
 o0oooOO00 . close ( )
 if 9 - 9: O0 % O0 - oOO00Oo
 OoO = open ( iiI , 'r' )
 i11i = OoO . read ( )
 OoO . close ( )
 iiI1IIIi = i11i . replace ( 'testid' , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) . replace ( 'testname' , 'idTent Parser' ) . replace ( 'testprovider' , 'bytesize' ) . replace ( 'testdesc' , 'important module do not delete' )
 o0oooOO00 = open ( iiI , 'w+' )
 o0oooOO00 . write ( iiI1IIIi )
 o0oooOO00 . close ( )
 if 47 - 47: II11iIiIIIiI % o00O0OoO % i11iIiiIii - O0 + o0oOo0
 if 94 - 94: Iiii1i1
def i11II1I11I1 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Audio' , url + '&typex=audio' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Image (Picture)' , url + '&typex=image' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Program' , url + '&typex=program' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Video' , url + '&typex=video' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Movies (Used for library scanning)' , url + '&typex=movie%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] TV Shows (Used for library scanning)' , url + '&typex=tv%20show%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Artists (Used for library scanning)' , url + '&typex=artist%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Videos (Used for library scanning)' , url + '&typex=music%20video%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] All Services' , url + '&typex=service' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] Weather Service' , url + '&typex=weather' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Repositories' , url + '&typex=repository' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Scripts (Program Add-ons)' , url + '&typex=executable' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Screensavers' , url + '&typex=screensaver' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Script Modules' , url + '&typex=script%20module' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Skins' , url + '&typex=skin' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Subtitles' , url + '&typex=subtitles' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Web Interface' , url + '&typex=web%20interface' , 'grab_addons' , '' , '' , '' , '' )
 if 67 - 67: o0Oo - oOO00Oo / o00O0OoO - i1IIi
 if 1 - 1: oO0OooOoO
def O0oOo00o ( ) :
 o0ooooO0o0O ( )
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://outdated/",return)' )
 if 24 - 24: O0 * oOO00Oo
 if 29 - 29: o0Oo % iiIi1i11 - o0Oo / iiIi1i11 . i1IIi
def i11III1111iIi ( url ) :
 oO00oOOoooO ( 'folder' , 'African' , url + '&genre=african' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Arabic' , url + '&genre=arabic' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Asian' , url + '&genre=asian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Australian' , url + '&genre=australian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Austrian' , url + '&genre=austrian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Belgian' , url + '&genre=belgian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Brazilian' , url + '&genre=brazilian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Canadian' , url + '&genre=canadian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Chinese' , url + '&genre=chinese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Colombian' , url + '&genre=columbian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Croatian' , url + '&genre=croatian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Czech' , url + '&genre=czech' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Danish' , url + '&genre=danish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dominican' , url + '&genre=dominican' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dutch' , url + '&genre=dutch' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Egyptian' , url + '&genre=egyptian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Filipino' , url + '&genre=filipino' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Finnish' , url + '&genre=finnish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'French' , url + '&genre=french' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'German' , url + '&genre=german' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Greek' , url + '&genre=greek' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hebrew' , url + '&genre=hebrew' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hungarian' , url + '&genre=hungarian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Icelandic' , url + '&genre=icelandic' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Indian' , url + '&genre=indian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Irish' , url + '&genre=irish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Italian' , url + '&genre=italian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Japanese' , url + '&genre=japanese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Korean' , url + '&genre=korean' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Lebanese' , url + '&genre=lebanese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Mongolian' , url + '&genre=mongolian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Moroccan' , url + '&genre=moroccan' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Nepali' , url + '&genre=nepali' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'New Zealand' , url + '&genre=newzealand' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Norwegian' , url + '&genre=norwegian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Pakistani' , url + '&genre=pakistani' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Polish' , url + '&genre=polish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Portuguese' , url + '&genre=portuguese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Romanian' , url + '&genre=romanian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Russian' , url + '&genre=russian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Singapore' , url + '&genre=singapore' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Spanish' , url + '&genre=spanish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swedish' , url + '&genre=swedish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swiss' , url + '&genre=swiss' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Syrian' , url + '&genre=syrian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Tamil' , url + '&genre=tamil' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Thai' , url + '&genre=thai' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Turkish' , url + '&genre=turkish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'UK' , url + '&genre=uk' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'USA' , url + '&genre=usa' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Vietnamese' , url + '&genre=vietnamese' , 'grab_addons' , '' , '' , '' , '' )
 if 38 - 38: i1Iii1i1I + o00O0OoO / Iiii1i1 % o0oOo0 - OoooO0Oo0O0
 if 14 - 14: III1IiiI / Iiii1i1
def ooo0O0o00O ( url ) :
 I1i11 = 'http://noobsandnerds.com/TI/AddonPortal/addondetails.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 47 - 47: II11iIiIIIiI * OoooO0Oo0O0 + iIii1I11I1II1 / Iiii1i1 / ii1ii11IIIiiI - OoooooooOO
 iII1i11IIi1i = re . compile ( 'addon_types="(.+?)"' ) . findall ( IiIi1I1 )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 II1III = re . compile ( 'UID="(.+?)"' ) . findall ( IiIi1I1 )
 III1 = re . compile ( 'id="(.+?)"' ) . findall ( IiIi1I1 )
 OooooO0oOOOO = re . compile ( 'provider_name="(.+?)"' ) . findall ( IiIi1I1 )
 o0O00oOOoo = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
 i1I1iIi = re . compile ( 'created="(.+?)"' ) . findall ( IiIi1I1 )
 IIii11Ii1i1I = re . compile ( 'addon_types="(.+?)"' ) . findall ( IiIi1I1 )
 Oooo0O = re . compile ( 'updated="(.+?)"' ) . findall ( IiIi1I1 )
 oo00O0oO0O0 = re . compile ( 'downloads="(.+?)"' ) . findall ( IiIi1I1 )
 if 96 - 96: i11iIiiIii % o0oOo0 / O00OOOoOoo0O
 I1IiI11 = re . compile ( 'description="(.+?)"' ) . findall ( IiIi1I1 )
 iI1iiiiIii = re . compile ( 'devbroke="(.+?)"' ) . findall ( IiIi1I1 )
 iIiIiIiI = re . compile ( 'broken="(.+?)"' ) . findall ( IiIi1I1 )
 i11OOoo = re . compile ( 'deleted="(.+?)"' ) . findall ( IiIi1I1 )
 iIIiiiI = re . compile ( 'mainbranch_notes="(.+?)"' ) . findall ( IiIi1I1 )
 if 60 - 60: o0Oo . Iiii1i1
 IiI111ii1ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IiIi1I1 )
 O0OOo = re . compile ( 'data_url="(.+?)"' ) . findall ( IiIi1I1 )
 IiIII1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( IiIi1I1 )
 O0Oo000 = re . compile ( 'genres="(.+?)"' ) . findall ( IiIi1I1 )
 iiI11i1II = re . compile ( 'forum="(.+?)"' ) . findall ( IiIi1I1 )
 OO0O0OOo0O = re . compile ( 'repo_id="(.+?)"' ) . findall ( IiIi1I1 )
 I1 = re . compile ( 'license="(.+?)"' ) . findall ( IiIi1I1 )
 o0OooOOOOOO = re . compile ( 'platform="(.+?)"' ) . findall ( IiIi1I1 )
 OOooO0o0 = re . compile ( 'visible="(.+?)"' ) . findall ( IiIi1I1 )
 iiIII1i = re . compile ( 'script="(.+?)"' ) . findall ( IiIi1I1 )
 I1I = re . compile ( 'program_plugin="(.+?)"' ) . findall ( IiIi1I1 )
 ooooO0oOoOOoO = re . compile ( 'script_module="(.+?)"' ) . findall ( IiIi1I1 )
 I1i11i = re . compile ( 'video_plugin="(.+?)"' ) . findall ( IiIi1I1 )
 IiIi = re . compile ( 'audio_plugin="(.+?)"' ) . findall ( IiIi1I1 )
 OOOOO0O00 = re . compile ( 'image_plugin="(.+?)"' ) . findall ( IiIi1I1 )
 Iii = re . compile ( 'repository="(.+?)"' ) . findall ( IiIi1I1 )
 iIIiIiI1I1 = re . compile ( 'weather_service="(.+?)"' ) . findall ( IiIi1I1 )
 ooO = re . compile ( 'skin="(.+?)"' ) . findall ( IiIi1I1 )
 ii = re . compile ( 'service="(.+?)"' ) . findall ( IiIi1I1 )
 OO0O0Ooo = re . compile ( 'warning="(.+?)"' ) . findall ( IiIi1I1 )
 oOoO0 = re . compile ( 'web_interface="(.+?)"' ) . findall ( IiIi1I1 )
 Oo0 = re . compile ( 'movie_scraper="(.+?)"' ) . findall ( IiIi1I1 )
 oo0O0o00o0O = re . compile ( 'tv_scraper="(.+?)"' ) . findall ( IiIi1I1 )
 I11i1II = re . compile ( 'artist_scraper="(.+?)"' ) . findall ( IiIi1I1 )
 OooiiIi1i = re . compile ( 'music_video_scraper="(.+?)"' ) . findall ( IiIi1I1 )
 I1i11111i1i11 = re . compile ( 'subtitles="(.+?)"' ) . findall ( IiIi1I1 )
 OOoOOO0 = re . compile ( 'requires="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1i = re . compile ( 'modules="(.+?)"' ) . findall ( IiIi1I1 )
 I1IIIiIiIi = re . compile ( 'icon="(.+?)"' ) . findall ( IiIi1I1 )
 IIIII1 = re . compile ( 'video_preview="(.+?)"' ) . findall ( IiIi1I1 )
 iIi1Ii1i1iI = re . compile ( 'video_guide="(.+?)"' ) . findall ( IiIi1I1 )
 IIiI1 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IiIi1I1 )
 i1iI1 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IiIi1I1 )
 ii1 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IiIi1I1 )
 I1IiiI1ii1i = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IiIi1I1 )
 O0o = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IiIi1I1 )
 oO0OoO00o = re . compile ( 'video_guide6="(.+?)"' ) . findall ( IiIi1I1 )
 II1iiiiII = re . compile ( 'video_guide7="(.+?)"' ) . findall ( IiIi1I1 )
 O0OoOO0oo0 = re . compile ( 'video_guide8="(.+?)"' ) . findall ( IiIi1I1 )
 oOO = re . compile ( 'video_guide9="(.+?)"' ) . findall ( IiIi1I1 )
 O0o0OO0000ooo = re . compile ( 'video_guide10="(.+?)"' ) . findall ( IiIi1I1 )
 iIIII1iIIii = re . compile ( 'video_label1="(.+?)"' ) . findall ( IiIi1I1 )
 oOOO00o000o = re . compile ( 'video_label2="(.+?)"' ) . findall ( IiIi1I1 )
 iIi11i1 = re . compile ( 'video_label3="(.+?)"' ) . findall ( IiIi1I1 )
 oO00oo0o00o0o = re . compile ( 'video_label4="(.+?)"' ) . findall ( IiIi1I1 )
 IiIIIIIi = re . compile ( 'video_label5="(.+?)"' ) . findall ( IiIi1I1 )
 IiIi1iIIi1 = re . compile ( 'video_label6="(.+?)"' ) . findall ( IiIi1I1 )
 O0OoO0ooOO0o = re . compile ( 'video_label7="(.+?)"' ) . findall ( IiIi1I1 )
 OoOo0oOooOoOO = re . compile ( 'video_label8="(.+?)"' ) . findall ( IiIi1I1 )
 oo00ooOoO00 = re . compile ( 'video_label9="(.+?)"' ) . findall ( IiIi1I1 )
 o00oOoOo0 = re . compile ( 'video_label10="(.+?)"' ) . findall ( IiIi1I1 )
 if 72 - 72: Iiii1i1
 if 90 - 90: II11iIiIIIiI % O0 * iIii1I11I1II1 . i1Iii1i1I
 if 8 - 8: o0oOo0 + oO0OooOoO / i1Iii1i1I / o00O0OoO
 ooo0O = iII1i11IIi1i [ 0 ] if ( len ( iII1i11IIi1i ) > 0 ) else ''
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 iII1iii = II1III [ 0 ] if ( len ( II1III ) > 0 ) else ''
 i11i1iiiII = III1 [ 0 ] if ( len ( III1 ) > 0 ) else ''
 ooOO0oO0oo00o = OooooO0oOOOO [ 0 ] if ( len ( OooooO0oOOOO ) > 0 ) else ''
 oOOo0oo0O = o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
 IiiIiI1Ii1i = i1I1iIi [ 0 ] if ( len ( i1I1iIi ) > 0 ) else ''
 i1iIi = IIii11Ii1i1I [ 0 ] if ( len ( IIii11Ii1i1I ) > 0 ) else ''
 iiiii1II = Oooo0O [ 0 ] if ( len ( Oooo0O ) > 0 ) else ''
 O0OOO0OOooo00 = oo00O0oO0O0 [ 0 ] if ( len ( oo00O0oO0O0 ) > 0 ) else ''
 if 6 - 6: iI1IiiIIIiIi - o0oOo0 * iiIi1i11 . i1Iii1i1I / O0 * o0oOo0
 II11iI111i1 = '[CR][CR][COLOR=dodgerblue]Description: [/COLOR]' + I1IiI11 [ 0 ] if ( len ( I1IiI11 ) > 0 ) else ''
 Oo00OoOo = iI1iiiiIii [ 0 ] if ( len ( iI1iiiiIii ) > 0 ) else ''
 ii1ii111 = iIiIiIiI [ 0 ] if ( len ( iIiIiIiI ) > 0 ) else ''
 i11111I1I = '[CR]' + i11OOoo [ 0 ] if ( len ( i11OOoo ) > 0 ) else ''
 ii1Oo0000oOo = '[CR][CR][COLOR=dodgerblue]User Notes: [/COLOR]' + iIIiiiI [ 0 ] if ( len ( iIIiiiI ) > 0 ) else ''
 if 31 - 31: o00O0OoO . Iiii1i1 * o0oOo0 + i11iIiiIii * III1IiiI
 OO0ooo0o0O0Oooooo = IiI111ii1ii [ 0 ] if ( len ( IiI111ii1ii ) > 0 ) else ''
 i11IIIiI1I = O0OOo [ 0 ] if ( len ( O0OOo ) > 0 ) else ''
 o0iiiI1I1iIIIi1 = IiIII1 [ 0 ] if ( len ( IiIII1 ) > 0 ) else ''
 IiiI1iiiiI1iI = O0Oo000 [ 0 ] if ( len ( O0Oo000 ) > 0 ) else ''
 iIiiiii1i = '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]' + iiI11i1II [ 0 ] if ( len ( iiI11i1II ) > 0 ) else '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]No forum details given by developer'
 iiIi1IIiI = iiI11i1II [ 0 ] if ( len ( iiI11i1II ) > 0 ) else 'None'
 i1oO0OO0 = OO0O0OOo0O [ 0 ] if ( len ( OO0O0OOo0O ) > 0 ) else ''
 license = I1 [ 0 ] if ( len ( I1 ) > 0 ) else ''
 o0O0Oo00 = '[COLOR=orange]     Platform: [/COLOR]' + o0OooOOOOOO [ 0 ] if ( len ( o0OooOOOOOO ) > 0 ) else ''
 O0Oo0o000oO = OOooO0o0 [ 0 ] if ( len ( OOooO0o0 ) > 0 ) else ''
 oO0o00oOOooO0 = iiIII1i [ 0 ] if ( len ( iiIII1i ) > 0 ) else ''
 OOOoO000 = I1I [ 0 ] if ( len ( I1I ) > 0 ) else ''
 oOOOO = ooooO0oOoOOoO [ 0 ] if ( len ( ooooO0oOoOOoO ) > 0 ) else ''
 Ii = I1i11i [ 0 ] if ( len ( I1i11i ) > 0 ) else ''
 Ii1ii111i1 = IiIi [ 0 ] if ( len ( IiIi ) > 0 ) else ''
 i1i1i1I = OOOOO0O00 [ 0 ] if ( len ( OOOOO0O00 ) > 0 ) else ''
 oOoo000 = Iii [ 0 ] if ( len ( Iii ) > 0 ) else ''
 OooOo00o = ii [ 0 ] if ( len ( ii ) > 0 ) else ''
 OOOO0OOoO0O0 = ooO [ 0 ] if ( len ( ooO ) > 0 ) else ''
 IiI11i1IIiiI = OO0O0Ooo [ 0 ] if ( len ( OO0O0Ooo ) > 0 ) else ''
 oOOo000oOoO0 = oOoO0 [ 0 ] if ( len ( oOoO0 ) > 0 ) else ''
 OoOo00o0OO = iIIiIiI1I1 [ 0 ] if ( len ( iIIiIiI1I1 ) > 0 ) else ''
 ii1IIIIiI11 = Oo0 [ 0 ] if ( len ( Oo0 ) > 0 ) else ''
 iI1IIIii = oo0O0o00o0O [ 0 ] if ( len ( oo0O0o00o0O ) > 0 ) else ''
 I1i11ii11 = I11i1II [ 0 ] if ( len ( I11i1II ) > 0 ) else ''
 OO00O0oOO = OooiiIi1i [ 0 ] if ( len ( OooiiIi1i ) > 0 ) else ''
 Ii1iI111 = I1i11111i1i11 [ 0 ] if ( len ( I1i11111i1i11 ) > 0 ) else ''
 OOoO00 = OOoOOO0 [ 0 ] if ( len ( OOoOOO0 ) > 0 ) else ''
 O0oooo00o0Oo = I1I1i [ 0 ] if ( len ( I1I1i ) > 0 ) else ''
 I1iii = I1IIIiIiIi [ 0 ] if ( len ( I1IIIiIiIi ) > 0 ) else ''
 oO0o0O0Ooo0o = IIIII1 [ 0 ] if ( len ( IIIII1 ) > 0 ) else 'None'
 i1Ii11II = iIi1Ii1i1iI [ 0 ] if ( len ( iIi1Ii1i1iI ) > 0 ) else 'None'
 IioO0oOOO0Ooo = IIiI1 [ 0 ] if ( len ( IIiI1 ) > 0 ) else 'None'
 i1i1I = i1iI1 [ 0 ] if ( len ( i1iI1 ) > 0 ) else 'None'
 IiIIi1iII11I1Ii1 = ii1 [ 0 ] if ( len ( ii1 ) > 0 ) else 'None'
 o0o0 = I1IiiI1ii1i [ 0 ] if ( len ( I1IiiI1ii1i ) > 0 ) else 'None'
 oOo0oO = O0o [ 0 ] if ( len ( O0o ) > 0 ) else 'None'
 IIi1IIIIi = oO0OoO00o [ 0 ] if ( len ( oO0OoO00o ) > 0 ) else 'None'
 OOOoO = II1iiiiII [ 0 ] if ( len ( II1iiiiII ) > 0 ) else 'None'
 I1i = O0OoOO0oo0 [ 0 ] if ( len ( O0OoOO0oo0 ) > 0 ) else 'None'
 iiiI = oOO [ 0 ] if ( len ( oOO ) > 0 ) else 'None'
 IiIi1 = O0o0OO0000ooo [ 0 ] if ( len ( O0o0OO0000ooo ) > 0 ) else 'None'
 i111iiI1ii = iIIII1iIIii [ 0 ] if ( len ( iIIII1iIIii ) > 0 ) else 'None'
 IIiii = oOOO00o000o [ 0 ] if ( len ( oOOO00o000o ) > 0 ) else 'None'
 I1i1i = iIi11i1 [ 0 ] if ( len ( iIi11i1 ) > 0 ) else 'None'
 OOOOooO0oO00O0o = oO00oo0o00o0o [ 0 ] if ( len ( oO00oo0o00o0o ) > 0 ) else 'None'
 ooOO00oOOo000 = IiIIIIIi [ 0 ] if ( len ( IiIIIIIi ) > 0 ) else 'None'
 IIi = IiIi1iIIi1 [ 0 ] if ( len ( IiIi1iIIi1 ) > 0 ) else 'None'
 i11II11II1 = O0OoO0ooOO0o [ 0 ] if ( len ( O0OoO0ooOO0o ) > 0 ) else 'None'
 II1I = OoOo0oOooOoOO [ 0 ] if ( len ( OoOo0oOooOoOO ) > 0 ) else 'None'
 OoOo000oOo0oo = oo00ooOoO00 [ 0 ] if ( len ( oo00ooOoO00 ) > 0 ) else 'None'
 oO0O = o00oOoOo0 [ 0 ] if ( len ( o00oOoOo0 ) > 0 ) else 'None'
 if 86 - 86: O00OOOoOoo0O . iIii1I11I1II1 - ii1ii11IIIiiI
 print "### Addon Details: " + i1iIIIi1i
 if 56 - 56: O0
 if i11111I1I != '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=red]This add-on is depreciated, it\'s no longer available.[/COLOR]'
  if 37 - 37: i1IIi
 elif ii1ii111 == '' and Oo00OoOo == '' and IiI11i1IIiiI == '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=lime]No reported problems[/COLOR]'
  if 46 - 46: O00OOOoOoo0O - o00O0OoO - iI1IiiIIIiIi . i1IIi
 elif ii1ii111 == '' and Oo00OoOo == '' and IiI11i1IIiiI != '' and i11111I1I == '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=orange]Although there have been no reported problems there may be issues with this add-on, see below.[/COLOR]'
  if 35 - 35: oO0OooOoO * o00O0OoO - OoooooooOO . o00O0OoO . o00O0OoO
 elif ii1ii111 == '' and Oo00OoOo != '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by the add-on developer.[CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + Oo00OoOo
  if 11 - 11: Iiii1i1 / O00OOOoOoo0O + o00O0OoO % iIii1I11I1II1
 elif ii1ii111 != '' and Oo00OoOo == '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]User Comments: [/COLOR]' + ii1ii111
  if 42 - 42: OoooO0Oo0O0 * O00OOOoOoo0O % o0oOo0 - O00OOOoOoo0O . i11iIiiIii - Iiii1i1
 elif ii1ii111 != '' and Oo00OoOo != '' :
  OOo00 = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by both the add-on developer and a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + Oo00OoOo + '[CR][COLOR=dodgerblue]User Comments: [/COLOR]' + ii1ii111
  if 84 - 84: Iiii1i1 - OoooO0Oo0O0 / o00O0OoO
  if 13 - 13: i11111IIIII - II11iIiIIIiI - o0oOo0
 O00Oo = str ( '[COLOR=orange]Name: [/COLOR]' + i1iIIIi1i + '[COLOR=orange]     Author(s): [/COLOR]' + ooOO0oO0oo00o + '[COLOR=orange][CR][CR]Version: [/COLOR]' + oOOo0oo0O + '[COLOR=orange]     Created: [/COLOR]' + IiiIiI1Ii1i + '[COLOR=orange]     Updated: [/COLOR]' + iiiii1II + '[COLOR=orange][CR][CR]Repository: [/COLOR]' + i1oO0OO0 + o0O0Oo00 + '[COLOR=orange]     Add-on Type(s): [/COLOR]' + i1iIi + OOoO00 + OOo00 + i11111I1I + IiI11i1IIiiI + iIiiiii1i + II11iI111i1 + ii1Oo0000oOo )
 if 42 - 42: oO0OooOoO % i11111IIIII % Iiii1i1 % i1IIi - III1IiiI
 if 30 - 30: o0oOo0 % o0oOo0 - oOO00Oo
 if os . path . exists ( os . path . join ( II11iiii1Ii , i11i1iiiII ) ) :
  if 'script.module' in i11i1iiiII or 'repo' in i11i1iiiII :
   oO00oOOoooO ( '' , '[COLOR=orange]Already installed[/COLOR]' , '' , '' , I1iii , '' , '' , '' )
  else :
   oO00oOOoooO ( '' , '[COLOR=orange]Already installed -[/COLOR] Click here to run the add-on' , i11i1iiiII , 'run_addon' , I1iii , '' , '' , '' )
   if 70 - 70: II11iIiIIIiI . O00OOOoOoo0O
   if 58 - 58: o00O0OoO + oO0OooOoO * i1Iii1i1I * i11iIiiIii - iIii1I11I1II1
 if i1iIIIi1i == '' :
  oO00oOOoooO ( '' , '[COLOR=yellow]Sorry request failed due to high traffic on server, please try again[/COLOR]' , '' , '' , I1iii , '' , '' , '' )
  if 68 - 68: OoooooooOO % oO0OooOoO
  if 26 - 26: oO0OooOoO % i11iIiiIii % iIii1I11I1II1 % o00O0OoO * o00O0OoO * OoooO0Oo0O0
 elif i1iIIIi1i != '' :
  if 24 - 24: oO0OooOoO % Iiii1i1 - o0oOo0 + o0Oo * OoooO0Oo0O0
  if ( ii1ii111 == '' ) and ( Oo00OoOo == '' ) and ( i11111I1I == '' ) and ( IiI11i1IIiiI == '' ) :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR] No problems reported' , O00Oo , 'text_guide' , I1iii , '' , '' , O00Oo )
   if 2 - 2: iI1IiiIIIiIi - i11111IIIII
  if ( ii1ii111 != '' and i11111I1I == '' ) or ( Oo00OoOo != '' and i11111I1I == '' ) or ( IiI11i1IIiiI != '' and i11111I1I == '' ) :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=orange] Possbile problems reported[/COLOR]' , O00Oo , 'text_guide' , I1iii , '' , '' , O00Oo )
   if 83 - 83: III1IiiI % oOO00Oo % iI1IiiIIIiIi - oO0OooOoO * iiIi1i11 / OoooooooOO
  if i11111I1I != '' :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=red] Add-on now depreciated[/COLOR]' , O00Oo , 'text_guide' , I1iii , '' , '' , O00Oo )
   if 18 - 18: ii1ii11IIIiiI + iIii1I11I1II1 - oO0OooOoO - o0Oo
   if 71 - 71: OoooooooOO
  if i11111I1I == '' :
   if 33 - 33: Iiii1i1
   if i1oO0OO0 != '' and 'superrepo' not in i1oO0OO0 :
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL - Recommended] [/COLOR]' + i1iIIIi1i , i1iIIIi1i , '' , 'addon_install_zero' , I1iii , '' , '' , II11iI111i1 , ooo0O , OO0ooo0o0O0Oooooo , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iiIi1IIiI , i11IIIiI1I )
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL - Backup Option] [/COLOR]' + i1iIIIi1i , i1iIIIi1i , '' , 'addon_install' , I1iii , '' , '' , II11iI111i1 , o0iiiI1I1iIIIi1 , OO0ooo0o0O0Oooooo , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iiIi1IIiI , i11IIIiI1I )
    if 62 - 62: OoooO0Oo0O0 + iI1IiiIIIiIi + i1IIi / OoooooooOO
   if i1oO0OO0 == '' or 'superrepo' in i1oO0OO0 :
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL] [/COLOR]' + i1iIIIi1i + ' - THIS IS NOT IN A SELF UPDATING REPO' , i1iIIIi1i , '' , 'addon_install' , '' , '' , '' , II11iI111i1 , o0iiiI1I1iIIIi1 , OO0ooo0o0O0Oooooo , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iiIi1IIiI , i11IIIiI1I )
    if 7 - 7: oOO00Oo + i1IIi . o0Oo / II11iIiIIIiI
    if 22 - 22: o0oOo0 - o0oOo0 % iiIi1i11 . Iiii1i1 + III1IiiI
  if oO0o0O0Ooo0o != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  Preview' , IioO0oOOO0Ooo , 'play_video' , '' , '' , '' , '' )
   if 63 - 63: o0Oo % Iiii1i1 * oOO00Oo + Iiii1i1 / II11iIiIIIiI % i1Iii1i1I
  if IioO0oOOO0Ooo != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i111iiI1ii , IioO0oOOO0Ooo , 'play_video' , '' , '' , '' , '' )
   if 45 - 45: i11111IIIII
  if i1i1I != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IIiii , i1i1I , 'play_video' , '' , '' , '' , '' )
   if 20 - 20: OoooooooOO * oOO00Oo * O0 . iiIi1i11
  if IiIIi1iII11I1Ii1 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + I1i1i , IiIIi1iII11I1Ii1 , 'play_video' , '' , '' , '' , '' )
   if 78 - 78: iIii1I11I1II1 + o00O0OoO - iI1IiiIIIiIi * Iiii1i1 - OoooooooOO % O00OOOoOoo0O
  if o0o0 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OOOOooO0oO00O0o , o0o0 , 'play_video' , '' , '' , '' , '' )
   if 34 - 34: O0
  if oOo0oO != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + ooOO00oOOo000 , oOo0oO , 'play_video' , '' , '' , '' , '' )
   if 80 - 80: i1IIi - II11iIiIIIiI / ii1ii11IIIiiI - i11iIiiIii
  if IIi1IIIIi != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IIi , IIi1IIIIi , 'play_video' , '' , '' , '' , '' )
   if 68 - 68: III1IiiI - OoooO0Oo0O0 % O0 % Iiii1i1
  if OOOoO != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i11II11II1 , OOOoO , 'play_video' , '' , '' , '' , '' )
   if 11 - 11: O0 / ii1ii11IIIiiI % iiIi1i11 + oOO00Oo + iIii1I11I1II1
  if I1i != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + II1I , I1i , 'play_video' , '' , '' , '' , '' )
   if 40 - 40: o0oOo0 - iiIi1i11 . iI1IiiIIIiIi * II11iIiIIIiI % Iiii1i1
  if iiiI != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OoOo000oOo0oo , iiiI , 'play_video' , '' , '' , '' , '' )
   if 56 - 56: i11iIiiIii . oOO00Oo - o0Oo * o00O0OoO
  if IiIi1 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oO0O , IiIi1 , 'play_video' , '' , '' , '' , '' )
   if 91 - 91: III1IiiI + OoooooooOO - i1IIi
   if 84 - 84: iI1IiiIIIiIi / i11111IIIII
def OOOooo0OooOoO ( url ) :
 oO00oOOoooO ( 'folder' , 'Anime' , url + '&genre=anime' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audiobooks' , url + '&genre=audiobooks' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comedy' , url + '&genre=comedy' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comics' , url + '&genre=comics' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Documentary' , url + '&genre=documentary' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Downloads' , url + '&genre=downloads' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Food' , url + '&genre=food' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Gaming' , url + '&genre=gaming' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Health' , url + '&genre=health' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'How To...' , url + '&genre=howto' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Kids' , url + '&genre=kids' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Live TV' , url + '&genre=livetv' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Movies' , url + '&genre=movies' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Music' , url + '&genre=music' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'News' , url + '&genre=news' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Photos' , url + '&genre=photos' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Podcasts' , url + '&genre=podcasts' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Radio' , url + '&genre=radio' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Religion' , url + '&genre=religion' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Space' , url + '&genre=space' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Sports' , url + '&genre=sports' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Subscription' , url + '&genre=subscription' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Technology' , url + '&genre=tech' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Trailers' , url + '&genre=trailers' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'TV Shows' , url + '&genre=tv' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Misc.' , url + '&genre=other' , 'grab_addons' , '' , '' , '' , '' )
 if 91 - 91: III1IiiI + o0Oo
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  oO00oOOoooO ( 'folder' , 'XXX' , url + '&genre=adult' , 'grab_addons' , '' , '' , '' , '' )
  if 59 - 59: o0Oo + i11iIiiIii + i1IIi / o00O0OoO
  if 44 - 44: o00O0OoO . O00OOOoOoo0O * o0Oo + OoooooooOO - i1Iii1i1I - i11111IIIII
def I1iiioOO0OO0O ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 forum = str ( forum )
 repo_id = str ( repo_id )
 o00o = 1
 III11I = 1
 Ii1I11I = 1
 iiIii1I = xbmc . translatePath ( os . path . join ( II11iiii1Ii , addon_id ) )
 if 47 - 47: o0oOo0 . o00O0OoO / oOO00Oo
 if os . path . exists ( iiIii1I ) :
  OOoOO = 1
  if 66 - 66: II11iIiIIIiI - oOO00Oo * i11111IIIII + O00OOOoOoo0O + oOO00Oo - iIii1I11I1II1
 else :
  OOoOO = 0
  if 17 - 17: III1IiiI
 i1ii11 = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , name + '.zip' ) )
 ii1i = xbmc . translatePath ( os . path . join ( II11iiii1Ii , addon_id ) )
 if 5 - 5: III1IiiI . OoooO0Oo0O0 . oO0OooOoO . OoooooooOO
 OOooO0OOoo . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 if 96 - 96: i11iIiiIii - iiIi1i11 % O0 / ii1ii11IIIiiI
 try :
  downloader . download ( repo_link , i1ii11 , OOooO0OOoo )
  extract . all ( i1ii11 , II11iiii1Ii , OOooO0OOoo )
  if 100 - 100: i1Iii1i1I / iI1IiiIIIiIi - OoooooooOO % oO0OooOoO - o0Oo % O00OOOoOoo0O
 except :
  if 60 - 60: iIii1I11I1II1 + i1IIi
  try :
   downloader . download ( zip_link , i1ii11 , OOooO0OOoo )
   extract . all ( i1ii11 , II11iiii1Ii , OOooO0OOoo )
   if 86 - 86: iIii1I11I1II1 + O00OOOoOoo0O . i11iIiiIii - iI1IiiIIIiIi
  except :
   if 51 - 51: O00OOOoOoo0O
   try :
    if not os . path . exists ( ii1i ) :
     os . makedirs ( ii1i )
     if 14 - 14: i11111IIIII % III1IiiI % II11iIiIIIiI - i11iIiiIii
    IiIi1I1 = IiIIi1 ( data_path , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    o0OO000ooOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IiIi1I1 )
    if 86 - 86: ii1ii11IIIiiI * OoooooooOO
    for OooO0oOo in o0OO000ooOo :
     oOOo00O0OOOo = xbmc . translatePath ( os . path . join ( ii1i , OooO0oOo ) )
     if 31 - 31: o00O0OoO % iiIi1i11 * o00O0OoO
     if addon_id not in OooO0oOo and '/' not in OooO0oOo :
      if 45 - 45: i1IIi . o0Oo + iiIi1i11 - OoooooooOO % o0oOo0
      try :
       OOooO0OOoo . update ( 0 , "Downloading [COLOR=yellow]" + OooO0oOo + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( data_path + OooO0oOo , oOOo00O0OOOo , OOooO0OOoo )
       if 1 - 1: iIii1I11I1II1
      except :
       print "failed to install" + OooO0oOo
       if 93 - 93: i1IIi . i11iIiiIii . II11iIiIIIiI
     if '/' in OooO0oOo and '..' not in OooO0oOo and 'http' not in OooO0oOo :
      O0O00OOo = data_path + OooO0oOo
      OoOOo ( oOOo00O0OOOo , O0O00OOo )
      if 17 - 17: i1IIi
   except :
    iI111I11I1I1 . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=yellow]' + name , '[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    o00o = 0
    if 1 - 1: o0oOo0
 if o00o == 1 :
  time . sleep ( 1 )
  OOooO0OOoo . update ( 0 , "[COLOR=yellow]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  oOO0oo = xbmc . translatePath ( os . path . join ( II11iiii1Ii , repo_id ) )
  if 29 - 29: o0Oo * oO0OooOoO * OoooooooOO - OoooO0Oo0O0 * oO0OooOoO
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( oOO0oo ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   iiO00O00O000OOO ( repo_id )
   if 3 - 3: O0
  xbmc . sleep ( 2000 )
  if 64 - 64: i1IIi % o0oOo0 / i11iIiiIii - i1IIi % iiIi1i11 . i1Iii1i1I
  if os . path . exists ( iiIii1I ) and OOoOO == 0 :
   II1i111 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    IiIIi1 ( II1i111 )
   except :
    pass
    if 50 - 50: i11111IIIII % i1IIi
  iii11II1I ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 5 - 5: O00OOOoOoo0O - i11111IIIII * i11111IIIII
  if III11I == 0 :
   iI111I11I1I1 . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
   if 50 - 50: oO0OooOoO * OoooO0Oo0O0 / iI1IiiIIIiIi . oOO00Oo + II11iIiIIIiI - iiIi1i11
  if Ii1I11I == 0 :
   iI111I11I1I1 . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
   if 18 - 18: O00OOOoOoo0O % i11iIiiIii % OoooO0Oo0O0 / III1IiiI / oOO00Oo / i1IIi
  if Ii1I11I != 0 and III11I != 0 and forum != 'None' :
   iI111I11I1I1 . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=yellow]' + forum , '[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.' )
   if 48 - 48: O00OOOoOoo0O + o00O0OoO / i11111IIIII + oO0OooOoO
  if Ii1I11I != 0 and III11I != 0 and forum == 'None' :
   iI111I11I1I1 . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given.' )
   if 18 - 18: OoooO0Oo0O0
   if 23 - 23: oO0OooOoO
   if 24 - 24: iIii1I11I1II1 + iIii1I11I1II1 * i1Iii1i1I
def i1I11iIII1i1I ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 iiIii1I = xbmc . translatePath ( os . path . join ( II11iiii1Ii , addon_id ) )
 forum = str ( forum )
 if 63 - 63: II11iIiIIIiI + Iiii1i1 - oO0OooOoO
 if not os . path . exists ( iiIii1I ) :
  i1iIIi1I1I11 = 1
  if 39 - 39: iIii1I11I1II1 - OoooooooOO
 else :
  i1iIIi1I1I11 = 0
  if 81 - 81: OoooO0Oo0O0 - O0 * OoooooooOO
 repo_id = str ( repo_id )
 oOO0oo = xbmc . translatePath ( os . path . join ( II11iiii1Ii , repo_id ) )
 if 23 - 23: oO0OooOoO / III1IiiI
 if os . path . exists ( iiIii1I ) :
  OOoOO = 1
  iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 17 - 17: O0
  if iII1Iii1I11i == 1 :
   OO ( iiIii1I )
   i1iIIi1I1I11 = 1
 else :
  OOoOO = 0
  if 77 - 77: oO0OooOoO
 IiiiIi1iI1iI = False
 if 98 - 98: ii1ii11IIIiiI / iiIi1i11 * OoooO0Oo0O0 / III1IiiI
 if i1iIIi1I1I11 == 1 :
  if 64 - 64: III1IiiI - o0Oo / i1Iii1i1I - ii1ii11IIIiiI
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( oOO0oo ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   IiiiIi1iI1iI = iiO00O00O000OOO ( repo_id )
   if 37 - 37: i11iIiiIii / i1Iii1i1I
   if 85 - 85: i11iIiiIii + Iiii1i1 * O00OOOoOoo0O
  if IiiiIi1iI1iI :
   if not os . path . exists ( iiIii1I ) :
    os . makedirs ( iiIii1I )
    if 1 - 1: i1IIi / II11iIiIIIiI . ii1ii11IIIiiI
   o0Oii1111i = os . path . join ( II11iiii1Ii , addon_id , 'addon.xml' )
   O0ooOO = os . path . join ( II11iiii1Ii , addon_id , 'default.py' )
   shutil . copyfile ( Oo00OOOOO , o0Oii1111i )
   if 28 - 28: i11iIiiIii / oOO00Oo . iIii1I11I1II1 / oO0OooOoO
   OoOO = open ( os . path . join ( o0Oii1111i ) , mode = 'r' )
   i11i = OoOO . read ( )
   OoOO . close ( )
   if 32 - 32: O00OOOoOoo0O * o0Oo % o0oOo0 * iI1IiiIIIiIi . O0
   if 48 - 48: i1Iii1i1I * i1Iii1i1I
   I1I1 = re . compile ( 'testid[\s\S]*?' ) . findall ( i11i )
   III1 = I1I1 [ 0 ] if ( len ( I1I1 ) > 0 ) else 'None'
   iI1I1iiIi1I = re . compile ( 'testname[\s\S]*?' ) . findall ( i11i )
   oOOoo0000O0o0 = iI1I1iiIi1I [ 0 ] if ( len ( iI1I1iiIi1I ) > 0 ) else 'None'
   I11i = re . compile ( 'testprovider[\s\S]*?' ) . findall ( i11i )
   Iiii1 = I11i [ 0 ] if ( len ( I11i ) > 0 ) else 'None'
   iIIIiiiI11I = re . compile ( 'testprovides[\s\S]*?' ) . findall ( i11i )
   I1ii1111Ii = iIIIiiiI11I [ 0 ] if ( len ( iIIIiiiI11I ) > 0 ) else 'None'
   iiI1IIIi = i11i . replace ( III1 , addon_id ) . replace ( oOOoo0000O0o0 , name ) . replace ( Iiii1 , provider_name ) . replace ( I1ii1111Ii , contenttypes )
   if 69 - 69: i11111IIIII . ii1ii11IIIiiI + oO0OooOoO
   o0oooOO00 = open ( o0Oii1111i , mode = 'w+' )
   o0oooOO00 . write ( str ( iiI1IIIi ) )
   o0oooOO00 . close ( )
   if 70 - 70: o0Oo / o00O0OoO
   IIiiiiIiIIii = open ( O0ooOO , mode = 'w' )
   IIiiiiIiIIii . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + addon_id + '"\nAddonName="' + name + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating. We recommend waiting but if you\'ve already tried that and it\'s not updating you can try re-installing via the CP backup method.",yeslabel="Install Option 2", nolabel="Wait...")\nif choice == 1: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.totalinstaller/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
   IIiiiiIiIIii . close ( )
   if 86 - 86: o00O0OoO / oOO00Oo - oOO00Oo + OoooO0Oo0O0 + III1IiiI
   xbmc . sleep ( 1000 )
   if 33 - 33: oOO00Oo . i1Iii1i1I . i11111IIIII . i1IIi
   if os . path . exists ( iiIii1I ) and OOoOO == 0 :
    II1i111 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
    try :
     IiIIi1 ( II1i111 , 5 )
    except :
     pass
     if 49 - 49: OoooO0Oo0O0
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   iI111I11I1I1 . ok ( name + " Install Complete" , '[COLOR=dodgerblue]' + name + '[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.' )
  else :
   iI111I11I1I1 . ok ( 'Failed Install' , 'The repository could not be installed, the developer may have deleted it. Please try the backup install option.' )
   if 84 - 84: o00O0OoO - II11iIiIIIiI / O0 - Iiii1i1
   if 21 - 21: O0 * O0 % OoooO0Oo0O0
def o00ooo ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 oOO0oo = xbmc . translatePath ( os . path . join ( II11iiii1Ii , repo_id ) )
 iiIii1I = xbmc . translatePath ( os . path . join ( II11iiii1Ii , addon_id ) )
 if 31 - 31: O0 * oOO00Oo % oOO00Oo / III1IiiI / o00O0OoO / ii1ii11IIIiiI
 if os . path . exists ( iiIii1I ) :
  if 11 - 11: O00OOOoOoo0O + i11111IIIII - OoooooooOO / ii1ii11IIIiiI
  iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 34 - 34: o0oOo0
  if iII1Iii1I11i == 1 :
   OO ( iiIii1I )
   if 45 - 45: o0oOo0 / II11iIiIIIiI / iI1IiiIIIiIi
 if os . path . exists ( oOO0oo ) :
  if 44 - 44: OoooO0Oo0O0 - iI1IiiIIIiIi / oO0OooOoO * ii1ii11IIIiiI * II11iIiIIIiI
  if os . path . exists ( iiIii1I ) :
   OOoOO = 1
   if 73 - 73: oOO00Oo - o0Oo * i1IIi / i11iIiiIii * iiIi1i11 % oO0OooOoO
  else :
   OOoOO = 0
   if 56 - 56: OoooooooOO * II11iIiIIIiI . II11iIiIIIiI . OoooO0Oo0O0
  iII1Iii1I11i = iI111I11I1I1 . yesno ( 'WARNING!' , '[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?' )
  if 24 - 24: II11iIiIIIiI . o00O0OoO * iI1IiiIIIiIi % i1Iii1i1I / iiIi1i11
  if iII1Iii1I11i == 1 :
   if 58 - 58: o0Oo - OoooO0Oo0O0 % O0 . o0Oo % ii1ii11IIIiiI % i11111IIIII
   if 'video' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.video/?",return)' )
    if 87 - 87: III1IiiI - i11iIiiIii
   elif 'executable' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.executable/?",return)' )
    if 78 - 78: i11iIiiIii / iIii1I11I1II1 - oOO00Oo
   elif 'audio' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.audio/?",return)' )
    if 23 - 23: o00O0OoO
  xbmc . sleep ( 2000 )
  if 40 - 40: oOO00Oo - oO0OooOoO / II11iIiIIIiI
  if os . path . exists ( iiIii1I ) and OOoOO == 0 :
   II1i111 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    IiIIi1 ( II1i111 , 5 )
   except :
    pass
    if 14 - 14: OoooO0Oo0O0
  xbmc . executebuiltin ( 'Container.Refresh' )
 else :
  iI111I11I1I1 . ok ( 'WARNING!' , '[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]' + repo_id + '[/COLOR]' )
  if 5 - 5: oOO00Oo . iIii1I11I1II1 % iIii1I11I1II1
  if 56 - 56: OoooooooOO - o00O0OoO - i1IIi
def I1i1I ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 iI111I11I1I1 . ok ( 'Add-on Not Approved' , 'Sorry there are no repository details for this add-on and it\'s been marked as potentially giving access to unlawful content. The most likely cause for this is the add-on has only been released via social media groups.' )
 if 35 - 35: i11iIiiIii - o0Oo
 if 99 - 99: ii1ii11IIIiiI * i11iIiiIii . OoooooooOO % II11iIiIIIiI
def Oo0Oo0oOooOoOo ( sign ) :
 if 49 - 49: iiIi1i11 . OoooO0Oo0O0 . i11iIiiIii - oO0OooOoO / iI1IiiIIIiIi
 if 62 - 62: iiIi1i11
 oO00oOOoooO ( 'folder' , '[COLOR=gold][Popular][/COLOR] Show the top 100 most downloaded add-ons' , 'popular' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=gold][Brand New][/COLOR] Show the new releases' , 'latest' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=gold][Manual Search][/COLOR] Type in author/name/content' , 'desc=' , 'search_addons' , '' , '' , '' , '' )
 if 1 - 1: i11111IIIII / i11111IIIII - i11iIiiIii
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Genres' , 'p' , 'addon_genres' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Countries' , 'p' , 'addon_countries' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Kodi Categories' , 'p' , 'addon_categories' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Install From Zip' , '' , 'install_from_zip' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Browse My Repositories' , '' , 'browse_repos' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Check For Add-on Updates' , '' , 'check_updates' , '' , '' , '' , '' )
 if 87 - 87: II11iIiIIIiI / O0 * i11111IIIII / oOO00Oo
 if 19 - 19: Iiii1i1 + i1IIi . o0Oo - II11iIiIIIiI
def iIi1I1 ( ) :
 for file in glob . glob ( os . path . join ( II11iiii1Ii , '*' ) ) :
  i1iIIIi1i = str ( file ) . replace ( II11iiii1Ii , '[COLOR=red]REMOVE [/COLOR]' ) . replace ( 'plugin.' , '[COLOR=dodgerblue](PLUGIN) [/COLOR]' ) . replace ( 'audio.' , '' ) . replace ( 'video.' , '' ) . replace ( 'skin.' , '[COLOR=yellow](SKIN) [/COLOR]' ) . replace ( 'repository.' , '[COLOR=orange](REPOSITORY) [/COLOR]' ) . replace ( 'script.' , '[COLOR=cyan](SCRIPT) [/COLOR]' ) . replace ( 'metadata.' , '[COLOR=orange](METADATA) [/COLOR]' ) . replace ( 'service.' , '[COLOR=pink](SERVICE) [/COLOR]' ) . replace ( 'weather.' , '[COLOR=green](WEATHER) [/COLOR]' ) . replace ( 'module.' , '[COLOR=orange](MODULE) [/COLOR]' )
  O0oOoo0OoO0O = ( os . path . join ( file , 'icon.png' ) )
  oo00IiI1 = ( os . path . join ( file , 'fanart.jpg' ) )
  oO00oOOoooO ( '' , i1iIIIi1i , file , 'remove_addons' , O0oOoo0OoO0O , oo00IiI1 , '' , '' )
  if 87 - 87: oOO00Oo % iIii1I11I1II1
  if 100 - 100: Iiii1i1 . o0Oo * Iiii1i1 - o0Oo . o00O0OoO * iI1IiiIIIiIi
def oO000o ( ) :
 i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 78 - 78: OoooooooOO
def OOoo0 ( ) :
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 oOOo0oo0O = float ( III1I1I [ : 4 ] )
 if oOOo0oo0O < 14 :
  i1i111i1 = os . path . join ( O0Oo000ooO00 , 'xbmc.log' )
 else :
  i1i111i1 = os . path . join ( O0Oo000ooO00 , 'kodi.log' )
  if 99 - 99: o0Oo + i1IIi + i11iIiiIii + II11iIiIIIiI % III1IiiI / o00O0OoO
 try :
  O0OO0o0OO0OO = open ( i1i111i1 , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
 except :
  try :
   O0OO0o0OO0OO = open ( os . path . join ( iIii1 , 'temp' , 'kodi.log' ) , mode = 'r' )
   i11i = O0OO0o0OO0OO . read ( )
   O0OO0o0OO0OO . close ( )
  except :
   try :
    O0OO0o0OO0OO = open ( os . path . join ( iIii1 , 'temp' , 'xbmc.log' ) , mode = 'r' )
    i11i = O0OO0o0OO0OO . read ( )
    O0OO0o0OO0OO . close ( )
   except :
    pass
    if 64 - 64: oO0OooOoO
 iIIIiIi1I1i = re . compile ( 'External storage path = (.+?);' ) . findall ( i11i )
 OoOOoO0oOo = iIIIiIi1I1i [ 0 ] if ( len ( iIIIiIi1I1i ) > 0 ) else ''
 return OoOOoO0oOo
 if 70 - 70: o00O0OoO % iIii1I11I1II1 . II11iIiIIIiI + II11iIiIIIiI - oOO00Oo % Iiii1i1
 if 38 - 38: Iiii1i1 % iiIi1i11 - OoooooooOO
def oOo0OOoooO ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 iIi1iIIIiIiI = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 OooOo000o0o = len ( sourcefile )
 iI1I1iII1i = [ ]
 iiIIii = [ ]
 if 70 - 70: oOO00Oo - iiIi1i11
 OOooO0OOoo . create ( message_header , message1 , message2 , message3 )
 if 62 - 62: o00O0OoO
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 34 - 34: i11iIiiIii - oO0OooOoO / o0Oo % oOO00Oo
  for file in I1iiIi111I :
   iiIIii . append ( file )
   if 33 - 33: iiIi1i11
 IiiiI111I = len ( iiIIii )
 if 49 - 49: oOO00Oo * iI1IiiIIIiIi + o00O0OoO + i1Iii1i1I
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 30 - 30: oOO00Oo / iiIi1i11 / i11111IIIII % o0oOo0 + oO0OooOoO
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in exclude_dirs ]
  I1iiIi111I [ : ] = [ iiI1iii for iiI1iii in I1iiIi111I if iiI1iii not in exclude_files and not 'crashlog' in iiI1iii and not 'stacktrace' in iiI1iii ]
  if 79 - 79: ii1ii11IIIiiI * O00OOOoOoo0O . OoooooooOO - o00O0OoO * oOO00Oo
  for file in I1iiIi111I :
   if 78 - 78: i11111IIIII
   try :
    iI1I1iII1i . append ( file )
    Oo0O0Oo00O = len ( iI1I1iII1i ) / float ( IiiiI111I ) * 100
    OOooO0OOoo . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % I1III111i , 'Please Wait' )
    iI = os . path . join ( O000oOo , file )
    if 66 - 66: o0Oo - i11111IIIII
   except :
    print "Unable to backup file: " + file
    if 33 - 33: o0Oo / ii1ii11IIIiiI
   if not 'temp' in OoOOOO :
    if 12 - 12: oO0OooOoO
    if not o0OO00 in OoOOOO :
     if 2 - 2: i1IIi - o0Oo + o00O0OoO . oO0OooOoO
     try :
      iIIiI1iiI = '01/01/1980'
      I11Ii111I = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iI ) ) )
      if 98 - 98: iIii1I11I1II1 + Iiii1i1 % O00OOOoOoo0O + o00O0OoO % O00OOOoOoo0O
      if I11Ii111I > iIIiI1iiI :
       iIi1iIIIiIiI . write ( iI , iI [ OooOo000o0o : ] )
       if 24 - 24: III1IiiI * Iiii1i1
     except :
      print "Unable to backup file: " + file
      if 40 - 40: iI1IiiIIIiIi - O00OOOoOoo0O * O00OOOoOoo0O . O00OOOoOoo0O + OoooooooOO
 iIi1iIIIiIiI . close ( )
 OOooO0OOoo . close ( )
 if 77 - 77: iIii1I11I1II1 . iI1IiiIIIiIi % III1IiiI / iI1IiiIIIiIi
 if 54 - 54: III1IiiI + o0oOo0 - II11iIiIIIiI
def I1I1IiIi1 ( sourcefile , destfile ) :
 iIi1iIIIiIiI = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 OooOo000o0o = len ( sourcefile )
 iI1I1iII1i = [ ]
 iiIIii = [ ]
 if 58 - 58: O00OOOoOoo0O - i1Iii1i1I - OoooooooOO
 OOooO0OOoo . create ( "Backing Up Files" , "Archiving..." , '' , 'Please Wait' )
 if 96 - 96: iIii1I11I1II1
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 82 - 82: O00OOOoOoo0O + O0 - i11111IIIII % III1IiiI * i11iIiiIii
  for file in I1iiIi111I :
   iiIIii . append ( file )
   if 15 - 15: oOO00Oo
 IiiiI111I = len ( iiIIii )
 if 39 - 39: iiIi1i11 / OoooO0Oo0O0 / o0Oo * Iiii1i1
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 44 - 44: O0 + o0oOo0 . iIii1I11I1II1 + II11iIiIIIiI / O0 - o00O0OoO
  for file in I1iiIi111I :
   iI1I1iII1i . append ( file )
   Oo0O0Oo00O = len ( iI1I1iII1i ) / float ( IiiiI111I ) * 100
   OOooO0OOoo . update ( int ( Oo0O0Oo00O ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   iI = os . path . join ( O000oOo , file )
   if 83 - 83: i11111IIIII * o00O0OoO / II11iIiIIIiI
   if not 'temp' in OoOOOO :
    if 32 - 32: oOO00Oo + O00OOOoOoo0O - OoooooooOO
    if not o0OO00 in OoOOOO :
     if 39 - 39: OoooooooOO * iiIi1i11 * O0 . o00O0OoO . ii1ii11IIIiiI + o0oOo0
     import time
     iIIiI1iiI = '01/01/1980'
     I11Ii111I = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iI ) ) )
     if 9 - 9: O00OOOoOoo0O + III1IiiI % OoooooooOO + oOO00Oo
     if I11Ii111I > iIIiI1iiI :
      iIi1iIIIiIiI . write ( iI , iI [ OooOo000o0o : ] )
 iIi1iIIIiIiI . close ( )
 OOooO0OOoo . close ( )
 if 56 - 56: OoooooooOO + OoooO0Oo0O0 - i1Iii1i1I
 if 24 - 24: oOO00Oo + o0oOo0 + o00O0OoO - iIii1I11I1II1
def I11Oo0oO00 ( ) :
 IiiI1III1I1 = iI111I11I1I1 . browse ( 3 , 'Select the folder you want to scan' , 'files' , '' , False , False )
 OooOo000o0o = len ( IiiI1III1I1 )
 iI1I1iII1i = [ ]
 iiIIii = [ ]
 if 80 - 80: Iiii1i1 . o00O0OoO
 OOooO0OOoo . create ( 'Checking File Structure' , '' , 'Please wait...' , '' )
 if 73 - 73: O00OOOoOoo0O . O0 / i1Iii1i1I * III1IiiI
 iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Delete or Scan?' , 'Do you want to delete all filenames with special characters or would you rather just scan and view the results in the log?' , yeslabel = 'Delete' , nolabel = 'Scan' )
 if 29 - 29: oOO00Oo
 oo0 = open ( O00oO , mode = 'w+' )
 iIiI = open ( I11i1I1I , mode = 'w+' )
 if 81 - 81: O00OOOoOoo0O % iI1IiiIIIiIi
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( IiiI1III1I1 ) :
  if 87 - 87: iIii1I11I1II1 . OoooooooOO * O00OOOoOoo0O
  for file in I1iiIi111I :
   iiIIii . append ( file )
   if 100 - 100: ii1ii11IIIiiI / i1IIi - o0Oo % iI1IiiIIIiIi - iIii1I11I1II1
 IiiiI111I = len ( iiIIii )
 if 17 - 17: o00O0OoO / oOO00Oo % II11iIiIIIiI
 for O000oOo , OoOOOO , I1iiIi111I in os . walk ( IiiI1III1I1 ) :
  if 71 - 71: i11111IIIII . Iiii1i1 . ii1ii11IIIiiI
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO ]
  I1iiIi111I [ : ] = [ iiI1iii for iiI1iii in I1iiIi111I ]
  if 68 - 68: i11iIiiIii % III1IiiI * ii1ii11IIIiiI * i11111IIIII * oO0OooOoO + O0
  for file in I1iiIi111I :
   if 66 - 66: o00O0OoO % OoooO0Oo0O0 % OoooooooOO
   iI1I1iII1i . append ( file )
   Oo0O0Oo00O = len ( iI1I1iII1i ) / float ( IiiiI111I ) * 100
   OOooO0OOoo . update ( 0 , "Checking for non ASCII files" , '[COLOR yellow]%s[/COLOR]' % I1III111i , 'Please Wait' )
   if 34 - 34: oOO00Oo / i1Iii1i1I % O0 . ii1ii11IIIiiI . i1IIi
   try :
    file . encode ( 'ascii' )
    if 29 - 29: O0 . Iiii1i1
   except UnicodeDecodeError :
    OO0o0oO0O000o = ( str ( O000oOo ) + '/' + str ( file ) ) . replace ( '\\' , '/' ) . replace ( ':/' , ':\\' )
    if 47 - 47: Iiii1i1 - ii1ii11IIIiiI / iI1IiiIIIiIi * OoooooooOO / iI1IiiIIIiIi . II11iIiIIIiI
    print " non-ASCII file status logged successfully: " + OO0o0oO0O000o
    if iII1Iii1I11i != 1 :
     oo0 . write ( '[COLOR=dodgerblue]Non-ASCII File:[/COLOR]\n' )
     for iiII1IiIi1iI1 in oOiiI1Ii11II1I ( OO0o0oO0O000o , 75 ) :
      oo0 . write ( iiII1IiIi1iI1 + '[CR]' )
     oo0 . write ( '\n' )
    if iII1Iii1I11i == 1 :
     try :
      os . remove ( OO0o0oO0O000o )
      print "### SUCCESS - deleted " + OO0o0oO0O000o
      oo0 . write ( '[COLOR=dodgerblue]SUCCESSFULLY DELETED:[/COLOR]\n' )
      for iiII1IiIi1iI1 in oOiiI1Ii11II1I ( OO0o0oO0O000o , 75 ) :
       oo0 . write ( iiII1IiIi1iI1 + '[CR]' )
      oo0 . write ( '\n' )
      if 44 - 44: iI1IiiIIIiIi % i11iIiiIii - i1Iii1i1I * OoooO0Oo0O0 + II11iIiIIIiI * iiIi1i11
     except :
      print "######## FAILED TO REMOVE: " + OO0o0oO0O000o
      print "######## Make sure you manually remove this file ##########"
      iIiI . write ( '[COLOR=red]FAILED TO DELETE:[/COLOR]\n' )
      for iiII1IiIi1iI1 in oOiiI1Ii11II1I ( OO0o0oO0O000o , 75 ) :
       iIiI . write ( iiII1IiIi1iI1 + '[CR]' )
      iIiI . write ( '\n' )
      if 41 - 41: O0 * o0oOo0 - O00OOOoOoo0O . iI1IiiIIIiIi
 iIiI . close ( )
 oo0 . close ( )
 if 65 - 65: II11iIiIIIiI . OoooooooOO
 if 70 - 70: II11iIiIIIiI - III1IiiI . iIii1I11I1II1 % o00O0OoO / O00OOOoOoo0O - O0
 oo0 = open ( O00oO , mode = 'r' )
 o0O0oo0o = oo0 . read ( )
 oo0 . close ( )
 iIiI = open ( I11i1I1I , mode = 'r' )
 II11iI1iiI = iIiI . read ( )
 iIiI . close ( )
 if o0O0oo0o == '' and II11iI1iiI == '' :
  iI111I11I1I1 . ok ( 'No Special Characters Found' , 'Great news, all filenames in the path you scanned are ASCII based - no special characters found.' )
 else :
  I1ii = open ( o0O , mode = 'w+' )
  I1ii . write ( o0O0oo0o + '\n\n' + II11iI1iiI )
  I1ii . close ( )
  oO0o = open ( o0O , mode = 'r' )
  I1I1O0Oo0 = oO0o . read ( )
  oO0o . close ( )
  OOooO0OO0 ( 'Final Results' , I1I1O0Oo0 )
  os . remove ( o0O )
 os . remove ( O00oO )
 os . remove ( I11i1I1I )
 if 5 - 5: i1Iii1i1I
 if 62 - 62: O00OOOoOoo0O . OoooooooOO . iiIi1i11 . ii1ii11IIIiiI * i1Iii1i1I
def OOOOOo ( ) :
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] How to create and share my build' , '' , 'instructions_1' , '' , '' , '' , 'Back Up Your Full System' )
 oO00oOOoooO ( '' , '[COLOR=gold]-----------------------------------------------------------------[/COLOR]' , '' , '' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Community Build (for sharing on CP)' , 'url' , 'community_backup' , '' , '' , '' , 'Back Up Your Full System' )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , 'Create OpenELEC Backup (full backup can only be used on OpenELEC)' , 'none' , 'openelec_backup' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create Universal Build (local backups only)' , 'none' , 'community_backup_2' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create Full Backup (will only work on THIS device)' , 'local' , 'local_backup' , '' , '' , '' , 'Back Up Your Full System' )
 oO00oOOoooO ( '' , 'Backup Addons Only' , 'addons' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addons' )
 oO00oOOoooO ( '' , 'Backup Addon Data Only' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addon Userdata' )
 oO00oOOoooO ( '' , 'Backup Guisettings.xml' , I11i1 , 'restore_backup' , '' , '' , '' , 'Back Up Your guisettings.xml' )
 if 77 - 77: iI1IiiIIIiIi / oO0OooOoO - iI1IiiIIIiIi / iiIi1i11
 if os . path . exists ( IIIII ) :
  oO00oOOoooO ( '' , 'Backup Favourites.xml' , IIIII , 'restore_backup' , '' , '' , '' , 'Back Up Your favourites.xml' )
  if 97 - 97: iiIi1i11 / III1IiiI . oO0OooOoO
 if os . path . exists ( ooooooO0oo ) :
  oO00oOOoooO ( '' , 'Backup Source.xml' , ooooooO0oo , 'restore_backup' , '' , '' , '' , 'Back Up Your sources.xml' )
  if 44 - 44: iI1IiiIIIiIi % o00O0OoO . Iiii1i1
 if os . path . exists ( IIiiiiiiIi1I1 ) :
  oO00oOOoooO ( '' , 'Backup Advancedsettings.xml' , IIiiiiiiIi1I1 , 'restore_backup' , '' , '' , '' , 'Back Up Your advancedsettings.xml' )
  if 18 - 18: iIii1I11I1II1 + o00O0OoO * o0Oo - iiIi1i11 / o0Oo
 if os . path . exists ( OOOO ) :
  oO00oOOoooO ( '' , 'Backup Advancedsettings.xml' , OOOO , 'restore_backup' , '' , '' , '' , 'Back Up Your keyboard.xml' )
  if 78 - 78: o00O0OoO . i11111IIIII
 if os . path . exists ( oOoOooOo0o0 ) :
  oO00oOOoooO ( '' , 'Backup RssFeeds.xml' , oOoOooOo0o0 , 'restore_backup' , '' , '' , '' , 'Back Up Your RssFeeds.xml' )
  if 38 - 38: O00OOOoOoo0O + i11111IIIII
  if 15 - 15: II11iIiIIIiI + o00O0OoO . o0oOo0 - iIii1I11I1II1 / O0 % iIii1I11I1II1
def oO0OOo00o0O0O ( ) :
 oO00oOOoooO ( 'folder' , 'Backup My Content' , 'none' , 'backup_option' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Restore My Content' , 'none' , 'restore_option' , '' , '' , '' , '' )
 if 84 - 84: o00O0OoO % i1IIi
 if 33 - 33: OoooO0Oo0O0 * OoooO0Oo0O0 . o0oOo0 . i11iIiiIii
def IIIIiIi11iiIi ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://repos/",return)' )
 if 48 - 48: i11111IIIII % o00O0OoO
def i1I1III1i1i ( name , script , arg ) :
 i1I11 = [ ]
 Ii111iIIIi = "XBMC.RunScript(" + str ( script ) + ", " + str ( arg ) + ")"
 i1I11 . append ( ( str ( name ) , Ii111iIIIi , ) )
 oo0ooO0O0o = xbmcgui . ListItem ( )
 oo0ooO0O0o . addContextMenuItems ( i1I11 )
 if 75 - 75: oO0OooOoO + iiIi1i11
 if 28 - 28: o0Oo
def I11o0000o0Oo ( localbuildcheck , localversioncheck , id , welcometext , livemsg ) :
 ooo0O0OOo0OoO ( )
 if livemsg != 'none' :
  try :
   exec menuitem
   oO00oOOoooO ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  except :
   pass
 if ( i1i1II . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) and i1i1II != '' :
  oO00oOOoooO ( '' , welcometext , 'show' , 'user_info' , '' , '' , '' , '' )
  if 45 - 45: O0 / i1IIi * III1IiiI * ii1ii11IIIiiI
  if id != 'None' :
   if 35 - 35: OoooO0Oo0O0 / i1Iii1i1I % o0Oo + iIii1I11I1II1
   if id != 'Local' :
    oO00o = i11I1IiiiiiiiIi ( localbuildcheck , localversioncheck , id )
    if 32 - 32: oOO00Oo + o0Oo . Iiii1i1
    if oO00o == True :
     if 41 - 41: O00OOOoOoo0O . i11iIiiIii / o00O0OoO
     if not 'Partially installed' in localbuildcheck :
      oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]' + localbuildcheck + ':[/COLOR] [COLOR=lime]NEW VERSION AVAILABLE[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
      if 98 - 98: O00OOOoOoo0O % oO0OooOoO
     if '(Partially installed)' in localbuildcheck :
      oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo2' , '' , '' , '' , '' )
    else :
     oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
     if 95 - 95: iIii1I11I1II1 - Iiii1i1 - iiIi1i11 + Iiii1i1 % OoooO0Oo0O0 . o0Oo
   else :
    if 41 - 41: O0 + III1IiiI . i1IIi - oO0OooOoO * oOO00Oo . ii1ii11IIIiiI
    if localbuildcheck == 'Incomplete' :
     oO00oOOoooO ( '' , '[COLOR=darkcyan]Your last restore is not yet completed[/COLOR]' , 'url' , oooO00Oo ( ) , '' , '' , '' , '' )
     if 86 - 86: oO0OooOoO + o0oOo0 + i11111IIIII
    else :
     oO00oOOoooO ( '' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]Local Build (' + localbuildcheck + ')[/COLOR]' , '' , '' , '' , '' , '' , '' )
  I11i11I = 0
  if 90 - 90: OoooO0Oo0O0
  if os . path . exists ( iiI1IiI ) :
   for i1iIIIi1i in os . listdir ( iiI1IiI ) :
    if i1iIIIi1i != 'Master' :
     I11i11I += 1
     if 9 - 9: i11111IIIII + o0oOo0
   if I11i11I > 1 :
    oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Switch Build Profile[/COLOR]' , localbuildcheck , 'switch_profile_menu' , '' , '' , '' , '' )
    if 7 - 7: O0 % Iiii1i1 + OoooO0Oo0O0 + iI1IiiIIIiIi % OoooooooOO . II11iIiIIIiI
  oO00oOOoooO ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 56 - 56: i1Iii1i1I
 elif o0oO0 == 'true' and not 'elc' in welcometext and i1i1II != '' :
  oO00oOOoooO ( '' , welcometext , 'None' , 'addon_settings' , '' , '' , '' , '' )
  if 84 - 84: O00OOOoOoo0O - i11iIiiIii
 else :
  oO00oOOoooO ( '' , welcometext , 'None' , 'register' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=yellow]Settings[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , '' )
 if 1 - 1: i1Iii1i1I * O00OOOoOoo0O
 oO00oOOoooO ( 'folder' , 'Install Content' , welcometext , 'install_content' , '' , '' , '' , '' )
 if 66 - 66: O00OOOoOoo0O + i1IIi % oO0OooOoO . O0 * OoooO0Oo0O0 % OoooO0Oo0O0
 if 87 - 87: iiIi1i11 + oOO00Oo . i1Iii1i1I - OoooooooOO
 if 6 - 6: iIii1I11I1II1 * OoooooooOO
 if 28 - 28: II11iIiIIIiI * oOO00Oo / Iiii1i1
 if 52 - 52: O0 / oOO00Oo % i1Iii1i1I * o0Oo % iiIi1i11
 if 69 - 69: OoooO0Oo0O0
 if 83 - 83: oOO00Oo
 if oOOoo00O0O == 'true' :
  oO00oOOoooO ( 'folder' , 'Tutorials' , '' , 'tutorial_root_menu' , '' , '' , '' , '' )
  if 38 - 38: Iiii1i1 + OoooooooOO . i1IIi
 if o0oOoO00o == 'true' :
  oO00oOOoooO ( 'folder' , 'Maintenance' , 'none' , 'tools' , '' , '' , '' , '' )
  if 19 - 19: i1Iii1i1I - oOO00Oo - iI1IiiIIIiIi - O00OOOoOoo0O . i1Iii1i1I . Iiii1i1
  if 48 - 48: i1Iii1i1I + i11111IIIII
def O0o0o0 ( ) :
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 15 - 15: iIii1I11I1II1 . O0
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 70 - 70: iI1IiiIIIiIi . i11iIiiIii % iI1IiiIIIiIi . O0 - iIii1I11I1II1
 i111i1iIi1 = O000OOo00oo ( )
 OoO0oO = IiIIi1 ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' , 10 )
 if 10 - 10: i1IIi . oO0OooOoO / oOO00Oo * o0oOo0
 OOooO0OOoo . create ( 'Backing Up Add-ons' , '' , 'Please Wait...' )
 if 10 - 10: o00O0OoO - II11iIiIIIiI
 for i1iIIIi1i in os . listdir ( II11iiii1Ii ) :
  if 59 - 59: OoooooooOO * II11iIiIIIiI + i1IIi
  if 23 - 23: o0oOo0
  if not 'totalinstaller' in i1iIIIi1i and not 'plugin.program.tbs' in i1iIIIi1i and not 'packages' in i1iIIIi1i and os . path . isdir ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) :
   if 13 - 13: iIii1I11I1II1
   if 77 - 77: i11iIiiIii - iIii1I11I1II1 / III1IiiI / o0oOo0 / ii1ii11IIIiiI
   if i1iIIIi1i in OoO0oO and not i1iIIIi1i in i111i1iIi1 and not 'repo.' in i1iIIIi1i and not 'repository.' in i1iIIIi1i and os . path . isdir ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) :
    if 56 - 56: OoooooooOO * O0
    if 85 - 85: OoooooooOO % O00OOOoOoo0O * iIii1I11I1II1
    if not 'service.xbmc.versioncheck' in i1iIIIi1i and not 'packages' in i1iIIIi1i and os . path . isdir ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) :
     if 44 - 44: iIii1I11I1II1 . OoooO0Oo0O0 + Iiii1i1 . o0oOo0
     try :
      OOooO0OOoo . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
      os . makedirs ( os . path . join ( i1Oo00 , i1iIIIi1i ) )
      if 7 - 7: OoooO0Oo0O0 + iIii1I11I1II1 * o00O0OoO * o00O0OoO / oO0OooOoO - iI1IiiIIIiIi
      o0Oii1111i = os . path . join ( i1Oo00 , i1iIIIi1i , 'addon.xml' )
      O0ooOO = os . path . join ( i1Oo00 , i1iIIIi1i , 'default.py' )
      OoOO = open ( os . path . join ( II11iiii1Ii , i1iIIIi1i , 'addon.xml' ) , mode = 'r' )
      i11i = OoOO . read ( )
      OoOO . close ( )
      if 65 - 65: III1IiiI + O00OOOoOoo0O + oO0OooOoO
      iI1I1iiIi1I = re . compile ( ' name="(.+?)"' ) . findall ( i11i )
      I11i = re . compile ( 'provider-name="(.+?)"' ) . findall ( i11i )
      oOOoo = re . compile ( '<addon[\s\S]*?">' ) . findall ( i11i )
      i1I1iIii11 = re . compile ( '<description[\s\S]*?<\/description>' ) . findall ( i11i )
      oOOoo0000O0o0 = iI1I1iiIi1I [ 0 ] if ( len ( iI1I1iiIi1I ) > 0 ) else 'None'
      OooooO0oOOOO = I11i [ 0 ] if ( len ( I11i ) > 0 ) else 'Anonymous'
      oOoO0O0oO = oOOoo [ 0 ] if ( len ( oOOoo ) > 0 ) else 'None'
      I1IiI11 = i1I1iIii11 [ 0 ] if ( len ( i1I1iIii11 ) > 0 ) else 'None'
      if 92 - 92: II11iIiIIIiI / i11iIiiIii + OoooO0Oo0O0
      oOo0Oo0O0O = '<addon id="' + i1iIIIi1i + '" name="' + oOOoo0000O0o0 + '" version="0" provider-name="' + OooooO0oOOOO + '">'
      O00Oo = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
      if 48 - 48: II11iIiIIIiI - o0oOo0 + II11iIiIIIiI - o0Oo * i11iIiiIii . i1Iii1i1I
      if oOoO0O0oO != 'None' :
       iiI1IIIi = i11i . replace ( I1IiI11 , O00Oo ) . replace ( oOoO0O0oO , oOo0Oo0O0O )
       if 35 - 35: i11111IIIII . O0 + II11iIiIIIiI + iiIi1i11 + i1IIi
      else :
       iiI1IIIi = i11i . replace ( I1IiI11 , O00Oo )
       if 65 - 65: O0 * o0Oo / o0Oo . O00OOOoOoo0O
      o0oooOO00 = open ( o0Oii1111i , mode = 'w+' )
      o0oooOO00 . write ( str ( iiI1IIIi ) )
      o0oooOO00 . close ( )
      IIiiiiIiIIii = open ( O0ooOO , mode = 'w+' )
      IIiiiiIiIIii . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + i1iIIIi1i + '"\nAddonName="' + oOOoo0000O0o0 + '"\ndialog=xbmcgui.Dialog()\ndialog.ok(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating so we recommend waiting a few minutes to see if it updates naturally. If it hasn\'t updated after 5mins please try reinstalling via the Community Portal add-on")\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
      IIiiiiIiIIii . close ( )
      if 87 - 87: oO0OooOoO * OoooO0Oo0O0 % II11iIiIIIiI * II11iIiIIIiI
     except :
      print "### Failed to backup: " + i1iIIIi1i
      if 58 - 58: iiIi1i11 . oOO00Oo + o0Oo % II11iIiIIIiI - ii1ii11IIIiiI
      if 50 - 50: i1Iii1i1I % oO0OooOoO - o0oOo0 . i1IIi + O0 % i1Iii1i1I
   else :
    try :
     shutil . copytree ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) , os . path . join ( i1Oo00 , i1iIIIi1i ) )
    except :
     print "### Failed to copy: " + i1iIIIi1i
     if 10 - 10: i1Iii1i1I . i1IIi + iI1IiiIIIiIi
 OOooO0OOoo . close ( )
 if 66 - 66: ii1ii11IIIiiI % oOO00Oo
 iI1ii11Ii = "Creating Backup"
 O0OO0OO = "Archiving..."
 Ooo0oO = ""
 IiIiIIiii1I = "Please Wait"
 if 56 - 56: i11iIiiIii - iIii1I11I1II1 . oO0OooOoO
 oOo0OOoooO ( i1Oo00 , i1i , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , '' , '' )
 if 81 - 81: i11111IIIII / O00OOOoOoo0O * i11111IIIII . O0
 try :
  shutil . rmtree ( i1Oo00 )
  if 61 - 61: ii1ii11IIIiiI * iiIi1i11 + Iiii1i1 . iIii1I11I1II1 % o00O0OoO . Iiii1i1
 except :
  print "### COMMUNITY BUILDS: Failed to remove temp addons folder - manual delete required ###"
  if 53 - 53: Iiii1i1 * i11111IIIII / iIii1I11I1II1 / o0Oo % OoooO0Oo0O0
  if 39 - 39: ii1ii11IIIiiI / OoooooooOO . ii1ii11IIIiiI * OoooO0Oo0O0 / O00OOOoOoo0O
def II111 ( url ) :
 OOooO0OOoo . create ( 'Cleaning Temp Paths' , '' , 'Please wait...' )
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 94 - 94: i1Iii1i1I % o0oOo0 . III1IiiI
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 85 - 85: iiIi1i11 * i1IIi % o0Oo - o0oOo0
 extract . all ( i1i , i1Oo00 , OOooO0OOoo )
 if 37 - 37: i11111IIIII . II11iIiIIIiI * II11iIiIIIiI * oO0OooOoO * O0
 for i1iIIIi1i in os . listdir ( i1Oo00 ) :
  if 83 - 83: i11111IIIII / Iiii1i1
  if not 'totalinstaller' in i1iIIIi1i and not 'plugin.program.tbs' in i1iIIIi1i :
   if not os . path . exists ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) :
    os . rename ( os . path . join ( i1Oo00 , i1iIIIi1i ) , os . path . join ( II11iiii1Ii , i1iIIIi1i ) )
    OOooO0OOoo . update ( 0 , "Installing: [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    print "### Successfully installed: " + i1iIIIi1i
    if 64 - 64: ii1ii11IIIiiI % i11111IIIII . Iiii1i1 % ii1ii11IIIiiI + o00O0OoO * i11111IIIII
   else :
    print "### " + i1iIIIi1i + " Already exists on system"
    if 83 - 83: oOO00Oo % III1IiiI + o00O0OoO % i11iIiiIii + O0
    if 65 - 65: iIii1I11I1II1 % III1IiiI + O0 / OoooooooOO
def O0000oO0o00 ( welcometext ) :
 oo000o ( 'disclaimer.xml' )
 oO00oOOoooO ( 'folder' , 'I have read and understand the disclaimer.' , welcometext , 'CB_Menu' , '' , '' , '' , '' )
 if 95 - 95: III1IiiI - o0oOo0 * o00O0OoO / ii1ii11IIIiiI / oO0OooOoO + O0
 if 37 - 37: o00O0OoO . Iiii1i1 + iiIi1i11 + o00O0OoO . i11111IIIII / iI1IiiIIIiIi
def i1I ( welcometext ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  OoOOoO0oOo = OOoo0 ( )
  oOOoooO0O0 = os . path . join ( OoOOoO0oOo , 'Download' )
  try :
   if not os . path . exists ( oOOoooO0O0 ) :
    os . makedirs ( oOOoooO0O0 )
  except :
   print "### Failed to make download folder"
   if 46 - 46: iIii1I11I1II1
  if not os . path . exists ( '/data/data/com.rechild.advancedtaskkiller' ) :
   iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Advanced Task Killer Required' , 'To be able to us features such as the backup/restore and community builds you need the Advanced Task Killer app installed. Would you like to download it now?' )
   if iII1Iii1I11i == 1 :
    OOooO0OOoo . create ( 'Downloading APK file' , '' , '' , '' )
    try :
     downloader . download ( 'https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk' , os . path . join ( oOOoooO0O0 , 'AdvancedTaskKiller.apk' ) )
     iI111I11I1I1 . ok ( 'Download Complete' , "The apk file has now been downloaded, you'll find this in your downloads folder. Just install this exactly the same as you would any other apk file - click on it and then click through the setup screen. The file is called AdvancedTaskKiller.apk" )
    except :
     try :
      downloader . download ( 'https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk' , os . path . join ( 'storage' , 'emulated' , 'legacy' , 'Download' , 'AdvancedTaskKiller.apk' ) )
      iI111I11I1I1 . ok ( 'Download Complete' , "The AdvancedTaskKiller.apk file has now been downloaded, you'll find this in your downloads folder. You'll need a File Manager app to install this file, we recommend installing ES File Explorer - just do a search for this on your box/stick." )
     except :
      iI111I11I1I1 . ok ( 'Download Failed' , 'It wasn\'t possible to download the Advanced Task Killer, without it you will almost certainly run into problems so make sure you get it installed otherwise you\'ll need to manually force close and switching profiles may fail.' )
      if 33 - 33: o00O0OoO % o00O0OoO % O0 / o0Oo . i1IIi
      if 91 - 91: o0oOo0 * o00O0OoO - oO0OooOoO . o0Oo - II11iIiIIIiI + o0oOo0
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 OO00o = float ( III1I1I [ : 2 ] )
 oOOo0oo0O = int ( OO00o )
 print "#### Welcome: " + welcometext
 if 32 - 32: iIii1I11I1II1 . iIii1I11I1II1 . i1Iii1i1I * o00O0OoO
 if not 'elc' in welcometext :
  oO00oOOoooO ( '' , '[COLOR=orange]To access community builds you must be logged in[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , 'Register at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
  if 93 - 93: III1IiiI * iI1IiiIIIiIi
 if o0oOOo0O0Ooo == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show My Private List[/COLOR]' , '&visibility=private' , 'grab_builds' , '' , '' , '' , '' )
  if 27 - 27: o0Oo * o0oOo0
 if ( ( i1i1II . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) ) :
  if 77 - 77: i11111IIIII
  if ( oOOo0oo0O < 14 ) or ( I1i1iiI1 == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Gotham Compatible Builds[/COLOR]' , '&xbmc=gotham&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 66 - 66: iIii1I11I1II1 . i11iIiiIii / o00O0OoO / o0oOo0 + Iiii1i1
  if ( oOOo0oo0O == 14 ) or ( I1i1iiI1 == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Helix Compatible Builds[/COLOR]' , '&xbmc=helix&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 5 - 5: O00OOOoOoo0O % i1Iii1i1I + i11111IIIII
  if ( oOOo0oo0O == 15 ) or ( I1i1iiI1 == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Isengard Compatible Builds[/COLOR]' , '&xbmc=isengard&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
  if ( oOOo0oo0O == 16 ) or ( I1i1iiI1 == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Jarvis Compatible Builds[/COLOR]' , '&xbmc=jarvis&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 13 - 13: i11111IIIII
  if I11 == 'false' :
   oO00oOOoooO ( '' , '[COLOR=gold]How to fix builds broken on other wizards![/COLOR]' , '' , 'instructions_5' , '' , '' , '' , '' )
  if Oo0o0000o0o0 != '' and I11 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + oOo0oooo00o + ' Builds[/COLOR]' , '&id=1' , 'grab_builds' , '' , '' , '' , '' )
  if oO0o0o0ooO0oO != '' and I11 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + oo0o0O00 + ' Builds[/COLOR]' , '&id=2' , 'grab_builds' , '' , '' , '' , '' )
  if oO != '' and I11 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + i1iiIIiiI111 + ' Builds[/COLOR]' , '&id=3' , 'grab_builds' , '' , '' , '' , '' )
  if oooOOOOO != '' and I11 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + i1iiIII111ii + ' Builds[/COLOR]' , '&id=4' , 'grab_builds' , '' , '' , '' , '' )
  if i1iIIi1 != '' and I11 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + ii11iIi1I + ' Builds[/COLOR]' , '&id=5' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Create My Own Community Build' , 'url' , 'backup_option' , '' , '' , '' , 'Back Up Your Full System' )
 if 19 - 19: oO0OooOoO - i11111IIIII
 if 59 - 59: oOO00Oo * ii1ii11IIIiiI - iI1IiiIIIiIi . iiIi1i11
def o0OO00oo0O ( skin ) :
 Ii1I1i111 = '<onleft>%s</onleft>'
 oOi1 = '<onright>%s</onright>'
 i11ioo0OoOO0o0o = '<onup>%s</onup>'
 OO0OOO00 = '<ondown>%s</ondown>'
 ooOOo0o = '<control type="button" id="%s">'
 if 50 - 50: oO0OooOoO - Iiii1i1 + iIii1I11I1II1 + iIii1I11I1II1
 if 91 - 91: oO0OooOoO - O0 . iIii1I11I1II1 . O0 + OoooO0Oo0O0 - oO0OooOoO
 iiIiiIi1 = [
 ( '65' , '140' ) ,
 ( '66' , '164' ) ,
 ( '67' , '162' ) ,
 ( '68' , '142' ) ,
 ( '69' , '122' ) ,
 ( '70' , '143' ) ,
 ( '71' , '144' ) ,
 ( '72' , '145' ) ,
 ( '73' , '127' ) ,
 ( '74' , '146' ) ,
 ( '75' , '147' ) ,
 ( '76' , '148' ) ,
 ( '77' , '166' ) ,
 ( '78' , '165' ) ,
 ( '79' , '128' ) ,
 ( '80' , '129' ) ,
 ( '81' , '120' ) ,
 ( '82' , '123' ) ,
 ( '83' , '141' ) ,
 ( '84' , '124' ) ,
 ( '85' , '126' ) ,
 ( '86' , '163' ) ,
 ( '87' , '121' ) ,
 ( '88' , '161' ) ,
 ( '89' , '125' ) ,
 ( '90' , '160' ) ]
 if 30 - 30: iiIi1i11 + oO0OooOoO - i11111IIIII * OoooooooOO
 for I1iIiiiI1 , OOO0O00Oo in iiIiiIi1 :
  ii1oOOO0ooOO = open ( skin ) . read ( )
  i11IiI1iiI11 = ii1oOOO0ooOO . replace ( ooOOo0o % I1iIiiiI1 , ooOOo0o % OOO0O00Oo ) . replace ( Ii1I1i111 % I1iIiiiI1 , Ii1I1i111 % OOO0O00Oo ) . replace ( oOi1 % I1iIiiiI1 , oOi1 % OOO0O00Oo ) . replace ( i11ioo0OoOO0o0o % I1iIiiiI1 , i11ioo0OoOO0o0o % OOO0O00Oo ) . replace ( OO0OOO00 % I1iIiiiI1 , OO0OOO00 % OOO0O00Oo )
  iiI1iii = open ( skin , mode = 'w' )
  iiI1iii . write ( i11IiI1iiI11 )
  iiI1iii . close ( )
  if 85 - 85: OoooO0Oo0O0 - O00OOOoOoo0O / OoooO0Oo0O0 + iiIi1i11 - i1Iii1i1I
def IIii1III ( u , skin ) :
 Ii1I1i111 = '<onleft>%s</onleft>'
 oOi1 = '<onright>%s</onright>'
 i11ioo0OoOO0o0o = '<onup>%s</onup>'
 OO0OOO00 = '<ondown>%s</ondown>'
 ooOOo0o = '<control type="button" id="%s">'
 if 94 - 94: i11iIiiIii % OoooooooOO / o0Oo
 if u < 49 :
  iII1Iii11111 = u + 61
  if 80 - 80: III1IiiI * o00O0OoO / iIii1I11I1II1 % III1IiiI / iIii1I11I1II1
 else :
  iII1Iii11111 = u + 51
  if 42 - 42: i1IIi / i11iIiiIii . II11iIiIIIiI * i1Iii1i1I . i11iIiiIii * O0
 ii1oOOO0ooOO = open ( skin ) . read ( )
 i11IiI1iiI11 = ii1oOOO0ooOO . replace ( Ii1I1i111 % u , Ii1I1i111 % iII1Iii11111 ) . replace ( oOi1 % u , oOi1 % iII1Iii11111 ) . replace ( i11ioo0OoOO0o0o % u , i11ioo0OoOO0o0o % iII1Iii11111 ) . replace ( OO0OOO00 % u , OO0OOO00 % iII1Iii11111 ) . replace ( ooOOo0o % u , ooOOo0o % iII1Iii11111 )
 iiI1iii = open ( skin , mode = 'w' )
 iiI1iii . write ( i11IiI1iiI11 )
 iiI1iii . close ( )
 if 44 - 44: i1IIi . o0Oo / i11iIiiIii + i11111IIIII
def iI111II1ii ( description ) :
 O0ooO00ooOO0o = os . path . join ( iiI1IiI , 'extracted' )
 o0OI1II = os . path . join ( iiI1IiI , 'temp' )
 iIIi1Ii1III = os . path . join ( O0ooO00ooOO0o , 'userdata' , '.cbcfg' )
 Oooo00 = os . path . join ( iiI1IiI , description , 'addonlist' )
 iii1II1iI1IIi = open ( Oooo00 , 'w+' )
 Ii11iiI1 = [ ]
 if 71 - 71: oOO00Oo / iiIi1i11 % iiIi1i11
 if not os . path . exists ( os . path . join ( iiI1IiI , description ) ) :
  os . makedirs ( os . path . join ( iiI1IiI , description ) )
  if iiIIIII1i1iI == 'true' :
   print "### (line 1147) Created: " + os . path . join ( iiI1IiI , description )
 if not os . path . exists ( II ) :
  os . makedirs ( II )
  if iiIIIII1i1iI == 'true' :
   print "### (line 1450) Created: " + II
 if os . path . exists ( o0OI1II ) :
  shutil . rmtree ( o0OI1II )
  if iiIIIII1i1iI == 'true' :
   print "### (line 1453) Removed: " + o0OI1II
   if 89 - 89: OoooooooOO + i11iIiiIii / o00O0OoO + iIii1I11I1II1 % o0oOo0
 if os . path . exists ( iIIi1Ii1III ) :
  if not os . path . exists ( o0OI1II ) :
   os . makedirs ( o0OI1II )
   if iiIIIII1i1iI == 'true' :
    print "### (line 1458) Created: " + o0OI1II
  extract . all ( iIIi1Ii1III , o0OI1II , OOooO0OOoo )
  print "### NEW STYLE BUILD"
  if iiIIIII1i1iI == 'true' :
   print "### (line 1461) Extracted " + iIIi1Ii1III + " to: " + o0OI1II
 elif os . path . exists ( os . path . join ( O0ooO00ooOO0o , 'addons' ) ) :
  os . rename ( os . path . join ( O0ooO00ooOO0o , 'addons' ) , o0OI1II )
  print "### OLD BUILD - RENAMED ADDONS FOLDER"
  if iiIIIII1i1iI == 'true' :
   print "### (line 1465) renamed " + os . path . join ( O0ooO00ooOO0o , 'addons' ) + " to " + o0OI1II
   if 29 - 29: OoooO0Oo0O0
 OOooO0OOoo . create ( 'Copying Addons' , '' , '' , '' )
 if 53 - 53: i11iIiiIii . OoooO0Oo0O0 % iI1IiiIIIiIi / o0oOo0 % iIii1I11I1II1
 for i1iIIIi1i in os . listdir ( OO0o ) :
  Ii11iiI1 . append ( i1iIIIi1i )
  if 6 - 6: II11iIiIIIiI - iiIi1i11 . iIii1I11I1II1
 for i1iIIIi1i in os . listdir ( II11iiii1Ii ) :
  Ii11iiI1 . append ( i1iIIIi1i )
  if 30 - 30: o0oOo0 + o0oOo0 % i11111IIIII - oOO00Oo - OoooO0Oo0O0
 if os . path . exists ( II ) :
  for i1iIIIi1i in os . listdir ( II ) :
   if not i1iIIIi1i in Ii11iiI1 :
    Ii11iiI1 . append ( i1iIIIi1i )
    if 36 - 36: o00O0OoO % iiIi1i11
    if 72 - 72: o0Oo / i1Iii1i1I - O0 + o00O0OoO
 if not os . path . exists ( os . path . join ( II , 'backups' ) ) :
  os . makedirs ( os . path . join ( II , 'backups' ) )
  if iiIIIII1i1iI == 'true' :
   print "### Created: " + os . path . join ( II , 'backups' )
 for i1iIIIi1i in os . listdir ( o0OI1II ) :
  try :
   if 83 - 83: O0
   if 89 - 89: II11iIiIIIiI + OoooO0Oo0O0 - oOO00Oo
   iii1II1iI1IIi . write ( i1iIIIi1i + '|' )
   if iiIIIII1i1iI == 'true' :
    print "### Added: " + os . path . join ( II , 'backups' , i1iIIIi1i )
    print "### Added " + i1iIIIi1i + " to " + iii1II1iI1IIi
  except :
   pass
   if 40 - 40: ii1ii11IIIiiI + ii1ii11IIIiiI
  if not i1iIIIi1i in Ii11iiI1 :
   try :
    os . rename ( os . path . join ( o0OI1II , i1iIIIi1i ) , os . path . join ( II , i1iIIIi1i ) )
    OOooO0OOoo . update ( 0 , "Configuring" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
    if iiIIIII1i1iI == 'true' :
     print "### Renamed from " + os . path . join ( o0OI1II , i1iIIIi1i ) + " to " + os . path . join ( II , i1iIIIi1i )
   except :
    pass
    if 94 - 94: i1Iii1i1I * iIii1I11I1II1 . o00O0OoO
 iii1II1iI1IIi . close ( )
 shutil . rmtree ( o0OI1II )
 shutil . rmtree ( O0ooO00ooOO0o )
 if 13 - 13: iIii1I11I1II1 * O00OOOoOoo0O / Iiii1i1 % o0oOo0 + III1IiiI
 if 41 - 41: OoooO0Oo0O0
def i1iI1i ( ) :
 I11iIi1i1II11 = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 59 - 59: i11111IIIII
 if not os . path . exists ( zip ) :
  iI111I11I1I1 . ok ( 'Download/Storage Path Check' , 'The download location you have stored does not exist .\nPlease update the addon settings and try again.' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  if 89 - 89: O00OOOoOoo0O % iIii1I11I1II1
  if 35 - 35: OoooO0Oo0O0 + Iiii1i1 - O00OOOoOoo0O % III1IiiI % oOO00Oo % O00OOOoOoo0O
def ii1IIiII111I ( ) :
 I1i11 = 'http://noobsandnerds.com/TI/menu_check'
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 O00OoOoO = re . compile ( 'd="(.+?)"' ) . findall ( IiIi1I1 )
 ooO0o0oo = O00OoOoO [ 0 ] if ( len ( O00OoOoO ) > 0 ) else ''
 if ooO0o0oo != '' :
  return ooO0o0oo
 else :
  return "none"
  if 79 - 79: i11111IIIII % ii1ii11IIIiiI
  if 81 - 81: i11iIiiIii + i11iIiiIii * ii1ii11IIIiiI + i11111IIIII
def i11I1IiiiiiiiIi ( localbuildcheck , localversioncheck , id ) :
 I1i11 = 'http://noobsandnerds.com/TI/Community_Builds/buildupdate.php?id=%s' % ( id )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 32 - 32: O0 . OoooooooOO
 if id != 'None' :
  iiIIiiIi = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
  i1ii1I = iiIIiiIi [ 0 ] if ( len ( iiIIiiIi ) > 0 ) else ''
  if 50 - 50: iIii1I11I1II1 + O00OOOoOoo0O . O00OOOoOoo0O + i1IIi + i11111IIIII
  if localversioncheck < i1ii1I :
   return True
   if 27 - 27: i1IIi % iI1IiiIIIiIi - ii1ii11IIIiiI / III1IiiI . o0oOo0 / II11iIiIIIiI
 else :
  return False
  if 99 - 99: ii1ii11IIIiiI - O00OOOoOoo0O * O00OOOoOoo0O . oO0OooOoO % o0oOo0
  if 1 - 1: OoooO0Oo0O0 + II11iIiIIIiI * III1IiiI + oOO00Oo - o00O0OoO . OoooO0Oo0O0
def oooO00Oo ( ) :
 O0OO0o0OO0OO = open ( I1IIiiIiii , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 if 31 - 31: iIii1I11I1II1 . oO0OooOoO - ii1ii11IIIiiI
 O0Oo0 = re . compile ( 'name="(.+?)"' ) . findall ( i11i )
 iIIIi1IiI11I1 = O0Oo0 [ 0 ] if ( len ( O0Oo0 ) > 0 ) else ''
 if 71 - 71: iI1IiiIIIiIi - O0 - i1Iii1i1I . iiIi1i11 % II11iIiIIIiI
 if iIIIi1IiI11I1 == "Incomplete" :
  iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "Finish Restore Process" , 'If you\'re certain the correct skin has now been set click OK' , 'to finish the install process, once complete XBMC/Kodi will' , ' then close. Do you want to finish the install process?' , yeslabel = 'Yes' , nolabel = 'No' )
  if 82 - 82: OoooooooOO + iiIi1i11 % O00OOOoOoo0O . ii1ii11IIIiiI * i1IIi
  if iII1Iii1I11i == 1 :
   iIiIi1iIIi11i ( )
   if 20 - 20: i11111IIIII + O00OOOoOoo0O - iiIi1i11 - iiIi1i11 - OoooO0Oo0O0
  elif iII1Iii1I11i == 0 :
   return
   if 7 - 7: O0
def II1i ( ) :
 I11iIi1i1II11 = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 68 - 68: oOO00Oo % OoooO0Oo0O0 / Iiii1i1 + Iiii1i1 - Iiii1i1 . ii1ii11IIIiiI
 try :
  os . makedirs ( I11iIi1i1II11 )
  os . removedirs ( I11iIi1i1II11 )
  iI111I11I1I1 . ok ( '[COLOR=lime]SUCCESS[/COLOR]' , 'Great news, the path you chose is writeable.' , 'Some of these builds are rather big, we recommend a minimum of 1GB storage space.' )
  if 100 - 100: O00OOOoOoo0O % II11iIiIIIiI
 except :
  iI111I11I1I1 . ok ( '[COLOR=red]CANNOT WRITE TO PATH[/COLOR]' , 'Kodi cannot write to the path you\'ve chosen. Please click OK in the settings menu to save the path then try again. Some devices give false results, we recommend using a USB stick as the backup path.' )
  if 76 - 76: oO0OooOoO / ii1ii11IIIiiI + OoooooooOO . OoooO0Oo0O0 . o00O0OoO . o0oOo0
  if 43 - 43: i1IIi
def oOiiI1Ii11II1I ( s , n ) :
 for iiI1IIIii in range ( 0 , len ( s ) , n ) :
  yield s [ iiI1IIIii : iiI1IIIii + n ]
  if 24 - 24: o0Oo . Iiii1i1 % iI1IiiIIIiIi
  if 62 - 62: OoooO0Oo0O0 - O0 . o0Oo . O0 * iIii1I11I1II1
def oOo0O ( data ) :
 data = data . replace ( '</p><p>' , '[CR][CR]' ) . replace ( '&ndash;' , '-' ) . replace ( '&mdash;' , '-' ) . replace ( "\n" , " " ) . replace ( "\r" , " " ) . replace ( "&rsquo;" , "'" ) . replace ( "&rdquo;" , '"' ) . replace ( "</a>" , " " ) . replace ( "&hellip;" , '...' ) . replace ( "&lsquo;" , "'" ) . replace ( "&ldquo;" , '"' )
 data = " " . join ( data . split ( ) )
 i1iOO = re . compile ( r'< script[^<>]*?>.*?< / script >' )
 data = i1iOO . sub ( '' , data )
 i1iOO = re . compile ( r'< style[^<>]*?>.*?< / style >' )
 data = i1iOO . sub ( '' , data )
 i1iOO = re . compile ( r'' )
 data = i1iOO . sub ( '' , data )
 i1iOO = re . compile ( r'<[^<]*?>' )
 data = i1iOO . sub ( '' , data )
 data = data . replace ( '&nbsp;' , ' ' )
 return data
 if 80 - 80: o0Oo - iI1IiiIIIiIi * o0Oo + iIii1I11I1II1 / O0 - iI1IiiIIIiIi
def IiI1Ii1ii ( ) :
 if 44 - 44: o0Oo % iI1IiiIIIiIi * o0Oo . II11iIiIIIiI + OoooO0Oo0O0 . iiIi1i11
 I11iIi1i1II11 = xbmc . translatePath ( 'special://home/userdata/Database' )
 I1iiIi111I = glob . glob ( os . path . join ( I11iIi1i1II11 , 'Textures*.db' ) )
 I1Iii11I111I = 0
 IIIiI1iiiiiIi = ''
 if 74 - 74: o00O0OoO / OoooooooOO / II11iIiIIIiI * i11iIiiIii . oO0OooOoO . OoooooooOO
 if 59 - 59: i11iIiiIii . OoooooooOO / o00O0OoO * OoooO0Oo0O0 + OoooooooOO
 for file in I1iiIi111I :
  Ii1I1i1ii1I1 = int ( re . compile ( 'extures(.+?).db' ) . findall ( file ) [ 0 ] )
  if I1Iii11I111I < Ii1I1i1ii1I1 :
   I1Iii11I111I = Ii1I1i1ii1I1
   IIIiI1iiiiiIi = file
   if 98 - 98: i11111IIIII * iIii1I11I1II1 . iI1IiiIIIiIi * II11iIiIIIiI / OoooO0Oo0O0 + o0oOo0
 iiI1ii111 = xbmc . translatePath ( IIIiI1iiiiiIi )
 OoOOIIIIIiI11Ii = database . connect ( iiI1ii111 , timeout = 10 , detect_types = database . PARSE_DECLTYPES , check_same_thread = False )
 OoOOIIIIIiI11Ii . row_factory = database . Row
 Iiii1Ii1I = OoOOIIIIIiI11Ii . cursor ( )
 if 94 - 94: iIii1I11I1II1 - ii1ii11IIIiiI . II11iIiIIIiI
 if 59 - 59: ii1ii11IIIiiI - ii1ii11IIIiiI + i1Iii1i1I
 iiII = datetime . datetime . today ( ) - datetime . timedelta ( days = 14 )
 II11iiii = 10
 if 20 - 20: i1Iii1i1I / iiIi1i11
 if 28 - 28: o0oOo0 * o00O0OoO % i11iIiiIii * i1Iii1i1I / iI1IiiIIIiIi
 iIII1iIi = [ ]
 o000O0oo = [ ]
 if 78 - 78: ii1ii11IIIiiI / II11iIiIIIiI - iIii1I11I1II1 - i11iIiiIii * i1Iii1i1I
 Iiii1Ii1I . execute ( "SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?" , ( II11iiii , str ( iiII ) ) )
 if 84 - 84: iiIi1i11 + iI1IiiIIIiIi + oOO00Oo
 for i1i1iIII11i in Iiii1Ii1I :
  iIII1iIi . append ( i1i1iIII11i [ "idtexture" ] )
  if 40 - 40: iIii1I11I1II1 / O00OOOoOoo0O - O0 * iIii1I11I1II1
 for id in iIII1iIi :
  Iiii1Ii1I . execute ( "SELECT cachedurl FROM texture WHERE id = ?" , ( id , ) )
  for i1i1iIII11i in Iiii1Ii1I :
   o000O0oo . append ( i1i1iIII11i [ "cachedurl" ] )
   if 56 - 56: iiIi1i11
 print "### Community Portal Automatic Cache Removal: %d Old Textures removed" % len ( o000O0oo )
 if 49 - 49: o0oOo0 . oO0OooOoO
 if 24 - 24: O0 . OoooooooOO - ii1ii11IIIiiI * OoooooooOO
 for id in iIII1iIi :
  Iiii1Ii1I . execute ( "DELETE FROM sizes   WHERE idtexture = ?" , ( id , ) )
  Iiii1Ii1I . execute ( "DELETE FROM texture WHERE id        = ?" , ( id , ) )
  if 12 - 12: O0 + i11111IIIII * i1IIi . ii1ii11IIIiiI
 Iiii1Ii1I . execute ( "VACUUM" )
 OoOOIIIIIiI11Ii . commit ( )
 Iiii1Ii1I . close ( )
 if 71 - 71: Iiii1i1 - oOO00Oo - iiIi1i11
 if 28 - 28: iIii1I11I1II1
 iI11II1i1I1 = xbmc . translatePath ( 'special://home/userdata/Thumbnails' )
 for o0oo00O0o in o000O0oo :
  I11iIi1i1II11 = os . path . join ( iI11II1i1I1 , o0oo00O0o )
  try :
   os . remove ( I11iIi1i1II11 )
  except :
   pass
   if 57 - 57: i1IIi * oO0OooOoO * III1IiiI
   if 30 - 30: o00O0OoO % O00OOOoOoo0O / OoooO0Oo0O0 * O0 * iI1IiiIIIiIi . o0Oo
   if 46 - 46: O00OOOoOoo0O - O0
def ooo0O0OOo0OoO ( ) :
 if os . path . exists ( os . path . join ( iiI1IiI , 'extracted' ) ) :
  try :
   shutil . rmtree ( os . path . join ( iiI1IiI , 'extracted' ) )
  except :
   print "### Unsuccessful Community Build Install detected, unabled to remove extracted folder"
   if 70 - 70: o00O0OoO + II11iIiIIIiI * iIii1I11I1II1 . o0Oo * o00O0OoO
 if os . path . exists ( os . path . join ( iiI1IiI , 'temp' ) ) :
  try :
   shutil . rmtree ( os . path . join ( iiI1IiI , 'temp' ) )
  except :
   print "### Unsuccessful Community Build Install detected, unabled to remove temp folder"
   if 49 - 49: oOO00Oo
   if 25 - 25: i1Iii1i1I . OoooooooOO * iIii1I11I1II1 . oOO00Oo / O0 + iI1IiiIIIiIi
def ooo0o0 ( ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Clear All Known Cache?' , 'This will clear all known cache files and can help if you\'re encountering kick-outs during playback as well as other random issues. There is no harm in using this.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 84 - 84: o00O0OoO - II11iIiIIIiI * O0 / iI1IiiIIIiIi . iI1IiiIIIiIi
 if iII1Iii1I11i == 1 :
  ooO0 ( )
  ii111iiIii ( )
  if 57 - 57: oOO00Oo / Iiii1i1
  if 13 - 13: OoooooooOO + ii1ii11IIIiiI
def ii1IIii ( url ) :
 oO00oOOoooO ( 'folder' , 'African' , str ( url ) + '&genre=african' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Arabic' , str ( url ) + '&genre=arabic' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Asian' , str ( url ) + '&genre=asian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Australian' , str ( url ) + '&genre=australian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Austrian' , str ( url ) + '&genre=austrian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Belgian' , str ( url ) + '&genre=belgian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Brazilian' , str ( url ) + '&genre=brazilian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Canadian' , str ( url ) + '&genre=canadian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Columbian' , str ( url ) + '&genre=columbian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Czech' , str ( url ) + '&genre=czech' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Danish' , str ( url ) + '&genre=danish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dominican' , str ( url ) + '&genre=dominican' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dutch' , str ( url ) + '&genre=dutch' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Egyptian' , str ( url ) + '&genre=egyptian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Filipino' , str ( url ) + '&genre=filipino' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Finnish' , str ( url ) + '&genre=finnish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'French' , str ( url ) + '&genre=french' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'German' , str ( url ) + '&genre=german' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Greek' , str ( url ) + '&genre=greek' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hebrew' , str ( url ) + '&genre=hebrew' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hungarian' , str ( url ) + '&genre=hungarian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Icelandic' , str ( url ) + '&genre=icelandic' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Indian' , str ( url ) + '&genre=indian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Irish' , str ( url ) + '&genre=irish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Italian' , str ( url ) + '&genre=italian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Japanese' , str ( url ) + '&genre=japanese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Korean' , str ( url ) + '&genre=korean' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Lebanese' , str ( url ) + '&genre=lebanese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Mongolian' , str ( url ) + '&genre=mongolian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Nepali' , str ( url ) + '&genre=nepali' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'New Zealand' , str ( url ) + '&genre=newzealand' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Norwegian' , str ( url ) + '&genre=norwegian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Pakistani' , str ( url ) + '&genre=pakistani' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Polish' , str ( url ) + '&genre=polish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Portuguese' , str ( url ) + '&genre=portuguese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Romanian' , str ( url ) + '&genre=romanian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Russian' , str ( url ) + '&genre=russian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Singapore' , str ( url ) + '&genre=singapore' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Spanish' , str ( url ) + '&genre=spanish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swedish' , str ( url ) + '&genre=swedish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swiss' , str ( url ) + '&genre=swiss' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Syrian' , str ( url ) + '&genre=syrian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Tamil' , str ( url ) + '&genre=tamil' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Thai' , str ( url ) + '&genre=thai' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Turkish' , str ( url ) + '&genre=turkish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'UK' , str ( url ) + '&genre=uk' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'USA' , str ( url ) + '&genre=usa' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Vietnamese' , str ( url ) + '&genre=vietnamese' , 'grab_builds' , '' , '' , '' , '' )
 if 31 - 31: iIii1I11I1II1 * o0oOo0 - OoooooooOO * o0oOo0
 if 60 - 60: iiIi1i11 % iiIi1i11 * III1IiiI / o0Oo * O00OOOoOoo0O * o0Oo
def OOoO0o ( ) :
 O00Ooiii = O0ooO0O0Ooo0o ( 'welcometext' )
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
 IIi11IIiIi1i = 1
 i1iI1i ( )
 iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Are you sure?!!!' , 'This is method is very dated and is only left here for LOCAL installs. For online backups you really should be using the NaN backup option which creates a much smaller file and allows for a much more reliable install process.' )
 if iII1Iii1I11i == 0 :
  return
 IiiOoo0o0ooooOOo = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
 oOoOO0000oO00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 O0oiIiiIi = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 19 - 19: oOO00Oo
 if not os . path . exists ( IiiOoo0o0ooooOOo ) :
  os . makedirs ( IiiOoo0o0ooooOOo )
  if 73 - 73: Iiii1i1 * II11iIiIIIiI * O00OOOoOoo0O
 Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
 if ( not Oo0OOo ) :
  return False , 0
  if 64 - 64: III1IiiI % O00OOOoOoo0O / oO0OooOoO % o0oOo0 - i1Iii1i1I
 I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( IiiOoo0o0ooooOOo , I1II1IiI1 + '.zip' ) )
 o00oo = [ o0OO00 ]
 O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 oooOOO0ooOoOOO = [ o0OO00 , 'cache' , 'system' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' ]
 o0IiIiI111IIII1 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
 iI1ii11Ii = "Creating full backup of existing build"
 OOOoOooO000oO = "Creating Community Build"
 O0OO0OO = "Archiving..."
 Ooo0oO = ""
 IiIiIIiii1I = "Please Wait"
 if 87 - 87: i1Iii1i1I % II11iIiIIIiI
 if iI1Ii11111iIi == 'true' :
  oOo0OOoooO ( iIii1 , oOoOO0000oO00 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
  if 62 - 62: ii1ii11IIIiiI + o0oOo0 / i1Iii1i1I * i11iIiiIii
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
 if 37 - 37: i1Iii1i1I
 if iII1Iii1I11i == 0 :
  oooOOO0ooOoOOO = [ o0OO00 , 'cache' , 'system' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
  if 33 - 33: ii1ii11IIIiiI - O0 - ii1ii11IIIiiI
 elif iII1Iii1I11i == 1 :
  pass
  if 94 - 94: i11111IIIII * o00O0OoO * OoooooooOO / oOO00Oo . i11111IIIII - oOO00Oo
 if i1i1II . replace ( '%20' , ' ' ) in O00Ooiii and i1i1II != '' :
  if ( os . path . exists ( os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) ) and i1i1II . replace ( '%20' , ' ' ) in I1I1iiii1IiI1i ( ) ) or not os . path . exists ( os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) ) :
   iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "Stop leechers profiting from your work?" , 'If you\'d prefer sellers not to profit from your build click yes to add a startup message on your build. Do you want add the message?' , yeslabel = 'No' , nolabel = 'Yes' )
   if iII1Iii1I11i == 0 :
    I11I ( i1i1II )
   if iII1Iii1I11i == 1 :
    try :
     OooO0ooO0o0 ( )
    except :
     pass
     if 88 - 88: III1IiiI % II11iIiIIIiI - o00O0OoO % III1IiiI + i11111IIIII - i1Iii1i1I
 ii1OO0 ( iIii1 )
 Oo ( )
 oOo0OOoooO ( iIii1 , iIIiI11iI1Ii1 , OOOoOooO000oO , O0OO0OO , Ooo0oO , IiIiIIiii1I , oooOOO0ooOoOOO , o0IiIiI111IIII1 )
 time . sleep ( 1 )
 if 54 - 54: o0Oo * iiIi1i11 + oOO00Oo % i1IIi - oOO00Oo + O00OOOoOoo0O
 IIIIiI11Ii1i = xbmc . translatePath ( os . path . join ( IiiOoo0o0ooooOOo , I1II1IiI1 + '_guisettings.zip' ) )
 O0O0O0o = zipfile . ZipFile ( IIIIiI11Ii1i , mode = 'w' )
 if 83 - 83: i1Iii1i1I % o00O0OoO
 try :
  O0O0O0o . write ( I11i1 , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
 except :
  IIi11IIiIi1i = 0
  if 6 - 6: O00OOOoOoo0O / o0oOo0 + i1Iii1i1I - oOO00Oo * iiIi1i11 + o0oOo0
 try :
  O0O0O0o . write ( xbmc . translatePath ( os . path . join ( iIii1 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
 except :
  pass
  if 76 - 76: oO0OooOoO - OoooooooOO % i11111IIIII
 O0O0O0o . close ( )
 if 40 - 40: iI1IiiIIIiIi
 if iI1Ii11111iIi == 'true' :
  O0Ooo0ooo00o = zipfile . ZipFile ( O0oiIiiIi , mode = 'w' )
  try :
   O0Ooo0ooo00o . write ( I11i1 , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
  except :
   IIi11IIiIi1i = 0
   if 73 - 73: o0oOo0 % o0oOo0 . i1Iii1i1I + Iiii1i1
  try :
   O0Ooo0ooo00o . write ( xbmc . translatePath ( os . path . join ( iIii1 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
  except :
   pass
  O0Ooo0ooo00o . close ( )
  if 10 - 10: O0 / iiIi1i11 * o0oOo0 - ii1ii11IIIiiI - i1IIi . O00OOOoOoo0O
 if IIi11IIiIi1i == 0 :
  iI111I11I1I1 . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your system, please reboot and try again.' , '' , '' )
  if 69 - 69: II11iIiIIIiI - iI1IiiIIIiIi % iI1IiiIIIiIi - iiIi1i11 * iiIi1i11 / II11iIiIIIiI
 else :
  iI111I11I1I1 . ok ( "SUCCESS!" , 'You Are Now Backed Up. Remember this should only be used for local backup purposes and is not recommended for sharing online. Use the far superior NaN CP backup method for online use.' )
  if 13 - 13: O00OOOoOoo0O
  if iI1Ii11111iIi == 'true' :
   iI111I11I1I1 . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + oOoOO0000oO00 , '[/COLOR]Universal Backup: [COLOR=dodgerblue]' + iIIiI11iI1Ii1 + '[/COLOR]' )
   if 67 - 67: OoooO0Oo0O0 . oO0OooOoO - iI1IiiIIIiIi % OoooooooOO
  else :
   iI111I11I1I1 . ok ( "Build Location" , 'Universal Backup:[CR][COLOR=dodgerblue]' + iIIiI11iI1Ii1 + '[/COLOR]' )
   if 49 - 49: OoooO0Oo0O0 + O0 . iI1IiiIIIiIi * OoooooooOO
   if 82 - 82: OoooO0Oo0O0
def OOO00o0 ( ) :
 O00Ooiii = O0ooO0O0Ooo0o ( 'welcometext' )
 i1iI1i ( )
 if 97 - 97: OoooO0Oo0O0 / OoooO0Oo0O0 / iIii1I11I1II1 % i1IIi . OoooO0Oo0O0 . i11111IIIII
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 4 - 4: II11iIiIIIiI - ii1ii11IIIiiI - i11iIiiIii * Iiii1i1 / iI1IiiIIIiIi - iiIi1i11
 iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Create noobsandnerds Build' , 'This backup will only work if you share your build on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal with the rest of the community. It will not work with any other installer/wizard, do you wish to continue?' )
 if 45 - 45: oOO00Oo % II11iIiIIIiI * i1IIi - O0
 if iII1Iii1I11i == 1 :
  OOooO0OOoo . create ( 'Checking File Structure' , '' , 'Please wait' , '' )
  if not os . path . exists ( oO0Oo ) :
   os . makedirs ( oO0Oo )
   if 82 - 82: oO0OooOoO / i1Iii1i1I
  IIi11IIiIi1i = 1
  IiiOoo0o0ooooOOo = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
  oOoOO0000oO00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
  O0oiIiiIi = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
  if 96 - 96: II11iIiIIIiI / III1IiiI . oO0OooOoO . II11iIiIIIiI
  if not os . path . exists ( IiiOoo0o0ooooOOo ) :
   os . makedirs ( IiiOoo0o0ooooOOo )
   if 91 - 91: oO0OooOoO . iiIi1i11 + oOO00Oo
  Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
  if 8 - 8: iiIi1i11 * II11iIiIIIiI / i1Iii1i1I - ii1ii11IIIiiI - OoooooooOO
  if ( not Oo0OOo ) :
   return False , 0
   if 100 - 100: III1IiiI . iIii1I11I1II1 . iIii1I11I1II1
  I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
  iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( IiiOoo0o0ooooOOo , I1II1IiI1 + '.zip' ) )
  if 55 - 55: III1IiiI
  if 37 - 37: i11111IIIII / i11iIiiIii / II11iIiIIIiI
  o00oo = [ o0OO00 ]
  O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
  o0IiIiI111IIII1 = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
  iI1ii11Ii = "Creating full backup of existing build"
  OOOoOooO000oO = "Creating Community Build"
  O0OO0OO = "Archiving..."
  Ooo0oO = ""
  IiIiIIiii1I = "Please Wait"
  if 97 - 97: Iiii1i1 . o00O0OoO / o0Oo
  if 83 - 83: o00O0OoO - OoooO0Oo0O0 * III1IiiI
  if iI1Ii11111iIi == 'true' :
   oOo0OOoooO ( iIii1 , oOoOO0000oO00 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
   if 90 - 90: II11iIiIIIiI * o0Oo
  iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
  if 75 - 75: OoooO0Oo0O0 - O00OOOoOoo0O * i11iIiiIii . OoooooooOO - II11iIiIIIiI . o00O0OoO
  if 6 - 6: o00O0OoO * III1IiiI / OoooooooOO % iI1IiiIIIiIi * oOO00Oo
  if iII1Iii1I11i == 0 :
   oooOOO0ooOoOOO = [ o0OO00 , 'cache' , 'system' , 'addons' , 'Thumbnails' , 'CP_Profiles' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' ]
   if 28 - 28: i11111IIIII * o0Oo % i11111IIIII
  elif iII1Iii1I11i == 1 :
   oooOOO0ooOoOOO = [ o0OO00 , 'cache' , 'system' , 'addons' , 'Thumbnails' , 'CP_Profiles' , "peripheral_data" , 'library' , 'keymaps' ]
   if 95 - 95: O0 / o00O0OoO . Iiii1i1
  if i1i1II . replace ( '%20' , ' ' ) in O00Ooiii and i1i1II != '' :
   if ( os . path . exists ( os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) ) and i1i1II . replace ( '%20' , ' ' ) in I1I1iiii1IiI1i ( ) ) or not os . path . exists ( os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) ) :
    iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "Stop leechers profiting from your work?" , 'If you\'d prefer sellers not to profit from your build click yes to add a startup message on your build. Do you want add the message?' , yeslabel = 'No' , nolabel = 'Yes' )
    if iII1Iii1I11i == 0 :
     I11I ( i1i1II )
    if iII1Iii1I11i == 1 :
     try :
      OooO0ooO0o0 ( )
     except :
      pass
      if 17 - 17: o00O0OoO
  O0o0o0 ( )
  ii1OO0 ( iIii1 )
  oOo0OOoooO ( iIii1 , iIIiI11iI1Ii1 , OOOoOooO000oO , O0OO0OO , Ooo0oO , IiIiIIiii1I , oooOOO0ooOoOOO , o0IiIiI111IIII1 )
  if 56 - 56: o0oOo0 * oOO00Oo + o00O0OoO
  if 48 - 48: i11111IIIII * ii1ii11IIIiiI % Iiii1i1 - o00O0OoO
  try :
   os . remove ( i1i )
  except :
   pass
   if 72 - 72: i1IIi % o0oOo0 % i11111IIIII % III1IiiI - III1IiiI
  try :
   os . remove ( i1Oo00 )
  except :
   pass
   if 97 - 97: oOO00Oo * O0 / oOO00Oo * ii1ii11IIIiiI * II11iIiIIIiI
  time . sleep ( 1 )
  if 38 - 38: Iiii1i1
  if 25 - 25: iIii1I11I1II1 % oO0OooOoO / o00O0OoO / OoooO0Oo0O0
  IIIIiI11Ii1i = xbmc . translatePath ( os . path . join ( IiiOoo0o0ooooOOo , I1II1IiI1 + '_guisettings.zip' ) )
  if 22 - 22: III1IiiI * i1Iii1i1I
  try :
   shutil . copyfile ( I11i1 , os . path . join ( oO0Oo , 'guisettings.xml' ) )
   if iiIIIII1i1iI == 'true' :
    print "### Successfully copied guisettings to : " + os . path . join ( oO0Oo , 'guisettings.xml' )
  except :
   if iiIIIII1i1iI == 'true' :
    print "### FAILED TO copy guisettings to : " + os . path . join ( oO0Oo , 'guisettings.xml' )
   IIi11IIiIi1i = 0
   if 4 - 4: O00OOOoOoo0O - III1IiiI + o0Oo
  try :
   shutil . copyfile ( xbmc . translatePath ( os . path . join ( iIii1 , 'userdata' , 'profiles.xml' ) ) , xbmc . translatePath ( os . path . join ( oO0Oo , 'profiles.xml' ) ) )
   print "### Successfully copied profiles to : " + os . path . join ( oO0Oo , 'profiles.xml' )
  except :
   pass
   if 36 - 36: i11111IIIII
  iIi = os . path . join ( O0OoO000O0OO , 'script.skinshortcuts' )
  if os . path . exists ( iIi ) :
   try :
    shutil . copytree ( os . path . join ( O0OoO000O0OO , 'script.skinshortcuts' ) , os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' ) )
    if iiIIIII1i1iI == 'true' :
     print "### Successfully copied skinshortcuts to : " + os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' )
   except :
    iI111I11I1I1 . ok ( 'Failed to copy Skin Shortcuts' , 'There was an error trying to backup your script.skinshortcuts, please try again and if you continue to receive this message upload a log and send details to the noobsandnerds forum.' )
    if iiIIIII1i1iI == 'true' :
     print "### FAILED to copy skinshortcuts to: " + os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' )
     if 52 - 52: iIii1I11I1II1
  if os . path . exists ( os . path . join ( O0OoO000O0OO , OOOO0OOoO0O0 ) ) :
   try :
    shutil . copytree ( os . path . join ( O0OoO000O0OO , OOOO0OOoO0O0 ) , os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 ) )
    if iiIIIII1i1iI == 'true' :
     print "### Successfully copied skin data to : " + os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 )
   except :
    iI111I11I1I1 . ok ( 'Failed to copy skin data' , 'There was an error trying to backup your skin data, please try again and if you continue to receive this message upload a log and send details to the noobsandnerds forum.' )
    if iiIIIII1i1iI == 'true' :
     print "### FAILED to copy skin data to: " + os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 )
     if 49 - 49: iiIi1i11
  I1I1IiIi1 ( oO0Oo , IIIIiI11Ii1i )
  if 23 - 23: ii1ii11IIIiiI / i1Iii1i1I / iIii1I11I1II1
  if 44 - 44: II11iIiIIIiI . II11iIiIIIiI + OoooooooOO * i11iIiiIii / o00O0OoO + Iiii1i1
  if 17 - 17: iiIi1i11 + oO0OooOoO
  if 43 - 43: o00O0OoO % iI1IiiIIIiIi / oOO00Oo * Iiii1i1
  if iI1Ii11111iIi == 'true' :
   I1I1IiIi1 ( oO0Oo , O0oiIiiIi )
   if 85 - 85: iIii1I11I1II1 . OoooooooOO . oOO00Oo
   if 77 - 77: o0Oo % o0oOo0
  if os . path . exists ( oO0Oo ) :
   shutil . rmtree ( oO0Oo )
   if 74 - 74: O00OOOoOoo0O / i1IIi % OoooooooOO
  if IIi11IIiIi1i == 0 :
   iI111I11I1I1 . ok ( 'ERROR' , 'There was an error backing up your guisettings.xml, you cannot share a build without one so please try again. If this keeps happening please upload a log and contact the noobsandnerds forum with details.' )
   if 52 - 52: i11111IIIII % o0oOo0
  else :
   iI111I11I1I1 . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 25 - 25: o00O0OoO / o00O0OoO % OoooooooOO - OoooO0Oo0O0 * III1IiiI
   if iI1Ii11111iIi == 'true' :
    iI111I11I1I1 . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + oOoOO0000oO00 , '[/COLOR]Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + iIIiI11iI1Ii1 + '[/COLOR]' )
    if 23 - 23: i11iIiiIii
   else :
    iI111I11I1I1 . ok ( "Build Location" , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Backup (this will ONLY work for sharing on the Community Portal):[CR][COLOR=dodgerblue]' + iIIiI11iI1Ii1 + '[/COLOR]' )
    if 100 - 100: III1IiiI + O0 . o0Oo + i1IIi - O00OOOoOoo0O + oOO00Oo
    if 65 - 65: oO0OooOoO / II11iIiIIIiI
def iiII1i ( url , video ) :
 ooo0O0OOo0OoO ( )
 I1i11 = 'http://noobsandnerds.com/TI/Community_Builds/community_builds_test.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IiiiI1 = re . compile ( 'path="(.+?)"' ) . findall ( IiIi1I1 )
 I1IIIi = re . compile ( 'myart="(.+?)"' ) . findall ( IiIi1I1 )
 I1iOo00oOO00 = re . compile ( 'artpack="(.+?)"' ) . findall ( IiIi1I1 )
 IIIII1 = re . compile ( 'videopreview="(.+?)"' ) . findall ( IiIi1I1 )
 Iio0000O00oO0O = re . compile ( 'videoguide1="(.+?)"' ) . findall ( IiIi1I1 )
 IiiI111I11 = re . compile ( 'videoguide2="(.+?)"' ) . findall ( IiIi1I1 )
 oO0Ooooo000 = re . compile ( 'videoguide3="(.+?)"' ) . findall ( IiIi1I1 )
 Iii1Iiii = re . compile ( 'videoguide4="(.+?)"' ) . findall ( IiIi1I1 )
 i1i1Ii1IiIII = re . compile ( 'videoguide5="(.+?)"' ) . findall ( IiIi1I1 )
 I1IIii11 = re . compile ( 'videolabel1="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1O0O = re . compile ( 'videolabel2="(.+?)"' ) . findall ( IiIi1I1 )
 OO0ooO00o = re . compile ( 'videolabel3="(.+?)"' ) . findall ( IiIi1I1 )
 I1iii1 = re . compile ( 'videolabel4="(.+?)"' ) . findall ( IiIi1I1 )
 iIiiiIIiii = re . compile ( 'videolabel5="(.+?)"' ) . findall ( IiIi1I1 )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 OO0 = re . compile ( 'author="(.+?)"' ) . findall ( IiIi1I1 )
 o0O00oOOoo = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
 i1I1iIii11 = re . compile ( 'description="(.+?)"' ) . findall ( IiIi1I1 )
 Oo00Oo = re . compile ( 'DownloadURL="(.+?)"' ) . findall ( IiIi1I1 )
 iIiO0O = re . compile ( 'UpdateURL="(.+?)"' ) . findall ( IiIi1I1 )
 oOOoooo = re . compile ( 'UpdateDate="(.+?)"' ) . findall ( IiIi1I1 )
 O0oIi1iIiIi1I11 = re . compile ( 'UpdateDesc="(.+?)"' ) . findall ( IiIi1I1 )
 Oooo0O = re . compile ( 'updated="(.+?)"' ) . findall ( IiIi1I1 )
 ii1I11 = re . compile ( 'defaultskin="(.+?)"' ) . findall ( IiIi1I1 )
 OOO0 = re . compile ( 'skins="(.+?)"' ) . findall ( IiIi1I1 )
 I1Ii1 = re . compile ( 'videoaddons="(.+?)"' ) . findall ( IiIi1I1 )
 O0oo0oOoO00 = re . compile ( 'audioaddons="(.+?)"' ) . findall ( IiIi1I1 )
 i1ii1iIi = re . compile ( 'programaddons="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1Ii = re . compile ( 'pictureaddons="(.+?)"' ) . findall ( IiIi1I1 )
 iI1IIII1 = re . compile ( 'sources="(.+?)"' ) . findall ( IiIi1I1 )
 Oo0o = re . compile ( 'adult="(.+?)"' ) . findall ( IiIi1I1 )
 OoO000oo000o0 = re . compile ( 'guisettings="(.+?)"' ) . findall ( IiIi1I1 )
 i1Ii1I1Ii11iI = re . compile ( 'thumb="(.+?)"' ) . findall ( IiIi1I1 )
 i1ii111i = re . compile ( 'fanart="(.+?)"' ) . findall ( IiIi1I1 )
 i1ii1i1Ii11 = re . compile ( 'openelec="(.+?)"' ) . findall ( IiIi1I1 )
 if 88 - 88: Iiii1i1 % o00O0OoO - OoooooooOO + o0oOo0
 OoOiI11IiI1i1 = I1IIIi [ 0 ] if ( len ( I1IIIi ) > 0 ) else ''
 ooOoOoO0 = I1iOo00oOO00 [ 0 ] if ( len ( I1iOo00oOO00 ) > 0 ) else ''
 I11iIi1i1II11 = IiiiI1 [ 0 ] if ( len ( IiiiI1 ) > 0 ) else ''
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 Iii1II1ii = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else ''
 oOOo0oo0O = o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
 O00Oo = i1I1iIii11 [ 0 ] if ( len ( i1I1iIii11 ) > 0 ) else 'No information available'
 iiiii1II = Oooo0O [ 0 ] if ( len ( Oooo0O ) > 0 ) else ''
 ooOo00 = ii1I11 [ 0 ] if ( len ( ii1I11 ) > 0 ) else ''
 OO0III = OOO0 [ 0 ] if ( len ( OOO0 ) > 0 ) else ''
 OoO0oOO0o0O0O0O0 = I1Ii1 [ 0 ] if ( len ( I1Ii1 ) > 0 ) else ''
 iI11IiIiiII1 = O0oo0oOoO00 [ 0 ] if ( len ( O0oo0oOoO00 ) > 0 ) else ''
 I11iii1i = i1ii1iIi [ 0 ] if ( len ( i1ii1iIi ) > 0 ) else ''
 ii1i1Iii = I1I1Ii [ 0 ] if ( len ( I1I1Ii ) > 0 ) else ''
 oO00oO00O0Oo = iI1IIII1 [ 0 ] if ( len ( iI1IIII1 ) > 0 ) else ''
 OO0o0o0oo = Oo0o [ 0 ] if ( len ( Oo0o ) > 0 ) else ''
 iIiII1 = OoO000oo000o0 [ 0 ] if ( len ( OoO000oo000o0 ) > 0 ) else 'None'
 i111iii1I1 = Oo00Oo [ 0 ] if ( len ( Oo00Oo ) > 0 ) else 'None'
 iiIiII1 = iIiO0O [ 0 ] if ( len ( iIiO0O ) > 0 ) else 'None'
 ii111iI = oOOoooo [ 0 ] if ( len ( oOOoooo ) > 0 ) else 'None'
 ii11I1 = O0oIi1iIiIi1I11 [ 0 ] if ( len ( O0oIi1iIiIi1I11 ) > 0 ) else 'None'
 oO0o0O0Ooo0o = IIIII1 [ 0 ] if ( len ( IIIII1 ) > 0 ) else 'None'
 IioO0oOOO0Ooo = Iio0000O00oO0O [ 0 ] if ( len ( Iio0000O00oO0O ) > 0 ) else 'None'
 i1i1I = IiiI111I11 [ 0 ] if ( len ( IiiI111I11 ) > 0 ) else 'None'
 IiIIi1iII11I1Ii1 = oO0Ooooo000 [ 0 ] if ( len ( oO0Ooooo000 ) > 0 ) else 'None'
 o0o0 = Iii1Iiii [ 0 ] if ( len ( Iii1Iiii ) > 0 ) else 'None'
 oOo0oO = i1i1Ii1IiIII [ 0 ] if ( len ( i1i1Ii1IiIII ) > 0 ) else 'None'
 i111iiI1ii = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else 'None'
 IIiii = I1I1O0O [ 0 ] if ( len ( I1I1O0O ) > 0 ) else 'None'
 I1i1i = OO0ooO00o [ 0 ] if ( len ( OO0ooO00o ) > 0 ) else 'None'
 OOOOooO0oO00O0o = I1iii1 [ 0 ] if ( len ( I1iii1 ) > 0 ) else 'None'
 ooOO00oOOo000 = iIiiiIIiii [ 0 ] if ( len ( iIiiiIIiii ) > 0 ) else 'None'
 O0oOoo0OoO0O = i1Ii1I1Ii11iI [ 0 ] if ( len ( i1Ii1I1Ii11iI ) > 0 ) else 'None'
 oo00IiI1 = i1ii111i [ 0 ] if ( len ( i1ii111i ) > 0 ) else 'None'
 I1IoOO0o0 = i1ii1i1Ii11 [ 0 ] if ( len ( i1ii1i1Ii11 ) > 0 ) else 'None'
 if 36 - 36: i11iIiiIii + OoooO0Oo0O0 % iiIi1i11 . o0Oo - o0oOo0
 O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'w+' )
 O0OO0o0OO0OO . write ( 'id="' + str ( video ) + '"\nname="' + i1iIIIi1i + '"\nversion="' + oOOo0oo0O + '"' )
 O0OO0o0OO0OO . close ( )
 if 94 - 94: o0Oo % O00OOOoOoo0O . i11111IIIII . o0oOo0 . ii1ii11IIIiiI
 o0oO0oo = open ( I1IIiiIiii , mode = 'r' )
 ooOO00Oo = o0oO0oo . read ( )
 o0oO0oo . close ( )
 if 82 - 82: i11111IIIII
 I1I1 = re . compile ( 'id="(.+?)"' ) . findall ( ooOO00Oo )
 OOOOOOO0oo = I1I1 [ 0 ] if ( len ( I1I1 ) > 0 ) else 'None'
 iII11IiI1 = re . compile ( 'version="(.+?)"' ) . findall ( ooOO00Oo )
 I1I1IiI1 = iII11IiI1 [ 0 ] if ( len ( iII11IiI1 ) > 0 ) else 'None'
 OoOOOO00oOO , iiIIiIi , O000oO = url . partition ( '&' )
 print "### Community Build Details:"
 print "### Name: " + i1iIIIi1i
 print "### URL: " + i111iii1I1
 oO00oOOoooO ( '' , '[COLOR=yellow]IMPORTANT:[/COLOR] Install Instructions' , '' , 'instructions_2' , '' , '' , '' , '' )
 oOo00oOoO000 ( '[COLOR=yellow]Description:[/COLOR] This contains important info from the build author' , 'None' , 'description' , '' , oo00IiI1 , i1iIIIi1i , Iii1II1ii , oOOo0oo0O , O00Oo , iiiii1II , OO0III , OoO0oOO0o0O0O0O0 , iI11IiIiiII1 , I11iii1i , ii1i1Iii , oO00oO00O0Oo , OO0o0o0oo )
 if 23 - 23: oO0OooOoO * i1Iii1i1I
 if OOOOOOO0oo == OoOOOO00oOO and I1I1IiI1 != oOOo0oo0O :
  oO00oOOoooO ( '' , '[COLOR=orange]----------------- UPDATE AVAILABLE ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  o0OIiII ( '[COLOR=dodgerblue]1. Update:[/COLOR] Overwrite My Library & Profiles' , i111iii1I1 , 'update_community' , O0oOoo0OoO0O , '' , 'update' , i1iIIIi1i , ooOo00 , iIiII1 , ooOoOoO0 )
  o0OIiII ( '[COLOR=dodgerblue]2. Update:[/COLOR] Keep My Library & Profiles' , i111iii1I1 , 'update_community' , O0oOoo0OoO0O , '' , 'updatelibprofile' , i1iIIIi1i , ooOo00 , iIiII1 , ooOoOoO0 )
  o0OIiII ( '[COLOR=dodgerblue]3. Update:[/COLOR] Keep My Library Only' , i111iii1I1 , 'update_community' , O0oOoo0OoO0O , '' , 'updatelibrary' , i1iIIIi1i , ooOo00 , iIiII1 , ooOoOoO0 )
  o0OIiII ( '[COLOR=dodgerblue]4. Update:[/COLOR] Keep My Profiles Only' , i111iii1I1 , 'update_community' , O0oOoo0OoO0O , '' , 'updateprofiles' , i1iIIIi1i , ooOo00 , iIiII1 , ooOoOoO0 )
  if 80 - 80: Iiii1i1 / i11iIiiIii + OoooooooOO
 if oO0o0O0Ooo0o != 'None' or IioO0oOOO0Ooo != 'None' or i1i1I != 'None' or IiIIi1iII11I1Ii1 != 'None' or o0o0 != 'None' or oOo0oO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]------------------ VIDEO GUIDES -----------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 38 - 38: OoooO0Oo0O0 % o0oOo0 + i1IIi * OoooooooOO * III1IiiI
 if oO0o0O0Ooo0o != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] Preview[/COLOR]' , oO0o0O0Ooo0o , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 83 - 83: iIii1I11I1II1 - o0oOo0 - Iiii1i1 / ii1ii11IIIiiI - O0
 if IioO0oOOO0Ooo != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + i111iiI1ii + '[/COLOR]' , IioO0oOOO0Ooo , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 81 - 81: iI1IiiIIIiIi - III1IiiI * OoooO0Oo0O0 / Iiii1i1
 if i1i1I != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + IIiii + '[/COLOR]' , i1i1I , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 21 - 21: ii1ii11IIIiiI
 if IiIIi1iII11I1Ii1 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + I1i1i + '[/COLOR]' , IiIIi1iII11I1Ii1 , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 63 - 63: o00O0OoO . O0 * o00O0OoO + iIii1I11I1II1
 if o0o0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + OOOOooO0oO00O0o + '[/COLOR]' , o0o0 , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 46 - 46: i1IIi + oO0OooOoO * i1IIi - iI1IiiIIIiIi
 if oOo0oO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + ooOO00oOOo000 + '[/COLOR]' , oOo0oO , 'play_video' , '' , oo00IiI1 , '' , '' )
  if 79 - 79: oO0OooOoO - III1IiiI * OoooO0Oo0O0 - O00OOOoOoo0O . OoooO0Oo0O0
 if OOOOOOO0oo != OoOOOO00oOO :
  oO00oOOoooO ( '' , '[COLOR=orange]------------------ INSTALL OPTIONS ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 11 - 11: O0 * O00OOOoOoo0O
 if i111iii1I1 == 'None' :
  o0OIiII ( '[COLOR=orange]Sorry this build is currently unavailable[/COLOR]' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 37 - 37: O00OOOoOoo0O + O0 . O0 * II11iIiIIIiI % Iiii1i1 / i1Iii1i1I
 if OOOOOOO0oo != OoOOOO00oOO :
  if I1IiiiIiI ( ) and I1IoOO0o0 != 'None' :
   if 18 - 18: OoooooooOO
   o0OIiII ( '[COLOR=darkcyan]OpenELEC FRESH INSTALL[/COLOR]' , I1IoOO0o0 , 'restore_openelec' , O0oOoo0OoO0O , oo00IiI1 , iIiII1 , i1iIIIi1i , '' , '' , '' )
   if 57 - 57: o0oOo0 . O00OOOoOoo0O * oOO00Oo - OoooooooOO
   if 75 - 75: i11iIiiIii / oOO00Oo . i11111IIIII . i1IIi . i1IIi / o00O0OoO
  o0OIiII ( '[COLOR=dodgerblue]Standard Install[/COLOR]' , i111iii1I1 , 'restore_community' , O0oOoo0OoO0O , oo00IiI1 , 'merge' , i1iIIIi1i , ooOo00 , iIiII1 , ooOoOoO0 )
  if 94 - 94: o0oOo0 + o0Oo
  if 56 - 56: O00OOOoOoo0O % oOO00Oo
  if 40 - 40: iiIi1i11 / i11111IIIII
  if 29 - 29: iI1IiiIIIiIi - iI1IiiIIIiIi / o0oOo0
 if iIiII1 != 'None' :
  if 49 - 49: o00O0OoO + III1IiiI % ii1ii11IIIiiI - II11iIiIIIiI - O0 - OoooooooOO
  oO00oOOoooO ( '' , '[COLOR=dodgerblue](Optional) Apply guisettings.xml fix[/COLOR]' , iIiII1 , 'guisettingsfix' , '' , oo00IiI1 , '' , '' )
  if 4 - 4: oO0OooOoO - III1IiiI % II11iIiIIIiI * i11iIiiIii
  if 18 - 18: II11iIiIIIiI % O0
def oooooO00OOO ( url ) :
 if 53 - 53: oO0OooOoO
 OoO0oO = ''
 if url == 'create_pack' :
  OoO0oO = IiIIi1 ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' , 10 )
  Oo0O0ooo0O0O = xbmcgui . Dialog ( ) . browse ( 3 , 'Select the folder you want to store this file in' , 'files' , '' , False , False )
  Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this keyword" )
  if 13 - 13: II11iIiIIIiI / OoooO0Oo0O0
  if ( not Oo0OOo ) :
   return False , 0
   if 29 - 29: o0oOo0 * oO0OooOoO * ii1ii11IIIiiI * i11111IIIII
  I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 OOooO0OOoo . create ( 'Backing Up Addons & Repositories' , '' , 'Please Wait...' )
 if 92 - 92: III1IiiI
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 7 - 7: i1Iii1i1I
  if 73 - 73: ii1ii11IIIiiI % OoooO0Oo0O0
 for i1iIIIi1i in os . listdir ( II11iiii1Ii ) :
  if not 'metadata' in i1iIIIi1i and not 'module' in i1iIIIi1i and not 'script.common' in i1iIIIi1i and not 'packages' in i1iIIIi1i and not 'service.xbmc.versioncheck' in i1iIIIi1i and os . path . isdir ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) :
   try :
    OOooO0OOoo . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
    if 32 - 32: iiIi1i11 + i1Iii1i1I + iIii1I11I1II1 * II11iIiIIIiI
    if 62 - 62: i11iIiiIii
    if i1iIIIi1i in OoO0oO or url != 'create_pack' :
     if 2 - 2: o0Oo
     if not os . path . exists ( os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) ) :
      os . makedirs ( os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) )
     shutil . copyfile ( os . path . join ( II11iiii1Ii , i1iIIIi1i , 'addon.xml' ) , os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i , 'addon.xml' ) )
    if not i1iIIIi1i in OoO0oO :
     shutil . copytree ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) , os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) )
     if 69 - 69: OoooooooOO / II11iIiIIIiI * Iiii1i1
    Oo0o0ooO0ooo = os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i , 'addon.xml' )
    if 47 - 47: i11111IIIII
    if 76 - 76: ii1ii11IIIiiI * iIii1I11I1II1 + OoooO0Oo0O0 - o0oOo0 - o00O0OoO / i1IIi
    if 27 - 27: OoooO0Oo0O0 . i11111IIIII
    OoO = open ( Oo0o0ooO0ooo , mode = 'r' )
    i11i = OoO . read ( )
    OoO . close ( )
    if 66 - 66: O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
    if 21 - 21: i11111IIIII - o0Oo % OoooooooOO + oOO00Oo
    oOOoo = re . compile ( '<addon[\s\S]*?">' ) . findall ( i11i )
    oOoO0O0oO = oOOoo [ 0 ] if ( len ( oOOoo ) > 0 ) else 'None'
    o00O0o = re . compile ( 'version="[\s\S]*?"' ) . findall ( oOoO0O0oO )
    i1Ii1 = o00O0o [ 0 ] if ( len ( o00O0o ) > 0 ) else '0'
    if 75 - 75: OoooooooOO * i11iIiiIii
    if 67 - 67: Iiii1i1 / ii1ii11IIIiiI . OoooooooOO
    OoIIiIIIII1I = str ( oOoO0O0oO ) . replace ( i1Ii1 , 'version="0.0.0.1"' )
    iiI1IIIi = i11i . replace ( oOoO0O0oO , OoIIiIIIII1I )
    if 96 - 96: i11iIiiIii . oO0OooOoO
    IIiiiiIiIIii = open ( Oo0o0ooO0ooo , mode = 'w' )
    IIiiiiIiIIii . write ( str ( iiI1IIIi ) )
    IIiiiiIiIIii . close ( )
    if 7 - 7: i1IIi
   except :
    if iiIIIII1i1iI == 'true' :
     print "### Failed to create: " + i1iIIIi1i + ' ###'
     if 63 - 63: iIii1I11I1II1 + i11111IIIII % i1IIi / o0Oo % oO0OooOoO
 if url == 'create_pack' :
  oooOOO0ooOoOOO = [ '.svn' , '.git' ]
  o0IiIiI111IIII1 = [ '.DS_Store' , 'Thumbs.db' , '.gitignore' ]
  OO0iiiii1iiIIii = os . path . join ( Oo0O0ooo0O0O , I1II1IiI1 + '.zip' )
  oOo0OOoooO ( i1Oo00 , OO0iiiii1iiIIii , 'Creating Addons Archive' , '' , '' , '' , oooOOO0ooOoOOO , o0IiIiI111IIII1 )
  try :
   shutil . rmtree ( i1Oo00 )
  except :
   pass
  iI111I11I1I1 . ok ( 'New Keyword Created' , 'Please read the instructions on how to share this keyword with the community. Your zip file can be found at:' , '[COLOR=dodgerblue]' + OO0iiiii1iiIIii + '[/COLOR]' )
  if 8 - 8: OoooO0Oo0O0 * OoooO0Oo0O0 * i1IIi + i1Iii1i1I . OoooO0Oo0O0
  if 100 - 100: OoooooooOO - O0 . o00O0OoO / o00O0OoO + oO0OooOoO * O00OOOoOoo0O
def i11111 ( name ) :
 if 60 - 60: iiIi1i11
 O0OO0o0OO0OO = open ( I1IIiiIiii , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 O0Oo0 = re . compile ( 'name="(.+?)"' ) . findall ( i11i )
 iIIIi1IiI11I1 = O0Oo0 [ 0 ] if ( len ( O0Oo0 ) > 0 ) else 'None'
 Ii11iiI1 = [ ]
 if 73 - 73: o0oOo0
 if 86 - 86: O00OOOoOoo0O . o00O0OoO / II11iIiIIIiI * o00O0OoO
 if iIIIi1IiI11I1 == 'None' or iIIIi1IiI11I1 == 'unknown' :
  iI111I11I1I1 . ok ( 'No Profile Set' , "There's no profile name set to the build you're currently running. Please enter a name for this build so we can save it and make sure no data is lost." )
  Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
  if ( not Oo0OOo ) :
   return False , 0
  Oo0OOo = Oo0OOo . replace ( ' ' , '_' )
  I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
  os . makedirs ( os . path . join ( iiI1IiI , I1II1IiI1 ) )
  I1111I1Ii = I1II1IiI1
  O0OO0o0OO0OO = open ( I1IIiiIiii , 'w' )
  iiI1IIIi = i11i . replace ( 'id="None"' , 'id="Local"' ) . replace ( 'name="None"' , 'name="' + str ( I1111I1Ii ) + '"' )
  O0OO0o0OO0OO . write ( iiI1IIIi )
  O0OO0o0OO0OO . close ( )
  if 68 - 68: ii1ii11IIIiiI + o0Oo * oOO00Oo . III1IiiI + O00OOOoOoo0O + o0oOo0
  if 80 - 80: O00OOOoOoo0O * iiIi1i11
  for iIIii1iiiIiiI in os . listdir ( OO0o ) :
   Ii11iiI1 . append ( iIIii1iiiIiiI )
   if 67 - 67: oO0OooOoO
  iI1iii1iIiiI = open ( os . path . join ( iiI1IiI , I1II1IiI1 , 'addonlist' ) , mode = 'w+' )
  for iIIii1iiiIiiI in os . listdir ( II11iiii1Ii ) :
   if not iIIii1iiiIiiI in Ii11iiI1 and iIIii1iiiIiiI != 'plugin.program.totalinstaller' and iIIii1iiiIiiI != 'script.module.addon.common' and iIIii1iiiIiiI != 'packages' :
    iI1iii1iIiiI . write ( iIIii1iiiIiiI + '|' )
  iI1iii1iIiiI . close ( )
  if 36 - 36: ii1ii11IIIiiI - O0 * o0Oo / OoooO0Oo0O0 / iiIi1i11
  o00oo = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' ]
  iI1ii11Ii = "Creating backup of existing build"
  O0OO0OO = "Archiving..."
  Ooo0oO = ""
  IiIiIIiii1I = "Please Wait"
  oOo0OOoooO ( iIii1 , os . path . join ( iiI1IiI , I1II1IiI1 , 'build.zip' ) , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
  if 33 - 33: OoooooooOO % OoooO0Oo0O0 . O0 / OoooO0Oo0O0
  if 63 - 63: i11111IIIII + iIii1I11I1II1 + o0Oo + Iiii1i1
  if 72 - 72: ii1ii11IIIiiI + i11iIiiIii + OoooO0Oo0O0
 else :
  I1111I1Ii = iIIIi1IiI11I1 . replace ( ' ' , '_' ) . replace ( ':' , '-' ) . replace ( "'" , '' )
  if 96 - 96: III1IiiI % i1IIi / oOO00Oo
  iI1iii1iIiiI = open ( os . path . join ( iiI1IiI , I1111I1Ii , 'addonlist' ) , mode = 'w+' )
  for iIIii1iiiIiiI in os . listdir ( II11iiii1Ii ) :
   if not iIIii1iiiIiiI in Ii11iiI1 and iIIii1iiiIiiI != 'plugin.program.totalinstaller' and iIIii1iiiIiiI != 'script.module.addon.common' and iIIii1iiiIiiI != 'packages' :
    iI1iii1iIiiI . write ( iIIii1iiiIiiI + '|' )
  iI1iii1iIiiI . close ( )
  if 13 - 13: oO0OooOoO - II11iIiIIIiI % i11iIiiIii + i1Iii1i1I
  o00oo = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' ]
  iI1ii11Ii = "Creating backup of existing build"
  O0OO0OO = "Archiving..."
  Ooo0oO = ""
  IiIiIIiii1I = "Please Wait"
  oOo0OOoooO ( iIii1 , os . path . join ( iiI1IiI , I1111I1Ii , 'build.zip' ) , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
 return I1111I1Ii
 if 88 - 88: O0 . III1IiiI % o0Oo
 if 10 - 10: o0Oo + O0
def Oooo0Oo00o ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 IIoO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 13 - 13: i1IIi
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( IIoO ) :
  O0OOOo0Oo0 = 0
  O0OOOo0Oo0 += len ( I1iiIi111I )
  if 55 - 55: iiIi1i11 / O00OOOoOoo0O * iiIi1i11
  if O0OOOo0Oo0 >= 0 :
   if 40 - 40: ii1ii11IIIiiI . i11iIiiIii + OoooO0Oo0O0 + o0Oo . III1IiiI
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
    if 90 - 90: Iiii1i1 . O00OOOoOoo0O * oO0OooOoO % o0oOo0
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
    if 36 - 36: o0Oo - II11iIiIIIiI % iiIi1i11 . o00O0OoO + o00O0OoO + iI1IiiIIIiIi
    if 28 - 28: II11iIiIIIiI / III1IiiI * O00OOOoOoo0O + OoooO0Oo0O0 - Iiii1i1
def Oo0Ii1iii ( ) :
 for o000o0o00Oo in glob . glob ( os . path . join ( O0Oo000ooO00 , 'xbmc_crashlog*.*' ) ) :
  oo0O00o0O0Oo = o000o0o00Oo
  os . remove ( o000o0o00Oo )
  iI111I11I1I1 = xbmcgui . Dialog ( )
  iI111I11I1I1 . ok ( "Crash Logs Deleted" , "Your old crash logs have now been deleted." )
  if 26 - 26: i1IIi / i1Iii1i1I . i1Iii1i1I
  if 20 - 20: iiIi1i11 - i1Iii1i1I / II11iIiIIIiI * ii1ii11IIIiiI
def Oo ( ) :
 print '############################################################       DELETING PACKAGES             ###############################################################'
 o00O = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 if 50 - 50: O00OOOoOoo0O - III1IiiI + iIii1I11I1II1 - ii1ii11IIIiiI . II11iIiIIIiI
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( o00O ) :
  O0OOOo0Oo0 = 0
  O0OOOo0Oo0 += len ( I1iiIi111I )
  if 8 - 8: iI1IiiIIIiIi
  if O0OOOo0Oo0 > 0 :
   if 30 - 30: i1IIi
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
    if 61 - 61: Iiii1i1 / Iiii1i1
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
    if 26 - 26: i11111IIIII . O0 * i11111IIIII - oOO00Oo * II11iIiIIIiI
    if 6 - 6: O00OOOoOoo0O . oO0OooOoO * o0Oo . o0Oo / iI1IiiIIIiIi
def I1I1ii1111 ( path ) :
 iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Are you certain?' , 'This will completely wipe this folder, are you absolutely certain you want to continue? There is NO going back after this!' )
 if iII1Iii1I11i == 1 :
  OOooO0OOoo . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
  shutil . rmtree ( path , ignore_errors = True )
  OOooO0OOoo . close ( )
  xbmc . executebuiltin ( 'container.Refresh' )
  if 4 - 4: OoooO0Oo0O0 * O0 - Iiii1i1 - i11iIiiIii / oOO00Oo . iiIi1i11
  if 44 - 44: o0oOo0 * i11iIiiIii
def II111Ii11II ( url ) :
 for i1iIIIi1i in os . listdir ( iiI1IiI ) :
  if i1iIIIi1i != 'Master' and i1iIIIi1i != url . replace ( ' ' , '_' ) . replace ( "'" , '' ) . replace ( ':' , '-' ) :
   oO00oOOoooO ( '' , '[COLOR=darkcyan]DELETE[/COLOR] ' + i1iIIIi1i . replace ( '_' , ' ' ) , os . path . join ( iiI1IiI , i1iIIIi1i ) , 'delete_path' , '' , '' , '' , '' )
   if 14 - 14: o0oOo0 * OoooooooOO + ii1ii11IIIiiI
   if 6 - 6: i1IIi - o00O0OoO
def O0o00ooo ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 IIoO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 5 - 5: i1IIi - III1IiiI / O00OOOoOoo0O
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( IIoO ) :
  O0OOOo0Oo0 = 0
  O0OOOo0Oo0 += len ( I1iiIi111I )
  if 13 - 13: oO0OooOoO
  if O0OOOo0Oo0 >= 0 :
   if 55 - 55: II11iIiIIIiI % i1IIi * o00O0OoO
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
    if 95 - 95: iiIi1i11 / oO0OooOoO - oOO00Oo % Iiii1i1 . o00O0OoO
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
    if 63 - 63: iIii1I11I1II1 / o0oOo0
    if 24 - 24: II11iIiIIIiI / iIii1I11I1II1 % iiIi1i11 * O00OOOoOoo0O - iIii1I11I1II1
def O000OOo00oo ( ) :
 OOooO0OOoo . create ( 'Checking dependencies' , '' , 'Please Wait...' )
 oo0OOo = [ ]
 if 50 - 50: oO0OooOoO
 for i1iIIIi1i in os . listdir ( II11iiii1Ii ) :
  if i1iIIIi1i != 'packages' :
   try :
    iI1iIIiiii = os . path . join ( II11iiii1Ii , i1iIIIi1i , 'addon.xml' )
    i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
    OOooo0O00o = i1iI11i1ii11 . read ( )
    i1iI11i1ii11 . close ( )
    oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
    if 39 - 39: oO0OooOoO . O00OOOoOoo0O - II11iIiIIIiI * i1IIi . OoooooooOO
    for OOoO00 in oOOoOooOo :
     if 44 - 44: o0Oo
     if not 'xbmc.python' in OOoO00 and not OOoO00 in oo0OOo :
      oo0OOo . append ( OOoO00 )
      print 'Script Requires --- ' + OOoO00
   except :
    pass
    if 55 - 55: III1IiiI . Iiii1i1 * Iiii1i1
 return oo0OOo
 if 82 - 82: o0Oo % ii1ii11IIIiiI % o00O0OoO + o00O0OoO
 if 6 - 6: II11iIiIIIiI
def iii11II1I ( name , addon_id ) :
 Ii1I11I = 1
 o00o = 1
 iI1iIIiiii = xbmc . translatePath ( os . path . join ( II11iiii1Ii , addon_id , 'addon.xml' ) )
 i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
 OOooo0O00o = i1iI11i1ii11 . read ( )
 i1iI11i1ii11 . close ( )
 oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
 if 73 - 73: Iiii1i1 * OoooO0Oo0O0 + oOO00Oo - II11iIiIIIiI . o00O0OoO
 for OOoO00 in oOOoOooOo :
  if 93 - 93: i11iIiiIii
  if not 'xbmc.python' in OOoO00 :
   print 'Script Requires --- ' + OOoO00
   OoOiII11IiIi = xbmc . translatePath ( os . path . join ( II11iiii1Ii , OOoO00 ) )
   if 27 - 27: ii1ii11IIIiiI + O00OOOoOoo0O
   if not os . path . exists ( OoOiII11IiIi ) :
    I1i11 = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( OOoO00 )
    IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
    o0O00oOOoo = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
    IiI111ii1ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IiIi1I1 )
    O0OOo = re . compile ( 'data_url="(.+?)"' ) . findall ( IiIi1I1 )
    IiIII1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( IiIi1I1 )
    OO0O0OOo0O = re . compile ( 'repo_id="(.+?)"' ) . findall ( IiIi1I1 )
    ooo0oOooo0o0 = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
    oOOo0oo0O = o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
    IIii1Ii1i1ii1 = IiI111ii1ii [ 0 ] if ( len ( IiI111ii1ii ) > 0 ) else ''
    oOOoOOooO0 = O0OOo [ 0 ] if ( len ( O0OOo ) > 0 ) else ''
    Iii1IIII1Iii = IiIII1 [ 0 ] if ( len ( IiIII1 ) > 0 ) else ''
    OOOOOOo0o0O0o = OO0O0OOo0O [ 0 ] if ( len ( OO0O0OOo0O ) > 0 ) else ''
    IIII = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , ooo0oOooo0o0 + '.zip' ) )
    if 42 - 42: oOO00Oo * O00OOOoOoo0O . ii1ii11IIIiiI - i1Iii1i1I / oO0OooOoO
    OOooO0OOoo . create ( 'Downloading Dependencies' , 'Installing [COLOR=yellow]' + ooo0oOooo0o0 , '' , '' )
    if 25 - 25: II11iIiIIIiI % O00OOOoOoo0O
    try :
     downloader . download ( IIii1Ii1i1ii1 , IIII , OOooO0OOoo )
     extract . all ( IIII , II11iiii1Ii , OOooO0OOoo )
     if 75 - 75: i1IIi
    except :
     if 74 - 74: II11iIiIIIiI + Iiii1i1 - III1IiiI - ii1ii11IIIiiI + i1Iii1i1I - iIii1I11I1II1
     try :
      downloader . download ( Iii1IIII1Iii , IIII , OOooO0OOoo )
      extract . all ( IIII , II11iiii1Ii , OOooO0OOoo )
      if 54 - 54: OoooO0Oo0O0 + oO0OooOoO . o0Oo / ii1ii11IIIiiI . o0oOo0
     except :
      if 58 - 58: i11111IIIII % i11iIiiIii * oO0OooOoO . OoooO0Oo0O0
      try :
       if 94 - 94: i11iIiiIii . iiIi1i11 + iIii1I11I1II1 * Iiii1i1 * Iiii1i1
       if not os . path . exists ( OoOiII11IiIi ) :
        os . makedirs ( OoOiII11IiIi )
        if 36 - 36: o00O0OoO - i11111IIIII . i11111IIIII
       IiIi1I1 = IiIIi1 ( oOOoOOooO0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
       o0OO000ooOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IiIi1I1 )
       if 60 - 60: i11iIiiIii * II11iIiIIIiI % ii1ii11IIIiiI + ii1ii11IIIiiI
       for OooO0oOo in o0OO000ooOo :
        oOOo00O0OOOo = xbmc . translatePath ( os . path . join ( OoOiII11IiIi , OooO0oOo ) )
        if 84 - 84: iIii1I11I1II1 + OoooooooOO
        if addon_id not in OooO0oOo and '/' not in OooO0oOo :
         if 77 - 77: O0 * OoooO0Oo0O0 * III1IiiI + ii1ii11IIIiiI + OoooO0Oo0O0 - Iiii1i1
         try :
          OOooO0OOoo . update ( 0 , '' , 'Downloading [COLOR=yellow]' + OooO0oOo + '[/COLOR]' , 'Please wait...' )
          downloader . download ( oOOoOOooO0 + OooO0oOo , oOOo00O0OOOo , OOooO0OOoo )
          if 10 - 10: OoooO0Oo0O0 + i11111IIIII
         except :
          print "failed to install" + OooO0oOo
          if 58 - 58: o0Oo + OoooooooOO / i1Iii1i1I . o0oOo0 % oOO00Oo / OoooO0Oo0O0
        if '/' in OooO0oOo and '..' not in OooO0oOo and 'http' not in OooO0oOo :
         O0O00OOo = oOOoOOooO0 + OooO0oOo
         OoOOo ( oOOo00O0OOOo , O0O00OOo )
         if 62 - 62: oO0OooOoO
      except :
       iI111I11I1I1 . ok ( "Error downloading dependency" , 'There was an error downloading [COLOR=dodgerblue]' + ooo0oOooo0o0 + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
       o00o = 0
       Ii1I11I = 0
       if 12 - 12: i11111IIIII + oO0OooOoO
    if o00o == 1 :
     time . sleep ( 1 )
     OOooO0OOoo . update ( 0 , "[COLOR=yellow]" + ooo0oOooo0o0 + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Please wait...' )
     time . sleep ( 1 )
     II1i111 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( OOoO00 )
     try :
      IiIIi1 ( II1i111 , 5 )
     except :
      pass
 OOooO0OOoo . close ( )
 time . sleep ( 1 )
 if 92 - 92: Iiii1i1 % iIii1I11I1II1 - i1Iii1i1I / i11iIiiIii % o0oOo0 * oOO00Oo
 if 80 - 80: i1Iii1i1I
def iI1I1ii11IIi1 ( name , url , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 OOooO0OO0 ( buildname + '     v.' + version , '[COLOR=yellow][B]Author:   [/B][/COLOR]' + author + '[COLOR=yellow][B]               Last Updated:   [/B][/COLOR]' + updated + '[COLOR=yellow][B]               Adult Content:   [/B][/COLOR]' + adult + '[CR][CR][COLOR=yellow][B]Description:[CR][/B][/COLOR]' + description +
 '[CR][CR][COLOR=blue][B]Skins:   [/B][/COLOR]' + skins + '[CR][CR][COLOR=blue][B]Video Addons:   [/B][/COLOR]' + videoaddons + '[CR][CR][COLOR=blue][B]Audio Addons:   [/B][/COLOR]' + audioaddons +
 '[CR][CR][COLOR=blue][B]Program Addons:   [/B][/COLOR]' + programaddons + '[CR][CR][COLOR=blue][B]Picture Addons:   [/B][/COLOR]' + pictureaddons + '[CR][CR][COLOR=blue][B]Sources:   [/B][/COLOR]' + sources +
 '[CR][CR][COLOR=orange]Disclaimer: [/COLOR]These are community builds and they may overwrite some of your existing settings, '
 'It\'s purely the responsibility of the user to choose whether or not they wish to install these builds, the individual who uploads the build should state what\'s included and then it\'s the users decision to decide whether or not that content is suitable for them.' )
 if 100 - 100: II11iIiIIIiI . iI1IiiIIIiIi . o0Oo % oO0OooOoO - III1IiiI
 if 52 - 52: o0Oo % ii1ii11IIIiiI * iI1IiiIIIiIi * i1Iii1i1I / iiIi1i11
def oooO00oo0 ( path ) :
 OOooO0OOoo . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
 shutil . rmtree ( path , ignore_errors = True )
 if 74 - 74: i11111IIIII / o0oOo0
def iIiIi1iIIi11i ( ) :
 os . remove ( I1IIiiIiii )
 os . rename ( i1I1iI , I1IIiiIiii )
 xbmc . executebuiltin ( 'UnloadSkin' )
 xbmc . executebuiltin ( "ReloadSkin" )
 iI111I11I1I1 . ok ( "Local Restore Complete" , 'XBMC/Kodi will now close.' , '' , '' )
 xbmc . executebuiltin ( "Quit" )
 if 86 - 86: O0 . i1IIi - ii1ii11IIIiiI / II11iIiIIIiI / OoooO0Oo0O0
 if 64 - 64: OoooooooOO - i1IIi / oO0OooOoO
def ii1OO0 ( url ) :
 OOooO0OOoo . create ( "Changing Physical Paths To Special" , "Renaming paths..." , '' , 'Please Wait' )
 if 49 - 49: II11iIiIIIiI + O0 + i11111IIIII . oO0OooOoO % o0oOo0
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( url ) :
  if 33 - 33: O00OOOoOoo0O . iIii1I11I1II1 / o00O0OoO % iI1IiiIIIiIi
  for file in I1iiIi111I :
   if 49 - 49: ii1ii11IIIiiI + oO0OooOoO / i11111IIIII - O0 % iI1IiiIIIiIi
   if file . endswith ( ".xml" ) or file . endswith ( ".hash" ) or file . endswith ( "properies" ) :
    OOooO0OOoo . update ( 0 , "Fixing" , file , 'Please Wait' )
    ii1oOOO0ooOO = open ( ( os . path . join ( IiiI111 , file ) ) ) . read ( )
    iII1i1 = iIii1 . replace ( ':' , '%3a' ) . replace ( '\\' , '%5c' )
    IIIii = iIii1 . replace ( '\\' , '\\\\' )
    OoOo00o00 = ii1oOOO0ooOO . replace ( iIii1 , 'special://home/' ) . replace ( iII1i1 , 'special://home/' ) . replace ( IIIii , 'special://home/' )
    iiI1iii = open ( ( os . path . join ( IiiI111 , file ) ) , mode = 'w' )
    iiI1iii . write ( str ( OoOo00o00 ) )
    iiI1iii . close ( )
    if 77 - 77: oOO00Oo - OoooooooOO + oOO00Oo . i11111IIIII
    if 23 - 23: o0Oo * o00O0OoO / i11iIiiIii * Iiii1i1 . iIii1I11I1II1
def iii ( ) :
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
 o00oo = [ ]
 O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
 iI1ii11Ii = "Creating full backup of existing build"
 OOOoOooO000oO = "Creating Community Build"
 O0OO0OO = "Archiving..."
 Ooo0oO = ""
 IiIiIIiii1I = "Please Wait"
 if 78 - 78: iIii1I11I1II1 / iI1IiiIIIiIi
 oOo0OOoooO ( iIii1 , myfullbackup , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
 if 66 - 66: o00O0OoO
def i1o0 ( ) :
 o0oOooOooo = 0
 Iii1II1 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
 oOiii1IiII = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
 o0oo0OooOO0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 oooOooOOo00 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 OOo0O = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 Oooo0oO0oOo0O = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 OoOo00 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 OOoOoO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 OO000 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 o0oOoo0o = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 IiiIiIIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
 O00OooOOoo = os . path . join ( iIii1 , 'temp' )
 OOooO0OOoo . create ( 'Calculating Used Space' , '' , 'Please wait' , '' )
 if 74 - 74: iIii1I11I1II1 / iI1IiiIIIiIi
 if 59 - 59: iI1IiiIIIiIi / oO0OooOoO - i11111IIIII % O00OOOoOoo0O % OoooooooOO
 if os . path . exists ( Iii1II1 ) :
  o0oOooOooo = O0oI1iII ( Iii1II1 , o0oOooOooo )
 if os . path . exists ( oOiii1IiII ) :
  o0oOooOooo = O0oI1iII ( oOiii1IiII , o0oOooOooo )
 if os . path . exists ( o0oo0OooOO0 ) :
  o0oOooOooo = O0oI1iII ( o0oo0OooOO0 , o0oOooOooo )
 if os . path . exists ( oooOooOOo00 ) :
  o0oOooOooo = O0oI1iII ( oooOooOOo00 , o0oOooOooo )
 if os . path . exists ( OOo0O ) :
  o0oOooOooo = O0oI1iII ( OOo0O , o0oOooOooo )
 if os . path . exists ( Oooo0oO0oOo0O ) :
  o0oOooOooo = O0oI1iII ( Oooo0oO0oOo0O , o0oOooOooo )
 if os . path . exists ( OoOo00 ) :
  o0oOooOooo = O0oI1iII ( OoOo00 , o0oOooOooo )
 if os . path . exists ( OOoOoO ) :
  o0oOooOooo = O0oI1iII ( OOoOoO , o0oOooOooo )
 if os . path . exists ( OO000 ) :
  o0oOooOooo = O0oI1iII ( OO000 , o0oOooOooo )
 if os . path . exists ( o0oOoo0o ) :
  o0oOooOooo = O0oI1iII ( o0oOoo0o , o0oOooOooo )
 if os . path . exists ( IiiIiIIi ) :
  o0oOooOooo = O0oI1iII ( IiiIiIIi , o0oOooOooo )
 if os . path . exists ( O00OooOOoo ) :
  o0oOooOooo = O0oI1iII ( O00OooOOoo , o0oOooOooo )
 o0oOooOooo = O0oI1iII ( OooO0 , o0oOooOooo )
 o0oOooOooo = O0oI1iII ( O00O0oOO00O00 , o0oOooOooo ) / 1000000
 iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Results' , 'You can free up [COLOR=dodgerblue]' + str ( o0oOooOooo ) + 'MB[/COLOR] of space if you run this cleanup program. Would you like to run the cleanup procedure?' )
 if iII1Iii1I11i == 1 :
  ooO0 ( )
  try :
   shutil . rmtree ( O00O0oOO00O00 )
  except :
   pass
  iII1Iii1I11i = iI111I11I1I1 . yesno ( 'Thumbnail Cleanup' , 'We highly recommend only wiping your OLD unused thumbnails. Do you want to clear just the old ones or all thumbnails?' , yeslabel = 'ALL' , nolabel = 'OLD ONLY' )
  if iII1Iii1I11i == 1 :
   ooOOOOoO ( )
   oooO00oo0 ( OooO0 )
   O00000OO00OO ( )
  else :
   IiI1Ii1ii ( )
   if 35 - 35: II11iIiIIIiI
   if 47 - 47: i1IIi % o0oOo0 - II11iIiIIIiI * o00O0OoO / i11iIiiIii
def Iii1Iii ( url ) :
 oO00oOOoooO ( 'folder' , 'Anime' , str ( url ) + '&genre=anime' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audiobooks' , str ( url ) + '&genre=audiobooks' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comedy' , str ( url ) + '&genre=comedy' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comics' , str ( url ) + '&genre=comics' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Documentary' , str ( url ) + '&genre=documentary' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Downloads' , str ( url ) + '&genre=downloads' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Food' , str ( url ) + '&genre=food' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Gaming' , str ( url ) + '&genre=gaming' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Health' , str ( url ) + '&genre=health' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'How To...' , str ( url ) + '&genre=howto' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Kids' , str ( url ) + '&genre=kids' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Live TV' , str ( url ) + '&genre=livetv' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Movies' , str ( url ) + '&genre=movies' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Music' , str ( url ) + '&genre=music' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'News' , str ( url ) + '&genre=news' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Photos' , str ( url ) + '&genre=photos' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Podcasts' , str ( url ) + '&genre=podcasts' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Radio' , str ( url ) + '&genre=radio' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Religion' , str ( url ) + '&genre=religion' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Space' , str ( url ) + '&genre=space' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Sports' , str ( url ) + '&genre=sports' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Technology' , str ( url ) + '&genre=tech' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Trailers' , str ( url ) + '&genre=trailers' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'TV Shows' , str ( url ) + '&genre=tv' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Misc.' , str ( url ) + '&genre=other' , 'grab_builds' , '' , '' , '' , '' )
 if 48 - 48: iiIi1i11
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  oO00oOOoooO ( 'folder' , 'XXX' , str ( url ) + '&genre=adult' , 'grab_builds' , '' , '' , '' , '' )
  if 26 - 26: i1Iii1i1I * Iiii1i1 * III1IiiI * O00OOOoOoo0O
  if 48 - 48: i1Iii1i1I % i11iIiiIii . OoooooooOO * i11111IIIII % ii1ii11IIIiiI . i1Iii1i1I
def O0oI1iII ( path , size ) :
 for IiOOo0 , o0O0O0O00o , OoOooOo00o in os . walk ( path ) :
  for iiI1iii in OoOooOo00o :
   OOooO0OOoo . update ( 0 , "Calulating..." , '[COLOR=dodgerblue]' + iiI1iii + '[/COLOR]' , 'Please Wait' )
   iI1IIi = os . path . join ( IiOOo0 , iiI1iii )
   size += os . path . getsize ( iI1IIi )
 return size
 if 10 - 10: OoooO0Oo0O0 / iI1IiiIIIiIi * i1IIi % O0 + o00O0OoO
def i1II11I11ii1 ( default = "" , heading = "" , hidden = False ) :
 I1i1ii1ii = xbmc . Keyboard ( default , heading , hidden )
 if 32 - 32: i11111IIIII / OoooooooOO
 I1i1ii1ii . doModal ( )
 if ( I1i1ii1ii . isConfirmed ( ) ) :
  return unicode ( I1i1ii1ii . getText ( ) , "utf-8" )
 return default
 if 30 - 30: O00OOOoOoo0O / o0Oo - ii1ii11IIIiiI - i1Iii1i1I - i11iIiiIii
 if 84 - 84: i1IIi - o0Oo % i1Iii1i1I
def oO00o0oOoo ( ) :
 oOOI1 = [ ]
 OOI1i = sys . argv [ 2 ]
 if len ( OOI1i ) >= 2 :
  i1II1iII1 = sys . argv [ 2 ]
  I11II11IiI11 = i1II1iII1 . replace ( '?' , '' )
  if ( i1II1iII1 [ len ( i1II1iII1 ) - 1 ] == '/' ) :
   i1II1iII1 = i1II1iII1 [ 0 : len ( i1II1iII1 ) - 2 ]
  O00o = I11II11IiI11 . split ( '&' )
  oOOI1 = { }
  for Ii11Iiii1iiii in range ( len ( O00o ) ) :
   i1IIII1111 = { }
   i1IIII1111 = O00o [ Ii11Iiii1iiii ] . split ( '=' )
   if ( len ( i1IIII1111 ) ) == 2 :
    oOOI1 [ i1IIII1111 [ 0 ] ] = i1IIII1111 [ 1 ]
    if 84 - 84: O0 % iI1IiiIIIiIi . iI1IiiIIIiIi . i1Iii1i1I * o00O0OoO
 return oOOI1
 if 43 - 43: O00OOOoOoo0O . OoooO0Oo0O0 % i1IIi
def OO0O00 ( ) :
 I11iIi1i1II11 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 OOooO0OOoo = xbmcgui . DialogProgress ( )
 OOooO0OOoo . create ( "Gotham Addon Fix" , "Please wait whilst your addons" , '' , 'are being made Gotham compatible.' )
 if 65 - 65: OoooooooOO
 for o000o0o00Oo in glob . glob ( os . path . join ( I11iIi1i1II11 , '*.*' ) ) :
  if 22 - 22: iiIi1i11 + oO0OooOoO + II11iIiIIIiI
  for file in glob . glob ( os . path . join ( o000o0o00Oo , '*.*' ) ) :
   if 83 - 83: o0oOo0
   if 'addon.xml' in file :
    OOooO0OOoo . update ( 0 , "Fixing" , file , 'Please Wait' )
    ii1oOOO0ooOO = open ( file ) . read ( )
    OoOo00o00 = ii1oOOO0ooOO . replace ( 'addon="xbmc.python" version="1.0"' , 'addon="xbmc.python" version="2.1.0"' ) . replace ( 'addon="xbmc.python" version="2.0"' , 'addon="xbmc.python" version="2.1.0"' )
    iiI1iii = open ( file , mode = 'w' )
    iiI1iii . write ( str ( OoOo00o00 ) )
    iiI1iii . close ( )
    if 43 - 43: iiIi1i11
 iI111I11I1I1 = xbmcgui . Dialog ( )
 iI111I11I1I1 . ok ( "Your addons have now been made compatible" , "If you still find you have addons that aren't working please run the addon so it throws up a script error, upload a log and post details on the relevant support forum." )
 if 84 - 84: iiIi1i11 . i11111IIIII . i1Iii1i1I
 if 2 - 2: II11iIiIIIiI - O00OOOoOoo0O
def I1iiII ( ) :
 iI111I11I1I1 = xbmcgui . Dialog ( )
 oOOOO0 = xbmcgui . Dialog ( ) . yesno ( 'Convert Addons To Gotham' , 'This will edit your addon.xml files so they show as Gotham compatible. It\'s doubtful this will have any effect on whether or not they work but it will get rid of the annoying incompatible pop-up message. Do you wish to continue?' )
 if 99 - 99: iiIi1i11 + o0Oo . OoooO0Oo0O0 * OoooooooOO
 if oOOOO0 == 1 :
  OO0O00 ( )
  if 82 - 82: i11iIiiIii + iIii1I11I1II1 / II11iIiIIIiI + iiIi1i11 * oO0OooOoO
  if 34 - 34: oOO00Oo % OoooooooOO
def iIIIi ( url ) :
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  OO0o0o0oo = 'yes'
  if 74 - 74: O0 . o00O0OoO
 else :
  OO0o0o0oo = 'no'
  if 64 - 64: o0oOo0 / i1IIi % i1Iii1i1I
 if url == 'popular' :
  OOoOo0O0 = 'http://noobsandnerds.com/TI/AddonPortal/popular.php?adult=%s' % ( OO0o0o0oo )
 elif url == 'latest' :
  OOoOo0O0 = 'http://noobsandnerds.com/TI/AddonPortal/latest.php?adult=%s' % ( OO0o0o0oo )
 elif url != 'popular' and url != 'latest' :
  OOoOo0O0 = 'http://noobsandnerds.com/TI/AddonPortal/sortby_bak.php?sortx=name&user=%s&adult=%s&%s' % ( i1i1II , OO0o0o0oo , url )
  if not "desc" in url :
   url = url + '&desc='
  if not "genre" in url :
   url = url + '&genre='
 print "URL: " + OOoOo0O0
 if 39 - 39: Iiii1i1 . ii1ii11IIIiiI % o0oOo0 . iiIi1i11 / i1Iii1i1I * ii1ii11IIIiiI
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 12 - 12: o0Oo / oOO00Oo
 if 86 - 86: II11iIiIIIiI % O00OOOoOoo0O
 o0OO000ooOo = re . compile ( 'name="(.+?)"  <br> downloads="(.+?)"  <br> icon="(.+?)"  <br> broken="(.+?)"  <br> UID="(.+?)"  <br>' , re . DOTALL ) . findall ( IiIi1I1 )
 if o0OO000ooOo == [ ] :
  if 77 - 77: iI1IiiIIIiIi % iiIi1i11 / III1IiiI
  o0OO000ooOo = re . compile ( 'name="(.+?)" <br> downloads="(.+?)" <br> icon="(.+?)" <br> broken="(.+?)" <br> UID="(.+?)" <br>' , re . DOTALL ) . findall ( IiIi1I1 )
  if 91 - 91: ii1ii11IIIiiI / ii1ii11IIIiiI . oO0OooOoO . o0oOo0 - o0Oo
 if o0OO000ooOo != [ ] and url != 'popular' and url != 'latest' :
  iii11 ( OOoOo0O0 , 'addons' )
  if 59 - 59: II11iIiIIIiI / i11iIiiIii * o0Oo + ii1ii11IIIiiI
  for i1iIIIi1i , O0OOO0OOooo00 , I1iii , ii1ii111 , I11iIIIIi1Iii1iIi in o0OO000ooOo :
   if 36 - 36: i11iIiiIii * OoooO0Oo0O0 * O00OOOoOoo0O
   if ii1ii111 == '0' :
    oO00oOOoooO ( 'addonfolder' , i1iIIIi1i + '[COLOR=lime] [' + O0OOO0OOooo00 + ' downloads][/COLOR]' , I11iIIIIi1Iii1iIi , 'addon_final_menu' , I1iii , '' , '' )
    if 24 - 24: III1IiiI . O0 * o0oOo0 / OoooooooOO - iI1IiiIIIiIi . o00O0OoO
   if ii1ii111 == '1' :
    oO00oOOoooO ( 'addonfolder' , '[COLOR=red]' + i1iIIIi1i + ' [REPORTED AS BROKEN][/COLOR]' , I11iIIIIi1Iii1iIi , 'addon_final_menu' , I1iii , '' , '' )
    if 41 - 41: ii1ii11IIIiiI % o0Oo - II11iIiIIIiI
 elif o0OO000ooOo != [ ] and ( url == 'popular' or url == 'latest' ) :
  for i1iIIIi1i , O0OOO0OOooo00 , I1iii , ii1ii111 , I11iIIIIi1Iii1iIi in o0OO000ooOo :
   if 11 - 11: iI1IiiIIIiIi * oOO00Oo / i11111IIIII + O00OOOoOoo0O + ii1ii11IIIiiI % Iiii1i1
   if ii1ii111 == '0' :
    oO00oOOoooO ( 'addonfolder' , i1iIIIi1i + '[COLOR=lime] [' + O0OOO0OOooo00 + ' downloads][/COLOR]' , I11iIIIIi1Iii1iIi , 'addon_final_menu' , I1iii , '' , '' )
    if 18 - 18: o0Oo - O00OOOoOoo0O
   if ii1ii111 == '1' :
    oO00oOOoooO ( 'addonfolder' , '[COLOR=red]' + i1iIIIi1i + ' [REPORTED AS BROKEN][/COLOR]' , I11iIIIIi1Iii1iIi , 'addon_final_menu' , I1iii , '' , '' )
    if 18 - 18: iiIi1i11 + ii1ii11IIIiiI * III1IiiI - III1IiiI . OoooO0Oo0O0 * o00O0OoO
 elif '&redirect' in url :
  iII1Iii1I11i = iI111I11I1I1 . yesno ( 'No Content Found' , 'This add-on cannot be found on the Add-on Portal.' , '' , 'Would you like to remove this item from your setup?' )
  if 95 - 95: OoooO0Oo0O0 / O00OOOoOoo0O
  if iII1Iii1I11i == 1 :
   print "### Need to add remove function to code still"
   if 10 - 10: i11111IIIII % OoooO0Oo0O0 - i11111IIIII
 else :
  iI111I11I1I1 . ok ( 'No Content Found' , 'Sorry no content can be found that matches' , 'your search criteria.' , '' )
  if 86 - 86: II11iIiIIIiI
  if 88 - 88: Iiii1i1 * o0Oo
def IIiI ( url ) :
 if zip == '' :
  iI111I11I1I1 . ok ( 'Storage/Download Folder Not Set' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' , '' , '' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  if 99 - 99: oOO00Oo * III1IiiI . Iiii1i1 / O00OOOoOoo0O . o0oOo0
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  OO0o0o0oo = ''
  if 1 - 1: iiIi1i11
 else :
  OO0o0o0oo = 'no'
  if 87 - 87: O0 * oO0OooOoO + iIii1I11I1II1 % III1IiiI % i11iIiiIii - O00OOOoOoo0O
 if 'genre' in url :
  OOoOo0O0 = 'http://noobsandnerds.com/TI/Community_Builds/sort_by_test.php?sortx=name&orderx=ASC&adult=%s&%s' % ( OO0o0o0oo , url )
 else :
  OOoOo0O0 = 'http://noobsandnerds.com/TI/Community_Builds/sort_by_test.php?sortx=name&orderx=ASC&genre=&adult=%s&%s' % ( OO0o0o0oo , url )
 print "BUILD URL: " + OOoOo0O0
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 73 - 73: i1Iii1i1I + iI1IiiIIIiIi
 o0OO000ooOo = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> Thumbnail="(.+?)"  <br> Fanart="(.+?)"  <br> downloads="(.+?)"  <br> <br>' , re . DOTALL ) . findall ( IiIi1I1 )
 if o0OO000ooOo == [ ] :
  if 37 - 37: III1IiiI - iIii1I11I1II1 + oO0OooOoO . iI1IiiIIIiIi % iIii1I11I1II1
  o0OO000ooOo = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> Thumbnail="(.+?)" <br> Fanart="(.+?)" <br> downloads="(.+?)" <br> <br>' , re . DOTALL ) . findall ( IiIi1I1 )
 iii11 ( url , 'communitybuilds' )
 if 17 - 17: Iiii1i1 + i1IIi % O0
 for i1iIIIi1i , id , oOoooO00OO0o , iIi1iI , O0OOO0OOooo00 in o0OO000ooOo :
  o0OIiII ( i1iIIIi1i + '[COLOR=lime] (' + O0OOO0OOooo00 + ' downloads)[/COLOR]' , id + url , 'community_menu' , oOoooO00OO0o , iIi1iI , id , '' , '' , '' , '' )
  if 48 - 48: o00O0OoO / iIii1I11I1II1 % oO0OooOoO
 if 'id=1' in url : OOoOo0O0 = Oo0o0000o0o0
 if 'id=2' in url : OOoOo0O0 = oO0o0o0ooO0oO
 if 'id=3' in url : OOoOo0O0 = oO
 if 'id=4' in url : OOoOo0O0 = oooOOOOO
 if 'id=5' in url : OOoOo0O0 = i1iIIi1
 if 39 - 39: i1IIi . OoooO0Oo0O0 / o00O0OoO / o00O0OoO
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0OO000ooOo = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( IiIi1I1 )
 if 100 - 100: OoooooooOO - OoooooooOO + i11111IIIII
 for i1iIIIi1i , url , O0oOoo0OoO0O , oo00IiI1 , O00Oo in o0OO000ooOo :
  if not 'viewport' in i1iIIIi1i :
   oO00oOOoooO ( 'addon' , i1iIIIi1i , url , 'restore_local_CB' , O0oOoo0OoO0O , oo00IiI1 , O00Oo , '' )
   if 32 - 32: O00OOOoOoo0O * oOO00Oo / OoooooooOO
   if 90 - 90: Iiii1i1
def ii11 ( url ) :
 OOoOo0O0 = 'http://noobsandnerds.com/TI/HardwarePortal/sortby.php?sortx=Added&orderx=DESC&%s' % ( url )
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 65 - 65: Iiii1i1 + i1Iii1i1I * i1Iii1i1I
 o0OO000ooOo = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> thumb="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 if o0OO000ooOo == [ ] :
  if 79 - 79: i1IIi / II11iIiIIIiI - o0Oo . O0
  o0OO000ooOo = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> thumb="(.+?)" <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 iii11 ( OOoOo0O0 , 'hardware' )
 if 56 - 56: i11111IIIII % O0 * i1IIi - oO0OooOoO
 for i1iIIIi1i , id , Oo0OoOOoo in o0OO000ooOo :
  oO00oOOoooO ( 'folder2' , i1iIIIi1i , id , 'hardware_final_menu' , Oo0OoOOoo , '' , '' )
  if 84 - 84: Iiii1i1
  if 53 - 53: i1IIi
def OO0oOoo ( url ) :
 OOoOo0O0 = 'http://noobsandnerds.com/TI/LatestNews/sortby.php?sortx=item_date&orderx=DESC&%s' % ( url )
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 9 - 9: i1IIi - O00OOOoOoo0O
 o0OO000ooOo = re . compile ( 'name="(.+?)"  <br> date="(.+?)"  <br> source="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 if o0OO000ooOo == [ ] :
  if 57 - 57: iIii1I11I1II1 * iI1IiiIIIiIi * i1Iii1i1I / III1IiiI
  o0OO000ooOo = re . compile ( 'name="(.+?)" <br> date="(.+?)" <br> source="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 for i1iIIIi1i , iIIiII1i1ii , o00Oo0O , id in o0OO000ooOo :
  if 17 - 17: ii1ii11IIIiiI
  if "OpenELEC" in o00Oo0O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIIiII1i1ii + ')' , id , 'news_menu' , '' , '' , '' )
   if 31 - 31: III1IiiI + OoooooooOO - iI1IiiIIIiIi % oOO00Oo / oOO00Oo / iIii1I11I1II1
  if "Official" in o00Oo0O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIIiII1i1ii + ')' , id , 'news_menu' , '' , '' , '' )
   if 31 - 31: OoooooooOO - iI1IiiIIIiIi . i11111IIIII % III1IiiI
  if "Raspbmc" in o00Oo0O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIIiII1i1ii + ')' , id , 'news_menu' , '' , '' , '' )
   if 16 - 16: iiIi1i11 * iI1IiiIIIiIi % Iiii1i1 / i11111IIIII + iIii1I11I1II1 / o0Oo
  if "XBMC4Xbox" in o00Oo0O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIIiII1i1ii + ')' , id , 'news_menu' , '' , '' , '' )
   if 36 - 36: ii1ii11IIIiiI + ii1ii11IIIiiI + ii1ii11IIIiiI % II11iIiIIIiI * i1Iii1i1I
  if "noobsandnerds" in o00Oo0O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIIiII1i1ii + ')' , id , 'news_menu' , '' , '' , '' )
   if 98 - 98: o00O0OoO . o00O0OoO / II11iIiIIIiI / iI1IiiIIIiIi / o0Oo
   if 56 - 56: oOO00Oo / i11111IIIII
def iI1I1 ( url ) :
 if not "name" in url :
  url = url + '&name='
 if not "desc" in url :
  url = url + '&desc='
 if not "hardware" in url :
  url = url + '&hardware='
 if not "platform" in url :
  url = url + '&platform='
 if not "thirdparty" in url :
  url = url + '&thirdparty='
 if not "type" in url :
  url = url + '&type='
 OOoOo0O0 = 'http://noobsandnerds.com/TI/TutorialPortal/sortby.php?sortx=Name&orderx=ASC&%s' % ( url )
 IiIi1I1 = IiIIi1 ( OOoOo0O0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 5 - 5: Iiii1i1 % oO0OooOoO + II11iIiIIIiI - iIii1I11I1II1
 o0OO000ooOo = re . compile ( 'name="(.+?)"  <br> about="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 if o0OO000ooOo == [ ] :
  if 64 - 64: Iiii1i1 + iIii1I11I1II1
  o0OO000ooOo = re . compile ( 'name="(.+?)" <br> about="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( IiIi1I1 )
 iii11 ( OOoOo0O0 , 'tutorials' )
 if 14 - 14: iI1IiiIIIiIi / OoooooooOO + oO0OooOoO . O0 / i1IIi
 for i1iIIIi1i , OOoo0Ii11I1iIIi , id in o0OO000ooOo :
  oO00oOOoooO ( 'folder' , i1iIIIi1i , id , 'tutorial_final_menu' , '' , '' , OOoo0Ii11I1iIIi )
  if 68 - 68: o00O0OoO / iIii1I11I1II1 . II11iIiIIIiI + i11iIiiIii + oOO00Oo
  if 92 - 92: ii1ii11IIIiiI . oOO00Oo . iI1IiiIIIiIi % O00OOOoOoo0O
def OO00O00o0O ( url , local ) :
 i1iI1i ( )
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'This will over-write your existing guisettings.xml.' , 'Are you sure this is the build you have installed?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 100 - 100: ii1ii11IIIiiI % O00OOOoOoo0O / o00O0OoO * O0 - III1IiiI
 if iII1Iii1I11i == 1 :
  I1IiIi1iiI ( url , local )
  if 26 - 26: o0Oo % O00OOOoOoo0O
def OO00o0oo ( path ) :
 if 3 - 3: iI1IiiIIIiIi * o0oOo0 - o0Oo / i1IIi
 O0OO0o0OO0OO = open ( I11i1 , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 if 21 - 21: oO0OooOoO + Iiii1i1
 i1Io00OOOo = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( i11i )
 Ii1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( i11i )
 ooOO0oo00Oo = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( i11i )
 i1I11I1i = i1Io00OOOo [ 0 ] if ( len ( i1Io00OOOo ) > 0 ) else ''
 oOO0oOooo = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
 o00IIIIii1111i1 = ooOO0oo00Oo [ 0 ] if ( len ( ooOO0oo00Oo ) > 0 ) else ''
 if 11 - 11: O00OOOoOoo0O
 if 31 - 31: oO0OooOoO * iI1IiiIIIiIi / i11111IIIII / i11iIiiIii
 o0oO0oo = open ( path , mode = 'r' )
 ooOO00Oo = o0oO0oo . read ( )
 o0oO0oo . close ( )
 if 88 - 88: II11iIiIIIiI . oOO00Oo - i11iIiiIii . O0 * iIii1I11I1II1 * O00OOOoOoo0O
 OoOOoO0o = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOO00Oo )
 o0O00ooo0 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOO00Oo )
 iI1 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOO00Oo )
 iIi1 = OoOOoO0o [ 0 ] if ( len ( OoOOoO0o ) > 0 ) else ''
 O00oOOO0 = o0O00ooo0 [ 0 ] if ( len ( o0O00ooo0 ) > 0 ) else ''
 Iiiiii = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else ''
 iiI1IIIi = i11i . replace ( i1I11I1i , iIi1 ) . replace ( o00IIIIii1111i1 , Iiiiii ) . replace ( oOO0oOooo , O00oOOO0 )
 if 80 - 80: o0Oo
 print "### Attempting to create new guisettings at: " + path
 o0oooOO00 = open ( path , mode = 'w+' )
 o0oooOO00 . write ( str ( iiI1IIIi ) )
 o0oooOO00 . close ( )
 if 58 - 58: III1IiiI + OoooO0Oo0O0 % O00OOOoOoo0O
 if 22 - 22: iIii1I11I1II1 - iI1IiiIIIiIi / o0Oo * i11111IIIII
def III1IIi ( src , dst , clean ) :
 for IiiIiIi1iI1i1 , OoOOOO , I1iiIi111I in os . walk ( src ) :
  o0o0oo0OOo0O0 = IiiIiIi1iI1i1 . replace ( src , dst , 1 )
  if not os . path . exists ( o0o0oo0OOo0O0 ) :
   os . makedirs ( o0o0oo0OOo0O0 )
  for iIIiiII11i1I1 in I1iiIi111I :
   Ii111Ii1iiIi1 = os . path . join ( IiiIiIi1iI1i1 , iIIiiII11i1I1 )
   OOI11i1IIi1i1 = os . path . join ( o0o0oo0OOo0O0 , iIIiiII11i1I1 )
   if os . path . exists ( OOI11i1IIi1i1 ) :
    os . remove ( OOI11i1IIi1i1 )
   shutil . move ( Ii111Ii1iiIi1 , o0o0oo0OOo0O0 )
 if clean == 1 :
  try :
   shutil . rmtree ( src )
  except :
   pass
   if 28 - 28: o00O0OoO . OoooooooOO * iiIi1i11 + i11iIiiIii % o0Oo . iIii1I11I1II1
   if 63 - 63: oO0OooOoO - o00O0OoO . O00OOOoOoo0O
def I1IiIi1iiI ( url , local ) :
 IIi1I1iII111 = False
 o0OoO00OO0o0ooO = 0
 Iii1iIIIi11I1 = 1
 if 38 - 38: II11iIiIIIiI * OoooO0Oo0O0 - o0oOo0 % OoooO0Oo0O0
 if os . path . exists ( Oo0OoO00oOO0o ) :
  os . remove ( Oo0OoO00oOO0o )
  if 12 - 12: iiIi1i11 + ii1ii11IIIiiI * o00O0OoO + iI1IiiIIIiIi + i11111IIIII
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 58 - 58: i1Iii1i1I * iI1IiiIIIiIi - i11iIiiIii % OoooO0Oo0O0
 if os . path . exists ( I1IIIii ) :
  os . remove ( I1IIIii )
  if 3 - 3: Iiii1i1 . o00O0OoO % oO0OooOoO * o0Oo % i1IIi * ii1ii11IIIiiI
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 5 - 5: oO0OooOoO * i1IIi % iI1IiiIIIiIi
  if 55 - 55: o0Oo + i1Iii1i1I
 try :
  shutil . copyfile ( I11i1 , Oo0OoO00oOO0o )
  if 85 - 85: III1IiiI + i1Iii1i1I % i1Iii1i1I / o00O0OoO . o0Oo - O00OOOoOoo0O
 except :
  print "No guisettings found, most likely due to a previously failed attempt at install"
  if 19 - 19: o00O0OoO / i1Iii1i1I + i11111IIIII
 if local != 1 :
  OoO00 = os . path . join ( OOO00 , 'guifix.zip' )
  if 57 - 57: II11iIiIIIiI - OoooooooOO % OoooO0Oo0O0 . ii1ii11IIIiiI * oO0OooOoO
  try :
   OOooO0OOoo . create ( 'Downloading Skin Fix' , '' , '' , '' )
   downloader . download ( url , OoO00 )
  except :
   print "Failed to download guisettings"
 else :
  OoO00 = xbmc . translatePath ( url )
 if iiIIIII1i1iI == 'true' :
  print "### lib=" + OoO00
  if 72 - 72: Iiii1i1 + o0oOo0 . i11111IIIII % oO0OooOoO
 oOoO0oO00ooOo = str ( os . path . getsize ( OoO00 ) )
 OOooO0OOoo . create ( "Installing Skin Fix" , "Checking " , '' , 'Please Wait' )
 if 2 - 2: III1IiiI . i1Iii1i1I
 extract . all ( OoO00 , OOO00O )
 if 42 - 42: ii1ii11IIIiiI - OoooO0Oo0O0 * i11111IIIII - o0oOo0
 if os . path . exists ( os . path . join ( OOO00O , 'script.skinshortcuts' ) ) :
  try :
   shutil . rmtree ( os . path . join ( O0OoO000O0OO , 'script.skinshortcuts' ) )
  except :
   pass
  os . rename ( os . path . join ( OOO00O , 'script.skinshortcuts' ) , os . path . join ( O0OoO000O0OO , 'script.skinshortcuts' ) )
  if 75 - 75: i1Iii1i1I * II11iIiIIIiI / Iiii1i1 * II11iIiIIIiI / o0oOo0
 if os . path . exists ( os . path . join ( OOO00O , 'addon_data' ) ) :
  III1IIi ( os . path . join ( OOO00O , 'addon_data' ) , oOOoO0 , 1 )
  if 14 - 14: i1IIi * iIii1I11I1II1 - iI1IiiIIIiIi * O00OOOoOoo0O - i1Iii1i1I / III1IiiI
 if local != 'library' or local != 'updatelibrary' or local != 'fresh' :
  if 73 - 73: OoooO0Oo0O0 - O00OOOoOoo0O * O0 - O00OOOoOoo0O - ii1ii11IIIiiI
  try :
   OoO = open ( os . path . join ( OOO00O , 'profiles.xml' ) , mode = 'r' )
   oOoO0o0o = OoO . read ( )
   OoO . close ( )
   if 72 - 72: o00O0OoO * O00OOOoOoo0O % Iiii1i1 % o0oOo0
   if os . path . exists ( os . path . join ( OOO00O , 'profiles.xml' ) ) :
    if 22 - 22: iiIi1i11 - OoooO0Oo0O0 / i11111IIIII
    if local == None :
     iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "KODI PROFILES DETECTED" , 'This build has profiles included (standard Kodi profiles, not CP Profiles), would you like to overwrite your existing profiles or keep the ones you have?' , '' , '' , nolabel = 'Keep my profiles' , yeslabel = 'Use new profiles' )
     if 95 - 95: oOO00Oo
    if local != None :
     iII1Iii1I11i = 1
     if 69 - 69: III1IiiI . o00O0OoO
    if iII1Iii1I11i == 1 :
     o0oooOO00 = open ( I1IIIii , mode = 'w' )
     time . sleep ( 1 )
     o0oooOO00 . write ( oOoO0o0o )
     time . sleep ( 1 )
     o0oooOO00 . close ( )
     Iii1iIIIi11I1 = 0
     if 36 - 36: o0oOo0
  except :
   print "no profiles.xml file"
   if 62 - 62: o00O0OoO % III1IiiI / OoooooooOO % OoooooooOO
   if 65 - 65: O0 . OoooO0Oo0O0 * Iiii1i1
 try :
  os . rename ( os . path . join ( OOO00O , 'guisettings.xml' ) , iIi1ii1I1 )
 except :
  iI111I11I1I1 . ok ( 'FILE MISSING' , 'No guisettings.xml could be found in your zip file. Please double check this file is a valid zip and hasn\'t become corrupt.' )
 if local != 'fresh' :
  iiIiI11IiI = iI111I11I1I1 . yesno ( "Keep Kodi Settings?" , 'Do you want to keep your existing KODI settings (weather, screen calibration, PVR etc.) or wipe and install the ones in this build?' , nolabel = 'Keep my settings' , yeslabel = 'Replace my settings' )
  if 23 - 23: o0Oo - oOO00Oo % III1IiiI . O0 * OoooooooOO + o0oOo0
 if local == 'fresh' :
  iiIiI11IiI = 1
  if 53 - 53: II11iIiIIIiI
 if iiIiI11IiI == 1 :
  if 3 - 3: i11111IIIII - OoooooooOO * OoooooooOO - o0Oo / Iiii1i1 * OoooO0Oo0O0
  if os . path . exists ( I11i1 ) :
   if 58 - 58: i11111IIIII % iIii1I11I1II1 / i11iIiiIii % oOO00Oo . Iiii1i1 * i1Iii1i1I
   try :
    print "### Attempting to remove guisettings"
    os . remove ( I11i1 )
    IIi1I1iII111 = True
    if 32 - 32: OoooooooOO + oOO00Oo
   except :
    print "### Problem removing guisettings"
    IIi1I1iII111 = False
    if 91 - 91: o0oOo0 - Iiii1i1 * Iiii1i1
   try :
    print "### Attempting to replace guisettings with new"
    os . rename ( iIi1ii1I1 , I11i1 )
    IIi1I1iII111 = True
    if 55 - 55: iIii1I11I1II1 + o0Oo - II11iIiIIIiI
   except :
    print "### Failed to replace guisettings with new"
    IIi1I1iII111 = False
    if 24 - 24: ii1ii11IIIiiI / Iiii1i1 + i1Iii1i1I * o00O0OoO * i1Iii1i1I
    if 10 - 10: o0Oo - OoooO0Oo0O0 - II11iIiIIIiI - oOO00Oo
 if iiIiI11IiI == 0 :
  O0OO0o0OO0OO = open ( Oo0OoO00oOO0o , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
  if 21 - 21: OoooooooOO + Iiii1i1
  i1Io00OOOo = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( i11i )
  Ii1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( i11i )
  ooOO0oo00Oo = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( i11i )
  i1I11I1i = i1Io00OOOo [ 0 ] if ( len ( i1Io00OOOo ) > 0 ) else ''
  oOO0oOooo = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
  o00IIIIii1111i1 = ooOO0oo00Oo [ 0 ] if ( len ( ooOO0oo00Oo ) > 0 ) else ''
  if 43 - 43: i11iIiiIii . OoooO0Oo0O0 . III1IiiI
  if 31 - 31: iI1IiiIIIiIi % oOO00Oo % Iiii1i1 . OoooO0Oo0O0 / oOO00Oo * III1IiiI
  o0oO0oo = open ( iIi1ii1I1 , mode = 'r' )
  ooOO00Oo = o0oO0oo . read ( )
  o0oO0oo . close ( )
  if 74 - 74: o0Oo . o0oOo0 / i1Iii1i1I . i11111IIIII
  OoOOoO0o = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOO00Oo )
  o0O00ooo0 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOO00Oo )
  iI1 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOO00Oo )
  iIi1 = OoOOoO0o [ 0 ] if ( len ( OoOOoO0o ) > 0 ) else ''
  O00oOOO0 = o0O00ooo0 [ 0 ] if ( len ( o0O00ooo0 ) > 0 ) else ''
  Iiiiii = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else ''
  iiI1IIIi = i11i . replace ( i1I11I1i , iIi1 ) . replace ( o00IIIIii1111i1 , Iiiiii ) . replace ( oOO0oOooo , O00oOOO0 )
  if 74 - 74: II11iIiIIIiI / Iiii1i1 % Iiii1i1 . i11111IIIII
  o0oooOO00 = open ( Oo0OoO00oOO0o , mode = 'w+' )
  o0oooOO00 . write ( str ( iiI1IIIi ) )
  o0oooOO00 . close ( )
  if 72 - 72: i1IIi
  if 21 - 21: Iiii1i1 . iiIi1i11 / i11iIiiIii * i1IIi
  if os . path . exists ( I11i1 ) :
   if 82 - 82: o0oOo0 * II11iIiIIIiI % i11iIiiIii * i1IIi . iiIi1i11
   try :
    os . remove ( I11i1 )
    IIi1I1iII111 = True
    if 89 - 89: i11111IIIII - i1IIi - i11111IIIII
   except :
    IIi1I1iII111 = False
    if 74 - 74: ii1ii11IIIiiI % ii1ii11IIIiiI
  try :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   os . remove ( iIi1ii1I1 )
   IIi1I1iII111 = True
   if 28 - 28: O00OOOoOoo0O % III1IiiI - iiIi1i11 + iiIi1i11 + III1IiiI / iIii1I11I1II1
  except :
   IIi1I1iII111 = False
   if 91 - 91: o0Oo / oO0OooOoO * iiIi1i11
   if 94 - 94: oO0OooOoO - iIii1I11I1II1 - iIii1I11I1II1
 if IIi1I1iII111 == True or local == None :
  if 83 - 83: OoooO0Oo0O0 * iIii1I11I1II1 + O00OOOoOoo0O * i1IIi . OoooooooOO % iI1IiiIIIiIi
  try :
   O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'r' )
   i11i = O0OO0o0OO0OO . read ( )
   O0OO0o0OO0OO . close ( )
   if 81 - 81: ii1ii11IIIiiI - iIii1I11I1II1
   o0oooO0O00OoO = re . compile ( 'id="(.+?)"' ) . findall ( i11i )
   iiiiI = re . compile ( 'name="(.+?)"' ) . findall ( i11i )
   IiO0o = re . compile ( 'version="(.+?)"' ) . findall ( i11i )
   oOo0Oooo = o0oooO0O00OoO [ 0 ] if ( len ( o0oooO0O00OoO ) > 0 ) else ''
   I1iiIIiI11I = iiiiI [ 0 ] if ( len ( iiiiI ) > 0 ) else ''
   i1ii1I = IiO0o [ 0 ] if ( len ( IiO0o ) > 0 ) else ''
   if 29 - 29: o00O0OoO + III1IiiI % o0oOo0 + O00OOOoOoo0O
   o0oooOO00 = open ( I1IIiiIiii , mode = 'w+' )
   o0oooOO00 . write ( 'id="' + str ( oOo0Oooo ) + '"\nname="' + I1iiIIiI11I + '"\nversion="' + i1ii1I + '"\ngui="' + oOoO0oO00ooOo + '"' )
   o0oooOO00 . close ( )
   if 92 - 92: oOO00Oo
   O0OO0o0OO0OO = open ( O000OO0 , mode = 'r' )
   i11i = O0OO0o0OO0OO . read ( )
   O0OO0o0OO0OO . close ( )
   if 37 - 37: III1IiiI
   i1Ii1 = re . compile ( 'version="(.+?)"' ) . findall ( i11i )
   I1I1IiI1 = i1Ii1 [ 0 ] if ( len ( i1Ii1 ) > 0 ) else ''
   iiI1IIIi = i11i . replace ( I1I1IiI1 , i1ii1I )
   if 18 - 18: i11111IIIII * i11iIiiIii + iIii1I11I1II1 % o00O0OoO + i1IIi - ii1ii11IIIiiI
   o0oooOO00 = open ( O000OO0 , mode = 'w' )
   o0oooOO00 . write ( str ( iiI1IIIi ) )
   o0oooOO00 . close ( )
   os . remove ( I11iii1Ii )
   if 85 - 85: ii1ii11IIIiiI * o00O0OoO + ii1ii11IIIiiI
  except :
   o0oooOO00 = open ( I1IIiiIiii , mode = 'w+' )
   o0oooOO00 . write ( 'id="None"\nname="Unknown"\nversion="Unknown"\ngui="' + oOoO0oO00ooOo + '"' )
   o0oooOO00 . close ( )
   if 39 - 39: II11iIiIIIiI / i1IIi % i1IIi
   if 20 - 20: iiIi1i11 * III1IiiI
 if os . path . exists ( os . path . join ( OOO00O , 'profiles.xml' ) ) :
  os . remove ( os . path . join ( OOO00O , 'profiles.xml' ) )
  time . sleep ( 1 )
  if 91 - 91: ii1ii11IIIiiI % i1IIi - iIii1I11I1II1 . iiIi1i11
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 31 - 31: III1IiiI % i1IIi . OoooooooOO - oOO00Oo + OoooooooOO
 I1i1Ii = xbmc . translatePath ( os . path . join ( O0OoO000O0OO , o0OO00 , 'notification.txt' ) )
 if 41 - 41: ii1ii11IIIiiI / i11111IIIII + Iiii1i1 . Iiii1i1 / III1IiiI
 if os . path . exists ( I1i1Ii ) :
  os . remove ( I1i1Ii )
  if 74 - 74: iI1IiiIIIiIi % i11iIiiIii . O0 * o0Oo * i1IIi * OoooooooOO
 if IIi1I1iII111 == True :
  ooOOOOoO ( )
  O00000OO00OO ( )
  if 22 - 22: Iiii1i1 + i1Iii1i1I - o00O0OoO + iIii1I11I1II1 / Iiii1i1 - OoooooooOO
  if 42 - 42: OoooooooOO - O00OOOoOoo0O - iiIi1i11 * Iiii1i1
def OO0iii111 ( url ) :
 I1i11 = 'http://noobsandnerds.com/TI/HardwarePortal/hardwaredetails.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 o00O000oooOo = re . compile ( 'manufacturer="(.+?)"' ) . findall ( IiIi1I1 )
 Iio0000O00oO0O = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IiIi1I1 )
 IiiI111I11 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IiIi1I1 )
 oO0Ooooo000 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IiIi1I1 )
 Iii1Iiii = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IiIi1I1 )
 i1i1Ii1IiIII = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IiIi1I1 )
 I1IIii11 = re . compile ( 'video_label1="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1O0O = re . compile ( 'video_label2="(.+?)"' ) . findall ( IiIi1I1 )
 OO0ooO00o = re . compile ( 'video_label3="(.+?)"' ) . findall ( IiIi1I1 )
 I1iii1 = re . compile ( 'video_label4="(.+?)"' ) . findall ( IiIi1I1 )
 iIiiiIIiii = re . compile ( 'video_label5="(.+?)"' ) . findall ( IiIi1I1 )
 O0o00oO0o0 = re . compile ( 'shops="(.+?)"' ) . findall ( IiIi1I1 )
 i1I1iIii11 = re . compile ( 'description="(.+?)"' ) . findall ( IiIi1I1 )
 iiiI1I1iiiII = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IiIi1I1 )
 IIiIi1I1iI1 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IiIi1I1 )
 i1I111II11 = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IiIi1I1 )
 o00oO = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IiIi1I1 )
 I11ii111i = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IiIi1I1 )
 IIiI1I11ii1i = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IiIi1I1 )
 o0o = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IiIi1I1 )
 ooIi1Iii1 = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IiIi1I1 )
 oooo = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IiIi1I1 )
 I11iii1iIIIIi = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IiIi1I1 )
 III1i1iiI1 = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IiIi1I1 )
 O0ooO0O00oo0 = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IiIi1I1 )
 II1i1iI = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IiIi1I1 )
 iI111I1 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IiIi1I1 )
 iIiii1IIi1I = re . compile ( 'added="(.+?)"' ) . findall ( IiIi1I1 )
 o0OooOOOOOO = re . compile ( 'platform="(.+?)"' ) . findall ( IiIi1I1 )
 IiIiii1IiI = re . compile ( 'chipset="(.+?)"' ) . findall ( IiIi1I1 )
 oo0o0ooOoo00O = re . compile ( 'official_guide="(.+?)"' ) . findall ( IiIi1I1 )
 iI1ii1 = re . compile ( 'official_preview="(.+?)"' ) . findall ( IiIi1I1 )
 i1Ii1I1Ii11iI = re . compile ( 'thumbnail="(.+?)"' ) . findall ( IiIi1I1 )
 O0oOOo = re . compile ( 'stock_rom="(.+?)"' ) . findall ( IiIi1I1 )
 ii111IIiiiiI = re . compile ( 'CPU="(.+?)"' ) . findall ( IiIi1I1 )
 oo0OOoOo0 = re . compile ( 'GPU="(.+?)"' ) . findall ( IiIi1I1 )
 oO00oO0 = re . compile ( 'RAM="(.+?)"' ) . findall ( IiIi1I1 )
 o0oI1Iii = re . compile ( 'flash="(.+?)"' ) . findall ( IiIi1I1 )
 II1I1Ii11 = re . compile ( 'wifi="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1iiI = re . compile ( 'bluetooth="(.+?)"' ) . findall ( IiIi1I1 )
 o0oOOO0 = re . compile ( 'LAN="(.+?)"' ) . findall ( IiIi1I1 )
 i1Iii = re . compile ( 'xbmc_version="(.+?)"' ) . findall ( IiIi1I1 )
 oOOo0OOOOo0o = re . compile ( 'pros="(.+?)"' ) . findall ( IiIi1I1 )
 I1i1iiii = re . compile ( 'cons="(.+?)"' ) . findall ( IiIi1I1 )
 O00O = re . compile ( 'library_scan="(.+?)"' ) . findall ( IiIi1I1 )
 IIIIIi1 = re . compile ( '4k="(.+?)"' ) . findall ( IiIi1I1 )
 o0oIi1iiiii = re . compile ( '1080="(.+?)"' ) . findall ( IiIi1I1 )
 O00o0 = re . compile ( '720="(.+?)"' ) . findall ( IiIi1I1 )
 IIiIiIi1II = re . compile ( '3D="(.+?)"' ) . findall ( IiIi1I1 )
 oO00 = re . compile ( 'DTS="(.+?)"' ) . findall ( IiIi1I1 )
 IiiIIiii = re . compile ( 'BootTime="(.+?)"' ) . findall ( IiIi1I1 )
 iIIIii111 = re . compile ( 'CopyFiles="(.+?)"' ) . findall ( IiIi1I1 )
 I1111IiII1 = re . compile ( 'CopyVideo="(.+?)"' ) . findall ( IiIi1I1 )
 IiiII = re . compile ( 'EthernetTest="(.+?)"' ) . findall ( IiIi1I1 )
 OO00OO0 = re . compile ( 'Slideshow="(.+?)"' ) . findall ( IiIi1I1 )
 Ooii = re . compile ( 'total_review="(.+?)"' ) . findall ( IiIi1I1 )
 i11iII1 = re . compile ( 'whufclee_review="(.+?)"' ) . findall ( IiIi1I1 )
 oOooo = re . compile ( 'CB_Premium="(.+?)"' ) . findall ( IiIi1I1 )
 if 15 - 15: o0oOo0 * iIii1I11I1II1 * III1IiiI
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 O0oo0O00ooOo = o00O000oooOo [ 0 ] if ( len ( o00O000oooOo ) > 0 ) else ''
 IioO0oOOO0Ooo = Iio0000O00oO0O [ 0 ] if ( len ( Iio0000O00oO0O ) > 0 ) else 'None'
 i1i1I = IiiI111I11 [ 0 ] if ( len ( IiiI111I11 ) > 0 ) else 'None'
 IiIIi1iII11I1Ii1 = oO0Ooooo000 [ 0 ] if ( len ( oO0Ooooo000 ) > 0 ) else 'None'
 o0o0 = Iii1Iiii [ 0 ] if ( len ( Iii1Iiii ) > 0 ) else 'None'
 oOo0oO = i1i1Ii1IiIII [ 0 ] if ( len ( i1i1Ii1IiIII ) > 0 ) else 'None'
 i111iiI1ii = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else 'None'
 IIiii = I1I1O0O [ 0 ] if ( len ( I1I1O0O ) > 0 ) else 'None'
 I1i1i = OO0ooO00o [ 0 ] if ( len ( OO0ooO00o ) > 0 ) else 'None'
 OOOOooO0oO00O0o = I1iii1 [ 0 ] if ( len ( I1iii1 ) > 0 ) else 'None'
 ooOO00oOOo000 = iIiiiIIiii [ 0 ] if ( len ( iIiiiIIiii ) > 0 ) else 'None'
 oOoOOo = O0o00oO0o0 [ 0 ] if ( len ( O0o00oO0o0 ) > 0 ) else ''
 O00Oo = i1I1iIii11 [ 0 ] if ( len ( i1I1iIii11 ) > 0 ) else ''
 I1111ii11 = iiiI1I1iiiII [ 0 ] if ( len ( iiiI1I1iiiII ) > 0 ) else ''
 I1iI1I1111i = IIiIi1I1iI1 [ 0 ] if ( len ( IIiIi1I1iI1 ) > 0 ) else ''
 iII11IiIIII = i1I111II11 [ 0 ] if ( len ( i1I111II11 ) > 0 ) else ''
 O00 = o00oO [ 0 ] if ( len ( o00oO ) > 0 ) else ''
 oooo0OOO00O00 = I11ii111i [ 0 ] if ( len ( I11ii111i ) > 0 ) else ''
 i11I111I1 = IIiI1I11ii1i [ 0 ] if ( len ( IIiI1I11ii1i ) > 0 ) else ''
 OOOoO000o0O0O = o0o [ 0 ] if ( len ( o0o ) > 0 ) else ''
 oO0oOO = ooIi1Iii1 [ 0 ] if ( len ( ooIi1Iii1 ) > 0 ) else ''
 Oo0O = oooo [ 0 ] if ( len ( oooo ) > 0 ) else ''
 i1iIi1iiii1ii = I11iii1iIIIIi [ 0 ] if ( len ( I11iii1iIIIIi ) > 0 ) else ''
 oO0oOo = III1i1iiI1 [ 0 ] if ( len ( III1i1iiI1 ) > 0 ) else ''
 IIiIiii = O0ooO0O00oo0 [ 0 ] if ( len ( O0ooO0O00oo0 ) > 0 ) else ''
 OOo0OO = II1i1iI [ 0 ] if ( len ( II1i1iI ) > 0 ) else ''
 ooIIi111I = iI111I1 [ 0 ] if ( len ( iI111I1 ) > 0 ) else ''
 ooo00oOoo000O = iIiii1IIi1I [ 0 ] if ( len ( iIiii1IIi1I ) > 0 ) else ''
 o0O0Oo00 = o0OooOOOOOO [ 0 ] if ( len ( o0OooOOOOOO ) > 0 ) else ''
 oO0OoO0O0o = IiIiii1IiI [ 0 ] if ( len ( IiIiii1IiI ) > 0 ) else ''
 iii1i = oo0o0ooOoo00O [ 0 ] if ( len ( oo0o0ooOoo00O ) > 0 ) else 'None'
 i111iiI11iI = iI1ii1 [ 0 ] if ( len ( iI1ii1 ) > 0 ) else 'None'
 Oo0OoOOoo = i1Ii1I1Ii11iI [ 0 ] if ( len ( i1Ii1I1Ii11iI ) > 0 ) else ''
 Oo0OO0oO0O = O0oOOo [ 0 ] if ( len ( O0oOOo ) > 0 ) else ''
 iIIii = ii111IIiiiiI [ 0 ] if ( len ( ii111IIiiiiI ) > 0 ) else ''
 o000oo = oo0OOoOo0 [ 0 ] if ( len ( oo0OOoOo0 ) > 0 ) else ''
 O0Ooo0o = oO00oO0 [ 0 ] if ( len ( oO00oO0 ) > 0 ) else ''
 Iii1 = o0oI1Iii [ 0 ] if ( len ( o0oI1Iii ) > 0 ) else ''
 iiIIi1i111i = II1I1Ii11 [ 0 ] if ( len ( II1I1Ii11 ) > 0 ) else ''
 iII = I1I1iiI [ 0 ] if ( len ( I1I1iiI ) > 0 ) else ''
 OoOo0Oo00Oo = o0oOOO0 [ 0 ] if ( len ( o0oOOO0 ) > 0 ) else ''
 III1I1I = i1Iii [ 0 ] if ( len ( i1Iii ) > 0 ) else ''
 i11i11I = oOOo0OOOOo0o [ 0 ] if ( len ( oOOo0OOOOo0o ) > 0 ) else ''
 OoO00O0oOo = I1i1iiii [ 0 ] if ( len ( I1i1iiii ) > 0 ) else ''
 ooIII = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 i1iIii1II11 = IIIIIi1 [ 0 ] if ( len ( IIIIIi1 ) > 0 ) else ''
 OOOOoOOOO = o0oIi1iiiii [ 0 ] if ( len ( o0oIi1iiiii ) > 0 ) else ''
 iiIi1 = O00o0 [ 0 ] if ( len ( O00o0 ) > 0 ) else ''
 Oo0OOoI1i1i1IIi1I = IIiIiIi1II [ 0 ] if ( len ( IIiIiIi1II ) > 0 ) else ''
 IIi11iIIiIiI = oO00 [ 0 ] if ( len ( oO00 ) > 0 ) else ''
 oo000oo00 = IiiIIiii [ 0 ] if ( len ( IiiIIiii ) > 0 ) else ''
 IiIiiI1II = iIIIii111 [ 0 ] if ( len ( iIIIii111 ) > 0 ) else ''
 iI1i = I1111IiII1 [ 0 ] if ( len ( I1111IiII1 ) > 0 ) else ''
 oo000o0O = IiiII [ 0 ] if ( len ( IiiII ) > 0 ) else ''
 iiIiIIiI1 = OO00OO0 [ 0 ] if ( len ( OO00OO0 ) > 0 ) else ''
 Ii11i = Ooii [ 0 ] if ( len ( Ooii ) > 0 ) else ''
 O00i1i = i11iII1 [ 0 ] if ( len ( i11iII1 ) > 0 ) else 'None'
 iiii = oOooo [ 0 ] if ( len ( oOooo ) > 0 ) else ''
 IIiii1I1I = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + ooo00oOoo000O + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + O0oo0O00ooOo + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + o0O0Oo00 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + oO0OoO0O0o + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + iIIii + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o000oo + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + O0Ooo0o + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + Iii1 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + iiIIi1i111i + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + iII + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + OoOo0Oo00Oo + '[CR][CR][COLOR=yellow]About: [/COLOR]' + O00Oo + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + i11i11I + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + OoO00O0oOo + '[CR][CR][COLOR=yellow]Benchmark Results:[/COLOR][CR][CR][COLOR=dodgerblue]Boot Time:[/COLOR][CR]' + oo000oo00 + '[CR][CR][COLOR=dodgerblue]Time taken to scan 1,000 movies (local NFO files):[/COLOR][CR]' + ooIII + '[CR][CR][COLOR=dodgerblue]Copy 4,000 files (660.8MB) locally:[/COLOR][CR]' + IiIiiI1II + '[CR][CR][COLOR=dodgerblue]Copy a MP4 file (339.4MB) locally:[/COLOR][CR]' + iI1i + '[CR][CR][COLOR=dodgerblue]Ethernet Speed - Copy MP4 (339.4MB) from SMB share to device:[/COLOR][CR]' + oo000o0O + '[CR][CR][COLOR=dodgerblue]4k Playback:[/COLOR][CR]' + i1iIii1II11 + '[CR][CR][COLOR=dodgerblue]1080p Playback:[/COLOR][CR]' + OOOOoOOOO + '[CR][CR][COLOR=dodgerblue]720p Playback:[/COLOR][CR]' + iiIi1 + '[CR][CR][COLOR=dodgerblue]Audio Playback:[/COLOR][CR]' + IIi11iIIiIiI + '[CR][CR][COLOR=dodgerblue]Image Slideshow:[/COLOR][CR]' + iiIiIIiI1 )
 oo0O0OoO = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + ooo00oOoo000O + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + O0oo0O00ooOo + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + o0O0Oo00 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + oO0OoO0O0o + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + iIIii + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + o000oo + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + O0Ooo0o + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + Iii1 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + iiIIi1i111i + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + iII + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + OoOo0Oo00Oo + '[CR][CR][COLOR=yellow]About: [/COLOR]' + O00Oo + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + i11i11I + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + OoO00O0oOo + '[CR][CR][COLOR=orange]4k Playback:[/COLOR]  ' + i1iIii1II11 + '[CR][CR][COLOR=orange]1080p Playback:[/COLOR]  ' + OOOOoOOOO + '[CR][CR][COLOR=orange]720p Playback:[/COLOR]  ' + iiIi1 + '[CR][CR][COLOR=orange]DTS Compatibility:[/COLOR]  ' + IIi11iIIiIiI + '[CR][CR][COLOR=orange]Time taken to scan 100 movies:[/COLOR]  ' + ooIII )
 if 62 - 62: II11iIiIIIiI - III1IiiI % II11iIiIIIiI % i1IIi % ii1ii11IIIiiI / i1IIi
 if O00Oo != '' and oOoOOo != '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , IIiii1I1I , 'text_guide' , '' , O0o0Oo , '' , '' )
 if O00Oo != '' and oOoOOo == '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , oo0O0OoO , 'text_guide' , '' , O0o0Oo , '' , '' )
 if O00i1i != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Benchmark Review' , O00i1i , 'play_video' , '' , O0o0Oo , '' , '' )
 if i111iiI11iI != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Preview' , i111iiI11iI , 'play_video' , '' , O0o0Oo , '' , '' )
 if iii1i != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Guide' , iii1i , 'play_video' , '' , O0o0Oo , '' , '' )
 if IioO0oOOO0Ooo != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i111iiI1ii , IioO0oOOO0Ooo , 'play_video' , '' , O0o0Oo , '' , '' )
 if i1i1I != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IIiii , i1i1I , 'play_video' , '' , O0o0Oo , '' , '' )
 if IiIIi1iII11I1Ii1 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1i1i , IiIIi1iII11I1Ii1 , 'play_video' , '' , O0o0Oo , '' , '' )
 if o0o0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + OOOOooO0oO00O0o , o0o0 , 'play_video' , '' , O0o0Oo , '' , '' )
 if oOo0oO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + ooOO00oOOo000 , oOo0oO , 'play_video' , '' , O0o0Oo , '' , '' )
  if 30 - 30: O00OOOoOoo0O - i11iIiiIii
  if 94 - 94: O00OOOoOoo0O % i1Iii1i1I
def iI11ii ( ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'hardware' , 'manual_search' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime]All Devices[/COLOR]' , '' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Game Consoles' , 'device=Console' , '' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] HTPC' , 'device=HTPC' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Phones' , 'device=Phone' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Set Top Boxes' , 'device=STB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Tablets' , 'device=Tablet' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Remotes/Keyboards' , 'device=Remote' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Gaming Controllers' , 'device=Controller' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Dongles' , 'device=Dongle' , 'grab_hardware' , '' , '' , '' , '' )
 if 23 - 23: O00OOOoOoo0O * i11111IIIII / III1IiiI
 if 60 - 60: o0oOo0 * iI1IiiIIIiIi + Iiii1i1 . iiIi1i11 . O0
def Ii1i1ii ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Allwinner Devices' , str ( url ) + '&chip=Allwinner' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] AMLogic Devices' , str ( url ) + '&chip=AMLogic' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Intel Devices' , str ( url ) + '&chip=Intel' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Rockchip Devices' , str ( url ) + '&chip=Rockchip' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Android' , str ( url ) + '&platform=Android' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] iOS' , str ( url ) + '&platform=iOS' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Linux' , str ( url ) + '&platform=Linux' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] OpenELEC' , str ( url ) + '&platform=OpenELEC' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] OSX' , str ( url ) + '&platform=OSX' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Pure Linux' , str ( url ) + '&platform=Custom_Linux' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Windows' , str ( url ) + '&platform=Windows' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 4GB' , str ( url ) + '&flash=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 8GB' , str ( url ) + '&flash=8GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 16GB' , str ( url ) + '&flash=16GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 32GB' , str ( url ) + '&flash=32GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 64GB' , str ( url ) + '&flash=64GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 1GB' , str ( url ) + '&ram=1GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 2GB' , str ( url ) + '&ram=2GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 4GB' , str ( url ) + '&ram=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 if 53 - 53: O0 . iiIi1i11
 if 79 - 79: OoooooooOO * Iiii1i1 - i1IIi * OoooooooOO % O0 % iIii1I11I1II1
 if 82 - 82: O00OOOoOoo0O . iI1IiiIIIiIi
def ooo00OoOooooo ( ) :
 OOOO0OOoO0O0 = xbmc . getSkinDir ( )
 I11iIi1i1II11 = xbmc . translatePath ( os . path . join ( II11iiii1Ii , OOOO0OOoO0O0 ) )
 if 87 - 87: oO0OooOoO - OoooooooOO / i1IIi . iI1IiiIIIiIi - II11iIiIIIiI . i11iIiiIii
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( I11iIi1i1II11 ) :
  if 47 - 47: II11iIiIIIiI % ii1ii11IIIiiI - o0oOo0 - II11iIiIIIiI * III1IiiI
  for iiI1iii in I1iiIi111I :
   if 72 - 72: oOO00Oo % oOO00Oo + i1Iii1i1I + OoooO0Oo0O0 / II11iIiIIIiI
   if 'DialogKeyboard.xml' in iiI1iii :
    OOOO0OOoO0O0 = os . path . join ( IiiI111 , iiI1iii )
    ii1oOOO0ooOO = open ( OOOO0OOoO0O0 ) . read ( )
    i11IiI1iiI11 = ii1oOOO0ooOO . replace ( '<control type="label" id="310"' , '<control type="edit" id="312"' )
    iiI1iii = open ( OOOO0OOoO0O0 , mode = 'w' )
    iiI1iii . write ( i11IiI1iiI11 )
    iiI1iii . close ( )
    o0OO00oo0O ( OOOO0OOoO0O0 )
    if 30 - 30: II11iIiIIIiI + o0Oo + i11iIiiIii / ii1ii11IIIiiI
    for Ii11Iiii1iiii in range ( 48 , 58 ) :
     IIii1III ( Ii11Iiii1iiii , OOOO0OOoO0O0 )
     if 64 - 64: i11111IIIII
 iI111I11I1I1 = xbmcgui . Dialog ( )
 iI111I11I1I1 . ok ( "Skin Changes Successful" , 'A BIG thank you to Mikey1234 for this fix. The code used for this function was ported from the Xunity Maintenance add-on' )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 80 - 80: o0Oo - i11iIiiIii / ii1ii11IIIiiI / O00OOOoOoo0O + O00OOOoOoo0O
def oo000oiIIIII ( ) :
 iI111I11I1I1 = xbmcgui . Dialog ( )
 oOOOO0 = xbmcgui . Dialog ( ) . yesno ( 'Convert This Skin To Kodi (Helix)?' , 'This will fix the problem with a blank on-screen keyboard showing in skins designed for Gotham (being run on Kodi). This will only affect the currently running skin.' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 48 - 48: O00OOOoOoo0O * OoooooooOO + OoooooooOO * iIii1I11I1II1 * oO0OooOoO % i11iIiiIii
 if oOOOO0 == 1 :
  ooo00OoOooooo ( )
  if 22 - 22: ii1ii11IIIiiI . O00OOOoOoo0O % oO0OooOoO - O0
  if 52 - 52: ii1ii11IIIiiI
def I1O0 ( ) :
 if iI111I11I1I1 . yesno ( "Hide Passwords" , "This will hide all your passwords in your" , "add-on settings, are you sure you wish to continue?" ) :
  for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( II11iiii1Ii ) :
   for iiI1iii in I1iiIi111I :
    if iiI1iii == 'settings.xml' :
     oO0oo0oOO = open ( os . path . join ( IiiI111 , iiI1iii ) ) . read ( )
     o0OO000ooOo = re . compile ( '<setting id=(.+?)>' ) . findall ( oO0oo0oOO )
     for iiII1iIi1ii1i in o0OO000ooOo :
      if 'pass' in iiII1iIi1ii1i :
       if not 'option="hidden"' in iiII1iIi1ii1i :
        try :
         i11IiI1 = iiII1iIi1ii1i . replace ( '/' , ' option="hidden"/' )
         iiI1iii = open ( os . path . join ( IiiI111 , iiI1iii ) , mode = 'w' )
         iiI1iii . write ( str ( oO0oo0oOO ) . replace ( iiII1iIi1ii1i , i11IiI1 ) )
         iiI1iii . close ( )
        except :
         pass
  iI111I11I1I1 . ok ( "Passwords Hidden" , "Your passwords will now show as stars (hidden), if you want to undo this please use the option to unhide passwords." )
  if 62 - 62: o0oOo0 * OoooO0Oo0O0 / i1Iii1i1I * iiIi1i11 / iiIi1i11 - i1Iii1i1I
  if 59 - 59: iI1IiiIIIiIi % i1Iii1i1I / oO0OooOoO + o0Oo * o0oOo0
def o0o0O0o0O ( url ) :
 I1i11 = 'http://noobsandnerds.com/TI/Community_Builds/guisettings.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 OoO000oo000o0 = re . compile ( 'guisettings="(.+?)"' ) . findall ( IiIi1I1 )
 iIiII1 = OoO000oo000o0 [ 0 ] if ( len ( OoO000oo000o0 ) > 0 ) else 'None'
 if 16 - 16: oOO00Oo
 I1IiIi1iiI ( iIiII1 , IiiiI1i )
 if 32 - 32: i1Iii1i1I + O00OOOoOoo0O . Iiii1i1 . i1IIi . O00OOOoOoo0O * o0oOo0
 if 59 - 59: oO0OooOoO * OoooooooOO - OoooooooOO
def iioOo00O0o ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keywords' , '' , 'nan_menu' , '' , '' , '' , '' )
 if 18 - 18: o0oOo0
 if Iii1ii1II11i == 'true' and iI111iI != '' and IiII != '' :
  oO00oOOoooO ( '' , 'Install ' + IiII + ' keyword' , iI111iI , 'keywords' , '' , '' , '' , '' )
  if 37 - 37: II11iIiIIIiI % i11iIiiIii - o0Oo * OoooO0Oo0O0 . o0oOo0
 if oo00 == 'true' :
  oO00oOOoooO ( 'folder' , 'Install Add-ons' , oOOo0 , 'addonmenu' , '' , '' , '' , '' )
  if 62 - 62: OoooooooOO / o0oOo0 + OoooO0Oo0O0 . oOO00Oo - i1Iii1i1I
 if o00 == 'true' :
  oO00oOOoooO ( 'folder' , 'Community Builds' , url , 'community' , '' , '' , '' , '' )
  if 29 - 29: III1IiiI
  if 26 - 26: O0 % iiIi1i11 - i11111IIIII . iiIi1i11
def OOo0O0 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://install/",return)' )
 if 24 - 24: o0Oo / iIii1I11I1II1 / O0 . iIii1I11I1II1 - ii1ii11IIIiiI . iIii1I11I1II1
 if 8 - 8: OoooO0Oo0O0 % ii1ii11IIIiiI % III1IiiI . OoooO0Oo0O0 * OoooO0Oo0O0
def iiO00O00O000OOO ( repo_id ) :
 III11I = 1
 I1i11 = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( repo_id )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 o0O00oOOoo = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
 IiI111ii1ii = re . compile ( 'repo_url="(.+?)"' ) . findall ( IiIi1I1 )
 O0OOo = re . compile ( 'data_url="(.+?)"' ) . findall ( IiIi1I1 )
 IiIII1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( IiIi1I1 )
 OO0O0OOo0O = re . compile ( 'repo_id="(.+?)"' ) . findall ( IiIi1I1 )
 oooooo0 = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 oOOo0oo0O = o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
 IIii1Ii1i1ii1 = IiI111ii1ii [ 0 ] if ( len ( IiI111ii1ii ) > 0 ) else ''
 oOOoOOooO0 = O0OOo [ 0 ] if ( len ( O0OOo ) > 0 ) else ''
 Iii1IIII1Iii = IiIII1 [ 0 ] if ( len ( IiIII1 ) > 0 ) else ''
 OOOOOOo0o0O0o = OO0O0OOo0O [ 0 ] if ( len ( OO0O0OOo0O ) > 0 ) else ''
 iII1iiio0O0o = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , OOOOOOo0o0O0o + '.zip' ) )
 OO0o0o = xbmc . translatePath ( os . path . join ( II11iiii1Ii , OOOOOOo0o0O0o ) )
 if 61 - 61: o00O0OoO * iI1IiiIIIiIi + o00O0OoO - II11iIiIIIiI % O00OOOoOoo0O . i1Iii1i1I
 OOooO0OOoo . create ( 'Installing Repository' , 'Please wait...' , '' )
 if 51 - 51: iiIi1i11 / o00O0OoO
 try :
  downloader . download ( IIii1Ii1i1ii1 , iII1iiio0O0o , OOooO0OOoo )
  extract . all ( iII1iiio0O0o , II11iiii1Ii , OOooO0OOoo )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 51 - 51: o0oOo0 * III1IiiI - Iiii1i1 + i1Iii1i1I
 except :
  if 46 - 46: oOO00Oo - i11iIiiIii % ii1ii11IIIiiI / iI1IiiIIIiIi - O00OOOoOoo0O
  try :
   downloader . download ( Iii1IIII1Iii , iII1iiio0O0o , OOooO0OOoo )
   extract . all ( iII1iiio0O0o , II11iiii1Ii , OOooO0OOoo )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 88 - 88: III1IiiI * o0Oo / ii1ii11IIIiiI - iiIi1i11 / i1IIi . Iiii1i1
  except :
   if 26 - 26: i11iIiiIii - o0oOo0
   try :
    if 45 - 45: o0oOo0 + oO0OooOoO % i1Iii1i1I
    if not os . path . exists ( OO0o0o ) :
     os . makedirs ( OO0o0o )
     if 55 - 55: o0oOo0 - III1IiiI % o0Oo
    IiIi1I1 = IiIIi1 ( oOOoOOooO0 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    o0OO000ooOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IiIi1I1 )
    if 61 - 61: o0oOo0
    for OooO0oOo in o0OO000ooOo :
     oOOo00O0OOOo = xbmc . translatePath ( os . path . join ( OO0o0o , OooO0oOo ) )
     if 22 - 22: iIii1I11I1II1 / o0oOo0 / o0Oo - oOO00Oo
     if i11i1iiiII not in OooO0oOo and '/' not in OooO0oOo :
      if 21 - 21: III1IiiI . i11iIiiIii * o00O0OoO . iiIi1i11 / iiIi1i11
      try :
       OOooO0OOoo . update ( 0 , "Downloading [COLOR=yellow]" + OooO0oOo + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( oOOoOOooO0 + OooO0oOo , oOOo00O0OOOo , OOooO0OOoo )
       if 42 - 42: OoooooooOO / Iiii1i1 . oOO00Oo / O0 - i11111IIIII * i11111IIIII
      except :
       print "failed to install" + OooO0oOo
       if 1 - 1: iI1IiiIIIiIi % Iiii1i1
     if '/' in OooO0oOo and '..' not in OooO0oOo and 'http' not in OooO0oOo :
      O0O00OOo = oOOoOOooO0 + OooO0oOo
      OoOOo ( oOOo00O0OOOo , O0O00OOo )
      if 97 - 97: O00OOOoOoo0O
   except :
    iI111I11I1I1 . ok ( "Error downloading repository" , 'There was an error downloading[CR][COLOR=dodgerblue]' + oooooo0 + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    III11I = 0
    if 13 - 13: O00OOOoOoo0O % iiIi1i11 . O0 / II11iIiIIIiI % II11iIiIIIiI
    if 19 - 19: Iiii1i1 % o0oOo0 - o0oOo0 % o0Oo . iiIi1i11 - OoooooooOO
 if III11I == 1 :
  time . sleep ( 1 )
  OOooO0OOoo . update ( 0 , "[COLOR=yellow]" + oooooo0 + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing dependencies' )
  time . sleep ( 1 )
  II1i111 = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( repo_id )
  try :
   IiIIi1 ( II1i111 , 5 )
  except :
   pass
  return True
 else :
  return False
  if 100 - 100: o0Oo + iI1IiiIIIiIi + oOO00Oo . i1IIi % OoooooooOO
  if 64 - 64: O0 % i1IIi * Iiii1i1 - iI1IiiIIIiIi + II11iIiIIIiI
def oOi1II111i1IIii ( ) :
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  What is Community Builds?' , 'url' , 'instructions_3' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Creating a Community Build' , 'url' , 'instructions_1' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Installing a Community Build' , 'url' , 'instructions_2' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Add Your Own Guides @ [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' , 'K0XIxEodUhc' , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Community Builds FULL GUIDE' , "ewuxVfKZ3Fs" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  IMPORTANT initial settings' , "1vXniHsEMEg" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Install a Community Build' , "kLsVOapuM1A" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Fixing a half installed build (guisettings.xml fix)' , "X8QYLziFzQU" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 1)' , "3rMScZF2h_U" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 2)' , "C2IPhn0OSSw" , 'play_video' , '' , '' , '' , '' )
 if 50 - 50: o0Oo % i11iIiiIii - o0Oo * i1Iii1i1I / i11111IIIII / O0
 if 31 - 31: oO0OooOoO . OoooooooOO + ii1ii11IIIiiI + oOO00Oo . o0Oo . oO0OooOoO
def I111I ( ) :
 OOooO0OO0 ( 'Creating A Backup To Share' ,
 '[COLOR=gold]THE OPTIONS:[/COLOR][CR]There are 3 options when choosing to create a backup, we shall explain here the differences between them:[CR][CR]'
 '[COLOR=dodgerblue]1. noobsandnerds Community Build[/COLOR] - This is by far the best way to create a build that you want to share with others, it will create a zip file for you to share that can only be used on with this add-on. The size of the zip will be incredibly small compared to other backup options out there and it will also do lots of other clever stuff too such as error checking against the Addon Portal and the addons will always be updated via the relevant developer repositories. Added to this when it comes to updating it\'s a breeze, only the new addons not already on the system will be installed and for the majority of builds Kodi won\'t even have to restart after installing![CR][CR]'
 '[COLOR=dodgerblue]2. Universal Build[/COLOR] - This was the original method created by TotalXBMC, we would really only recommend this if for some strange reason you want your build available on other inferior wizards. The zip size is much larger and every time someone wants to update their build they have to download and install the whole thing again which can be very frustrating and time consuming. The whole build is backed up in full with the exception of the packages and thumbnails folder. Just like the option above all physical paths (so long as they exist somewhere in the Kodi environment) will be changed to special paths so they work on all devices.[CR][CR]'
 '[COLOR=dodgerblue]3. Full Backup[/COLOR] - It\'s highly unlikely you will ever want to use this option and it\'s more for the geeks out there. It will create a complete backup of your setup and not do any extra clever stuff. Things like packages will remain intact as will temp cache files, be warned the size could be VERY large![CR][CR]'
 '[CR][COLOR=gold]CREATING A COMMUNITY BUILD:[/COLOR][CR][CR][COLOR=blue][B]Step 1:[/COLOR] Remove any sensitive data[/B][CR]Make sure you\'ve removed any sensitive data such as passwords and usernames in your addon_data folder.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Backup your system[/B][CR]Choose the backup option you want from the list on the previous page, if you\'re sharing this via the CP Addon then please use the noobsandnerds backup option, this will create two zip files that you need to upload to a server.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip files to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it. [COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Submit the build[/B]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR].[CR]Full details can be found on there of the template you should use when posting, once you\'ve created your support thread (NOT BEFORE) you can request to become a member of the Community Builder group and you\'ll then be able to add your build via the web form. As soon as you\'ve successfully added the details your build will be live, if you can\'t find it in the CP addon make sure you have XXX enabled (if you marked it as having adult content) and also make sure you\'re running the same version of Kodi that you said it was compatible with. If you\'re running another version then you can select the option to "show all community builds" in the addon settings and that will show even the builds that aren\'t marked as compatible with your version of Kodi.'
 '[CR][CR][COLOR=gold]PRIVATE BUILDS[/COLOR][CR]If you aren\'t interested in sharing your build with the community you can still use our system for private builds. Just follow the instructions above but you will not need to create a support thread and you WILL require a minimum of 5 useful (not spam) posts on the forum. The 5 post rule only applies to users that wish to use the private builds option. Once you have 5 posts you\'ll be able to access the web form and in there you can enter up to 3 IP addresses that you want to be able to view your build(s). Anybody caught disobeying the forum rules will be banned so please make sure you understand the forum rules before posting, we welcome everyone but there is strictly no spamming or nonsense posts just saying something like "Thanks" in order to bump up your post count. The site rules even have examples of how you can get to 5 posts without receiving a ban.' )
 if 86 - 86: oO0OooOoO . i11111IIIII + OoooooooOO
 if 22 - 22: oO0OooOoO / OoooO0Oo0O0 * i11111IIIII - oOO00Oo % OoooO0Oo0O0
def oo00o0OO ( ) :
 OOooO0OO0 ( 'Installing a build' , '[COLOR=dodgerblue][B]Step 1 (Optional):[/COLOR] Backup your system[/B][CR]When selecting an install option you\'ll be asked if you want to create a backup - we strongly recommend creating a backup of your system in case you don\'t like the build and want to revert back. Remember your backup may be quite large so if you\'re using a device with a very small amount of storage we recommend using a USB stick or SD card as the storage location otherwise you may run out of space and the install may fail.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Choose an install method:[/B][CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]1. Overwrite my current setup & install new build:[/COLOR] This copy over the whole build[CR]As the title suggests this will overwrite your existing setup with the one created by the community builder. We recommend using the wipe option in the maintenance section before running this, that will completely wipe your existing settings and will ensure you don\'t have any conflicting data left on the device. Once you\'ve wiped please restart Kodi and install the build, you can of course use this install option 1 without wiping but you may encounter problems. If you choose to do this DO NOT bombard the community builder with questions on how to fix certain things, they will expect you to have installed over a clean setup and if you\'ve installed over another build the responsibility for bug tracking lies solely with you!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]2. Install:[/COLOR] Keep my library & profiles[CR]This will install a build over the top of your existing setup so you won\'t lose anything already installed in Kodi. Your library and any profiles you may have setup will also remain unchanged.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]3. Install:[/COLOR] Keep my library only[CR]This will do exactly the same as number 2 (above) but it will delete any profiles you may have and replace them with the ones the build author has created.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]4. Install:[/COLOR] Keep my profiles only[CR]Again, the same as number 2 but your library will be replaced with the one created by the build author. If you\'ve spent a long time setting up your library and have it just how you want it then use this with caution and make sure you do a backup!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Replace or keep settings?[/B][CR]When completing the install process you\'ll be asked if you want to keep your existing Kodi settings or replace with the ones in the build. If you choose to keep your settings then only the important skin related settings are copied over from the build. All your other Kodi settings such as screen calibration, region, audio output, resolution etc. will remain intact. Choosing to replace your settings could possibly cause a few issues, unless the build author has specifically recommended you replace the settings with theirs we would always recommend keeping your own.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4: [/COLOR][COLOR=red]VERY IMPORTANT[/COLOR][/B][CR]For the install to complete properly Kodi MUST force close, this means forcing it to close via your operating system rather than elegantly via the Kodi menu. By default this add-on will attempt to make your operating system force close Kodi but there are systems that will not allow this (devices that do not allow Kodi to have root permissions).'
 ' Once the final step of the install process has been completed you\'ll see a dialog explaining Kodi is attempting a force close, please be patient and give it a minute. If after a minute Kodi hasn\'t closed or restarted you will need to manually force close. The recommended solution for force closing is to go into your operating system menu and make it force close the Kodi app but if you dont\'t know how to do that you can just pull the power from the unit.'
 ' Pulling the power is fairly safe these days, on most set top boxes it\'s the only way to switch them off - they rarely have a power switch. Even though it\'s considered fairly safe nowadays you do this at your own risk and we would always recommend force closing via the operating system menu.' )
 if 27 - 27: O0
 if 95 - 95: O00OOOoOoo0O . II11iIiIIIiI + oO0OooOoO - OoooO0Oo0O0
def OoOOoo0o00O0oO ( ) :
 OOooO0OO0 ( 'What is a noobsandnerds keyword?' , '[COLOR=gold]WHAT IS A KEYWORD?[/COLOR][CR]The noobsandnerds keywords are based on the ingenious TLBB keyword system that was introduced years ago. It\'s nothing new and unlike certain other people out there we\'re not going to claim it as our idea. If you\'re already familiar with TLBB Keywords or even some of the copies out there like Cloudwords you will already know how this works but for those of you that don\'t have one of those devices we\'ll just go through the details...'
 '[CR][CR]Anyone in the community can make their own keywords and share them with others, it\'s a simple word you type in and then the content you uploaded to the web is downloaded and installed. Previously keywords have mostly been used for addon packs, this is a great way to get whole packs of addons in one go without the need to install a whole new build. We are taking this to the next level and will be introducing artwork packs and also addon fixes. More details will be available in the Community Portal section of the forum on www.noobsandnerds.com'
 '[CR][CR][CR][COLOR=gold]HOW DO I FIND A KEYWORD?[/COLOR][CR]The full list of noobsandnerds keywords can be found on the forum, in the Community Portal section you\'ll see a section for the keywords at the top of the page. Just find the pack you would like to install then using this addon type the keyword in when prompted (after clicking "Install a noobsandnerds keyword"). Your content will now be installed, if installing addon packs please be patient while each addon updates to the latest version directly from the developers repo.'
 '[CR][CR][CR][COLOR=gold]CAN I USE OTHER KEYWORDS?[/COLOR] (Cloudwords, TLBB etc.)[CR]Yes you can, just go to the addon settings and enter the url shortener that particular company use. Again you will find full details of supported keywords on the forum.' )
 if 28 - 28: OoooooooOO % O0 - iiIi1i11 / oOO00Oo / o0Oo
 if 41 - 41: oO0OooOoO * i11111IIIII / ii1ii11IIIiiI . III1IiiI
def IiiiiI ( ) :
 OOooO0OO0 ( 'How to create a keyword?' , '[COLOR=gold]NaN MAKE IT EASY![/COLOR][CR]The keywords can now be made very simply by anyone. We\'ve not locked this down to just our addon and others can use this on similar systems for creating keywords if they want...'
 '[CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Use a vanilla Kodi setup[/B][CR]You will require a complete fresh install of Kodi with absolutely nothing else installed and running the default skin. Decide what kind of pack you want to create, lets say we want to create a kids pack... Add all the kid related addons you want and make sure you also have the relevant repository installed too. In the unlikely event you\'ve found an addon that doesn\'t belong in a repository that\'s fine the system will create a full backup of that addon too (just means it won\'t auto update with future updates to the addon).'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Create the backup[/B][CR]Using this addon create your backup, currently only addon packs are supported but soon more packs will be added. When you create the keyword you\'ll be asked for a location to store the zip file that will be created and a name, this can be anywhwere you like and can be called whatever you want - you do not need to add the zip extension, that will automatically be added for you so in our example here we would call it "kids".'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip file to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it.[CR][CR][COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Create the keyword[/B][CR]Copy the download URL to your clipboard and then go to www.urlshortbot.com. In here you need to enter the URL in the "Long URL" field and then in the "Custom Keyword" field you need to enter "noobs" (without the quotation marks) followed by your keyword. We recommend always using a random test keyword for testing because once you have a keyword you can\'t change it, also when uploading make sure it\'s a link you can edit and still keep the same URL - that way it\'s easy to keep up to date and you can still use the same keyword. In our example of kids we would set the custom keyword as "noobskids". The noobs bit is ignored and is only for helping the addon know what to look for, the user would just type in "kids" for the kids pack to be installed.' )
 if 12 - 12: i11iIiiIii . o00O0OoO * iiIi1i11 % i1IIi . o0oOo0
 if 58 - 58: i1Iii1i1I % iIii1I11I1II1 . iIii1I11I1II1 / o00O0OoO
def OOO0O ( ) :
 OOooO0OO0 ( 'Adding Third Party Wizards' , '[COLOR=gold]ONE WIZARD TO RULE THEM ALL![/COLOR][CR]Did you know the vast majority of wizards out there (every single one we\'ve tested) has just been a copy/paste of very old code created by the team here? We\'ve noticed a lot of the users installing builds via these third party wizards have run into many different problems so we thought we\'d take it upon ourselves to help out...'
 '[CR][CR][CR][COLOR=gold]WHAT BENEFITS DOES THIS HAVE?[/COLOR][CR]We\'ve added extra code that checks for common errors, unfortunately there are some people out there using inferior programs to create their backups and that is causing problems in their wizards. If such a problem exists when trying to use another wizard you can try adding the details to this addon and it automatically fixes any corrupt files it finds. Of course there are other benefits... installing code from an unknown source can give the author access to your system so make sure you always trust the author(s). Why take the risk of installing wizards created by anonymous usernames on social media sites when you can install from a trusted source like noobsandnerds and you\'ll also be safe in the knowledge that any new updates and improvements will be made here first - we do not copy/paste code, we are actively creating new exciting solutions!'
 '[CR][CR][CR][COLOR=gold]ADDING 3RD PARTY WIZARDS TO THIS ADDON[/COLOR][CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Enabling 3rd Party Wizards[/B][CR]In the addon settings under the Community Builds section you have the option to enable third party community builds, if you click on this you will be able to enter details of up to 5 different wizards.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Enter the URL[/B][CR]As virtually all wizards use exactly the same structure all you need to do is find out what URL they are looking up in the code, you can open the default.py file of the wizard in a text editor and search for "http" and you will more than likely find the URL straight away. Try entering it in a web address, it should show the details for all the builds in that wizard in a text based page. If the page is blank don\'t worry it may just be locked from web browsers and can only be opened in Kodi, try it out and see if it works.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Enter the name[/B][CR]Give the wizard a name, now when you go into the Community Builds section you\'ll have the official noobsandnerds builds as an option and also any new ones you\'ve added.' )
 if 21 - 21: II11iIiIIIiI / i11111IIIII * O00OOOoOoo0O - Iiii1i1
 if 44 - 44: OoooooooOO + iI1IiiIIIiIi
def Oooooo0O ( url = 'http://www.iplocation.net/' , inc = 1 ) :
 o0OO000ooOo = re . compile ( "<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>" ) . findall ( ooOooo000oOO . http_GET ( url ) . content )
 for oooo000 , ii1II1I , oOoo0 , oo0o0o in o0OO000ooOo :
  if inc < 2 : iI111I11I1I1 = xbmcgui . Dialog ( ) ; iI111I11I1I1 . ok ( 'Check My IP' , "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % oooo000 , '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % oOoo0 , '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % oo0o0o )
  inc = inc + 1
  if 25 - 25: i11111IIIII * Iiii1i1 - III1IiiI * i11iIiiIii * o0Oo * iiIi1i11
  if 56 - 56: OoooooooOO . o0Oo . oO0OooOoO % i1Iii1i1I
def O0OOOO0o0O ( url ) :
 if not os . path . exists ( O00O0oOO00O00 ) :
  os . makedirs ( O00O0oOO00O00 )
  if 76 - 76: ii1ii11IIIiiI + iiIi1i11 - i11111IIIII . i1IIi
 o0o00O = ''
 I1II1IiI1 = 'Enter Keyword'
 Iii1I11i1IiiI = OOoo ( I1II1IiI1 )
 o0o00O = url + Iii1I11i1IiiI
 OoO00 = os . path . join ( O00O0oOO00O00 , Iii1I11i1IiiI + '.zip' )
 if 76 - 76: O00OOOoOoo0O * iI1IiiIIIiIi * iIii1I11I1II1 * i1IIi - OoooO0Oo0O0
 if Iii1I11i1IiiI != '' :
  I1Ii11I1i1iii = iI111I11I1I1 . yesno ( 'Backup existing setup' , 'Installing certain keywords can result in some existing settings or add-ons to be replaced. Would you like to create a backup before proceeding?' )
  if 83 - 83: O0 / ii1ii11IIIiiI
  if I1Ii11I1i1iii == 1 :
   o0O000O00o ( )
   if 38 - 38: OoooooooOO . i1Iii1i1I
  try :
   if iiIIIII1i1iI == 'true' :
    print "### Attempting download " + o0o00O + " to " + OoO00
   OOooO0OOoo . create ( "Web Installer" , "Downloading " , '' , 'Please Wait' )
   downloader . download ( o0o00O , OoO00 )
   print "### Keyword " + Iii1I11i1IiiI + " Successfully downloaded"
   OOooO0OOoo . update ( 0 , "" , "Extracting Zip Please Wait" )
   if 43 - 43: OoooooooOO
   if zipfile . is_zipfile ( OoO00 ) :
    if 8 - 8: iiIi1i11 + o00O0OoO . o00O0OoO
    try :
     extract . all ( OoO00 , iIii1 , OOooO0OOoo )
     xbmc . executebuiltin ( 'UpdateLocalAddons' )
     xbmc . executebuiltin ( 'UpdateAddonRepos' )
     iI111I11I1I1 . ok ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "" , "Content now installed" , "" )
     OOooO0OOoo . close ( )
     if 89 - 89: OoooO0Oo0O0 * OoooO0Oo0O0 * O00OOOoOoo0O / i1Iii1i1I
    except :
     iI111I11I1I1 . ok ( "Error with zip" , 'There was an error trying to install this file. It may possibly be corrupt, either try again or contact the author of this keyword.' )
     print "### Unable to install keyword (passed zip check): " + Iii1I11i1IiiI
   else :
    iI111I11I1I1 . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
    if 60 - 60: ii1ii11IIIiiI / i1Iii1i1I / o0Oo + III1IiiI
  except :
   iI111I11I1I1 . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
   print "### Unable to install keyword (unknown error, most likely a typo in keyword entry): " + Iii1I11i1IiiI
   if 93 - 93: OoooooooOO * iI1IiiIIIiIi / O0 + iI1IiiIIIiIi - iIii1I11I1II1
 if os . path . exists ( OoO00 ) :
  os . remove ( OoO00 )
  if 6 - 6: i11111IIIII - II11iIiIIIiI - o00O0OoO - O0 % OoooooooOO
  if 88 - 88: O0 / oOO00Oo * oOO00Oo . oOO00Oo . O0
def O00000OO00OO ( ) :
 if 27 - 27: i11iIiiIii % i1Iii1i1I + iI1IiiIIIiIi . iiIi1i11
 if not os . path . exists ( OOoOO0oo0ooO ) :
  os . makedirs ( OOoOO0oo0ooO )
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 oOOo0oo0O = float ( III1I1I [ : 4 ] )
 if xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if oOOo0oo0O < 14 :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'win_xbmc.bat' ) , 'w+' )
    o0oooOO00 . write ( '@ECHO off\nTASKKILL /im XBMC.exe /f\ntskill XBMC.exe\nXBMC.exe' )
    o0oooOO00 . close ( )
    os . system ( os . path . join ( OOoOO0oo0ooO , 'win_xbmc.bat' ) )
   except :
    print "### Failed to run win_xbmc.bat"
  else :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'win_kodi.bat' ) , 'w+' )
    o0oooOO00 . write ( '@ECHO off\nTASKKILL /im Kodi.exe /f\ntskill Kodi.exe\nKodi.exe' )
    o0oooOO00 . close ( )
    os . system ( os . path . join ( OOoOO0oo0ooO , 'win_kodi.bat' ) )
   except :
    print "### Failed to run win_kodi.bat"
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  if oOOo0oo0O < 14 :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) , 'w+' )
    o0oooOO00 . write ( 'killall -9 XBMC\nXBMC' )
    o0oooOO00 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod 755 ' + os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) )
   except :
    print "### Failed to run osx_xbmc.sh"
  else :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) , 'w+' )
    o0oooOO00 . write ( 'killall -9 Kodi\nKodi' )
    o0oooOO00 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod 755 ' + os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) )
   except :
    print "### Failed to run osx_kodi.sh"
    if 9 - 9: ii1ii11IIIiiI
 elif xbmc . getCondVisibility ( 'system.platform.android' ) :
  if os . path . exists ( '/data/data/com.rechild.advancedtaskkiller' ) :
   iI111I11I1I1 . ok ( 'Attempting to force close' , 'On the following screen please press the big button at the top which says "KILL selected apps". Kodi will restart, please be patient while your system updates the necessary files and your skin will automatically switch once fully updated.' )
   try :
    xbmc . executebuiltin ( 'StartAndroidActivity(com.rechild.advancedtaskkiller)' )
   except :
    print "### Failed to run Advanced Task Killer. Make sure you have it installed, you can download from https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk"
  else :
   iI111I11I1I1 . ok ( 'Advanced Task Killer Not Found' , "The Advanced Task Killer app cannot be found on this system. Please make sure you actually installed it after downloading. We can't do everything for you - on Android you do have to physically click on the download to install an app." )
  try :
   os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc,kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc.xbmc());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc());' )
  except :
   pass
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  if oOOo0oo0O < 14 :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) , 'w+' )
    o0oooOO00 . write ( 'killall XBMC\nkillall -9 xbmc.bin\nXBMC' )
    o0oooOO00 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod a+x ' + os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) )
   except :
    print "### Failed to run: linux_xbmc"
  else :
   try :
    o0oooOO00 = open ( os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) , 'w+' )
    o0oooOO00 . write ( 'killall Kodi\nkillall -9 kodi.bin\nkodi' )
    o0oooOO00 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod a+x ' + os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) )
   except :
    print "### Failed to run: linux_kodi"
 else :
  try :
   os . system ( 'killall AppleTV' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop kodi' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop xbmc' )
  except :
   pass
   if 43 - 43: iI1IiiIIIiIi . iiIi1i11 + o0Oo * i11iIiiIii
   if 2 - 2: iiIi1i11
def IiOoo0o0OO0 ( ) :
 xbmc . executebuiltin ( 'ReplaceWindow(settings)' )
 if 75 - 75: o0oOo0 % iiIi1i11 / oOO00Oo % oO0OooOoO
 if 30 - 30: oOO00Oo
def o0O000O00o ( ) :
 i1iI1i ( )
 if 15 - 15: oO0OooOoO - iI1IiiIIIiIi - i1Iii1i1I . III1IiiI / i11iIiiIii
 IiiOoo0o0ooooOOo = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
 oOoOO0000oO00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 O0oiIiiIi = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 38 - 38: ii1ii11IIIiiI
 if not os . path . exists ( IiiOoo0o0ooooOOo ) :
  os . makedirs ( IiiOoo0o0ooooOOo )
  if 3 - 3: oO0OooOoO . o0Oo / II11iIiIIIiI + oOO00Oo
 Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
 if 54 - 54: i1IIi - oO0OooOoO . i1IIi
 if ( not Oo0OOo ) :
  return False , 0
  if 33 - 33: i1Iii1i1I + II11iIiIIIiI % o00O0OoO . III1IiiI
 I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( IiiOoo0o0ooooOOo , I1II1IiI1 + '.zip' ) )
 o00oo = [ o0OO00 ]
 O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 iI1ii11Ii = "Creating full backup of existing build"
 OOOoOooO000oO = "Creating Community Build"
 O0OO0OO = "Archiving..."
 Ooo0oO = ""
 IiIiIIiii1I = "Please Wait"
 if 6 - 6: i11111IIIII + OoooO0Oo0O0
 oOo0OOoooO ( iIii1 , oOoOO0000oO00 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
 iI111I11I1I1 . ok ( 'Full Backup Complete' , 'You can locate your backup at:[COLOR=dodgerblue]' , oOoOO0000oO00 + '[/COLOR]' )
 if 62 - 62: III1IiiI . Iiii1i1 - OoooooooOO * oO0OooOoO . i11iIiiIii
 if 13 - 13: iIii1I11I1II1 * oOO00Oo - i11iIiiIii
def oo0O0OO0Oooo ( ) :
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 oOOo0oo0O = float ( III1I1I [ : 4 ] )
 if 7 - 7: oO0OooOoO - OoooO0Oo0O0 / o00O0OoO % OoooooooOO + i1IIi
 if oOOo0oo0O < 14 :
  I1Iii1 = os . path . join ( O0Oo000ooO00 , 'xbmc.log' )
  OOooO0OO0 ( 'XBMC Log' , I1Iii1 )
  if 9 - 9: oO0OooOoO % II11iIiIIIiI * iI1IiiIIIiIi + i11111IIIII % ii1ii11IIIiiI . i1IIi
 else :
  I1Iii1 = os . path . join ( O0Oo000ooO00 , 'kodi.log' )
  OOooO0OO0 ( 'Kodi Log' , I1Iii1 )
  if 68 - 68: oO0OooOoO % Iiii1i1 * i11iIiiIii
  if 9 - 9: oO0OooOoO + OoooO0Oo0O0 / i1Iii1i1I
def O0OOOo0o0O0 ( ) :
 iI111I11I1I1 . ok ( "Restore local guisettings fix" , "You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix is failing to download via the addon. Installing via this method means you do not receive notifications of updates" )
 I1I1i1 ( )
 if 36 - 36: o0Oo / II11iIiIIIiI % iIii1I11I1II1 / O0 . OoooO0Oo0O0
 if 53 - 53: oOO00Oo % OoooooooOO - III1IiiI - i1IIi / ii1ii11IIIiiI
def i1111II1iIII ( mode ) :
 if 41 - 41: i11111IIIII * OoooooooOO . o0oOo0 % i11iIiiIii
 Oo0OOo = i1II11I11ii1 ( heading = "Search for content" )
 if 11 - 11: iIii1I11I1II1 . Iiii1i1 - II11iIiIIIiI / o00O0OoO + oO0OooOoO
 if ( not Oo0OOo ) :
  return False , 0
  if 29 - 29: o00O0OoO . i11iIiiIii + i1IIi - iI1IiiIIIiIi + O0 . o0Oo
 I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 if 8 - 8: oOO00Oo
 if mode == 'tutorials' :
  iI1I1 ( 'name=' + I1II1IiI1 )
  if 78 - 78: i1IIi - II11iIiIIIiI
 if mode == 'hardware' :
  ii11 ( 'name=' + I1II1IiI1 )
  if 48 - 48: iI1IiiIIIiIi - OoooooooOO + Iiii1i1 % oOO00Oo - O00OOOoOoo0O . o0Oo
 if mode == 'news' :
  OO0oOoo ( 'name=' + I1II1IiI1 )
  if 42 - 42: Iiii1i1
 if mode . endswith ( "premium" ) or mode . endswith ( "public" ) or mode . endswith ( "private" ) :
  IIiI ( mode + '&name=' + I1II1IiI1 )
  if 70 - 70: oOO00Oo / o00O0OoO + III1IiiI % o0Oo % II11iIiIIIiI + ii1ii11IIIiiI
  if 80 - 80: iiIi1i11
  if 12 - 12: iI1IiiIIIiIi
  if 2 - 2: OoooooooOO
  if 100 - 100: II11iIiIIIiI / O0 * i11iIiiIii * OoooooooOO
  if 46 - 46: O0 % OoooooooOO
  if 22 - 22: i1Iii1i1I + OoooooooOO - O00OOOoOoo0O - ii1ii11IIIiiI * Iiii1i1 - III1IiiI
  if 99 - 99: o0oOo0 / o0Oo . iI1IiiIIIiIi - iI1IiiIIIiIi * o0Oo
  if 24 - 24: o00O0OoO * ii1ii11IIIiiI - III1IiiI / iIii1I11I1II1 - II11iIiIIIiI . iiIi1i11
def I1IiiI11 ( ) :
 oO00oOOoooO ( '' , 'Install a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , 'http://urlshortbot.com/noobs' , 'keywords' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , 'create_pack' , 'create_keyword' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Installing a keyword' , '' , 'instructions_3' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Creating a keyword' , '' , 'instructions_4' , '' , '' , '' , '' )
 if 46 - 46: ii1ii11IIIiiI % OoooO0Oo0O0
 if 58 - 58: III1IiiI + i11111IIIII % i1Iii1i1I - iI1IiiIIIiIi - iiIi1i11 % iI1IiiIIIiIi
def oo0OOOoO ( url ) :
 I1i11 = 'http://noobsandnerds.com/TI/LatestNews/LatestNews.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 OO0 = re . compile ( 'author="(.+?)"' ) . findall ( IiIi1I1 )
 II1111i11i11 = re . compile ( 'date="(.+?)"' ) . findall ( IiIi1I1 )
 IIii11Ii1i1I = re . compile ( 'content="(.+?)###END###"' ) . findall ( IiIi1I1 )
 if 43 - 43: O0 * i11iIiiIii - OoooooooOO - III1IiiI
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 Iii1II1ii = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else ''
 iIIiII1i1ii = II1111i11i11 [ 0 ] if ( len ( II1111i11i11 ) > 0 ) else ''
 i11i = IIii11Ii1i1I [ 0 ] if ( len ( IIii11Ii1i1I ) > 0 ) else ''
 iIiiI1iIiI1I = oOo0O ( i11i )
 O00Oo = str ( '[COLOR=orange]Source: [/COLOR]' + Iii1II1ii + '     [COLOR=orange]Date: [/COLOR]' + iIIiII1i1ii + '[CR][CR][COLOR=lime]Details: [/COLOR][CR]' + iIiiI1iIiI1I )
 if 90 - 90: OoooO0Oo0O0 - i1Iii1i1I . i11iIiiIii / o0Oo
 OOooO0OO0 ( i1iIIIi1i , O00Oo )
 if 41 - 41: Iiii1i1 * ii1ii11IIIiiI - i1Iii1i1I . iI1IiiIIIiIi
 if 41 - 41: iIii1I11I1II1 - O0 - OoooO0Oo0O0 - III1IiiI + Iiii1i1
def Ii1111iI1i1 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'news' , 'manual_search' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][All News][/COLOR] From all sites' , str ( url ) + '' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Official Kodi.tv News' , str ( url ) + '&author=Official%20Kodi' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'OpenELEC News' , str ( url ) + '&author=OpenELEC' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Raspbmc News' , str ( url ) + '&author=Raspbmc' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] News' , str ( url ) + '&author=noobsandnerds' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'XBMC4Xbox News' , str ( url ) + '&author=XBMC4Xbox' , 'grab_news' , '' , '' , '' , '' )
 if 78 - 78: OoooO0Oo0O0 . i1Iii1i1I % oO0OooOoO
 if 90 - 90: OoooooooOO % i11iIiiIii % oOO00Oo % Iiii1i1 - o0oOo0 + iIii1I11I1II1
def oooO ( title , message , times , icon ) :
 icon = oOOoo0Oo + icon
 xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," + times + "," + icon + ")" )
 if 83 - 83: Iiii1i1 . O0 + O0 - O0 - o00O0OoO
 if 6 - 6: III1IiiI / OoooO0Oo0O0 / ii1ii11IIIiiI
def iiiiIIii1I ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(filemanager,return)' )
 return
 if 14 - 14: iiIi1i11 * o0Oo - OoooO0Oo0O0
 if 10 - 10: i1Iii1i1I % Iiii1i1 * OoooO0Oo0O0 * O0 * i11iIiiIii % Iiii1i1
def ooOoo0O0o0OO0 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(systeminfo)' )
 if 47 - 47: Iiii1i1 * iiIi1i11
 if 8 - 8: II11iIiIIIiI
def IiIIi1 ( url , t ) :
 i1iII1IiI1I = urllib2 . Request ( url )
 i1iII1IiI1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 10.0; WOW64; Windows NT 5.1; en-GB; rv:1.9.0.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 Gecko/2008092417 Firefox/3.0.3' )
 if 31 - 31: OoooooooOO % i11iIiiIii - oO0OooOoO * i11iIiiIii
 ooO00 = 0
 IIi1I1iII111 = False
 while ooO00 < 5 and IIi1I1iII111 == False :
  I11II1i1I11I1 = urllib2 . urlopen ( i1iII1IiI1I , timeout = t )
  IiIi1I1 = I11II1i1I11I1 . read ( )
  I11II1i1I11I1 . close ( )
  ooO00 += 1
  if IiIi1I1 != '' :
   IIi1I1iII111 = True
 if IIi1I1iII111 == True :
  return IiIi1I1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 else :
  iI111I11I1I1 . ok ( 'Unable to contact server' , 'There was a problem trying to access the server, please try again later.' )
  return
  if 11 - 11: o0oOo0 - OoooooooOO
  if 55 - 55: o00O0OoO + i1IIi - i1Iii1i1I + oOO00Oo * i11111IIIII
def oooo00o0O0 ( ) :
 import tarfile
 if 43 - 43: O00OOOoOoo0O * ii1ii11IIIiiI % i1IIi * iI1IiiIIIiIi + iIii1I11I1II1
 if not os . path . exists ( oO0 ) :
  os . makedirs ( oO0 )
  if 80 - 80: oOO00Oo . i1Iii1i1I . OoooooooOO
 OOooO0OOoo . create ( "Creating Backup" , "Adding files... " , '' , 'Please Wait' )
 o00o000Oo = tarfile . open ( os . path . join ( oO0 , IiIiIIIiI1iII ( ) + '.tar' ) , 'w' )
 if 29 - 29: OoooooooOO . i11iIiiIii * i11iIiiIii / III1IiiI
 for O0O0Ooo0 in III1iII1I1ii :
  OOooO0OOoo . update ( 0 , "Backing Up" , '[COLOR blue]%s[/COLOR]' % O0O0Ooo0 , 'Please Wait' )
  o00o000Oo . add ( O0O0Ooo0 )
  if 34 - 34: III1IiiI - oO0OooOoO - oOO00Oo + i1Iii1i1I + Iiii1i1
 o00o000Oo . close ( )
 OOooO0OOoo . close ( )
 if 70 - 70: OoooooooOO + ii1ii11IIIiiI * II11iIiIIIiI
 if 20 - 20: i11iIiiIii - oO0OooOoO - o0oOo0 % III1IiiI . o0oOo0
def I1IiiiIiI ( ) :
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 if 50 - 50: iIii1I11I1II1 + Iiii1i1 - o00O0OoO - OoooooooOO
 if os . path . exists ( os . path . join ( O0Oo000ooO00 , 'xbmc.log' ) ) :
  i1i111i1 = 'xbmc.log'
 elif os . path . exists ( os . path . join ( O0Oo000ooO00 , 'kodi.log' ) ) :
  i1i111i1 = 'kodi.log'
 elif os . path . exists ( os . path . join ( O0Oo000ooO00 , 'spmc.log' ) ) :
  i1i111i1 = 'spmc.log'
 elif os . path . exists ( os . path . join ( O0Oo000ooO00 , 'tvmc.log' ) ) :
  i1i111i1 = 'tvmc.log'
 try :
  O0OO0o0OO0OO = open ( os . path . join ( O0Oo000ooO00 , i1i111i1 ) , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
 except :
  return False
 if 'Running on OpenELEC' in i11i :
  return True
  if 84 - 84: O00OOOoOoo0O - o00O0OoO
  if 80 - 80: i11iIiiIii % iiIi1i11 - II11iIiIIIiI % iiIi1i11
def O0O0oOo0o0o0 ( ) :
 xbmc . executebuiltin ( 'RunAddon(service.openelec.settings)' )
 if 86 - 86: oOO00Oo / O00OOOoOoo0O
 if 40 - 40: i1Iii1i1I
def o000 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Install:[/COLOR]  Installation tutorials (e.g. flashing a new OS)' , str ( url ) + '&thirdparty=InstallTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Add-on Tools:[/COLOR]  Add-on maintenance and coding tutorials' , str ( url ) + '&thirdparty=AddonTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Audio Tools:[/COLOR]  Audio related tutorials' , str ( url ) + '&thirdparty=AudioTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Gaming Tools:[/COLOR]  Integrate a gaming section into your setup' , str ( url ) + '&thirdparty=GamingTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Image Tools:[/COLOR]  Tutorials to assist with your pictures/photos' , str ( url ) + '&thirdparty=ImageTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Library Tools:[/COLOR]  Music and Video Library Tutorials' , str ( url ) + '&thirdparty=LibraryTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Skinning Tools:[/COLOR]  All your skinning advice' , str ( url ) + '&thirdparty=SkinningTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Video Tools:[/COLOR]  All video related tools' , str ( url ) + '&thirdparty=VideoTools' , 'grab_tutorials' , '' , '' , '' , '' )
 if 85 - 85: i1IIi % oOO00Oo * OoooO0Oo0O0 * ii1ii11IIIiiI . oO0OooOoO
 if 69 - 69: iI1IiiIIIiIi / Iiii1i1 % Iiii1i1 / o0oOo0 + Iiii1i1 / i1IIi
def oo000o ( xmlfile ) :
 if 70 - 70: iiIi1i11 - i11111IIIII . Iiii1i1
 if 'http' in xmlfile :
  IiII11 = 'none'
  oO00oI1I = xmlfile [ - 10 : ]
  oO00oI1I = oO00oI1I [ : - 4 ]
  OOO = os . path . join ( O0OoO000O0OO , o0OO00 , 'latest' )
  if 5 - 5: OoooO0Oo0O0 % i11iIiiIii / i1IIi * o0Oo
  if os . path . exists ( OOO ) :
   OoO = open ( OOO , mode = 'r' )
   IiII11 = OoO . read ( )
   OoO . close ( )
   if 33 - 33: o0Oo / o00O0OoO . II11iIiIIIiI
  if IiII11 == oO00oI1I :
   oO00oI1I = IiII11
   if 89 - 89: i1Iii1i1I + i1IIi - i11111IIIII + o0oOo0 . oO0OooOoO
  else :
   OOooO0OOoo . create ( 'Grabbing Latest Updates' , '' , '' , '' )
   downloader . download ( xmlfile , os . path . join ( II11iiii1Ii , o0OO00 , 'resources' , 'skins' , 'DefaultSkin' , 'media' , 'latest.jpg' ) )
   o0oooOO00 = open ( OOO , mode = 'w+' )
   o0oooOO00 . write ( oO00oI1I )
   o0oooOO00 . close ( )
  xmlfile = 'latest.xml'
 Oo00oOOO0 = O0ooO0Oo00o ( xmlfile , i1IiI1I11 . getAddonInfo ( 'path' ) , 'DefaultSkin' , close_time = 34 )
 Oo00oOOO0 . doModal ( )
 del Oo00oOOO0
 if 13 - 13: O0 + iIii1I11I1II1 % oO0OooOoO + iIii1I11I1II1
 if 85 - 85: o0Oo * iIii1I11I1II1 . i1Iii1i1I / i1Iii1i1I
def I1I1iiii1IiI1i ( ) :
 if 43 - 43: o0Oo
 oOOo00O0OOOo = os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) , 'tag.cfg' )
 if os . path . exists ( oOOo00O0OOOo ) :
  OoO = open ( oOOo00O0OOOo , 'r' )
  i11i = OoO . read ( )
  OoO . close ( )
  return binascii . unhexlify ( i11i )
 else :
  return binascii . unhexlify ( '6e6c616b73646a666c6b61736a64666c6a616c736b6a666c6b616a7366' )
  if 78 - 78: ii1ii11IIIiiI % oO0OooOoO + O00OOOoOoo0O / o0Oo
  if 34 - 34: oOO00Oo % OoooO0Oo0O0 + iI1IiiIIIiIi * o00O0OoO / III1IiiI
def O0ooO0O0Ooo0o ( info ) :
 OoO = open ( oo0OooOOo0 , 'r' )
 i11i = OoO . read ( )
 OoO . close ( )
 i111Iii11i1Ii = re . compile ( 'l="(.+?)"' ) . findall ( i11i )
 O00Ooiii = i111Iii11i1Ii [ 0 ] if ( len ( i111Iii11i1Ii ) > 0 ) else ''
 oo00000ooOooO = re . compile ( 'p="(.+?)"' ) . findall ( i11i )
 oo0o0OO00oOO = oo00000ooOooO [ 0 ] if ( len ( oo00000ooOooO ) > 0 ) else '0'
 if oo0o0OO00oOO != '0' :
  oo0o0OO00oOO = binascii . unhexlify ( oo0o0OO00oOO )
 if O00Ooiii != '' :
  O00Ooiii = binascii . unhexlify ( O00Ooiii )
 if 'Welcome Back' in O00Ooiii and i1i1II . replace ( '%20' , '' ) in O00Ooiii and info == 'posts' :
  return oo0o0OO00oOO
 if 'Welcome Back' in O00Ooiii and i1i1II . replace ( '%20' , '' ) in O00Ooiii and info == 'welcometext' :
  return O00Ooiii
 else :
  return False
  if 45 - 45: iIii1I11I1II1 - II11iIiIIIiI . o00O0OoO - II11iIiIIIiI / o0oOo0 / oOO00Oo
  if 81 - 81: i1Iii1i1I - o00O0OoO
def OoOOo ( recursive_location , remote_path ) :
 if not os . path . exists ( recursive_location ) :
  os . makedirs ( recursive_location )
  if 20 - 20: i1IIi
 IiIi1I1 = IiIIi1 ( remote_path , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 o0OO000ooOo = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( IiIi1I1 )
 if 15 - 15: o0Oo . II11iIiIIIiI . O0 . oO0OooOoO / o00O0OoO . O00OOOoOoo0O
 for OooO0oOo in o0OO000ooOo :
  oOOo00O0OOOo = xbmc . translatePath ( os . path . join ( recursive_location , OooO0oOo ) )
  if 3 - 3: O00OOOoOoo0O
  if '/' not in OooO0oOo :
   if 52 - 52: O00OOOoOoo0O
   try :
    OOooO0OOoo . update ( 0 , "Downloading [COLOR=yellow]" + OooO0oOo + '[/COLOR]' , '' , 'Please wait...' )
    downloader . download ( remote_path + OooO0oOo , oOOo00O0OOOo , OOooO0OOoo )
    if 79 - 79: o0Oo + II11iIiIIIiI % O00OOOoOoo0O - i11111IIIII + o0Oo * III1IiiI
   except :
    print "failed to install" + OooO0oOo
    if 52 - 52: O00OOOoOoo0O % OoooO0Oo0O0 * II11iIiIIIiI % OoooooooOO - ii1ii11IIIiiI
  if '/' in OooO0oOo and '..' not in OooO0oOo and 'http' not in OooO0oOo :
   i1I1I111iiII = remote_path + OooO0oOo
   OoOOo ( oOOo00O0OOOo , i1I1I111iiII )
   if 62 - 62: o0oOo0 * iI1IiiIIIiIi % OoooO0Oo0O0 - i1IIi - OoooO0Oo0O0
  else :
   pass
   if 24 - 24: iiIi1i11
   if 71 - 71: i11111IIIII - i1IIi
def oOO00o0 ( ) :
 iI111I11I1I1 . ok ( "Register to unlock features" , "To get the most out of this addon please register at the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] forum for free." , 'www.noobsandnerds.com' )
 if 29 - 29: oO0OooOoO - i1Iii1i1I / III1IiiI % OoooooooOO % i1Iii1i1I + i11111IIIII
 if 44 - 44: O0 / O0
def IIIiI1i ( ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Delete Addon_Data Folder?' , 'This will free up space by deleting your addon_data folder. This contains all addon related settings including username and password info.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 58 - 58: i1IIi * i1Iii1i1I . O0 % iI1IiiIIIiIi
 if iII1Iii1I11i == 1 :
  O0o00ooo ( )
  iI111I11I1I1 . ok ( "Addon_Data Removed" , '' , 'Your addon_data folder has now been removed.' , '' )
  if 40 - 40: oOO00Oo * i11111IIIII / OoooO0Oo0O0 / Iiii1i1 - i11111IIIII
def OO ( url ) :
 OOo00OOo = str ( url ) . replace ( II11iiii1Ii , O0OoO000O0OO )
 if 64 - 64: i1Iii1i1I . o0oOo0 % iI1IiiIIIiIi
 if iI111I11I1I1 . yesno ( "Remove" , '' , "Do you want to Remove" ) :
  if 21 - 21: Iiii1i1 / III1IiiI
  for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( url ) :
   if 82 - 82: iIii1I11I1II1 - i1Iii1i1I . i1IIi . i11111IIIII % i11iIiiIii * iIii1I11I1II1
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
    if 58 - 58: OoooO0Oo0O0 % i11iIiiIii + O00OOOoOoo0O / o00O0OoO - OoooooooOO
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
  os . rmdir ( url )
  if 62 - 62: ii1ii11IIIiiI . O00OOOoOoo0O
  try :
   if 22 - 22: o0oOo0 . i11iIiiIii . OoooooooOO . i1IIi
   for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( OOo00OOo ) :
    if 12 - 12: O00OOOoOoo0O % iiIi1i11 + III1IiiI . O0 % iIii1I11I1II1
    for iiI1iii in I1iiIi111I :
     os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
     if 41 - 41: OoooooooOO
    for I1III111i in OoOOOO :
     shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
     if 13 - 13: o00O0OoO + Iiii1i1 - Iiii1i1 % III1IiiI / o00O0OoO
   os . rmdir ( OOo00OOo )
   if 4 - 4: o0Oo + iiIi1i11 - i11111IIIII + i1Iii1i1I
  except :
   pass
   if 78 - 78: iI1IiiIIIiIi
  i11Ii = os . path . join ( oOOoO0 , 'Database' , 'Addons16.db' )
  if 34 - 34: iiIi1i11
  try :
   os . remove ( i11Ii )
   if 99 - 99: oO0OooOoO
  except :
   pass
   if 13 - 13: o00O0OoO - o0oOo0 + i1Iii1i1I % o00O0OoO . i1Iii1i1I - i1IIi
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  O0OiiiIIiIi1ii11 ( )
  iI111I11I1I1 . ok ( 'Add-on removed' , 'You may have to restart Kodi to repopulate' , 'your add-on database. Until you restart you\'ll' , 'find your add-on is still showing even though it\'s deleted' )
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 78 - 78: o0oOo0
  if 94 - 94: OoooooooOO + O00OOOoOoo0O / O0
def o0O0ooooO0 ( ) :
 i1iI1i ( )
 i11Ii1iiiI1I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to DELETE' , 'files' , '.zip' , False , False , OOO00 )
 if 50 - 50: II11iIiIIIiI - o0Oo * ii1ii11IIIiiI . o0oOo0 % ii1ii11IIIiiI + OoooooooOO
 if i11Ii1iiiI1I != OOO00 :
  i1ii11Iii11 = ntpath . basename ( i11Ii1iiiI1I )
  iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Delete Backup File' , 'This will completely remove ' + i1ii11Iii11 , 'Are you sure you want to delete?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Delete' )
  if 56 - 56: II11iIiIIIiI
  if iII1Iii1I11i == 1 :
   os . remove ( i11Ii1iiiI1I )
   if 77 - 77: OoooooooOO
   if 52 - 52: i1Iii1i1I - ii1ii11IIIiiI % i11iIiiIii . o00O0OoO
def OooOoOo ( ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Remove All Crash Logs?' , 'There is absolutely no harm in doing this, these are log files generated when Kodi crashes and are only used for debugging purposes.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 8 - 8: i11111IIIII
 if iII1Iii1I11i == 1 :
  Oo0Ii1iii ( )
  iI111I11I1I1 . ok ( "Crash Logs Removed" , '' , 'Your crash log files have now been removed.' , '' )
  if 37 - 37: o0Oo / OoooooooOO % i11iIiiIii % OoooO0Oo0O0
  if 19 - 19: II11iIiIIIiI - ii1ii11IIIiiI + i11iIiiIii / iIii1I11I1II1
def OooO0ooO0o0 ( ) :
 shutil . rmtree ( os . path . join ( II11iiii1Ii , binascii . unhexlify ( '7363726970742e6d6f64756c652e637967706669' ) ) )
 iI111I11I1I1 . ok ( binascii . unhexlify ( '53746172747570206469616c6f672064697361626c6564' ) , binascii . unhexlify ( '54686520436f6d6d756e6974792050726f74656374696f6e206e61672073637265656e20686173206e6f77206265656e2064697361626c65642e20596f752063616e206e6f77206372656174652061206261636b75702074686174206e6f206c6f6e67657220686173207468652070726f74656374696f6e2c204f4e4c5920796f7520746865206275696c6420617574686f722063616e2064697361626c65207468697320736f206d616b65207375726520796f7520646f6e2774207368617265206c6f67696e20696e666f2e' ) )
 if 1 - 1: i11111IIIII % i1IIi
 if 41 - 41: ii1ii11IIIiiI * ii1ii11IIIiiI / i1Iii1i1I + OoooO0Oo0O0 . oOO00Oo
def O0OiiiIIiIi1ii11 ( ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Delete Packages Folder' , 'Do you want to clean the packages folder? This will free up space by deleting the old zip install files of your addons. Keeping these files can also sometimes cause problems when reinstalling addons' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 84 - 84: i11iIiiIii + ii1ii11IIIiiI * o0Oo + OoooO0Oo0O0 / iI1IiiIIIiIi
 if iII1Iii1I11i == 1 :
  Oo ( )
  iI111I11I1I1 . ok ( "Packages Removed" , '' , 'Your zip install files have now been removed.' , '' )
  if 80 - 80: OoooO0Oo0O0
  if 67 - 67: oO0OooOoO
def ii111iiIii ( ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Clear Cached Images?' , 'This will clear your textures13.db file and remove your Thumbnails folder. These will automatically be repopulated after a restart.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 2 - 2: oOO00Oo - O0 * iI1IiiIIIiIi % i11111IIIII
 if iII1Iii1I11i == 1 :
  ooOOOOoO ( )
  oooO00oo0 ( OooO0 )
  if 64 - 64: i1IIi . o0oOo0
  iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if 7 - 7: III1IiiI . i1Iii1i1I - i1Iii1i1I / Iiii1i1 % II11iIiIIIiI
  if iII1Iii1I11i == 1 :
   try :
    xbmc . executebuiltin ( "RestartApp" )
    if 61 - 61: III1IiiI - OoooO0Oo0O0 / i1Iii1i1I % OoooO0Oo0O0 + ii1ii11IIIiiI / II11iIiIIIiI
   except :
    O00000OO00OO ( )
    if 10 - 10: i11iIiiIii / O00OOOoOoo0O
    if 27 - 27: o0Oo / OoooooooOO
def ooOOOOoO ( ) :
 OOO00Oo00o = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  IiII1Iiii = database . connect ( OOO00Oo00o )
  I1o000o00OO00Oo = IiII1Iiii . cursor ( )
  I1o000o00OO00Oo . execute ( "DROP TABLE IF EXISTS path" )
  I1o000o00OO00Oo . execute ( "VACUUM" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( "DROP TABLE IF EXISTS sizes" )
  I1o000o00OO00Oo . execute ( "VACUUM" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( "DROP TABLE IF EXISTS texture" )
  I1o000o00OO00Oo . execute ( "VACUUM" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  IiII1Iiii . commit ( )
 except :
  pass
  if 12 - 12: o00O0OoO * III1IiiI - Iiii1i1 * i1Iii1i1I - o0oOo0 * Iiii1i1
  if 90 - 90: iI1IiiIIIiIi . O00OOOoOoo0O
def o0OOOOoo ( name , url , description ) :
 if 'Backup' in name :
  i1iI1i ( )
  oOi1IiIiIii11I = open ( url ) . read ( )
  O0o0O00 = os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] )
  iiI1iii = open ( O0o0O00 , mode = 'w' )
  iiI1iii . write ( oOi1IiIiIii11I )
  iiI1iii . close ( )
  if 85 - 85: i11iIiiIii . o00O0OoO + iI1IiiIIIiIi / iI1IiiIIIiIi
 else :
  if 'guisettings.xml' in description :
   ii1oOOO0ooOO = open ( os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   i1o00Oo = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % OOOO0OOoO0O0
   o0OO000ooOo = re . compile ( i1o00Oo ) . findall ( ii1oOOO0ooOO )
   if 38 - 38: Iiii1i1
   for type , OOoO000oO , iIiIi in o0OO000ooOo :
    iIiIi = iIiIi . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , OOoO000oO , iIiIi ) )
    if 7 - 7: OoooO0Oo0O0
  else :
   O0o0O00 = os . path . join ( url )
   oOi1IiIiIii11I = open ( os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   iiI1iii = open ( O0o0O00 , mode = 'w' )
   iiI1iii . write ( oOi1IiIiIii11I )
   iiI1iii . close ( )
   if 11 - 11: o0oOo0
 iI111I11I1I1 . ok ( "Restore Complete" , "" , 'All Done !' , '' )
 if 36 - 36: ii1ii11IIIiiI % iIii1I11I1II1 - OoooO0Oo0O0 - i1IIi % oOO00Oo
 if 54 - 54: i11111IIIII - oO0OooOoO . o0oOo0 + iI1IiiIIIiIi
def IIiii1I ( name , url , video , description , skins , guisettingslink , artpack ) :
 O0O000 = 1
 o00OoOoo0 = 0
 iiiiiiiiiiiI = os . path . join ( iIii1 , 'CP_Profiles' )
 iI111iiI1II = os . path . join ( iiiiiiiiiiiI , 'list.txt' )
 Ii11iiI1 = [ ]
 i11Ii1iiiI1I = description . replace ( ' ' , '_' ) . replace ( "'" , "" ) . replace ( ":" , "-" )
 if 96 - 96: O00OOOoOoo0O * O0 - oO0OooOoO . o0oOo0 - iI1IiiIIIiIi
 if not os . path . exists ( iiiiiiiiiiiI ) :
  os . makedirs ( iiiiiiiiiiiI )
  if 84 - 84: III1IiiI * oOO00Oo * oOO00Oo - i1Iii1i1I
 III1Ii = os . path . join ( iiiiiiiiiiiI , i11Ii1iiiI1I )
 if not os . path . exists ( III1Ii ) :
  os . makedirs ( III1Ii )
 else :
  o00OoOoo0 = iI111I11I1I1 . yesno ( 'Profile Already Exists' , 'This build is already installed on your system, would you like to remove the old one and reinstall?' )
  if o00OoOoo0 == 1 :
   try :
    shutil . rmtree ( III1Ii )
    os . makedirs ( III1Ii )
   except :
    pass
  else :
   O0O000 = 2
   if 90 - 90: o0Oo
 if O0O000 == 1 :
  OoO00 = os . path . join ( iiiiiIIii , i11Ii1iiiI1I + '_gui.zip' )
  if iiIIIII1i1iI == 'true' :
   print "### Download path = " + OoO00
   if 27 - 27: iIii1I11I1II1 - III1IiiI
  OOooO0OOoo . create ( "Community Builds" , "Downloading Skin Tweaks" , '' , 'Please Wait' )
  try :
   downloader . download ( guisettingslink , OoO00 )
   if iiIIIII1i1iI == 'true' :
    print "### successfully downloaded guisettings.xml"
  except :
   iI111I11I1I1 . ok ( 'Problem Detected' , 'Sorry there was a problem downloading the guisettings file. Please check your storage location, if you\'re certain that\'s ok please notify the build author on the relevant support thread.' )
   if iiIIIII1i1iI == 'true' :
    print "### FAILED to download " + guisettingslink
    if 73 - 73: iiIi1i11 . II11iIiIIIiI + II11iIiIIIiI % II11iIiIIIiI % O0
    if 8 - 8: i1Iii1i1I . iI1IiiIIIiIi - i1IIi % ii1ii11IIIiiI / o00O0OoO
  if zipfile . is_zipfile ( OoO00 ) :
   oOoO0oO00ooOo = str ( os . path . getsize ( OoO00 ) )
  else :
   oOoO0oO00ooOo = '0'
   if 13 - 13: II11iIiIIIiI / O00OOOoOoo0O . OoooO0Oo0O0 . iiIi1i11
  OOooO0OOoo . create ( "Community Builds" , "Downloading " + description , '' , 'Please Wait' )
  OoO00 = os . path . join ( iiiiiIIii , i11Ii1iiiI1I + '.zip' )
  if 31 - 31: oOO00Oo
  if not os . path . exists ( iiiiiIIii ) :
   os . makedirs ( iiiiiIIii )
   if 59 - 59: II11iIiIIIiI / II11iIiIIIiI
   if 87 - 87: OoooO0Oo0O0 % O00OOOoOoo0O + iI1IiiIIIiIi . i11iIiiIii / iI1IiiIIIiIi
  i1I1I1 = os . path . join ( iiI1IiI , 'extracted' )
  downloader . download ( url , OoO00 , OOooO0OOoo )
  OOooO0OOoo . create ( "Community Builds" , "Extracting " + description , '' , 'Please Wait' )
  extract . all ( OoO00 , i1I1I1 , OOooO0OOoo )
  if os . path . exists ( os . path . join ( i1I1I1 , 'userdata' , '.cbcfg' ) ) :
   try :
    os . makedirs ( os . path . join ( O0OoO000O0OO , o0OO00 , 'updating' ) )
   except :
    pass
  if iiIIIII1i1iI == 'true' :
   print "### Downloaded build to: " + OoO00
   print "### Extracted build to: " + i1I1I1
   if 31 - 31: iI1IiiIIIiIi / i1Iii1i1I
  O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
  if 3 - 3: i11111IIIII
  o0oooO0O00OoO = re . compile ( 'id="(.+?)"' ) . findall ( i11i )
  iiiiI = re . compile ( 'name="(.+?)"' ) . findall ( i11i )
  IiO0o = re . compile ( 'version="(.+?)"' ) . findall ( i11i )
  if 37 - 37: iI1IiiIIIiIi * OoooooooOO * o00O0OoO + II11iIiIIIiI . o0Oo
  oOo0Oooo = o0oooO0O00OoO [ 0 ] if ( len ( o0oooO0O00OoO ) > 0 ) else ''
  I1iiIIiI11I = iiiiI [ 0 ] if ( len ( iiiiI ) > 0 ) else ''
  i1ii1I = IiO0o [ 0 ] if ( len ( IiO0o ) > 0 ) else ''
  if 61 - 61: iiIi1i11 . iiIi1i11
  print "### Build name details to store in ti_id: " + I1iiIIiI11I
  if 17 - 17: oO0OooOoO / o0oOo0
  o0OO0OOoo0oO = os . path . join ( i1I1I1 , 'userdata' , 'addon_data' , 'ti_id' )
  OOOOo00oOOO00 = os . path . join ( o0OO0OOoo0oO , 'id.xml' )
  if not os . path . exists ( o0OO0OOoo0oO ) :
   os . makedirs ( o0OO0OOoo0oO )
   if 13 - 13: OoooO0Oo0O0 / ii1ii11IIIiiI * i11iIiiIii % ii1ii11IIIiiI % ii1ii11IIIiiI * oO0OooOoO
  o0oooOO00 = open ( OOOOo00oOOO00 , mode = 'w+' )
  o0oooOO00 . write ( 'id="' + str ( oOo0Oooo ) + '"\nname="' + I1iiIIiI11I + '"\nversion="' + i1ii1I + '"\ngui="' + oOoO0oO00ooOo + '"' )
  o0oooOO00 . close ( )
  if 17 - 17: o00O0OoO . O0 * i1IIi - O00OOOoOoo0O % i1IIi
  O000OO0 = os . path . join ( o0OO0OOoo0oO , 'startup.xml' )
  o0oooOO00 = open ( O000OO0 , mode = 'w+' )
  o0oooOO00 . write ( 'date="01011001"\nversion="' + i1ii1I + '"' )
  o0oooOO00 . close ( )
  if 35 - 35: iI1IiiIIIiIi + OoooO0Oo0O0 . III1IiiI * II11iIiIIIiI
  IiI1I = open ( OOOOo00oOOO00 , 'r' )
  o0o0OoOOOoo = IiI1I . read ( )
  IiI1I . close ( )
  print "### ti_id/id.xml contents: " + o0o0OoOOOoo
  if 89 - 89: Iiii1i1
  if 16 - 16: iI1IiiIIIiIi + o00O0OoO - iiIi1i11 * i1Iii1i1I - O0
  IiiI1Ii1IIi = iI111I11I1I1 . yesno ( "Keep Kodi Settings?" , 'Do you want to keep your existing KODI settings (weather, screen calibration, PVR etc.) or wipe and install the ones supplied in this build?' , yeslabel = 'Replace my settings' , nolabel = 'Keep my settings' )
  if IiiI1Ii1IIi == 0 :
   OO00o0oo ( os . path . join ( iiI1IiI , 'extracted' , 'userdata' , 'guisettings.xml' ) )
   if 8 - 8: iiIi1i11 % i1Iii1i1I . III1IiiI
  for iIIii1iiiIiiI in os . listdir ( OO0o ) :
   Ii11iiI1 . append ( iIIii1iiiIiiI )
   if 39 - 39: o0Oo . III1IiiI
   if 4 - 4: i1IIi % oOO00Oo % III1IiiI . i1IIi
  iI1iii1iIiiI = open ( os . path . join ( III1Ii , 'addonlist' ) , mode = 'w+' )
  for iIIii1iiiIiiI in os . listdir ( II11iiii1Ii ) :
   if not iIIii1iiiIiiI in Ii11iiI1 and iIIii1iiiIiiI != 'plugin.program.totalinstaller' and iIIii1iiiIiiI != 'script.module.addon.common' and iIIii1iiiIiiI != 'packages' :
    iI1iii1iIiiI . write ( iIIii1iiiIiiI + '|' )
  iI1iii1iIiiI . close ( )
  if iiIIIII1i1iI == 'true' :
   print "### Created addonlist to: " + os . path . join ( III1Ii , 'addonlist' )
  o00oo = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' , '.cbcfg' ]
  iI1ii11Ii = "Creating Profile Data File"
  O0OO0OO = "Archiving..."
  Ooo0oO = ""
  IiIiIIiii1I = "Please Wait"
  oOo0OOoooO ( i1I1I1 , os . path . join ( III1Ii , 'build.zip' ) , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
  if iiIIIII1i1iI == 'true' :
   print "### Created: " + os . path . join ( III1Ii , 'build.zip' )
   if 85 - 85: i11111IIIII . iI1IiiIIIiIi * oOO00Oo % II11iIiIIIiI % oO0OooOoO + Iiii1i1
  if IIiIiII11i == 'false' :
   os . remove ( OoO00 )
   if iiIIIII1i1iI == 'true' :
    print "### removed: " + OoO00
  iI111II1ii ( i11Ii1iiiI1I )
  II1i111 = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( oOo0Oooo )
  if not 'update' in video :
   try :
    IiIIi1 ( II1i111 , 5 )
   except :
    pass
    if 85 - 85: oO0OooOoO / o0oOo0 * oO0OooOoO
    if 43 - 43: oOO00Oo / O0 + i1IIi - OoooO0Oo0O0 % i11iIiiIii
  O0oOoOOO000 ( III1Ii )
  if 57 - 57: oOO00Oo - i11111IIIII . iiIi1i11
  if 7 - 7: OoooO0Oo0O0 / O00OOOoOoo0O . ii1ii11IIIiiI / II11iIiIIIiI . O0 . o00O0OoO
  if 60 - 60: oO0OooOoO + Iiii1i1 / III1IiiI % OoooooooOO - i1IIi
  if 57 - 57: o0oOo0
def OO00O0O ( url ) :
 o0oo0oo0 = 0
 IIi1II = 0
 print "### Local Build Restore Location: " + url
 if 68 - 68: O00OOOoOoo0O % i11iIiiIii + oO0OooOoO . II11iIiIIIiI
 oo000o ( 'noobsandnerds.xml' )
 if 80 - 80: i1IIi * OoooO0Oo0O0
 i1iI1i ( )
 if 93 - 93: O0 - i11iIiiIii - ii1ii11IIIiiI + iI1IiiIIIiIi
 if url == 'local' :
  i11Ii1iiiI1I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.zip' , False , False , OOO00 )
  if i11Ii1iiiI1I == '' :
   o0oo0oo0 = 1
   if 86 - 86: o0Oo / OoooO0Oo0O0 * iI1IiiIIIiIi % i11iIiiIii
 if o0oo0oo0 == 1 :
  print "### No file selected, quitting restore process ###"
  return
  if 20 - 20: i1Iii1i1I . OoooooooOO + i1Iii1i1I + o0oOo0 * OoooO0Oo0O0
 if url != 'local' :
  OOooO0OOoo . create ( "Community Builds" , "Downloading build." , '' , 'Please Wait' )
  i11Ii1iiiI1I = os . path . join ( iiiiiIIii , IiIiIIIiI1iII ( ) + '.zip' )
  if 44 - 44: i11iIiiIii
  if not os . path . exists ( iiiiiIIii ) :
   os . makedirs ( iiiiiIIii )
   if 69 - 69: iiIi1i11 * O0 + i11iIiiIii
  downloader . download ( url , i11Ii1iiiI1I , OOooO0OOoo )
  if 65 - 65: O0 / i1Iii1i1I . i1IIi * i1Iii1i1I / iIii1I11I1II1 - III1IiiI
 if os . path . exists ( Oo0OoO00oOO0o ) :
  if os . path . exists ( I11i1 ) :
   os . remove ( Oo0OoO00oOO0o )
  else :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   if 93 - 93: O00OOOoOoo0O % i11iIiiIii - iI1IiiIIIiIi % ii1ii11IIIiiI
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 55 - 55: oOO00Oo . OoooO0Oo0O0
  if 63 - 63: III1IiiI
 if not os . path . exists ( I11iii1Ii ) :
  O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'w+' )
  if 79 - 79: OoooO0Oo0O0 - III1IiiI - oOO00Oo . iiIi1i11
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 65 - 65: i11iIiiIii . ii1ii11IIIiiI % i1Iii1i1I + i11111IIIII - i11iIiiIii
  if 60 - 60: Iiii1i1
 try :
  os . rename ( I11i1 , Oo0OoO00oOO0o )
  if 14 - 14: II11iIiIIIiI % III1IiiI * i1Iii1i1I - i11iIiiIii / OoooO0Oo0O0 * i11iIiiIii
 except :
  iI111I11I1I1 . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
  if 95 - 95: iIii1I11I1II1 + O00OOOoOoo0O . o0Oo + O00OOOoOoo0O * o00O0OoO + iiIi1i11
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'We highly recommend backing up your existing build before installing any builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if iII1Iii1I11i == 0 :
  i1i11IiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
  if 94 - 94: iIii1I11I1II1 / o0Oo * OoooO0Oo0O0
  if not os . path . exists ( i1i11IiII ) :
   os . makedirs ( i1i11IiII )
   if 45 - 45: Iiii1i1 * o00O0OoO / iIii1I11I1II1 / o0Oo % oO0OooOoO
  Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
  if ( not Oo0OOo ) :
   return False , 0
   if 49 - 49: iI1IiiIIIiIi / i1Iii1i1I . i1Iii1i1I . i1Iii1i1I + i11iIiiIii % o00O0OoO
  I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
  iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( i1i11IiII , I1II1IiI1 + '.zip' ) )
  o00oo = [ o0OO00 ]
  O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
  iI1ii11Ii = "Creating full backup of existing build"
  O0OO0OO = "Archiving..."
  Ooo0oO = ""
  IiIiIIiii1I = "Please Wait"
  if 7 - 7: i11111IIIII * o0oOo0 + O00OOOoOoo0O
  oOo0OOoooO ( iIii1 , iIIiI11iI1Ii1 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
 iIiiIi11iiI1 = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'Would you like to keep your existing database files or overwrite? Overwriting will wipe any existing music or video library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if iIiiIi11iiI1 == 1 :
  if os . path . exists ( O0o0O00Oo0o0 ) :
   shutil . rmtree ( O0o0O00Oo0o0 )
   if 82 - 82: o00O0OoO % i1IIi
  try :
   shutil . copytree ( ooOoOoo0O , O0o0O00Oo0o0 , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 14 - 14: Iiii1i1 + iI1IiiIIIiIi * II11iIiIIIiI
  except :
   IIi1II = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if IIi1II == 1 : pass
   if IIi1II == 0 : o0oo0oo0 = 1 ; return
   if 49 - 49: II11iIiIIIiI
  iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( OOO00 , 'Database.zip' ) )
  I1I1IiIi1 ( O0o0O00Oo0o0 , iIIiI11iI1Ii1 )
  if 57 - 57: O0 * o0oOo0 - i1Iii1i1I - iIii1I11I1II1 * i1Iii1i1I
 if o0oo0oo0 == 1 :
  print "### User decided to exit restore function ###"
  return
  if 9 - 9: i11111IIIII . o00O0OoO
 else :
  time . sleep ( 1 )
  OoO = open ( Ooo , mode = 'r' )
  oOoO0o0o = OoO . read ( )
  OoO . close ( )
  if 23 - 23: O0 % OoooooooOO - O0 . o0Oo + i11iIiiIii
  if 96 - 96: o0oOo0 % O0
  print "### Checking zip file structure ###"
  Ooo0oOOO = zipfile . ZipFile ( i11Ii1iiiI1I )
  if 'xbmc.log' in Ooo0oOOO . namelist ( ) or 'kodi.log' in Ooo0oOOO . namelist ( ) or '.git' in Ooo0oOOO . namelist ( ) or '.svn' in Ooo0oOOO . namelist ( ) :
   print "### Whoever created this build has used completely the wrong backup method, lets try and fix it! ###"
   iI111I11I1I1 . ok ( 'Fixing Bad Zip' , 'Whoever created this build has used the wrong backup method, please wait while we fix it - this could take some time! Click OK to proceed' )
   Ooo00O = zipfile . ZipFile ( i11Ii1iiiI1I , 'r' )
   OOoO00o00oo = os . path . join ( iiiiiIIii , 'fixed.zip' )
   iIiiIi11 = zipfile . ZipFile ( OOoO00o00oo , 'w' )
   if 73 - 73: i11111IIIII - i11111IIIII / OoooooooOO
   OOooO0OOoo . create ( "Fixing Build" , "Checking " , '' , 'Please Wait' )
   if 53 - 53: oOO00Oo / ii1ii11IIIiiI . OoooooooOO
   for iIIii1iiiIiiI in Ooo00O . infolist ( ) :
    buffer = Ooo00O . read ( iIIii1iiiIiiI . filename )
    O00OO0oo00O0O = str ( iIIii1iiiIiiI . filename )
    if 14 - 14: o0Oo
    if ( iIIii1iiiIiiI . filename [ - 4 : ] != '.log' ) and not '.git' in O00OO0oo00O0O and not '.svn' in O00OO0oo00O0O :
     iIiiIi11 . writestr ( iIIii1iiiIiiI , buffer )
     OOooO0OOoo . update ( 0 , "Fixing..." , '[COLOR yellow]%s[/COLOR]' % iIIii1iiiIiiI . filename , 'Please Wait' )
     if 45 - 45: O0 / III1IiiI + II11iIiIIIiI
   OOooO0OOoo . close ( )
   iIiiIi11 . close ( )
   Ooo00O . close ( )
   i11Ii1iiiI1I = OOoO00o00oo
   if 37 - 37: OoooooooOO / OoooO0Oo0O0 % oOO00Oo
  OOooO0OOoo . create ( "Restoring Backup Build" , "Checking " , '' , 'Please Wait' )
  OOooO0OOoo . update ( 0 , "" , "Extracting Zip Please Wait" )
  if 34 - 34: O00OOOoOoo0O . o00O0OoO % III1IiiI - O0 * O0
  try :
   extract . all ( i11Ii1iiiI1I , iIii1 , OOooO0OOoo )
  except :
   iI111I11I1I1 . ok ( 'ERROR IN BUILD ZIP' , 'Please contact the build author, there are errors in this zip file that has caused the install process to fail. Most likely cause is it contains files with special characters in the name.' )
   return
   if 11 - 11: O0 * i11iIiiIii * oO0OooOoO / iiIi1i11 * O0
  time . sleep ( 1 )
  if 71 - 71: o00O0OoO . II11iIiIIIiI
  if iIiiIi11iiI1 == 1 :
   extract . all ( iIIiI11iI1Ii1 , ooOoOoo0O , OOooO0OOoo )
   if 24 - 24: iiIi1i11 * OoooooooOO . O0 . ii1ii11IIIiiI . o0Oo
   if IIi1II != 1 :
    shutil . rmtree ( O0o0O00Oo0o0 )
    if 80 - 80: O0 * ii1ii11IIIiiI . Iiii1i1 % O0
  ii11I1iIIi = open ( Ooo , mode = 'w+' )
  ii11I1iIIi . write ( oOoO0o0o )
  ii11I1iIIi . close ( )
  try :
   os . rename ( I11i1 , iIi1ii1I1 )
   if 29 - 29: iI1IiiIIIiIi + i1Iii1i1I % OoooO0Oo0O0 + o00O0OoO * II11iIiIIIiI - i11iIiiIii
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 24 - 24: i11iIiiIii . o0oOo0 + o0oOo0 - i11iIiiIii % iiIi1i11
  time . sleep ( 1 )
  O0OO0o0OO0OO = open ( Oo0OoO00oOO0o , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
  i1Io00OOOo = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( i11i )
  i1I11I1i = i1Io00OOOo [ 0 ] if ( len ( i1Io00OOOo ) > 0 ) else ''
  Ii1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( i11i )
  oOO0oOooo = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
  ooOO0oo00Oo = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( i11i )
  o00IIIIii1111i1 = ooOO0oo00Oo [ 0 ] if ( len ( ooOO0oo00Oo ) > 0 ) else ''
  if 58 - 58: o0Oo
  try :
   o0oO0oo = open ( iIi1ii1I1 , mode = 'r' )
   ooOO00Oo = o0oO0oo . read ( )
   o0oO0oo . close ( )
   OoOOoO0o = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOO00Oo )
   iIi1 = OoOOoO0o [ 0 ] if ( len ( OoOOoO0o ) > 0 ) else ''
   o0O00ooo0 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOO00Oo )
   O00oOOO0 = o0O00ooo0 [ 0 ] if ( len ( o0O00ooo0 ) > 0 ) else ''
   iI1 = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOO00Oo )
   Iiiiii = iI1 [ 0 ] if ( len ( iI1 ) > 0 ) else ''
   iiI1IIIi = i11i . replace ( i1I11I1i , iIi1 ) . replace ( o00IIIIii1111i1 , Iiiiii ) . replace ( oOO0oOooo , O00oOOO0 )
   o0oooOO00 = open ( Oo0OoO00oOO0o , mode = 'w+' )
   o0oooOO00 . write ( str ( iiI1IIIi ) )
   o0oooOO00 . close ( )
   if 94 - 94: oOO00Oo + iI1IiiIIIiIi % oOO00Oo . Iiii1i1 - o0oOo0 * o0Oo
  except :
   print "### NO GUISETTINGS DOWNLOADED"
   if 62 - 62: II11iIiIIIiI * i1IIi % OoooO0Oo0O0 + II11iIiIIIiI . O0 . o0oOo0
  if os . path . exists ( I11i1 ) :
   os . remove ( I11i1 )
   if 57 - 57: II11iIiIIIiI - Iiii1i1 + O0 % oOO00Oo
  os . rename ( Oo0OoO00oOO0o , I11i1 )
  try :
   os . remove ( iIi1ii1I1 )
   if 72 - 72: iiIi1i11 . O00OOOoOoo0O / oO0OooOoO
  except :
   pass
   if 69 - 69: iiIi1i11 * oO0OooOoO - o0oOo0 - i1IIi + i11iIiiIii
  os . makedirs ( OOO00O )
  time . sleep ( 1 )
  O00000OO00OO ( )
  if 50 - 50: OoooooooOO * i1IIi / III1IiiI
  if 83 - 83: i1IIi
  if 38 - 38: OoooooooOO * iIii1I11I1II1
  if 54 - 54: OoooooooOO . Iiii1i1
  if 71 - 71: iI1IiiIIIiIi
  if 31 - 31: o00O0OoO . i11iIiiIii . ii1ii11IIIiiI * II11iIiIIIiI % iI1IiiIIIiIi . oOO00Oo
  if 92 - 92: OoooooooOO / O0 * i1IIi + iIii1I11I1II1
  if 93 - 93: o0oOo0 % Iiii1i1
  if 46 - 46: OoooO0Oo0O0 * O00OOOoOoo0O * i11111IIIII * OoooO0Oo0O0 . OoooO0Oo0O0
  if 43 - 43: o0oOo0 . i1IIi
  if 68 - 68: i11111IIIII % II11iIiIIIiI . O0 - O00OOOoOoo0O + OoooO0Oo0O0 . i11iIiiIii
  if 45 - 45: o0Oo
  if 17 - 17: OoooooooOO - o0oOo0 + iI1IiiIIIiIi . OoooooooOO % II11iIiIIIiI
  if 92 - 92: Iiii1i1 - iiIi1i11 % ii1ii11IIIiiI - oOO00Oo % i1IIi
  if 38 - 38: OoooO0Oo0O0 . o00O0OoO / O00OOOoOoo0O % o00O0OoO
  if 10 - 10: O0 . o0Oo * oOO00Oo / i1Iii1i1I
  if 61 - 61: II11iIiIIIiI - Iiii1i1
  if 51 - 51: i1Iii1i1I * o0oOo0 / O0 / O0
  if 52 - 52: OoooooooOO % O0
def I1I1i1 ( ) :
 i1iI1i ( )
 OO0oOooo = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the guisettings zip file you want to restore' , 'files' , '.zip' , False , False , OOO00 )
 if 49 - 49: iIii1I11I1II1 / o00O0OoO
 if OO0oOooo == '' :
  return
  if 53 - 53: ii1ii11IIIiiI
 else :
  IiiiI1i = 1
  OO00O00o0O ( OO0oOooo , IiiiI1i )
  if 96 - 96: OoooooooOO - iIii1I11I1II1 . III1IiiI
  if 2 - 2: i1IIi
def Iii1I1i1i1 ( name , url , video ) :
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option for first time install or if you\'re encountering any issues with your device. This will wipe all your Kodi settings, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if iII1Iii1I11i == 0 :
  return
  if 5 - 5: O0 . i11iIiiIii + OoooooooOO / i1Iii1i1I % o0Oo
 elif iII1Iii1I11i == 1 :
  if 80 - 80: O00OOOoOoo0O % II11iIiIIIiI
  OoO00 = '/storage/openelec_temp/'
  oooooOO0 = '/storage/.restore/'
  I11iIi1i1II11 = os . path . join ( oooooOO0 , IiIiIIIiI1iII ( ) + '.tar' )
  if not os . path . exists ( oooooOO0 ) :
   try :
    os . makedirs ( oooooOO0 )
   except :
    pass
  try :
   OOooO0OOoo . create ( 'Downloading Build' , 'Please wait' , '' , '' )
   downloader . download ( url , I11iIi1i1II11 )
   IIi1I1iII111 = True
  except :
   IIi1I1iII111 = False
  time . sleep ( 2 )
  if 69 - 69: II11iIiIIIiI + i11111IIIII - o00O0OoO . iIii1I11I1II1 - iI1IiiIIIiIi
  if IIi1I1iII111 == True :
   if 27 - 27: i1Iii1i1I % II11iIiIIIiI . OoooO0Oo0O0 . i1IIi % O00OOOoOoo0O . oOO00Oo
   try :
    O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'r' )
    i11i = O0OO0o0OO0OO . read ( )
    O0OO0o0OO0OO . close ( )
    if 37 - 37: i1Iii1i1I + Iiii1i1 * iI1IiiIIIiIi + i11111IIIII
    o0oooO0O00OoO = re . compile ( 'id="(.+?)"' ) . findall ( i11i )
    oOo0Oooo = o0oooO0O00OoO [ 0 ] if ( len ( o0oooO0O00OoO ) > 0 ) else ''
    if 39 - 39: O0 * II11iIiIIIiI - o0Oo + iI1IiiIIIiIi / oO0OooOoO
   except :
    pass
   if oOo0Oooo != '' :
    II1i111 = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( oOo0Oooo )
   try :
    IiIIi1 ( II1i111 , 5 )
   except :
    pass
    if 66 - 66: o0oOo0 + III1IiiI % OoooooooOO
    if 23 - 23: III1IiiI . O00OOOoOoo0O + iIii1I11I1II1
   if not os . path . exists ( OoO00 ) :
    try :
     os . makedirs ( OoO00 )
    except :
     pass
     if 17 - 17: i11111IIIII
   iI111I11I1I1 . ok ( "Download Complete - Press OK To Reboot" , 'Once you press OK your device will attempt to reboot, if it hasn\'t rebooted within 30 seconds please pull the power to manually shutdown. When booting you may see lines of text, don\'t worry this is normal update behaviour!' )
   xbmc . executebuiltin ( 'Reboot' )
   if 12 - 12: i1IIi . ii1ii11IIIiiI
   if 14 - 14: iiIi1i11 + oO0OooOoO % iiIi1i11 . III1IiiI * o0oOo0
def o0O00ooo0oO0o ( ) :
 o0oo0oo0 = 0
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option if you\'re encountering any issues with your device. This will wipe all your Kodi settings and restore with whatever is in the backup, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if iII1Iii1I11i == 0 :
  return
  if 21 - 21: iIii1I11I1II1 / o0oOo0 * Iiii1i1
 elif iII1Iii1I11i == 1 :
  i11Ii1iiiI1I = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.tar' , False , False , oO0 )
  if i11Ii1iiiI1I == '' :
   o0oo0oo0 = 1
   if 98 - 98: O0 + oOO00Oo
  if o0oo0oo0 == 1 :
   print "### No file selected, quitting restore process ###"
   return
  I11iIi1i1II11 = os . path . join ( Ii1iIiII1ii1 , IiIiIIIiI1iII ( ) + '.tar' )
  if not os . path . exists ( Ii1iIiII1ii1 ) :
   try :
    os . makedirs ( Ii1iIiII1ii1 )
   except :
    pass
  OOooO0OOoo . create ( 'Copying File To Restore Folder' , '' , 'Please wait...' )
  shutil . copyfile ( i11Ii1iiiI1I , I11iIi1i1II11 )
  xbmc . executebuiltin ( 'Reboot' )
  if 23 - 23: i1Iii1i1I / i1Iii1i1I
  if 25 - 25: i1Iii1i1I
def OO0OO0 ( ) :
 oooO00Oo ( )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore a locally stored OpenELEC Backup[/COLOR]' , '' , 'restore_local_OE' , '' , '' , '' , 'Restore A Full OE System Backup' )
  if 92 - 92: o0Oo / OoooO0Oo0O0 + iI1IiiIIIiIi * oO0OooOoO
 oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore A Locally stored build[/COLOR]' , 'local' , 'restore_local_CB' , '' , '' , '' , 'Restore A Full System Backup' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]' , 'url' , 'LocalGUIDialog' , '' , '' , '' , 'Back Up Your Full System' )
 if 78 - 78: Iiii1i1 - i1IIi + O00OOOoOoo0O + II11iIiIIIiI * OoooO0Oo0O0 * oOO00Oo
 if os . path . exists ( os . path . join ( OOO00 , 'addons.zip' ) ) :
  oO00oOOoooO ( '' , 'Restore Your Addons' , 'addons' , 'restore_zip' , '' , '' , '' , 'Restore Your Addons' )
  if 97 - 97: i1IIi
 if os . path . exists ( os . path . join ( OOO00 , 'addon_data.zip' ) ) :
  oO00oOOoooO ( '' , 'Restore Your Addon UserData' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Restore Your Addon UserData' )
  if 29 - 29: o0Oo
 if os . path . exists ( os . path . join ( OOO00 , 'guisettings.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Guisettings.xml' , I11i1 , 'restore_backup' , '' , '' , '' , 'Restore Your guisettings.xml' )
  if 37 - 37: OoooO0Oo0O0 * Iiii1i1 * o0Oo * O0
 if os . path . exists ( os . path . join ( OOO00 , 'favourites.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Favourites.xml' , IIIII , 'restore_backup' , '' , '' , '' , 'Restore Your favourites.xml' )
  if 35 - 35: o0Oo - OoooO0Oo0O0 * i1Iii1i1I + i11111IIIII / i1IIi
 if os . path . exists ( os . path . join ( OOO00 , 'sources.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Source.xml' , ooooooO0oo , 'restore_backup' , '' , '' , '' , 'Restore Your sources.xml' )
  if 46 - 46: II11iIiIIIiI . o0oOo0 % II11iIiIIIiI / oO0OooOoO * o0oOo0 * iiIi1i11
 if os . path . exists ( os . path . join ( OOO00 , 'advancedsettings.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Advancedsettings.xml' , IIiiiiiiIi1I1 , 'restore_backup' , '' , '' , '' , 'Restore Your advancedsettings.xml' )
  if 59 - 59: Iiii1i1 * i1Iii1i1I
 if os . path . exists ( os . path . join ( OOO00 , 'keyboard.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Advancedsettings.xml' , OOOO , 'restore_backup' , '' , '' , '' , 'Restore Your keyboard.xml' )
  if 31 - 31: o00O0OoO / O0
 if os . path . exists ( os . path . join ( OOO00 , 'RssFeeds.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore RssFeeds.xml' , oOoOooOo0o0 , 'restore_backup' , '' , '' , '' , 'Restore Your RssFeeds.xml' )
  if 57 - 57: i1IIi % o0oOo0
  if 69 - 69: oOO00Oo
def o00ooOOo0ooO0 ( url ) :
 i1iI1i ( )
 if 'addons' in url :
  I11i1I1 = xbmc . translatePath ( os . path . join ( OOO00 , 'addons.zip' ) )
  iiI1iI111 = II11iiii1Ii
  if 23 - 23: OoooO0Oo0O0 + o0Oo + OoooooooOO
 else :
  I11i1I1 = xbmc . translatePath ( os . path . join ( OOO00 , 'addon_data.zip' ) )
  iiI1iI111 = O0OoO000O0OO
  if 47 - 47: Iiii1i1
 if 'Backup' in i1iIIIi1i :
  Oo ( )
  OOooO0OOoo . create ( "Creating Backup" , "Backing Up" , '' , 'Please Wait' )
  iIi1iIIIiIiI = zipfile . ZipFile ( I11i1I1 , 'w' , zipfile . ZIP_DEFLATED )
  OooOo000o0o = len ( iiI1iI111 )
  iI1I1iII1i = [ ]
  iiIIii = [ ]
  for O000oOo , OoOOOO , I1iiIi111I in os . walk ( iiI1iI111 ) :
   for file in I1iiIi111I :
    iiIIii . append ( file )
  IiiiI111I = len ( iiIIii )
  for O000oOo , OoOOOO , I1iiIi111I in os . walk ( iiI1iI111 ) :
   for file in I1iiIi111I :
    iI1I1iII1i . append ( file )
    Oo0O0Oo00O = len ( iI1I1iII1i ) / float ( IiiiI111I ) * 100
    OOooO0OOoo . update ( int ( Oo0O0Oo00O ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
    iI = os . path . join ( O000oOo , file )
    if not 'temp' in OoOOOO :
     if not o0OO00 in OoOOOO :
      import time
      iIIiI1iiI = '01/01/1980'
      I11Ii111I = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iI ) ) )
      if I11Ii111I > iIIiI1iiI :
       iIi1iIIIiIiI . write ( iI , iI [ OooOo000o0o : ] )
  iIi1iIIIiIiI . close ( )
  OOooO0OOoo . close ( )
  iI111I11I1I1 . ok ( "Backup Complete" , "You Are Now Backed Up" , '' , '' )
  if 65 - 65: iI1IiiIIIiIi
 else :
  OOooO0OOoo . create ( "Extracting Zip" , "Checking " , '' , 'Please Wait' )
  OOooO0OOoo . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( I11i1I1 , iiI1iI111 , OOooO0OOoo )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 71 - 71: Iiii1i1 % Iiii1i1 . III1IiiI + i11iIiiIii - i11iIiiIii
  if 'Backup' in i1iIIIi1i :
   iI111I11I1I1 . ok ( "Install Complete" , 'Kodi will now close. Just re-open Kodi and wait for all the updates to complete.' )
   O00000OO00OO ( )
   if 16 - 16: iIii1I11I1II1 / o0Oo / Iiii1i1 - i11iIiiIii . o0oOo0 / iiIi1i11
  else :
   iI111I11I1I1 . ok ( "SUCCESS!" , "You Are Now Restored" , '' , '' )
   if 13 - 13: oOO00Oo % O0 - Iiii1i1 * OoooooooOO / II11iIiIIIiI - OoooooooOO
   if 78 - 78: III1IiiI % OoooooooOO
def OO00O0OoooO ( url ) :
 xbmc . executebuiltin ( 'RunAddon(' + url + ')' )
 if 78 - 78: OoooooooOO % III1IiiI - i11iIiiIii
 if 37 - 37: i11111IIIII % iI1IiiIIIiIi % i1IIi
def OOoo ( title ) :
 i1Iii1ii = ''
 I1i1ii1ii = xbmc . Keyboard ( i1Iii1ii , title )
 I1i1ii1ii . doModal ( )
 if I1i1ii1ii . isConfirmed ( ) :
  i1Iii1ii = I1i1ii1ii . getText ( ) . replace ( ' ' , '%20' )
  if i1Iii1ii == None :
   return False
 return i1Iii1ii
 if 61 - 61: oOO00Oo . i11111IIIII . O0 + OoooooooOO + O0
 if 65 - 65: i1IIi * iiIi1i11 * OoooooooOO - i11111IIIII . i1Iii1i1I - ii1ii11IIIiiI
def o0Oo0oo0o0o0 ( url ) :
 Oo0OOo = i1II11I11ii1 ( heading = "Search for add-ons" )
 if 92 - 92: iI1IiiIIIiIi - o0oOo0 / o0oOo0 + i11111IIIII
 if ( not Oo0OOo ) : return False , 0
 if 57 - 57: iiIi1i11 - OoooooooOO * ii1ii11IIIiiI * i1Iii1i1I + III1IiiI
 if 100 - 100: Iiii1i1 - i1IIi
 I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 url += I1II1IiI1
 iIIIi ( url )
 if 90 - 90: iI1IiiIIIiIi + III1IiiI . oO0OooOoO - O00OOOoOoo0O % iIii1I11I1II1
 if 24 - 24: i11111IIIII / iI1IiiIIIiIi * iiIi1i11
def iiIIi1Ii1 ( url ) :
 Oo0OOo = i1II11I11ii1 ( heading = "Search for content" )
 if 48 - 48: o00O0OoO . i11iIiiIii % o0Oo
 if 57 - 57: iiIi1i11 * ii1ii11IIIiiI + O0 % Iiii1i1 - o0Oo
 if ( not Oo0OOo ) : return False , 0
 if 43 - 43: Iiii1i1
 if 10 - 10: i1IIi - oOO00Oo / OoooooooOO + i11iIiiIii + iIii1I11I1II1
 I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
 url += I1II1IiI1
 IIiI ( url )
 if 26 - 26: i11iIiiIii . iiIi1i11 - O0
 if 73 - 73: o0Oo
def OO0OOOOOOoo ( url ) :
 I1i11 = 'http://noobsandnerds.com/TI/Community_Builds/community_builds.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 5 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 OO0 = re . compile ( 'author="(.+?)"' ) . findall ( IiIi1I1 )
 o0O00oOOoo = re . compile ( 'version="(.+?)"' ) . findall ( IiIi1I1 )
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 Iii1II1ii = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else ''
 oOOo0oo0O = o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
 iI111I11I1I1 . ok ( i1iIIIi1i , 'Author: [COLOR=dodgerblue]' + Iii1II1ii + '[/COLOR]      Latest Version: [COLOR=dodgerblue]' + oOOo0oo0O + '[/COLOR]' , '' , 'Click OK to view the build page.' )
 try :
  iiII1i ( url + '&visibility=homepage' , url )
 except :
  return
  print "### Could not find build No. " + url
  iI111I11I1I1 . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private or servers may be busy. Please try manually searching via the Community Builds section' )
  if 50 - 50: III1IiiI . iIii1I11I1II1 % iiIi1i11
  if 68 - 68: o0oOo0
def OOOO0000 ( url ) :
 iI111I11I1I1 . ok ( "This build is not complete" , 'The guisettings.xml file was not copied over during the last install process. Click OK to go to the build page and complete Install Step 2 (guisettings fix).' )
 if 91 - 91: iIii1I11I1II1 / iI1IiiIIIiIi . OoooooooOO / iiIi1i11 * iI1IiiIIIiIi
 try :
  iiII1i ( url + '&visibility=homepage' , url )
  if 64 - 64: i11iIiiIii . iIii1I11I1II1
 except :
  return
  print "### Could not find build No. " + url
  iI111I11I1I1 . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 7 - 7: O00OOOoOoo0O % o0oOo0 + O00OOOoOoo0O - O00OOOoOoo0O * i11iIiiIii % ii1ii11IIIiiI
  if 57 - 57: iiIi1i11 / ii1ii11IIIiiI + OoooO0Oo0O0
def Oo0OO0o0oOO0 ( ) :
 I1i11 = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( i1i1II , O0oo0OO0 )
 IiIi1I1 = IiIIi1 ( I1i11 , 5 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i111Iii11i1Ii = re . compile ( 'login_msg="(.+?)"' ) . findall ( IiIi1I1 )
 O00Ooiii = i111Iii11i1Ii [ 0 ] if ( len ( i111Iii11i1Ii ) > 0 ) else ''
 i1II1IiIIi = re . compile ( 'posts="(.+?)"' ) . findall ( IiIi1I1 )
 o0O0 = re . compile ( 'messages="(.+?)"' ) . findall ( IiIi1I1 )
 iiIi1I1IIIII1IIi = re . compile ( 'unread="(.+?)"' ) . findall ( IiIi1I1 )
 i11iii1II1I1 = re . compile ( 'email="(.+?)"' ) . findall ( IiIi1I1 )
 IiIi11iI1IIi = o0O0 [ 0 ] if ( len ( o0O0 ) > 0 ) else ''
 iII111I = iiIi1I1IIIII1IIi [ 0 ] if ( len ( iiIi1I1IIIII1IIi ) > 0 ) else ''
 Ooooo0Oo0oOo = i11iii1II1I1 [ 0 ] if ( len ( i11iii1II1I1 ) > 0 ) else ''
 oo0o0OO00oOO = i1II1IiIIi [ 0 ] if ( len ( i1II1IiIIi ) > 0 ) else ''
 if 33 - 33: OoooooooOO - iI1IiiIIIiIi - O00OOOoOoo0O + i11111IIIII - i1IIi . i11iIiiIii
 I1i11 = 'http://noobsandnerds.com/TI/menu_check'
 try :
  IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  O00OoOoO = re . compile ( 'd="(.+?)"' ) . findall ( IiIi1I1 )
  ooO0o0oo = O00OoOoO [ 0 ] if ( len ( O00OoOoO ) > 0 ) else 'none'
 except :
  ooO0o0oo = 'none'
  if 28 - 28: Iiii1i1 / III1IiiI . OoooO0Oo0O0
 if 'Welcome Back' in O00Ooiii :
  print "### ATTEMPTING TO WRITE COOKIE "
  o0oooOO00 = open ( oo0OooOOo0 , mode = 'w+' )
  o0oooOO00 . write ( 'd="' + binascii . hexlify ( IiIiIIIiI1iII ( ) ) + '"\nl="' + binascii . hexlify ( O00Ooiii ) + '"\np="' + binascii . hexlify ( oo0o0OO00oOO ) + '"\nm="' + binascii . hexlify ( ooO0o0oo ) + '"' )
  o0oooOO00 . close ( )
 if not "Account currently restricted" in O00Ooiii :
  iI111I11I1I1 . ok ( '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' , 'Username:  ' + i1i1II , 'Email: ' + Ooooo0Oo0oOo , 'Unread Messages: ' + iII111I + '/' + IiIi11iI1IIi + '[CR]Posts: ' + oo0o0OO00oOO )
 else :
  iI111I11I1I1 . ok ( 'Account Currently Restricted' , 'Your account has a restriction in place, this is usually for account sharing. Any users caught sharing accounts are automatically put on a suspension and continual abuse will result in a permanent ban.' )
  if 83 - 83: o00O0OoO
  if 36 - 36: iIii1I11I1II1
def iii11 ( url , type ) :
 if type == 'communitybuilds' :
  o0OOoOO00OO0 = 'grab_builds'
  if url . endswith ( "visibility=public" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=public' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=private" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=private' , 'manual_search' , '' , '' , '' , '' )
 if type == 'tutorials' :
  o0OOoOO00OO0 = 'grab_tutorials'
 if type == 'hardware' :
  o0OOoOO00OO0 = 'grab_hardware'
 if type == 'addons' :
  o0OOoOO00OO0 = 'grab_addons'
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloads&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 if type == 'hardware' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]Filter Results[/COLOR]' , url , 'hardware_filter_menu' , '' , '' , '' , '' )
 if type != 'addons' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloadcount&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 if type == 'tutorials' or type == 'hardware' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=Added&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 else :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=created&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Recently Updated[/COLOR]' , str ( url ) + '&sortx=updated&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by A-Z[/COLOR]' , str ( url ) + '&sortx=name&orderx=ASC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Z-A[/COLOR]' , str ( url ) + '&sortx=name&orderx=DESC' , o0OOoOO00OO0 , '' , '' , '' , '' )
 if type == 'public_CB' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Genre[/COLOR]' , url , 'genres' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Country/Language[/COLOR]' , url , 'countries' , '' , '' , '' , '' )
  if 93 - 93: oO0OooOoO * oO0OooOoO + o0Oo / II11iIiIIIiI
  if 9 - 9: II11iIiIIIiI - i11111IIIII
def ii1i1iIiIIi ( ) :
 OOooO0OO0 ( 'Speed Test Instructions' , '[COLOR=blue][B]What file should I use: [/B][/COLOR][CR]This function will download a file and will work out your speed based on how long it took to download. You will then be notified of '
 'what quality streams you can expect to stream without buffering. You can choose to download a 10MB, 16MB, 32MB, 64MB or 128MB file to use with the test. Using the larger files will give you a better '
 'indication of how reliable your speeds are but obviously if you have a limited amount of bandwidth allowance you may want to opt for a smaller file.'
 '[CR][CR][COLOR=blue][B]How accurate is this speed test:[/B][/COLOR][CR]Not very accurate at all! As this test is based on downloading a file from a server it\'s reliant on the server not having a go-slow day '
 'but the servers used should be pretty reliable. The 10MB file is hosted on a different server to the others so if you\'re not getting the results expected please try another file. If you have a fast fiber '
 'connection the chances are your speed will show as considerably slower than your real download speed due to the server not being able to send the file as fast as your download speed allows. Essentially the '
 'test results will be limited by the speed of the server but you will at least be able to see if it\'s your connection that\'s causing buffering or if it\'s the host you\'re trying to stream from'
 '[CR][CR][COLOR=blue][B]What is the differnce between Live Streams and Online Video:[/COLOR][/B][CR]When you run the test you\'ll see results based on your speeds and these let you know the quality you should expect to '
 'be able stream with your connection. Live Streams as the title suggests are like traditional TV channels, they are being streamed live so for example if you wanted to watch CNN this would fall into this category. '
 'Online Videos relates to movies, tv shows, youtube clips etc. Basically anything that isn\'t live - if you\'re new to the world of streaming then think of it as On Demand content, this is content that\'s been recorded and stored on the web.'
 '[CR][CR][COLOR=blue][B]Why am I still getting buffering:[/COLOR][/B][CR]The results you get from this test are strictly based on your download speed, there are many other factors that can cause buffering and contrary to popular belief '
 'having a massively fast internet connection will not make any difference to your buffering issues if the server you\'re trying to get the content from is unable to send it fast enough. This can often happen and is usually '
 'down to heavy traffic (too many users accessing the same server). A 10 Mb/s connection should be plenty fast enough for almost all content as it\'s very rare a server can send it any quicker than that.'
 '[CR][CR][COLOR=blue][B]What\'s the difference between MB/s and Mb/s:[/COLOR][/B][CR]A lot of people think the speed they see advertised by their ISP is Megabytes (MB/S) per second - this is not true. Speeds are usually shown as Mb/s '
 'which is Megabit per second - there are 8 of these to a megabyte so if you want to work out how many megabytes per second you\'re getting you need to divide the speed by 8. It may sound sneaky but really it\'s just the unit that has always been used.'
 '[CR][CR]A direct link to the buffering thread explaining what you can do to improve your viewing experience can be found at [COLOR=yellow]http://bit.ly/bufferingfix[/COLOR]'
 '[CR][CR]Thank you, [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Team.' )
 if 24 - 24: oOO00Oo - i1Iii1i1I % II11iIiIIIiI
 if 83 - 83: iI1IiiIIIiIi . iiIi1i11 * i11111IIIII % oO0OooOoO - iI1IiiIIIiIi
def ooOO0oo0o0o ( ) :
 oO00oOOoooO ( '' , '[COLOR=blue]Instructions - Read me first[/COLOR]' , 'none' , 'speed_instructions' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 16MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 32MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 64MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 128MB file - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]' , 'http://www.wswd.net/testdownloadfiles/10MB.zip' , 'runtest' , '' , '' , '' , '' )
 if 23 - 23: Iiii1i1 * i1Iii1i1I . oO0OooOoO - OoooooooOO + iI1IiiIIIiIi
def O0oOoOOO000 ( name ) :
 if 73 - 73: OoooooooOO % o0oOo0 . i1IIi - iIii1I11I1II1 . ii1ii11IIIiiI
 OOooO0OOoo . create ( 'Creating Profile' , '' , '' , '' )
 I1111I1Ii = i11111 ( name )
 if 100 - 100: i1IIi * i1IIi
 if 26 - 26: iiIi1i11 . ii1ii11IIIiiI % O00OOOoOoo0O
 Ii11iiI1 = [ ]
 for iIIii1iiiIiiI in os . listdir ( OO0o ) :
  Ii11iiI1 . append ( iIIii1iiiIiiI )
  if 94 - 94: i11111IIIII
  if 15 - 15: iI1IiiIIIiIi - i11111IIIII / O0
  i1i11iii11 = open ( os . path . join ( iiI1IiI , name , 'addonlist' ) , mode = 'r' )
  I11111i = i1i11iii11 . read ( )
  i1i11iii11 . close ( )
  I11111i = I11111i . split ( '|' )
  if 46 - 46: OoooooooOO
  if 80 - 80: O0 * i1Iii1i1I
 oooooO00OOO ( 'profiles' )
 for iIIii1iiiIiiI in os . listdir ( II11iiii1Ii ) :
  if not iIIii1iiiIiiI in Ii11iiI1 and iIIii1iiiIiiI != 'plugin.program.totalinstaller' and iIIii1iiiIiiI != 'script.module.addon.common' and iIIii1iiiIiiI != 'repository.noobsandnerds' and iIIii1iiiIiiI != 'packages' :
   try :
    shutil . copytree ( os . path . join ( i1Oo00 , 'addons' , iIIii1iiiIiiI ) , os . path . join ( iiI1IiI , 'Master' , 'backups' , iIIii1iiiIiiI ) )
    if iiIIIII1i1iI == 'true' :
     print "### Successfully copied " + iIIii1iiiIiiI + " to " + os . path . join ( iiI1IiI , 'Master' , 'backups' , iIIii1iiiIiiI )
   except :
    print "### Failed to copy " + iIIii1iiiIiiI + " to backup folder, must already exist"
   if not iIIii1iiiIiiI in I11111i and iIIii1iiiIiiI != OOOO0OOoO0O0 :
    try :
     os . rename ( os . path . join ( II11iiii1Ii , iIIii1iiiIiiI ) , os . path . join ( iiI1IiI , 'Master' , iIIii1iiiIiiI ) )
    except :
     try :
      shutil . copytree ( os . path . join ( II11iiii1Ii , iIIii1iiiIiiI ) , os . path . join ( iiI1IiI , 'Master' , iIIii1iiiIiiI ) )
     except :
      try :
       shutil . rmtree ( os . path . join ( II11iiii1Ii , iIIii1iiiIiiI ) )
      except :
       print "### Unable to move " + iIIii1iiiIiiI + " as it's currently in use"
 shutil . rmtree ( i1Oo00 )
 if 73 - 73: i11111IIIII / iI1IiiIIIiIi + Iiii1i1 . iiIi1i11 - oO0OooOoO / iIii1I11I1II1
 if 79 - 79: Iiii1i1 * II11iIiIIIiI . oOO00Oo - Iiii1i1
 for iIIii1iiiIiiI in I11111i :
  if not iIIii1iiiIiiI in Ii11iiI1 and not iIIii1iiiIiiI in II11iiii1Ii :
   try :
    os . rename ( os . path . join ( iiI1IiI , 'Master' , iIIii1iiiIiiI ) , os . path . join ( II11iiii1Ii , iIIii1iiiIiiI ) )
   except :
    pass
    if 16 - 16: o0Oo - O0 * OoooO0Oo0O0 . OoooO0Oo0O0 % iiIi1i11
 IiI11 ( )
 I1iiiii ( )
 O0O0o00o00O00 ( IIIi1I1IIii1II )
 print "### WIPE FUNCTIONS COMPLETE"
 if 94 - 94: OoooO0Oo0O0 + oO0OooOoO - OoooO0Oo0O0 + o00O0OoO
 try :
  O0OO0o0OO0OO = open ( I1IIiiIiii , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
  print "### original idfile contents: " + i11i
 except :
  print "### original id file does not exist"
  if 90 - 90: iIii1I11I1II1
 try :
  extract . all ( os . path . join ( iiI1IiI , name , 'build.zip' ) , iIii1 , OOooO0OOoo )
  IIi1I1iII111 = 1
  print "### Extraction of build successful"
 except :
  iI111I11I1I1 . ok ( 'Error' , "Sorry it wasn't possible to extract your build, there is a problem with your build zip file." )
  IIi1I1iII111 = 0
 if os . path . exists ( os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'id.xml' ) ) and os . path . exists ( os . path . join ( O0OoO000O0OO , 'ti_id' , 'id.xml' ) ) :
  print "### id.xml and temporary id.xml exists, attempting remove of original and replace with temp"
  os . remove ( os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'id.xml' ) )
  print "### removal ok"
  os . rename ( os . path . join ( O0OoO000O0OO , 'ti_id' , 'id.xml' ) , os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'id.xml' ) )
  print "### rename ok"
 if os . path . exists ( os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'startup.xml' ) ) and os . path . exists ( os . path . join ( O0OoO000O0OO , 'ti_id' , 'startup.xml' ) ) :
  print "### startup.xml and temporary startup.xml exists, attempting remove of original and replace with temp"
  os . remove ( os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'startup.xml' ) )
  print "### removal ok"
  os . rename ( os . path . join ( O0OoO000O0OO , 'ti_id' , 'startup.xml' ) , os . path . join ( O0OoO000O0OO , 'plugin.program.totalinstaller' , 'startup.xml' ) )
  print "### rename ok"
  if 18 - 18: o00O0OoO * OoooO0Oo0O0 / i11iIiiIii / iIii1I11I1II1 * OoooooooOO . iiIi1i11
 O0OO0o0OO0OO = open ( I1IIiiIiii , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 if 69 - 69: II11iIiIIIiI * o0oOo0
 print "### new idfile contents: " + i11i
 if 91 - 91: oOO00Oo . o0oOo0 / ii1ii11IIIiiI / i11iIiiIii * oOO00Oo
 if IIi1I1iII111 == 1 :
  O00000OO00OO ( )
  if 52 - 52: o0Oo - i11iIiiIii / i11111IIIII . III1IiiI
  if 38 - 38: III1IiiI + OoooooooOO * O00OOOoOoo0O % III1IiiI
def oo0Oooo0O ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]DELETE A BUILD[/COLOR]' , url , 'delete_profile' , '' , '' , '' )
 for i1iIIIi1i in os . listdir ( iiI1IiI ) :
  if i1iIIIi1i != 'Master' and i1iIIIi1i != url . replace ( ' ' , '_' ) . replace ( "'" , '' ) . replace ( ':' , '-' ) :
   oO00oOOoooO ( '' , 'Load Profile: [COLOR=dodgerblue]' + i1iIIIi1i . replace ( '_' , ' ' ) + '[/COLOR]' , i1iIIIi1i , 'switch_profile' , '' , '' , '' , '' )
   if 80 - 80: II11iIiIIIiI
   if 16 - 16: o0Oo * i1Iii1i1I . iIii1I11I1II1
def OOooO0OO0 ( heading , anounce ) :
 class Oooo000ooo00O ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try :
    iiI1iii = open ( anounce ) ; iiI11I1iII = iiI1iii . read ( )
   except :
    iiI11I1iII = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( iiI11I1iII ) )
   return
 Oooo000ooo00O ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  xbmc . sleep ( 500 )
  if 26 - 26: OoooO0Oo0O0 - i1IIi . iiIi1i11 . iI1IiiIIIiIi
  if 5 - 5: i11111IIIII - o00O0OoO
def I1iOoO00O ( url ) :
 try :
  O0oo0ooO , iiI11I1iII = url . split ( '|' )
  OOooO0OO0 ( O0oo0ooO , iiI11I1iII )
 except :
  OOooO0OO0 ( '' , url )
  if 6 - 6: iIii1I11I1II1 / i1Iii1i1I
  if 1 - 1: Iiii1i1 / O00OOOoOoo0O * O00OOOoOoo0O - oOO00Oo % iI1IiiIIIiIi
def IiIiIIIiI1iII ( ) :
 O000o = time . time ( )
 iiI1I = time . localtime ( O000o )
 return time . strftime ( '%Y%m%d%H%M%S' , iiI1I )
 if 15 - 15: OoooooooOO
 if 31 - 31: oO0OooOoO
def Oo000O00o0O ( ) :
 oO00oOOoooO ( '' , '[COLOR=gold]CLEAN MY KODI FOLDERS (Save Space)[/COLOR]' , '' , 'full_clean' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , '' , 'nan_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][Noobs][/COLOR] Community Portal Folder Check' , 'url' , 'check_storage' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Test My Download Speed' , 'none' , 'speedtest_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Backup/Restore My Content' , 'none' , 'backup_restore' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Nerds][/COLOR] Advanced Options' , '' , 'advanced_tools' , '' , '' , '' , '' )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , '[COLOR=dodgerblue]Wi-Fi / OpenELEC Settings[/COLOR]' , '' , 'openelec_settings' , '' , '' , '' , '' )
  if 83 - 83: o0oOo0 - iiIi1i11 / O0
  if 17 - 17: oOO00Oo . i11111IIIII . i11iIiiIii + OoooooooOO % i11iIiiIii
def IIiI1iIiii ( ) :
 o0OoO0o00o = I1I1iiii1IiI1i ( )
 oO00oOOoooO ( '' , 'Check For Special Characters In Filenames' , '' , 'ASCII_Check' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Check My IP Address' , 'none' , 'ipcheck' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Check XBMC/Kodi Version' , 'none' , 'xbmcversion' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear All Cache Folders' , 'url' , 'clear_cache' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear Cached Artwork (thumbnails & textures)' , 'none' , 'remove_textures' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear Packages Folder' , 'url' , 'remove_packages' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Completely remove an add-on (inc. passwords)' , 'plugin' , 'addon_removal_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Convert Physical Paths To Special' , iIii1 , 'fix_special' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Addon_Data' , 'url' , 'remove_addon_data' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Old Builds/Zips From Device' , 'url' , 'remove_build' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Old Crash Logs' , 'url' , 'remove_crash_logs' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Force Close Kodi' , 'url' , 'kill_xbmc' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Make Add-ons Gotham/Helix Compatible' , 'none' , 'gotham' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Make Skins Kodi (Helix) Compatible' , 'none' , 'helix' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Passwords - Hide when typing in' , 'none' , 'hide_passwords' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Passwords - Unhide when typing in' , 'none' , 'unhide_passwords' , '' , '' , '' , '' )
 if i1i1II . replace ( '%20' , ' ' ) in o0OoO0o00o and i1i1II != '' :
  oO00oOOoooO ( '' , 'Remove Community Build Protection' , 'none' , 'remove_nag' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Update My Add-ons (Force Refresh)' , 'none' , 'update' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Upload Log' , 'none' , 'uploadlog' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'View My Log' , 'none' , 'log' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Wipe My Install (Fresh Start)' , 'none' , 'wipe_xbmc' , '' , '' , '' , '' )
 if 46 - 46: i1Iii1i1I + Iiii1i1 % OoooooooOO * OoooO0Oo0O0
 if 89 - 89: i11111IIIII - i11111IIIII % i1Iii1i1I / o00O0OoO + III1IiiI - i11111IIIII
def O0oOoO0o0oO ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Add-on Maintenance[/COLOR]' , str ( url ) + '&type=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audio Add-ons' , str ( url ) + '&type=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Picture Add-ons' , str ( url ) + '&type=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Program Add-ons' , str ( url ) + '&type=Programs' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Video Add-ons' , str ( url ) + '&type=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 if 80 - 80: III1IiiI / O0
 if 55 - 55: o0Oo * o00O0OoO / O0 % O00OOOoOoo0O
def Oo0OOOOOOOo0O ( url ) :
 II1i111 = 'http://noobsandnerds.com/TI/TutorialPortal/downloadcount.php?id=%s' % ( url )
 try :
  IiIIi1 ( II1i111 , 5 )
 except :
  pass
 I1i11 = 'http://noobsandnerds.com/TI/TutorialPortal/tutorialdetails.php?id=%s' % ( url )
 IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoo0000O0o0 = re . compile ( 'name="(.+?)"' ) . findall ( IiIi1I1 )
 OO0 = re . compile ( 'author="(.+?)"' ) . findall ( IiIi1I1 )
 Iio0000O00oO0O = re . compile ( 'video_guide1="(.+?)"' ) . findall ( IiIi1I1 )
 IiiI111I11 = re . compile ( 'video_guide2="(.+?)"' ) . findall ( IiIi1I1 )
 oO0Ooooo000 = re . compile ( 'video_guide3="(.+?)"' ) . findall ( IiIi1I1 )
 Iii1Iiii = re . compile ( 'video_guide4="(.+?)"' ) . findall ( IiIi1I1 )
 i1i1Ii1IiIII = re . compile ( 'video_guide5="(.+?)"' ) . findall ( IiIi1I1 )
 I1IIii11 = re . compile ( 'video_label1="(.+?)"' ) . findall ( IiIi1I1 )
 I1I1O0O = re . compile ( 'video_label2="(.+?)"' ) . findall ( IiIi1I1 )
 OO0ooO00o = re . compile ( 'video_label3="(.+?)"' ) . findall ( IiIi1I1 )
 I1iii1 = re . compile ( 'video_label4="(.+?)"' ) . findall ( IiIi1I1 )
 iIiiiIIiii = re . compile ( 'video_label5="(.+?)"' ) . findall ( IiIi1I1 )
 I1III = re . compile ( 'about="(.+?)"' ) . findall ( IiIi1I1 )
 ii1I1IIi = re . compile ( 'step1="(.+?)"' ) . findall ( IiIi1I1 )
 o00oOO0OOo = re . compile ( 'step2="(.+?)"' ) . findall ( IiIi1I1 )
 OooOooO0OoOoo0o = re . compile ( 'step3="(.+?)"' ) . findall ( IiIi1I1 )
 iII1iIIIIII = re . compile ( 'step4="(.+?)"' ) . findall ( IiIi1I1 )
 IIIIII11iIiI1III = re . compile ( 'step5="(.+?)"' ) . findall ( IiIi1I1 )
 o0Ooo0 = re . compile ( 'step6="(.+?)"' ) . findall ( IiIi1I1 )
 I1ii11iiIIi = re . compile ( 'step7="(.+?)"' ) . findall ( IiIi1I1 )
 ooOoO0o0OoOo = re . compile ( 'step8="(.+?)"' ) . findall ( IiIi1I1 )
 IiII11iI = re . compile ( 'step9="(.+?)"' ) . findall ( IiIi1I1 )
 o00o000 = re . compile ( 'step10="(.+?)"' ) . findall ( IiIi1I1 )
 IIIi1IiI1iII = re . compile ( 'step11="(.+?)"' ) . findall ( IiIi1I1 )
 OOOO0oo = re . compile ( 'step12="(.+?)"' ) . findall ( IiIi1I1 )
 iii1I1ii1 = re . compile ( 'step13="(.+?)"' ) . findall ( IiIi1I1 )
 IIiII11Iiii1i1II = re . compile ( 'step14="(.+?)"' ) . findall ( IiIi1I1 )
 ii1iIii = re . compile ( 'step15="(.+?)"' ) . findall ( IiIi1I1 )
 iiiI1I1iiiII = re . compile ( 'screenshot1="(.+?)"' ) . findall ( IiIi1I1 )
 IIiIi1I1iI1 = re . compile ( 'screenshot2="(.+?)"' ) . findall ( IiIi1I1 )
 i1I111II11 = re . compile ( 'screenshot3="(.+?)"' ) . findall ( IiIi1I1 )
 o00oO = re . compile ( 'screenshot4="(.+?)"' ) . findall ( IiIi1I1 )
 I11ii111i = re . compile ( 'screenshot5="(.+?)"' ) . findall ( IiIi1I1 )
 IIiI1I11ii1i = re . compile ( 'screenshot6="(.+?)"' ) . findall ( IiIi1I1 )
 o0o = re . compile ( 'screenshot7="(.+?)"' ) . findall ( IiIi1I1 )
 ooIi1Iii1 = re . compile ( 'screenshot8="(.+?)"' ) . findall ( IiIi1I1 )
 oooo = re . compile ( 'screenshot9="(.+?)"' ) . findall ( IiIi1I1 )
 I11iii1iIIIIi = re . compile ( 'screenshot10="(.+?)"' ) . findall ( IiIi1I1 )
 III1i1iiI1 = re . compile ( 'screenshot11="(.+?)"' ) . findall ( IiIi1I1 )
 O0ooO0O00oo0 = re . compile ( 'screenshot12="(.+?)"' ) . findall ( IiIi1I1 )
 II1i1iI = re . compile ( 'screenshot13="(.+?)"' ) . findall ( IiIi1I1 )
 iI111I1 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( IiIi1I1 )
 OoOOOO0 = re . compile ( 'screenshot15="(.+?)"' ) . findall ( IiIi1I1 )
 if 33 - 33: o0Oo - i1Iii1i1I . i1IIi / i11iIiiIii
 i1iIIIi1i = oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 Iii1II1ii = OO0 [ 0 ] if ( len ( OO0 ) > 0 ) else ''
 IioO0oOOO0Ooo = Iio0000O00oO0O [ 0 ] if ( len ( Iio0000O00oO0O ) > 0 ) else 'None'
 i1i1I = IiiI111I11 [ 0 ] if ( len ( IiiI111I11 ) > 0 ) else 'None'
 IiIIi1iII11I1Ii1 = oO0Ooooo000 [ 0 ] if ( len ( oO0Ooooo000 ) > 0 ) else 'None'
 o0o0 = Iii1Iiii [ 0 ] if ( len ( Iii1Iiii ) > 0 ) else 'None'
 oOo0oO = i1i1Ii1IiIII [ 0 ] if ( len ( i1i1Ii1IiIII ) > 0 ) else 'None'
 i111iiI1ii = I1IIii11 [ 0 ] if ( len ( I1IIii11 ) > 0 ) else 'None'
 IIiii = I1I1O0O [ 0 ] if ( len ( I1I1O0O ) > 0 ) else 'None'
 I1i1i = OO0ooO00o [ 0 ] if ( len ( OO0ooO00o ) > 0 ) else 'None'
 OOOOooO0oO00O0o = I1iii1 [ 0 ] if ( len ( I1iii1 ) > 0 ) else 'None'
 ooOO00oOOo000 = iIiiiIIiii [ 0 ] if ( len ( iIiiiIIiii ) > 0 ) else 'None'
 OOoo0Ii11I1iIIi = I1III [ 0 ] if ( len ( I1III ) > 0 ) else ''
 O0oo0 = '[CR][CR][COLOR=dodgerblue]Step 1:[/COLOR][CR]' + ii1I1IIi [ 0 ] if ( len ( ii1I1IIi ) > 0 ) else ''
 oOO00o0O0O = '[CR][CR][COLOR=dodgerblue]Step 2:[/COLOR][CR]' + o00oOO0OOo [ 0 ] if ( len ( o00oOO0OOo ) > 0 ) else ''
 o0Ooo0OoO = '[CR][CR][COLOR=dodgerblue]Step 3:[/COLOR][CR]' + OooOooO0OoOoo0o [ 0 ] if ( len ( OooOooO0OoOoo0o ) > 0 ) else ''
 I1iI1i = '[CR][CR][COLOR=dodgerblue]Step 4:[/COLOR][CR]' + iII1iIIIIII [ 0 ] if ( len ( iII1iIIIIII ) > 0 ) else ''
 iIIi = '[CR][CR][COLOR=dodgerblue]Step 5:[/COLOR][CR]' + IIIIII11iIiI1III [ 0 ] if ( len ( IIIIII11iIiI1III ) > 0 ) else ''
 iI1II = '[CR][CR][COLOR=dodgerblue]Step 6:[/COLOR][CR]' + o0Ooo0 [ 0 ] if ( len ( o0Ooo0 ) > 0 ) else ''
 i11i1IIi = '[CR][CR][COLOR=dodgerblue]Step 7:[/COLOR][CR]' + I1ii11iiIIi [ 0 ] if ( len ( I1ii11iiIIi ) > 0 ) else ''
 Oo0oiiiii11i = '[CR][CR][COLOR=dodgerblue]Step 8:[/COLOR][CR]' + ooOoO0o0OoOo [ 0 ] if ( len ( ooOoO0o0OoOo ) > 0 ) else ''
 OOoOOo0o0OOo0 = '[CR][CR][COLOR=dodgerblue]Step 9:[/COLOR][CR]' + IiII11iI [ 0 ] if ( len ( IiII11iI ) > 0 ) else ''
 iiiI11I = '[CR][CR][COLOR=dodgerblue]Step 10:[/COLOR][CR]' + o00o000 [ 0 ] if ( len ( o00o000 ) > 0 ) else ''
 OOo = '[CR][CR][COLOR=dodgerblue]Step 11:[/COLOR][CR]' + IIIi1IiI1iII [ 0 ] if ( len ( IIIi1IiI1iII ) > 0 ) else ''
 i1I1I = '[CR][CR][COLOR=dodgerblue]Step 12:[/COLOR][CR]' + OOOO0oo [ 0 ] if ( len ( OOOO0oo ) > 0 ) else ''
 iIiiiIII1II = '[CR][CR][COLOR=dodgerblue]Step 13:[/COLOR][CR]' + iii1I1ii1 [ 0 ] if ( len ( iii1I1ii1 ) > 0 ) else ''
 oO00oOOOO = '[CR][CR][COLOR=dodgerblue]Step 14:[/COLOR][CR]' + IIiII11Iiii1i1II [ 0 ] if ( len ( IIiII11Iiii1i1II ) > 0 ) else ''
 o0o0OOO0ooo00 = '[CR][CR][COLOR=dodgerblue]Step 15:[/COLOR][CR]' + ii1iIii [ 0 ] if ( len ( ii1iIii ) > 0 ) else ''
 I1111ii11 = iiiI1I1iiiII [ 0 ] if ( len ( iiiI1I1iiiII ) > 0 ) else ''
 I1iI1I1111i = IIiIi1I1iI1 [ 0 ] if ( len ( IIiIi1I1iI1 ) > 0 ) else ''
 iII11IiIIII = i1I111II11 [ 0 ] if ( len ( i1I111II11 ) > 0 ) else ''
 O00 = o00oO [ 0 ] if ( len ( o00oO ) > 0 ) else ''
 oooo0OOO00O00 = I11ii111i [ 0 ] if ( len ( I11ii111i ) > 0 ) else ''
 i11I111I1 = IIiI1I11ii1i [ 0 ] if ( len ( IIiI1I11ii1i ) > 0 ) else ''
 OOOoO000o0O0O = o0o [ 0 ] if ( len ( o0o ) > 0 ) else ''
 oO0oOO = ooIi1Iii1 [ 0 ] if ( len ( ooIi1Iii1 ) > 0 ) else ''
 Oo0O = oooo [ 0 ] if ( len ( oooo ) > 0 ) else ''
 i1iIi1iiii1ii = I11iii1iIIIIi [ 0 ] if ( len ( I11iii1iIIIIi ) > 0 ) else ''
 oO0oOo = III1i1iiI1 [ 0 ] if ( len ( III1i1iiI1 ) > 0 ) else ''
 IIiIiii = O0ooO0O00oo0 [ 0 ] if ( len ( O0ooO0O00oo0 ) > 0 ) else ''
 OOo0OO = II1i1iI [ 0 ] if ( len ( II1i1iI ) > 0 ) else ''
 ooIIi111I = iI111I1 [ 0 ] if ( len ( iI111I1 ) > 0 ) else ''
 I11III111i1I = OoOOOO0 [ 0 ] if ( len ( OoOOOO0 ) > 0 ) else ''
 O00Oo = str ( '[COLOR=orange]Author: [/COLOR]' + Iii1II1ii + '[CR][CR][COLOR=lime]About: [/COLOR]' + OOoo0Ii11I1iIIi + O0oo0 + oOO00o0O0O + o0Ooo0OoO + I1iI1i + iIIi + iI1II + i11i1IIi + Oo0oiiiii11i + OOoOOo0o0OOo0 + iiiI11I + OOo + i1I1I + iIiiiIII1II + oO00oOOOO + o0o0OOO0ooo00 )
 if 52 - 52: i1Iii1i1I % iIii1I11I1II1 . OoooO0Oo0O0 + III1IiiI % i1Iii1i1I * i1Iii1i1I
 if O0oo0 != '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  ' + i1iIIIi1i , O00Oo , 'text_guide' , '' , O0o0Oo , OOoo0Ii11I1iIIi , '' )
 if IioO0oOOO0Ooo != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i111iiI1ii , IioO0oOOO0Ooo , 'play_video' , '' , O0o0Oo , '' , '' )
 if i1i1I != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IIiii , i1i1I , 'play_video' , '' , O0o0Oo , '' , '' )
 if IiIIi1iII11I1Ii1 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1i1i , IiIIi1iII11I1Ii1 , 'play_video' , '' , O0o0Oo , '' , '' )
 if o0o0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + OOOOooO0oO00O0o , o0o0 , 'play_video' , '' , O0o0Oo , '' , '' )
 if oOo0oO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + ooOO00oOOo000 , oOo0oO , 'play_video' , '' , O0o0Oo , '' , '' )
  if 83 - 83: III1IiiI - Iiii1i1
  if 46 - 46: i11iIiiIii
def I1111 ( ) :
 if i1IiI1I11 . getSetting ( 'tutorial_manual_search' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'tutorials' , 'manual_search' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_all' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]All Guides[/COLOR] Everything in one place' , '' , 'grab_tutorials' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_kodi' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]XBMC / Kodi[/COLOR] Specific' , '' , 'xbmc_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_xbmc4xbox' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]XBMC4Xbox[/COLOR] Specific' , '&platform=XBMC4Xbox' , 'xbmc_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_android' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Android' , '&platform=Android' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_atv' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Apple TV' , '&platform=ATV' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_ios' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] ATV2 & iOS' , '&platform=iOS' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_linux' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Linux' , '&platform=Linux' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_pure_linux' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Pure Linux' , '&platform=Custom_Linux' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_openelec' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OpenELEC' , '&platform=OpenELEC' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_osmc' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSMC' , '&platform=OSMC' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_osx' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSX' , '&platform=OSX' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_raspbmc' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Raspbmc' , '&platform=Raspbmc' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_windows' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Windows' , '&platform=Windows' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_allwinner' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Allwinner Devices' , '&hardware=Allwinner' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_aftv' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Amazon Fire TV' , '&hardware=AFTV' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_amlogic' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] AMLogic Devices' , '&hardware=AMLogic' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_boxee' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Boxee' , '&hardware=Boxee' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_intel' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Intel Devices' , '&hardware=Intel' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_rpi' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Raspberry Pi' , '&hardware=RaspberryPi' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_rockchip' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Rockchip Devices' , '&hardware=Rockchip' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_xbox' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Xbox' , '&hardware=Xbox' , 'platform_menu' , '' , '' , '' , '' )
  if 80 - 80: i11111IIIII + oOO00Oo
  if 40 - 40: o00O0OoO . i1IIi - iI1IiiIIIiIi - i1Iii1i1I
def i1II ( ) :
 iI111I11I1I1 = xbmcgui . Dialog ( )
 if iI111I11I1I1 . yesno ( "Make Add-on Passwords Visible?" , "This will make all your add-on passwords visible in the add-on settings. Are you sure you wish to continue?" ) :
  for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( II11iiii1Ii ) :
   for iiI1iii in I1iiIi111I :
    if iiI1iii == 'settings.xml' :
     oO0oo0oOO = open ( os . path . join ( IiiI111 , iiI1iii ) ) . read ( )
     o0OO000ooOo = re . compile ( '<setting id=(.+?)>' ) . findall ( oO0oo0oOO )
     for iiII1iIi1ii1i in o0OO000ooOo :
      if 'pass' in iiII1iIi1ii1i :
       if 'option="hidden"' in iiII1iIi1ii1i :
        try :
         i11IiI1 = iiII1iIi1ii1i . replace ( ' option="hidden"' , '' )
         iiI1iii = open ( os . path . join ( IiiI111 , iiI1iii ) , mode = 'w' )
         iiI1iii . write ( str ( oO0oo0oOO ) . replace ( iiII1iIi1ii1i , i11IiI1 ) )
         iiI1iii . close ( )
        except :
         pass
  iI111I11I1I1 . ok ( "Passwords Are now visible" , "Your passwords will now be visible in your add-on settings. If you want to undo this please use the option to hide passwords." )
  if 28 - 28: i11111IIIII - iI1IiiIIIiIi . i11111IIIII - OoooO0Oo0O0 * i1Iii1i1I * ii1ii11IIIiiI
  if 58 - 58: i11111IIIII . OoooO0Oo0O0 * i1IIi
def ooO00O000o0 ( name , url , video , description , skins , guisettingslink , artpack ) :
 OOooO0OOoo . create ( "Backing Up Important Data" , 'Please wait...' , '' , '' )
 if 2 - 2: i1IIi . i11iIiiIii - oOO00Oo * o0oOo0 * o0Oo
 if 65 - 65: o00O0OoO . i11iIiiIii
 I111ii1i1ii = open ( I1IIiiIiii , mode = 'r' )
 IIII1i1IIIi = I111ii1i1ii . read ( )
 I111ii1i1ii . close ( )
 if 25 - 25: III1IiiI % o0oOo0 - i1Iii1i1I * ii1ii11IIIiiI
 IiI11iI = re . compile ( 'gui="(.+?)"' ) . findall ( IIII1i1IIIi )
 iiiI1iiIiII1 = IiI11iI [ 0 ] if ( len ( IiI11iI ) > 0 ) else '0'
 if 55 - 55: II11iIiIIIiI % Iiii1i1 . oO0OooOoO
 if 53 - 53: O0 / ii1ii11IIIiiI % i11iIiiIii
 if I1IiI == 'true' :
  try :
   I1IiI11i1i1Ii1iiII1I = open ( IIIII , mode = 'r' )
   IIIII11IIi = I1IiI11i1i1Ii1iiII1I . read ( )
   I1IiI11i1i1Ii1iiII1I . close ( )
   if 50 - 50: Iiii1i1 % i11111IIIII
  except :
   print "### No favourites file to copy"
   if 63 - 63: OoooooooOO . iI1IiiIIIiIi - III1IiiI / oO0OooOoO + o0Oo
 if o0OOO == 'true' :
  try :
   o00O0oOO0o = open ( ooooooO0oo , mode = 'r' )
   O0000000oooOO = o00O0oOO0o . read ( )
   o00O0oOO0o . close ( )
   if 7 - 7: ii1ii11IIIiiI - o0oOo0 % i1IIi
  except :
   print "### No sources file to copy"
   if 24 - 24: ii1ii11IIIiiI % O0 % o00O0OoO
 IIi1II = 1
 i1iI1i ( )
 if 61 - 61: o0oOo0 . i1Iii1i1I / o0oOo0 * OoooooooOO
 if 13 - 13: oO0OooOoO
 if os . path . exists ( Oo0OoO00oOO0o ) :
  if 17 - 17: oO0OooOoO
  if os . path . exists ( I11i1 ) :
   os . remove ( Oo0OoO00oOO0o )
   if 66 - 66: i11111IIIII * III1IiiI
  else :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   if 73 - 73: i11iIiiIii + O0 % O0
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 70 - 70: oO0OooOoO * OoooooooOO - iI1IiiIIIiIi + III1IiiI * O0
  if 49 - 49: III1IiiI . iI1IiiIIIiIi . O00OOOoOoo0O - OoooO0Oo0O0
 if not os . path . exists ( I11iii1Ii ) :
  O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'w+' )
  O0OO0o0OO0OO . close ( )
  if 74 - 74: o0oOo0 % OoooO0Oo0O0 * i1IIi
 OOooO0OOoo . close ( )
 OOooO0OOoo . create ( "Downloading Skin Fix" , "Downloading guisettings.xml" , '' , 'Please Wait' )
 OoO00 = os . path . join ( OOO00 , 'guifix.zip' )
 if 18 - 18: O00OOOoOoo0O
 if 30 - 30: oO0OooOoO
 try :
  print "### attempting to download guisettings.xml"
  downloader . download ( guisettingslink , OoO00 , OOooO0OOoo )
  OOooO0OOoo . close ( )
 except :
  iI111I11I1I1 . ok ( 'Problem Detected' , 'Sorry there was a problem downloading the guisettings file. Please check your storage location, if you\'re certain that\'s ok please notify the build author on the relevant support thread.' )
  print "### FAILED to download " + guisettingslink
  if 27 - 27: i1IIi - iIii1I11I1II1 + O0 % II11iIiIIIiI / iiIi1i11 + i1IIi
 if zipfile . is_zipfile ( OoO00 ) :
  oOoO0oO00ooOo = str ( os . path . getsize ( OoO00 ) )
  if 48 - 48: II11iIiIIIiI
 else :
  oOoO0oO00ooOo = iiiI1iiIiII1
  if 70 - 70: OoooooooOO * i11iIiiIii
  if 60 - 60: i11111IIIII / iIii1I11I1II1 + OoooooooOO - OoooO0Oo0O0 * i11iIiiIii
 O0OO0o0OO0OO = open ( I11iii1Ii , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 if 47 - 47: O0 . o0Oo / o0oOo0 % i11iIiiIii
 o0oooO0O00OoO = re . compile ( 'id="(.+?)"' ) . findall ( i11i )
 iiiiI = re . compile ( 'name="(.+?)"' ) . findall ( i11i )
 IiO0o = re . compile ( 'version="(.+?)"' ) . findall ( i11i )
 if 47 - 47: iI1IiiIIIiIi . O00OOOoOoo0O . iIii1I11I1II1 . oOO00Oo
 oOo0Oooo = o0oooO0O00OoO [ 0 ] if ( len ( o0oooO0O00OoO ) > 0 ) else ''
 I1iiIIiI11I = iiiiI [ 0 ] if ( len ( iiiiI ) > 0 ) else ''
 i1ii1I = IiO0o [ 0 ] if ( len ( IiO0o ) > 0 ) else ''
 if 39 - 39: oOO00Oo
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 89 - 89: OoooooooOO + i1Iii1i1I . Iiii1i1 / iI1IiiIIIiIi
  if 75 - 75: iIii1I11I1II1 * i1Iii1i1I / O00OOOoOoo0O * oO0OooOoO . i1IIi
 if iiiI1iiIiII1 != oOoO0oO00ooOo :
  try :
   os . rename ( I11i1 , Oo0OoO00oOO0o )
   if 6 - 6: iI1IiiIIIiIi % iI1IiiIIIiIi / OoooooooOO * III1IiiI . o0Oo . i1IIi
  except :
   iI111I11I1I1 . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit Kodi and try again' , '' )
   return
   if 59 - 59: o00O0OoO . o00O0OoO * o0Oo - iI1IiiIIIiIi % O00OOOoOoo0O
   if 19 - 19: OoooooooOO / II11iIiIIIiI - Iiii1i1 . O00OOOoOoo0O
 if video != 'fresh' :
  iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( name , 'We highly recommend backing up your existing build before installing any community builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
  if 8 - 8: o00O0OoO % o0oOo0 . iIii1I11I1II1
  if iII1Iii1I11i == 0 :
   i1i11IiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
   if 95 - 95: oOO00Oo + i11iIiiIii . OoooO0Oo0O0 . o0oOo0 . oOO00Oo
   if not os . path . exists ( i1i11IiII ) :
    os . makedirs ( i1i11IiII )
    if 93 - 93: i1Iii1i1I
   Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
   if 55 - 55: oO0OooOoO % oOO00Oo - ii1ii11IIIiiI
   if ( not Oo0OOo ) :
    return False , 0
    if 48 - 48: o0oOo0 * iIii1I11I1II1 % O00OOOoOoo0O
   I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
   iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( i1i11IiII , I1II1IiI1 + '.zip' ) )
   o00oo = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
   O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
   iI1ii11Ii = "Creating full backup of existing build"
   O0OO0OO = "Archiving..."
   Ooo0oO = ""
   IiIiIIiii1I = "Please Wait"
   oOo0OOoooO ( iIii1 , iIIiI11iI1Ii1 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
   if 100 - 100: oO0OooOoO - i11iIiiIii + ii1ii11IIIiiI % o0oOo0 - iIii1I11I1II1 * i11iIiiIii
 o0oooOO00 = open ( I1IIiiIiii , mode = 'w+' )
 if 30 - 30: ii1ii11IIIiiI . ii1ii11IIIiiI . iI1IiiIIIiIi % iI1IiiIIIiIi * i1IIi * III1IiiI
 if iiiI1iiIiII1 != oOoO0oO00ooOo :
  o0oooOO00 . write ( 'id="' + str ( oOo0Oooo ) + '"\nname="' + I1iiIIiI11I + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="' + i1ii1I + '"\ngui="' + oOoO0oO00ooOo + '"' )
  if 74 - 74: OoooooooOO
 else :
  o0oooOO00 . write ( 'id="' + str ( oOo0Oooo ) + '"\nname="' + I1iiIIiI11I + '"\nversion="' + i1ii1I + '"\ngui="' + oOoO0oO00ooOo + '"' )
 o0oooOO00 . close ( )
 if 33 - 33: oOO00Oo - oO0OooOoO
 if 95 - 95: OoooooooOO
 if video == 'libprofile' or video == 'library' or video == 'updatelibprofile' or video == 'updatelibrary' :
  try :
   shutil . copytree ( ooOoOoo0O , O0o0O00Oo0o0 , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 23 - 23: oO0OooOoO + o00O0OoO / O0 . o00O0OoO . Iiii1i1 + iIii1I11I1II1
  except :
   IIi1II = xbmcgui . Dialog ( ) . yesno ( name , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if 2 - 2: i1IIi . O0 / oOO00Oo . oO0OooOoO / ii1ii11IIIiiI % i1IIi
   if IIi1II == 0 :
    return
    if 12 - 12: oOO00Oo
  iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( OOO00 , 'Database.zip' ) )
  I1I1IiIi1 ( O0o0O00Oo0o0 , iIIiI11iI1Ii1 )
  if 58 - 58: iIii1I11I1II1 * iI1IiiIIIiIi . o0oOo0 . II11iIiIIIiI * iI1IiiIIIiIi
 if IIi1II == 0 :
  return
  if 63 - 63: O00OOOoOoo0O . o00O0OoO * oOO00Oo - o00O0OoO % o00O0OoO
 time . sleep ( 1 )
 if 62 - 62: o00O0OoO - o0oOo0 / o0oOo0
 if 95 - 95: O00OOOoOoo0O - i1IIi / Iiii1i1 . o0oOo0 % iiIi1i11 - i1IIi
 i1ii1iIIIiI1 = xbmc . translatePath ( os . path . join ( iIii1 , '..' , 'koditemp.zip' ) )
 time . sleep ( 2 )
 OOooO0OOoo . create ( "Community Builds" , "Downloading " + description + " build." , '' , 'Please Wait' )
 i11Ii1iiiI1I = description . replace ( ' ' , '_' ) . replace ( ':' , '-' ) . replace ( "'" , '' )
 OoO00 = os . path . join ( iiiiiIIii , i11Ii1iiiI1I + '.zip' )
 if 97 - 97: OoooooooOO * oO0OooOoO
 if not os . path . exists ( iiiiiIIii ) :
  os . makedirs ( iiiiiIIii )
  if 85 - 85: II11iIiIIIiI
 downloader . download ( url , OoO00 , OOooO0OOoo )
 if 33 - 33: i11iIiiIii + o0Oo
 if 95 - 95: OoooO0Oo0O0 / i11111IIIII % iIii1I11I1II1 + O0
 try :
  i111IiI1III1 = open ( I1IIIii , mode = 'r' )
  ooOOooooo0Oo = i111IiI1III1 . read ( )
  i111IiI1III1 . close ( )
 except :
  print "### No profiles detected, most likely a fresh wipe performed"
  if 32 - 32: o0oOo0 / oO0OooOoO . O0 . o0oOo0 % o0Oo - oOO00Oo
 OOooO0OOoo . close ( )
 OOooO0OOoo . create ( "Community Builds" , "Checking " , '' , 'Please Wait' )
 if 69 - 69: iI1IiiIIIiIi - o0Oo * iiIi1i11 . iIii1I11I1II1 * O00OOOoOoo0O . OoooooooOO
 if 6 - 6: O0 . oOO00Oo - O00OOOoOoo0O
 if zipfile . is_zipfile ( OoO00 ) :
  OOooO0OOoo . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( OoO00 , iIii1 , OOooO0OOoo )
  if 3 - 3: OoooooooOO % iIii1I11I1II1 * Iiii1i1 % II11iIiIIIiI + iIii1I11I1II1
 else :
  iI111I11I1I1 . ok ( 'Not a valid zip file' , 'This file is not a valid zip file, please let the build author know on their support thread so they can amend the download path. It\'s most likely just a simple typo on their behalf.' )
  return
  if 66 - 66: II11iIiIIIiI - O00OOOoOoo0O
 OOooO0OOoo . create ( "Restoring Dependencies" , "Checking " , '' , 'Please Wait' )
 OOooO0OOoo . update ( 0 , "" , "Extracting Zip Please Wait" )
 if 43 - 43: i1Iii1i1I / Iiii1i1 * o0Oo % o0oOo0 % o0Oo
 if I1IiI == 'true' :
  try :
   print "### Attempting to add back favourites ###"
   o0oooOO00 = open ( IIIII , mode = 'w+' )
   o0oooOO00 . write ( IIIII11IIi )
   o0oooOO00 . close ( )
   OOooO0OOoo . update ( 0 , "" , "Copying Favourites" )
  except :
   print "### Failed to copy back favourites"
   if 18 - 18: ii1ii11IIIiiI
 if o0OOO == 'true' :
  try :
   print "### Attempting to add back sources ###"
   o0oooOO00 = open ( ooooooO0oo , mode = 'w+' )
   o0oooOO00 . write ( O0000000oooOO )
   o0oooOO00 . close ( )
   OOooO0OOoo . update ( 0 , "" , "Copying Sources" )
   if 99 - 99: i1Iii1i1I / III1IiiI . i11iIiiIii / o00O0OoO + i1IIi - o00O0OoO
  except :
   print "### Failed to copy back sources"
   if 50 - 50: i1IIi
 time . sleep ( 1 )
 if os . path . exists ( O0o0O00Oo0o0 ) :
  shutil . rmtree ( O0o0O00Oo0o0 )
  if 56 - 56: ii1ii11IIIiiI + Iiii1i1 / iI1IiiIIIiIi
  if 75 - 75: O00OOOoOoo0O
 if os . path . exists ( O000OO0 ) :
  O0OO0o0OO0OO = open ( O000OO0 , mode = 'r' )
  i11i = O0OO0o0OO0OO . read ( )
  O0OO0o0OO0OO . close ( )
  i1Ii1 = re . compile ( 'version="[\s\S]*?"' ) . findall ( i11i )
  I1I1IiI1 = i1Ii1 [ 0 ] if ( len ( i1Ii1 ) > 0 ) else ''
  iiI1IIIi = i11i . replace ( I1I1IiI1 , 'version="' + i1ii1I + '"' )
  o0oooOO00 = open ( O000OO0 , mode = 'w' )
  o0oooOO00 . write ( str ( iiI1IIIi ) )
  o0oooOO00 . close ( )
  if 96 - 96: oOO00Oo * o00O0OoO * II11iIiIIIiI
 else :
  o0oooOO00 = open ( O000OO0 , mode = 'w+' )
  o0oooOO00 . write ( 'date="01011001"\nversion="' + i1ii1I + '"' )
  o0oooOO00 . close ( )
  if 36 - 36: OoooooooOO + o0oOo0 . III1IiiI * o0oOo0 + i11111IIIII
  if 45 - 45: III1IiiI / i1Iii1i1I + OoooO0Oo0O0 - II11iIiIIIiI - o0oOo0 . iIii1I11I1II1
 if IIiIiII11i == 'false' :
  os . remove ( OoO00 )
  if 52 - 52: o0Oo + i1IIi . i1Iii1i1I * o0Oo
  if 31 - 31: II11iIiIIIiI % iIii1I11I1II1 . O0
 if 'prof' in video :
  try :
   o0OOOIii11i1Ii = open ( I1IIIii , mode = 'w+' )
   o0OOOIii11i1Ii . write ( ooOOooooo0Oo )
   o0OOOIii11i1Ii . close ( )
  except :
   print "### Failed to write existing profile info back into profiles.xml"
   if 56 - 56: i11iIiiIii + i1IIi % iiIi1i11 / iI1IiiIIIiIi
   if 51 - 51: o00O0OoO % oO0OooOoO - oOO00Oo % ii1ii11IIIiiI * i11iIiiIii * i1Iii1i1I
 if video == 'library' or video == 'libprofile' or video == 'updatelibprofile' or video == 'updatelibrary' :
  extract . all ( iIIiI11iI1Ii1 , ooOoOoo0O , OOooO0OOoo )
  if 82 - 82: OoooooooOO / o0Oo * oO0OooOoO - OoooooooOO % iIii1I11I1II1 * ii1ii11IIIiiI
  if 32 - 32: i11iIiiIii - O00OOOoOoo0O * o00O0OoO . II11iIiIIIiI * o0oOo0
  if IIi1II != 1 :
   shutil . rmtree ( O0o0O00Oo0o0 )
 try :
  OOooO0OOoo . close ( )
 except :
  pass
  if 21 - 21: iiIi1i11
  if 11 - 11: III1IiiI % i11iIiiIii * O0
 if os . path . exists ( i1i ) :
  II111 ( description )
  if 28 - 28: Iiii1i1 / iIii1I11I1II1 + iiIi1i11 . OoooO0Oo0O0 % iiIi1i11 + ii1ii11IIIiiI
  try :
   os . remove ( i1i )
   if 79 - 79: III1IiiI
  except :
   print "###' Failed to remove: " + i1i
   if 39 - 39: Iiii1i1 % III1IiiI % O0 % O0 - i1Iii1i1I - III1IiiI
  try :
   shutil . rmtree ( i1Oo00 )
   if 83 - 83: i11iIiiIii + iIii1I11I1II1
  except :
   print "###' Failed to remove: " + i1Oo00
   if 21 - 21: oOO00Oo / i11iIiiIii % Iiii1i1
 else :
  print "### Community Builds - using an old build"
  if 56 - 56: oOO00Oo * iIii1I11I1II1 . iI1IiiIIIiIi + O00OOOoOoo0O % Iiii1i1
  if 11 - 11: iiIi1i11
 if iiiI1iiIiII1 != oOoO0oO00ooOo :
  print "### GUI SIZE DIFFERENT ATTEMPTING MERGE ###"
  Ii111I1iIiiIi = os . path . join ( iIii1 , 'newbuild' )
  if 45 - 45: i11111IIIII * iI1IiiIIIiIi . oOO00Oo
  if not os . path . exists ( Ii111I1iIiiIi ) :
   os . makedirs ( Ii111I1iIiiIi )
   if 68 - 68: II11iIiIIIiI + oOO00Oo * iiIi1i11 . oO0OooOoO % iI1IiiIIIiIi
  os . makedirs ( OOO00O )
  time . sleep ( 1 )
  I1IiIi1iiI ( guisettingslink , video )
  time . sleep ( 1 )
  O00000OO00OO ( )
  iI111I11I1I1 . ok ( "Force Close Required" , "If you\'re seeing this message it means the force close was unsuccessful. Please close XBMC/Kodi via your operating system or pull the power." )
  if 14 - 14: OoooooooOO * II11iIiIIIiI % o0oOo0 . iI1IiiIIIiIi - i1Iii1i1I - oO0OooOoO
 if iiiI1iiIiII1 == oOoO0oO00ooOo :
  iI111I11I1I1 . ok ( 'Successfully Updated' , 'Congratulations the following build:[COLOR=dodgerblue]' , description , '[/COLOR]has been successfully updated!' )
  if 67 - 67: i1Iii1i1I
  if 69 - 69: iiIi1i11 + i1Iii1i1I / Iiii1i1
def Iii1111Ii1iI ( ) :
 if i1IiI1I11 . getSetting ( 'email' ) == '' :
  iI111I11I1I1 = xbmcgui . Dialog ( )
  iI111I11I1I1 . ok ( "No Email Address Set" , "A new window will Now open for you to enter your Email address. The logfile will be sent here" )
  i1IiI1I11 . openSettings ( )
 xbmc . executebuiltin ( 'XBMC.RunScript(special://home/addons/' + o0OO00 + '/uploadLog.py)' )
 if 98 - 98: iI1IiiIIIiIi - OoooooooOO * o00O0OoO * III1IiiI % OoooO0Oo0O0 * oO0OooOoO
 if 86 - 86: i11iIiiIii / o00O0OoO * i1Iii1i1I - i1Iii1i1I
def iIiiIIi1i111iI ( localbuildcheck , localversioncheck , localidcheck ) :
 print "### USER_INFO CHECK"
 if o0oO0 == 'true' :
  try :
   I1i11 = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( i1i1II , O0oo0OO0 )
   IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   i111Iii11i1Ii = re . compile ( 'login_msg="(.+?)"' ) . findall ( IiIi1I1 )
   O00Ooiii = i111Iii11i1Ii [ 0 ] if ( len ( i111Iii11i1Ii ) > 0 ) else ''
   oo00000ooOooO = re . compile ( 'posts="(.+?)"' ) . findall ( IiIi1I1 )
   oo0o0OO00oOO = oo00000ooOooO [ 0 ] if ( len ( oo00000ooOooO ) > 0 ) else '0'
  except :
   O00Ooiii = '[COLOR=lime]UNABLE TO VERIFY LOGIN[/COLOR]'
   if 10 - 10: i11111IIIII % oO0OooOoO
 else :
  O00Ooiii = '[COLOR=lime]REGISTER FOR FREE TO UNLOCK FEATURES[/COLOR]'
  if 50 - 50: O00OOOoOoo0O * i1Iii1i1I
 print "### WELCOMETEXT: " + O00Ooiii
 if 59 - 59: o0Oo * o0Oo / o00O0OoO
 I1i11 = 'http://noobsandnerds.com/TI/menu_check'
 try :
  IiIi1I1 = IiIIi1 ( I1i11 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  O00OoOoO = re . compile ( 'd="(.+?)"' ) . findall ( IiIi1I1 )
  ooO0o0oo = O00OoOoO [ 0 ] if ( len ( O00OoOoO ) > 0 ) else 'none'
 except :
  ooO0o0oo = 'none'
  if 92 - 92: oOO00Oo
 print "### MENU: " + ooO0o0oo
 if 8 - 8: i1Iii1i1I + OoooO0Oo0O0 . iI1IiiIIIiIi
 if 50 - 50: II11iIiIIIiI
 if not 'REGISTER FOR FREE' in O00Ooiii and not 'UNABLE TO VERIFY' in O00Ooiii :
  print "### ATTEMPTING TO WRITE COOKIE "
  o0oooOO00 = open ( oo0OooOOo0 , mode = 'w+' )
  o0oooOO00 . write ( 'd="' + binascii . hexlify ( IiIiIIIiI1iII ( ) ) + '"\nl="' + binascii . hexlify ( O00Ooiii ) + '"\np="' + binascii . hexlify ( oo0o0OO00oOO ) + '"\nm="' + binascii . hexlify ( ooO0o0oo ) + '"' )
  o0oooOO00 . close ( )
  if 16 - 16: iI1IiiIIIiIi - O00OOOoOoo0O % II11iIiIIIiI / iI1IiiIIIiIi . o00O0OoO + o0oOo0
 I11o0000o0Oo ( localbuildcheck , localversioncheck , localidcheck , O00Ooiii , ooO0o0oo )
 if 78 - 78: iIii1I11I1II1 + ii1ii11IIIiiI + i11iIiiIii
 if 21 - 21: II11iIiIIIiI + iI1IiiIIIiIi % o0oOo0 + O00OOOoOoo0O % o00O0OoO
def o0ooooO0o0O ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 xbmcgui . Dialog ( ) . ok ( 'Force Refresh Started Successfully' , 'Depending on the speed of your device it could take a few minutes for the update to take effect.' )
 return
 if 22 - 22: i1IIi / OoooooooOO . ii1ii11IIIiiI
 if 83 - 83: o0Oo - OoooooooOO + OoooO0Oo0O0 . iI1IiiIIIiIi / oOO00Oo + o0oOo0
def oooOooOO ( ) :
 i1i1IIiIiI11 = 1
 try :
  IiIIi1 ( 'http://google.com' , 5 )
 except :
  try :
   IiIIi1 ( 'http://google.com' , 5 )
  except :
   try :
    IiIIi1 ( 'http://google.com' , 5 )
   except :
    try :
     IiIIi1 ( 'http://google.cn' , 5 )
    except :
     try :
      IiIIi1 ( 'http://google.cn' , 5 )
     except :
      iI111I11I1I1 . ok ( "NO INTERNET CONNECTION" , 'It looks like this device isn\'t connected to the internet. Only some of the maintenance options will work until you fix the connectivity problem.' )
      I11o0000o0Oo ( '' , '' , '' , '[COLOR=orange]NO INTERNET CONNECTION[/COLOR]' )
      i1i1IIiIiI11 = 0
 if i1i1IIiIiI11 == 1 :
  ooo0OO0o00 ( )
  if 78 - 78: i11iIiiIii + oOO00Oo
  if 84 - 84: OoooO0Oo0O0 + o0oOo0 % i11111IIIII / oO0OooOoO + i11iIiiIii
def ooo0OO0o00 ( ) :
 iIIIi1IiI11I1 = 'None'
 OOOOOOO0oo = '0'
 if 20 - 20: O00OOOoOoo0O / oOO00Oo % O00OOOoOoo0O * o0Oo
 if 26 - 26: o00O0OoO . i1Iii1i1I . oOO00Oo
 O0OO0o0OO0OO = open ( O000OO0 , mode = 'r' )
 i11i = O0OO0o0OO0OO . read ( )
 O0OO0o0OO0OO . close ( )
 if 15 - 15: ii1ii11IIIiiI / i1Iii1i1I
 iio00 = re . compile ( 'date="(.+?)"' ) . findall ( i11i )
 OO0oo0o = iio00 [ 0 ] if ( len ( iio00 ) > 0 ) else ''
 i1Ii1 = re . compile ( 'version="(.+?)"' ) . findall ( i11i )
 I1I1IiI1 = i1Ii1 [ 0 ] if ( len ( i1Ii1 ) > 0 ) else ''
 if 89 - 89: i1Iii1i1I / OoooO0Oo0O0 + i11iIiiIii
 o0oO0oo = open ( I1IIiiIiii , mode = 'r' )
 ooOO00Oo = o0oO0oo . read ( )
 o0oO0oo . close ( )
 if 18 - 18: ii1ii11IIIiiI
 I1I1 = re . compile ( 'id="(.+?)"' ) . findall ( ooOO00Oo )
 O0Oo0 = re . compile ( 'name="(.+?)"' ) . findall ( ooOO00Oo )
 OOOOOOO0oo = I1I1 [ 0 ] if ( len ( I1I1 ) > 0 ) else 'None'
 iIIIi1IiI11I1 = O0Oo0 [ 0 ] if ( len ( O0Oo0 ) > 0 ) else ''
 if 58 - 58: OoooooooOO * i11iIiiIii
 if 19 - 19: OoooO0Oo0O0 * O0 - o0oOo0
 if 27 - 27: i1Iii1i1I / oOO00Oo . O00OOOoOoo0O * iI1IiiIIIiIi * Iiii1i1
 if 81 - 81: Iiii1i1
 if 45 - 45: iiIi1i11 * oO0OooOoO * OoooooooOO / OoooooooOO * Iiii1i1
 if 38 - 38: i1Iii1i1I . OoooooooOO
 if 28 - 28: Iiii1i1 * i1IIi . OoooO0Oo0O0
 if 75 - 75: O0 / III1IiiI * o0oOo0 - iiIi1i11 / i1IIi
 if 61 - 61: o00O0OoO
 if 100 - 100: O0 - iIii1I11I1II1 * II11iIiIIIiI
 if 35 - 35: o0oOo0
 if 57 - 57: ii1ii11IIIiiI . II11iIiIIIiI + o0Oo
 if 18 - 18: o0Oo - OoooO0Oo0O0 * o00O0OoO / i11iIiiIii - oOO00Oo % oOO00Oo
 if 31 - 31: o00O0OoO
 if 100 - 100: i11iIiiIii * i11iIiiIii . iIii1I11I1II1 % i1Iii1i1I * OoooO0Oo0O0
 if 17 - 17: iI1IiiIIIiIi * i11111IIIII * i11iIiiIii / OoooO0Oo0O0 / i11iIiiIii
 if 23 - 23: OoooooooOO + i11iIiiIii / II11iIiIIIiI / i1Iii1i1I . i1Iii1i1I * o0Oo
 if 98 - 98: i11111IIIII
 if 23 - 23: o00O0OoO / i1IIi * ii1ii11IIIiiI
 if 51 - 51: iiIi1i11 - OoooooooOO / OoooooooOO % OoooooooOO
 if 85 - 85: ii1ii11IIIiiI . oOO00Oo . o0Oo
 if 75 - 75: iIii1I11I1II1 - iI1IiiIIIiIi % O0 % i11111IIIII
 if 6 - 6: II11iIiIIIiI % III1IiiI * o0oOo0 - i1IIi . O00OOOoOoo0O
 if not os . path . exists ( oo0OooOOo0 ) :
  print "### First login check ###"
  iIiiIIi1i111iI ( iIIIi1IiI11I1 , I1I1IiI1 , OOOOOOO0oo )
  if 20 - 20: II11iIiIIIiI / Iiii1i1 . II11iIiIIIiI
  if 60 - 60: OoooO0Oo0O0 - o0Oo * O0 * II11iIiIIIiI . i1IIi . O00OOOoOoo0O
 else :
  try :
   i1ii1I1ii111I = open ( oo0OooOOo0 , mode = 'r' )
   IIIi1ii1i1 = i1ii1I1ii111I . read ( )
   i1ii1I1ii111I . close ( )
   if 87 - 87: oO0OooOoO / iIii1I11I1II1 % OoooO0Oo0O0
   iII1IiI1I11i = re . compile ( 'd="(.+?)"' ) . findall ( IIIi1ii1i1 )
   Ii1i11I11i = re . compile ( 'l="(.+?)"' ) . findall ( IIIi1ii1i1 )
   oO0oooo = re . compile ( 'm="(.+?)"' ) . findall ( IIIi1ii1i1 )
   oO00o = iII1IiI1I11i [ 0 ] if ( len ( iII1IiI1I11i ) > 0 ) else '0'
   if 59 - 59: II11iIiIIIiI + O0 - o00O0OoO + iiIi1i11
   if oO00o != '0' :
    oO00o = binascii . unhexlify ( oO00o )
    if 97 - 97: o0Oo * oOO00Oo
   O00Ooiii = Ii1i11I11i [ 0 ] if ( len ( Ii1i11I11i ) > 0 ) else ''
   O00Ooiii = binascii . unhexlify ( O00Ooiii )
   O0O0oO0o = oO0oooo [ 0 ] if ( len ( oO0oooo ) > 0 ) else ''
   O0O0oO0o = binascii . unhexlify ( O0O0oO0o )
  except :
   os . remove ( oo0OooOOo0 )
  if int ( oO00o ) + 2000000 > int ( IiIiIIIiI1iII ( ) ) :
   print "### Login successful ###"
   I11o0000o0Oo ( iIIIi1IiI11I1 , I1I1IiI1 , OOOOOOO0oo , O00Ooiii , O0O0oO0o )
  else :
   print "### Checking login ###"
   iIiiIIi1i111iI ( iIIIi1IiI11I1 , I1I1IiI1 , OOOOOOO0oo )
   if 79 - 79: oOO00Oo
   if 40 - 40: OoooO0Oo0O0
def ooO0 ( ) :
 i111 = os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' ) ) )
 if 9 - 9: OoooooooOO / II11iIiIIIiI / oOO00Oo % II11iIiIIIiI
 O00OOo = [
 ( i111 ) ,
 ( O0OoO000O0OO ) ,
 ( os . path . join ( iIii1 , 'cache' ) ) ,
 ( os . path . join ( iIii1 , 'temp' ) ) ,
 ( os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' ) ) ,
 ( os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' ) ) ,
 ( os . path . join ( O0OoO000O0OO , 'script.module.simple.downloader' ) ) ,
 ( os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' , 'script.module.simple.downloader' ) ) ) ) ,
 ( os . path . join ( O0OoO000O0OO , 'plugin.video.itv' , 'Images' ) ) ,
 ( os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' , 'plugin.video.itv' , 'Images' ) ) ) ) ]
 if 77 - 77: O0 - iI1IiiIIIiIi * oO0OooOoO / OoooO0Oo0O0 / iI1IiiIIIiIi - III1IiiI
 for iIIii1iiiIiiI in O00OOo :
  if os . path . exists ( iIIii1iiiIiiI ) and iIIii1iiiIiiI != O0OoO000O0OO and iIIii1iiiIiiI != i111 :
   for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( iIIii1iiiIiiI ) :
    O0OOOo0Oo0 = 0
    O0OOOo0Oo0 += len ( I1iiIi111I )
    if O0OOOo0Oo0 > 0 :
     for iiI1iii in I1iiIi111I :
      try :
       os . unlink ( os . path . join ( IiiI111 , iiI1iii ) )
      except :
       pass
     for I1III111i in OoOOOO :
      try :
       shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
       print "### Successfully cleared " + str ( O0OOOo0Oo0 ) + " files from " + os . path . join ( iIIii1iiiIiiI , I1III111i )
      except :
       print "### Failed to wipe cache in: " + os . path . join ( iIIii1iiiIiiI , I1III111i )
  else :
   for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( iIIii1iiiIiiI ) :
    for I1III111i in OoOOOO :
     if 'Cache' in I1III111i or 'cache' in I1III111i or 'CACHE' in I1III111i :
      try :
       shutil . rmtree ( os . path . join ( IiiI111 , I1III111i ) )
       print "### Successfully wiped " + os . path . join ( iIIii1iiiIiiI , I1III111i )
      except :
       print "### Failed to wipe cache in: " + os . path . join ( iIIii1iiiIiiI , I1III111i )
       if 66 - 66: ii1ii11IIIiiI % II11iIiIIIiI . oO0OooOoO
       if 84 - 84: o0oOo0 * OoooooooOO + O0
 try :
  IiiIiIIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  IiII1Iiii = database . connect ( IiiIiIIi )
  I1o000o00OO00Oo = IiII1Iiii . cursor ( )
  I1o000o00OO00Oo . execute ( "DROP TABLE IF EXISTS rel_list" )
  I1o000o00OO00Oo . execute ( "VACUUM" )
  IiII1Iiii . commit ( )
  I1o000o00OO00Oo . execute ( "DROP TABLE IF EXISTS rel_lib" )
  I1o000o00OO00Oo . execute ( "VACUUM" )
  IiII1Iiii . commit ( )
 except :
  pass
  if 84 - 84: i1IIi . o00O0OoO . i1IIi . II11iIiIIIiI
  if 21 - 21: oO0OooOoO . O0 + II11iIiIIIiI - i11iIiiIii
def IiIiII111i11I ( mode ) :
 if zip == '' :
  iI111I11I1I1 . ok ( 'Please set your backup location before proceeding' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  IiIiiii1I11i1 = i1IiI1I11 . getSetting ( 'zip' )
  if IiIiiii1I11i1 == '' :
   IiIiII111i11I ( mode )
 i1i11IiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
 if not os . path . exists ( i1i11IiII ) :
  os . makedirs ( i1i11IiII )
 iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "ABSOLUTELY CERTAIN?!!!" , 'Are you absolutely certain you want to wipe?' , '' , 'All addons and settings will be completely wiped!' , yeslabel = 'Yes' , nolabel = 'No' )
 if 20 - 20: Iiii1i1 . oO0OooOoO - O0
 if iII1Iii1I11i == 1 :
  if OOOO0OOoO0O0 != "skin.confluence" :
   iI111I11I1I1 . ok ( 'Default Confluence Skin Required' , 'Please switch to the default Confluence skin before performing a wipe.' )
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings,return)" )
   return
  else :
   if 44 - 44: i1IIi
   iII1Iii1I11i = xbmcgui . Dialog ( ) . yesno ( "VERY IMPORTANT" , 'This will completely wipe your install.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'No' , nolabel = 'Yes' )
   if iII1Iii1I11i == 0 :
    if not os . path . exists ( i1i11IiII ) :
     os . makedirs ( i1i11IiII )
    Oo0OOo = i1II11I11ii1 ( heading = "Enter a name for this backup" )
    if ( not Oo0OOo ) : return False , 0
    I1II1IiI1 = urllib . quote_plus ( Oo0OOo )
    iIIiI11iI1Ii1 = xbmc . translatePath ( os . path . join ( i1i11IiII , I1II1IiI1 + '.zip' ) )
    o00oo = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
    O0oO0oo0O = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
    iI1ii11Ii = "Creating full backup of existing build"
    O0OO0OO = "Archiving..."
    Ooo0oO = ""
    IiIiIIiii1I = "Please Wait"
    oOo0OOoooO ( iIii1 , iIIiI11iI1Ii1 , iI1ii11Ii , O0OO0OO , Ooo0oO , IiIiIIiii1I , o00oo , O0oO0oo0O )
   ii1iiI1III1i ( iiI111I1iIiI )
   IiI11 ( )
   ooOoo ( )
   I1iiiii ( )
   O0O0o00o00O00 ( iiI111I1iIiI )
   if os . path . exists ( O000OO0 ) :
    os . remove ( O000OO0 )
   if os . path . exists ( I11iii1Ii ) :
    os . remove ( I11iii1Ii )
   if os . path . exists ( I1IIiiIiii ) :
    os . remove ( I1IIiiIiii )
  if mode != 'CB' :
   O00000OO00OO ( )
  try :
   os . remove ( O000OO0 )
  except :
   print "### Failed to remove startup.xml"
  try :
   os . remove ( I1IIiiIiii )
  except :
   print "### Failed to remove id.xml"
 else :
  return
  if 43 - 43: o0Oo
  if 35 - 35: o0oOo0 + O00OOOoOoo0O * OoooooooOO - oO0OooOoO
def ii1iiI1III1i ( excludefiles ) :
 OOooO0OOoo . create ( "Wiping Existing Content" , '' , 'Please wait...' , '' )
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( iIii1 , topdown = True ) :
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in iiI111I1iIiI ]
  for i1iIIIi1i in I1iiIi111I :
   try :
    OOooO0OOoo . update ( 0 , "Removing [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    os . unlink ( os . path . join ( IiiI111 , i1iIIIi1i ) )
    os . remove ( os . path . join ( IiiI111 , i1iIIIi1i ) )
    os . rmdir ( os . path . join ( IiiI111 , i1iIIIi1i ) )
   except :
    print "Failed to remove file: " + i1iIIIi1i
    if 19 - 19: i1IIi / iI1IiiIIIiIi / O00OOOoOoo0O . o0Oo / iI1IiiIIIiIi % oOO00Oo
    if 39 - 39: o0oOo0 - OoooooooOO
def IiI11 ( ) :
 Oo0oOo = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( oOOoO0 ) if os . path . isdir ( os . path . join ( oOOoO0 , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in Oo0oOo :
   try :
    if i1iIIIi1i not in iiI111I1iIiI :
     OOooO0OOoo . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( oOOoO0 , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 69 - 69: o00O0OoO - oO0OooOoO
  if 66 - 66: o0Oo . o0Oo - O00OOOoOoo0O * OoooooooOO * oO0OooOoO + o0Oo
 for IiiI111 , OoOOOO , I1iiIi111I in os . walk ( oOOoO0 , topdown = True ) :
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in iiI111I1iIiI ]
  for i1iIIIi1i in I1iiIi111I :
   try :
    OOooO0OOoo . update ( 0 , "Removing [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    os . unlink ( os . path . join ( IiiI111 , i1iIIIi1i ) )
    os . remove ( os . path . join ( IiiI111 , i1iIIIi1i ) )
   except :
    print "Failed to remove file: " + i1iIIIi1i
    if 59 - 59: iI1IiiIIIiIi
    if 59 - 59: oO0OooOoO - ii1ii11IIIiiI
def ooOoo ( ) :
 I1iI1IiII = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( II11iiii1Ii ) if os . path . isdir ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in I1iI1IiII :
   try :
    if iIiiiI == 'true' :
     if i1iIIIi1i not in iiI111I1iIiI and not 'repo' in i1iIIIi1i :
      OOooO0OOoo . update ( 0 , "Removing Add-on: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
      shutil . rmtree ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) )
    else :
     if i1iIIIi1i not in iiI111I1iIiI :
      OOooO0OOoo . update ( 0 , "Removing Add-on: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
      shutil . rmtree ( os . path . join ( II11iiii1Ii , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 38 - 38: iiIi1i11 + i11111IIIII * ii1ii11IIIiiI / O00OOOoOoo0O
  if 68 - 68: OoooO0Oo0O0 / o0oOo0 % O0
def I1iiiii ( ) :
 OOOoOooOO0O0OooO0 = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( O0OoO000O0OO ) if os . path . isdir ( os . path . join ( O0OoO000O0OO , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in OOOoOooOO0O0OooO0 :
   try :
    if i1iIIIi1i not in iiI111I1iIiI :
     OOooO0OOoo . update ( 0 , "Removing Add-on Data: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( O0OoO000O0OO , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 4 - 4: i1IIi / ii1ii11IIIiiI / i1IIi - III1IiiI + i11iIiiIii - ii1ii11IIIiiI
  if 71 - 71: Iiii1i1 . OoooooooOO / i11111IIIII + III1IiiI * III1IiiI % iI1IiiIIIiIi
def O0O0o00o00O00 ( excludefiles ) :
 Ii111iI = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( iIii1 ) if os . path . isdir ( os . path . join ( iIii1 , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in Ii111iI :
   try :
    if i1iIIIi1i not in excludefiles :
     OOooO0OOoo . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( iIii1 , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 21 - 21: i1Iii1i1I / iiIi1i11 % i11111IIIII
  if 51 - 51: o00O0OoO + o0oOo0 / o0Oo
def Ii11iO0OO0oOooo0 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Install[/COLOR]' , str ( url ) + '&tags=Install&XBMC=1' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime]2. Settings[/COLOR]' , str ( url ) + '&tags=Settings' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]3. Add-ons[/COLOR]' , str ( url ) , 'tutorial_addon_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Audio' , str ( url ) + '&tags=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Errors' , str ( url ) + '&tags=Errors' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Gaming' , str ( url ) + '&tags=Gaming' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  LiveTV' , str ( url ) + '&tags=LiveTV' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Maintenance' , str ( url ) + '&tags=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Pictures' , str ( url ) + '&tags=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Profiles' , str ( url ) + '&tags=Profiles' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Skins' , str ( url ) + '&tags=Skins' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Video' , str ( url ) + '&tags=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Weather' , str ( url ) + '&tags=Weather' , 'grab_tutorials' , '' , '' , '' , '' )
 if 58 - 58: i11iIiiIii * i1Iii1i1I / iI1IiiIIIiIi - III1IiiI - OoooO0Oo0O0 % oOO00Oo
 if 16 - 16: OoooooooOO
def O0oo00O0ooO ( url ) :
 III1I1I = xbmc . getInfoLabel ( "System.BuildVersion" )
 oOOo0oo0O = float ( III1I1I [ : 4 ] )
 if oOOo0oo0O < 14 :
  iI1I1i11i1 = 'You are running XBMC'
 else :
  iI1I1i11i1 = 'You are running Kodi'
 iI111I11I1I1 = xbmcgui . Dialog ( )
 iI111I11I1I1 . ok ( iI1I1i11i1 , "Your version is: %s" % oOOo0oo0O )
 if 61 - 61: oO0OooOoO
 if 78 - 78: i11iIiiIii + OoooooooOO + i1Iii1i1I - ii1ii11IIIiiI
 if 1 - 1: OoooooooOO - o0oOo0
 if 24 - 24: oO0OooOoO % i1Iii1i1I % iI1IiiIIIiIi % i1Iii1i1I % o00O0OoO . iIii1I11I1II1
 if 48 - 48: III1IiiI . oO0OooOoO * iIii1I11I1II1 / oOO00Oo * iI1IiiIIIiIi * Iiii1i1
 if 11 - 11: iI1IiiIIIiIi / iiIi1i11 * iiIi1i11 * O0
 if 1 - 1: iIii1I11I1II1 % OoooO0Oo0O0 . III1IiiI . i11111IIIII . oOO00Oo / oOO00Oo
 if 52 - 52: O0 * OoooooooOO . Iiii1i1 . iiIi1i11 - i1Iii1i1I % i1Iii1i1I
 if 33 - 33: i11iIiiIii - oOO00Oo . o0Oo - III1IiiI - oO0OooOoO + O0
 if 54 - 54: iIii1I11I1II1 - i11111IIIII - i11111IIIII
 if 18 - 18: i11iIiiIii + iIii1I11I1II1 . i11iIiiIii
 if 63 - 63: i1Iii1i1I - ii1ii11IIIiiI * iiIi1i11
 if 89 - 89: i1Iii1i1I / II11iIiIIIiI
 if 66 - 66: oOO00Oo + O00OOOoOoo0O % OoooooooOO . o00O0OoO
 if 30 - 30: oO0OooOoO - II11iIiIIIiI - i11iIiiIii + O0
 if 93 - 93: i1IIi + Iiii1i1 / ii1ii11IIIiiI - o00O0OoO % II11iIiIIIiI / iI1IiiIIIiIi
 if 1 - 1: II11iIiIIIiI / iI1IiiIIIiIi . i11iIiiIii % iiIi1i11 + oOO00Oo + O0
 if 54 - 54: Iiii1i1 + o0oOo0 % i11111IIIII
 if 83 - 83: oOO00Oo * iIii1I11I1II1
 if 36 - 36: O00OOOoOoo0O + oO0OooOoO - ii1ii11IIIiiI % o0oOo0 * i1IIi
 if 4 - 4: iI1IiiIIIiIi + ii1ii11IIIiiI * OoooO0Oo0O0
 if 13 - 13: O00OOOoOoo0O - i11111IIIII * iIii1I11I1II1 * O0
i1II1iII1 = oO00o0oOoo ( )
i11i1iiiII = None
ooOoOoO0 = None
iI11IiIiiII1 = None
Iii1II1ii = None
I1111I1Ii = None
OOo00OOo = None
O00Oo = None
Ooooo0Oo0oOo = None
oo00IiI1 = None
iIiiiii1i = None
O0oOoo0OoO0O = None
IiIi1I1 = None
IiiiI1i = None
IiIi11iI1IIi = None
IiIIiI = None
i1iIIIi1i = None
I11iii1i = None
ooOO0oO0oo00o = None
i1oO0OO0 = None
iIi1I111Ii1I1 = None
OO0III = None
oO00oO00O0Oo = None
I1II1IiI1 = None
iiiii1II = None
iII111I = None
o00OO0Oo0Oo = None
oOOo0oo0O = None
I111iI = None
OoO0oOO0o0O0O0O0 = None
O00Ooiii = None
I1OooOo0o0Oo0 = None
i11iI1i11I111 = 'maintenance'
if 57 - 57: i1IIi . i1Iii1i1I
try :
 i11i1iiiII = urllib . unquote_plus ( i1II1iII1 [ "addon_id" ] )
except :
 pass
try :
 OO0o0o0oo = urllib . unquote_plus ( i1II1iII1 [ "adult" ] )
except :
 pass
try :
 ooOoOoO0 = urllib . unquote_plus ( i1II1iII1 [ "artpack" ] )
except :
 pass
try :
 iI11IiIiiII1 = urllib . unquote_plus ( i1II1iII1 [ "audioaddons" ] )
except :
 pass
try :
 Iii1II1ii = urllib . unquote_plus ( i1II1iII1 [ "author" ] )
except :
 pass
try :
 I1111I1Ii = urllib . unquote_plus ( i1II1iII1 [ "buildname" ] )
except :
 pass
try :
 OOo00OOo = urllib . unquote_plus ( i1II1iII1 [ "data_path" ] )
except :
 pass
try :
 O00Oo = urllib . unquote_plus ( i1II1iII1 [ "description" ] )
except :
 pass
try :
 Ooooo0Oo0oOo = urllib . unquote_plus ( i1II1iII1 [ "email" ] )
except :
 pass
try :
 oo00IiI1 = urllib . unquote_plus ( i1II1iII1 [ "fanart" ] )
except :
 pass
try :
 iIiiiii1i = urllib . unquote_plus ( i1II1iII1 [ "forum" ] )
except :
 pass
try :
 iIiII1 = urllib . unquote_plus ( i1II1iII1 [ "guisettingslink" ] )
except :
 pass
try :
 O0oOoo0OoO0O = urllib . unquote_plus ( i1II1iII1 [ "iconimage" ] )
except :
 pass
try :
 IiIi1I1 = urllib . unquote_plus ( i1II1iII1 [ "link" ] )
except :
 pass
try :
 IiiiI1i = urllib . unquote_plus ( i1II1iII1 [ "local" ] )
except :
 pass
try :
 IiIi11iI1IIi = urllib . unquote_plus ( i1II1iII1 [ "messages" ] )
except :
 pass
try :
 IiIIiI = str ( i1II1iII1 [ "mode" ] )
except :
 pass
try :
 i1iIIIi1i = urllib . unquote_plus ( i1II1iII1 [ "name" ] )
except :
 pass
try :
 ii1i1Iii = urllib . unquote_plus ( i1II1iII1 [ "pictureaddons" ] )
except :
 pass
try :
 I11iii1i = urllib . unquote_plus ( i1II1iII1 [ "programaddons" ] )
except :
 pass
try :
 ooOO0oO0oo00o = urllib . unquote_plus ( i1II1iII1 [ "provider_name" ] )
except :
 pass
try :
 iIi1I111Ii1I1 = urllib . unquote_plus ( i1II1iII1 [ "repo_link" ] )
except :
 pass
try :
 i1oO0OO0 = urllib . unquote_plus ( i1II1iII1 [ "repo_id" ] )
except :
 pass
try :
 OO0III = urllib . unquote_plus ( i1II1iII1 [ "skins" ] )
except :
 pass
try :
 oO00oO00O0Oo = urllib . unquote_plus ( i1II1iII1 [ "sources" ] )
except :
 pass
try :
 I1II1IiI1 = urllib . unquote_plus ( i1II1iII1 [ "title" ] )
except :
 pass
try :
 iiiii1II = urllib . unquote_plus ( i1II1iII1 [ "updated" ] )
except :
 pass
try :
 iII111I = urllib . unquote_plus ( i1II1iII1 [ "unread" ] )
except :
 pass
try :
 o00OO0Oo0Oo = urllib . unquote_plus ( i1II1iII1 [ "url" ] )
except :
 pass
try :
 oOOo0oo0O = urllib . unquote_plus ( i1II1iII1 [ "version" ] )
except :
 pass
try :
 I111iI = urllib . unquote_plus ( i1II1iII1 [ "video" ] )
except :
 pass
try :
 OoO0oOO0o0O0O0O0 = urllib . unquote_plus ( i1II1iII1 [ "videoaddons" ] )
except :
 pass
try :
 O00Ooiii = urllib . unquote_plus ( i1II1iII1 [ "welcometext" ] )
except :
 pass
try :
 I1OooOo0o0Oo0 = urllib . unquote_plus ( i1II1iII1 [ "zip_link" ] )
except :
 pass
 if 50 - 50: III1IiiI
if not os . path . exists ( Oo0oOOo ) :
 os . makedirs ( Oo0oOOo )
 if 55 - 55: OoooO0Oo0O0
if not os . path . exists ( O000OO0 ) :
 O0OO0o0OO0OO = open ( O000OO0 , mode = 'w+' )
 O0OO0o0OO0OO . write ( 'date="01011001"\nversion="0.0"' )
 O0OO0o0OO0OO . close ( )
 if 55 - 55: II11iIiIIIiI % iI1IiiIIIiIi . iIii1I11I1II1 * Iiii1i1
if not os . path . exists ( I1IIiiIiii ) :
 O0OO0o0OO0OO = open ( I1IIiiIiii , mode = 'w+' )
 O0OO0o0OO0OO . write ( 'id="None"\nname="None"' )
 O0OO0o0OO0OO . close ( )
 if 33 - 33: O0 - o0Oo / OoooO0Oo0O0 / ii1ii11IIIiiI + i1Iii1i1I - III1IiiI
if os . path . exists ( O000oo0O ) :
 try :
  shutil . rmtree ( O000oo0O )
 except :
  pass
  if 27 - 27: Iiii1i1 + o0oOo0 - Iiii1i1 % i11iIiiIii * II11iIiIIIiI * oOO00Oo
if os . path . exists ( OOOOi11i1 ) :
 try :
  shutil . rmtree ( OOOOi11i1 )
 except :
  pass
  if 88 - 88: iiIi1i11
if os . path . exists ( IIIii1II1II ) :
 try :
  shutil . rmtree ( IIIii1II1II )
 except :
  pass
  if 25 - 25: ii1ii11IIIiiI + oOO00Oo . o0oOo0 - iI1IiiIIIiIi . III1IiiI * iI1IiiIIIiIi
o0Ooii = binascii . unhexlify ( '6164646f6e2e786d6c' )
iI1iIIiiii = xbmc . translatePath ( os . path . join ( II11iiii1Ii , o0OO00 , o0Ooii ) )
ooOOOo = open ( iI1iIIiiii , mode = 'r' )
i11i = file . read ( ooOOOo )
file . close ( ooOOOo )
ooOO = re . compile ( '<ref>(.+?)</ref>' ) . findall ( i11i )
oO0Ooo = ooOO [ 0 ] if ( len ( ooOO ) > 0 ) else ''
iiiiIIiiII1Iii1 = hashlib . md5 ( open ( o00OO00OoO , 'rb' ) . read ( ) ) . hexdigest ( )
if oO0Ooo != iiiiIIiiII1Iii1 :
 OoO = open ( O00o0OO , mode = 'r' )
 i11i = file . read ( OoO )
 file . close ( OoO )
 o0oooOO00 = open ( o00OO00OoO , mode = 'w+' )
 o0oooOO00 . write ( i11i )
 o0oooOO00 . close ( )
 if 93 - 93: O00OOOoOoo0O % iI1IiiIIIiIi / iI1IiiIIIiIi - o0oOo0 - i11111IIIII % o0oOo0
I1I1iiii1IiI1i ( )
if IiIIiI == None : ooo0OO0o00 ( )
elif IiIIiI == 'ASCII_Check' : I11Oo0oO00 ( )
elif IiIIiI == 'addon_final_menu' : ooo0O0o00O ( o00OO0Oo0Oo )
elif IiIIiI == 'addon_categories' : i11II1I11I1 ( o00OO0Oo0Oo )
elif IiIIiI == 'addon_countries' : i11III1111iIi ( o00OO0Oo0Oo )
elif IiIIiI == 'addon_genres' : OOOooo0OooOoO ( o00OO0Oo0Oo )
elif IiIIiI == 'addon_install' : I1iiioOO0OO0O ( i1iIIIi1i , I1OooOo0o0Oo0 , iIi1I111Ii1I1 , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iIiiiii1i , OOo00OOo )
elif IiIIiI == 'addon_install_badzip' : I1i1I ( i1iIIIi1i , I1OooOo0o0Oo0 , iIi1I111Ii1I1 , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iIiiiii1i , OOo00OOo )
elif IiIIiI == 'addon_install_na' : o00ooo ( i1iIIIi1i , I1OooOo0o0Oo0 , iIi1I111Ii1I1 , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iIiiiii1i , OOo00OOo )
elif IiIIiI == 'addon_install_zero' : i1I11iIII1i1I ( i1iIIIi1i , I1OooOo0o0Oo0 , iIi1I111Ii1I1 , i1oO0OO0 , i11i1iiiII , ooOO0oO0oo00o , iIiiiii1i , OOo00OOo )
elif IiIIiI == 'addon_loop' : O0o0o0 ( )
elif IiIIiI == 'addon_removal_menu' : iIi1I1 ( )
elif IiIIiI == 'addonmenu' : Oo0Oo0oOooOoOo ( o00OO0Oo0Oo )
elif IiIIiI == 'addon_settings' : oO000o ( )
elif IiIIiI == 'advanced_tools' : IIiI1iIiii ( )
elif IiIIiI == 'backup' : BACKUP ( )
elif IiIIiI == 'backup_option' : OOOOOo ( )
elif IiIIiI == 'backup_restore' : oO0OOo00o0O0O ( )
elif IiIIiI == 'browse_repos' : IIIIiIi11iiIi ( )
elif IiIIiI == 'cb_test_loop' : O0o0o0 ( )
elif IiIIiI == 'CB_Menu' : i1I ( o00OO0Oo0Oo )
elif IiIIiI == 'check_storage' : checkPath . check ( i11iI1i11I111 )
elif IiIIiI == 'check_updates' : O0oOo00o ( )
elif IiIIiI == 'clear_cache' : ooo0o0 ( )
elif IiIIiI == 'create_keyword' : oooooO00OOO ( o00OO0Oo0Oo )
elif IiIIiI == 'community' : O0000oO0o00 ( o00OO0Oo0Oo )
elif IiIIiI == 'community_backup' : OOO00o0 ( )
elif IiIIiI == 'community_backup_2' : OOoO0o ( )
elif IiIIiI == 'community_menu' : iiII1i ( o00OO0Oo0Oo , I111iI )
elif IiIIiI == 'countries' : ii1IIii ( o00OO0Oo0Oo )
elif IiIIiI == 'description' : iI1I1ii11IIi1 ( i1iIIIi1i , o00OO0Oo0Oo , I1111I1Ii , Iii1II1ii , oOOo0oo0O , O00Oo , iiiii1II , OO0III , OoO0oOO0o0O0O0O0 , iI11IiIiiII1 , I11iii1i , ii1i1Iii , oO00oO00O0Oo , OO0o0o0oo )
elif IiIIiI == 'delete_path' : I1I1ii1111 ( o00OO0Oo0Oo )
elif IiIIiI == 'delete_profile' : II111Ii11II ( o00OO0Oo0Oo )
elif IiIIiI == 'fix_special' : ii1OO0 ( o00OO0Oo0Oo )
elif IiIIiI == 'full_backup' : iii ( )
elif IiIIiI == 'full_clean' : i1o0 ( )
elif IiIIiI == 'genres' : Iii1Iii ( o00OO0Oo0Oo )
elif IiIIiI == 'gotham' : I1iiII ( )
elif IiIIiI == 'grab_addons' : iIIIi ( o00OO0Oo0Oo )
elif IiIIiI == 'grab_builds' : IIiI ( o00OO0Oo0Oo )
elif IiIIiI == 'grab_hardware' : ii11 ( o00OO0Oo0Oo )
elif IiIIiI == 'grab_news' : OO0oOoo ( o00OO0Oo0Oo )
elif IiIIiI == 'grab_tutorials' : iI1I1 ( o00OO0Oo0Oo )
elif IiIIiI == 'guisettingsfix' : OO00O00o0O ( o00OO0Oo0Oo , IiiiI1i )
elif IiIIiI == 'hardware_filter_menu' : Ii1i1ii ( o00OO0Oo0Oo )
elif IiIIiI == 'hardware_final_menu' : OO0iii111 ( o00OO0Oo0Oo )
elif IiIIiI == 'hardware_root_menu' : iI11ii ( )
elif IiIIiI == 'helix' : oo000oiIIIII ( )
elif IiIIiI == 'hide_passwords' : I1O0 ( )
elif IiIIiI == 'ipcheck' : Oooooo0O ( )
elif IiIIiI == 'install_content' : iioOo00O0o ( o00OO0Oo0Oo )
elif IiIIiI == 'install_from_zip' : OOo0O0 ( )
elif IiIIiI == 'instructions' : oOi1II111i1IIii ( )
elif IiIIiI == 'instructions_1' : I111I ( )
elif IiIIiI == 'instructions_2' : oo00o0OO ( )
elif IiIIiI == 'instructions_3' : OoOOoo0o00O0oO ( )
elif IiIIiI == 'instructions_4' : IiiiiI ( )
elif IiIIiI == 'instructions_5' : OOO0O ( )
elif IiIIiI == 'instructions_6' : Instructions_6 ( )
elif IiIIiI == 'keywords' : O0OOOO0o0O ( o00OO0Oo0Oo )
elif IiIIiI == 'kill_xbmc' : O00000OO00OO ( )
elif IiIIiI == 'kodi_settings' : IiOoo0o0OO0 ( )
elif IiIIiI == 'local_backup' : o0O000O00o ( )
elif IiIIiI == 'LocalGUIDialog' : O0OOOo0o0O0 ( )
elif IiIIiI == 'log' : oo0O0OO0Oooo ( )
elif IiIIiI == 'login_check' : oooOooOO ( )
elif IiIIiI == 'manual_search' : i1111II1iIII ( o00OO0Oo0Oo )
elif IiIIiI == 'nan_menu' : I1IiiI11 ( )
elif IiIIiI == 'news_root_menu' : Ii1111iI1i1 ( o00OO0Oo0Oo )
elif IiIIiI == 'news_menu' : oo0OOOoO ( o00OO0Oo0Oo )
elif IiIIiI == 'open_system_info' : ooOoo0O0o0OO0 ( )
elif IiIIiI == 'open_filemanager' : iiiiIIii1I ( )
elif IiIIiI == 'openelec_backup' : oooo00o0O0 ( )
elif IiIIiI == 'openelec_settings' : O0O0oOo0o0o0 ( )
elif IiIIiI == 'play_video' : yt . PlayVideo ( o00OO0Oo0Oo )
elif IiIIiI == 'platform_menu' : o000 ( o00OO0Oo0Oo )
elif IiIIiI == 'pop' : oo000o ( o00OO0Oo0Oo )
elif IiIIiI == 'register' : oOO00o0 ( )
elif IiIIiI == 'remove_addon_data' : IIIiI1i ( )
elif IiIIiI == 'remove_addons' : OO ( o00OO0Oo0Oo )
elif IiIIiI == 'remove_build' : o0O0ooooO0 ( )
elif IiIIiI == 'remove_crash_logs' : OooOoOo ( )
elif IiIIiI == 'remove_packages' : O0OiiiIIiIi1ii11 ( )
elif IiIIiI == 'remove_textures' : ii111iiIii ( )
elif IiIIiI == 'restore' : RESTORE ( )
elif IiIIiI == 'restore_backup' : o0OOOOoo ( i1iIIIi1i , o00OO0Oo0Oo , O00Oo )
elif IiIIiI == 'restore_community' : IIiii1I ( i1iIIIi1i , o00OO0Oo0Oo , I111iI , O00Oo , OO0III , iIiII1 , ooOoOoO0 )
elif IiIIiI == 'restore_local_CB' : OO00O0O ( o00OO0Oo0Oo )
elif IiIIiI == 'restore_local_gui' : I1I1i1 ( )
elif IiIIiI == 'restore_local_OE' : o0O00ooo0oO0o ( )
elif IiIIiI == 'restore_openelec' : Iii1I1i1i1 ( i1iIIIi1i , o00OO0Oo0Oo , I111iI )
elif IiIIiI == 'restore_option' : OO0OO0 ( )
elif IiIIiI == 'restore_zip' : o00ooOOo0ooO0 ( o00OO0Oo0Oo )
elif IiIIiI == 'run_addon' : OO00O0OoooO ( o00OO0Oo0Oo )
elif IiIIiI == 'runtest' : speedtest . runtest ( o00OO0Oo0Oo )
elif IiIIiI == 'search_addons' : o0Oo0oo0o0o0 ( o00OO0Oo0Oo )
elif IiIIiI == 'search_builds' : iiIIi1Ii1 ( o00OO0Oo0Oo )
elif IiIIiI == 'Search_Private' : Private_Search ( o00OO0Oo0Oo )
elif IiIIiI == 'showinfo' : OO0OOOOOOoo ( o00OO0Oo0Oo )
elif IiIIiI == 'showinfo2' : OOOO0000 ( o00OO0Oo0Oo )
elif IiIIiI == 'SortBy' : iii11 ( BuildURL , type )
elif IiIIiI == 'speed_instructions' : ii1i1iIiIIi ( )
elif IiIIiI == 'speedtest_menu' : ooOO0oo0o0o ( )
elif IiIIiI == 'switch_profile_menu' : oo0Oooo0O ( o00OO0Oo0Oo )
elif IiIIiI == 'switch_profile' : O0oOoOOO000 ( o00OO0Oo0Oo )
elif IiIIiI == 'text_guide' : I1iOoO00O ( o00OO0Oo0Oo )
elif IiIIiI == 'tools' : Oo000O00o0O ( )
elif IiIIiI == 'tutorial_final_menu' : Oo0OOOOOOOo0O ( o00OO0Oo0Oo )
elif IiIIiI == 'tutorial_addon_menu' : O0oOoO0o0oO ( o00OO0Oo0Oo )
elif IiIIiI == 'tutorial_root_menu' : I1111 ( )
elif IiIIiI == 'unhide_passwords' : i1II ( )
elif IiIIiI == 'update' : o0ooooO0o0O ( )
elif IiIIiI == 'update_community' : ooO00O000o0 ( i1iIIIi1i , o00OO0Oo0Oo , I111iI , O00Oo , OO0III , iIiII1 , ooOoOoO0 )
elif IiIIiI == 'uploadlog' : Iii1111Ii1iI ( )
elif IiIIiI == 'user_info' : Oo0OO0o0oOO0 ( )
elif IiIIiI == 'xbmc_menu' : Ii11iO0OO0oOooo0 ( o00OO0Oo0Oo )
elif IiIIiI == 'xbmcversion' : O0oo00O0ooO ( o00OO0Oo0Oo )
elif IiIIiI == 'wipe_xbmc' : IiIiII111i11I ( IiIIiI )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
