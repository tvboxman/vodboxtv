import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon
import os , sys , time , xbmcvfs , glob , shutil , datetime , zipfile , ntpath
import subprocess , threading
import yt , downloader , checkPath
import binascii
import hashlib
import speedtest
import extract
try :
 from sqlite3 import dbapi2 as database
except :
 from pysqlite2 import dbapi2 as database
 if 64 - 64: i11iIiiIii
from addon . common . addon import Addon
from addon . common . net import Net
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
######################################################
o0OO00 = 'plugin.program.totalinstaller'
oo = 'The Community Portal'
if 27 - 27: oO0OooOoO * o0Oo
i1IiI1I11 = xbmcaddon . Addon ( id = o0OO00 )
zip = i1IiI1I11 . getSetting ( 'zip' )
IIiIiII11i = i1IiI1I11 . getSetting ( 'localcopy' )
o0oOOo0O0Ooo = i1IiI1I11 . getSetting ( 'private' )
I1ii11iIi11i = i1IiI1I11 . getSetting ( 'reseller' )
I1IiI = i1IiI1I11 . getSetting ( 'openelec' )
o0OOO = i1IiI1I11 . getSetting ( 'favourites' )
iIiiiI = i1IiI1I11 . getSetting ( 'sources' )
Iii1ii1II11i = i1IiI1I11 . getSetting ( 'repositories' )
iI111iI = i1IiI1I11 . getSetting ( 'enablekeyword' )
IiII = i1IiI1I11 . getSetting ( 'keywordpath' )
iI1Ii11111iIi = i1IiI1I11 . getSetting ( 'keywordname' )
i1i1II = i1IiI1I11 . getSetting ( 'mastercopy' )
O0oo0OO0 = i1IiI1I11 . getSetting ( 'username' ) . replace ( ' ' , '%20' )
I1i1iiI1 = i1IiI1I11 . getSetting ( 'password' )
iiIIIII1i1iI = i1IiI1I11 . getSetting ( 'versionoverride' )
o0oO0 = i1IiI1I11 . getSetting ( 'debug' )
oo00 = i1IiI1I11 . getSetting ( 'login' )
o00 = i1IiI1I11 . getSetting ( 'addonportal' )
Oo0oO0ooo = i1IiI1I11 . getSetting ( 'maintenance' )
o0oOoO00o = i1IiI1I11 . getSetting ( 'hardwareportal' )
i1 = i1IiI1I11 . getSetting ( 'maintenance' )
oOOoo00O0O = i1IiI1I11 . getSetting ( 'latestnews' )
i1111 = i1IiI1I11 . getSetting ( 'tutorialportal' )
i11 = i1IiI1I11 . getSetting ( 'startupvideo' )
I11 = i1IiI1I11 . getSetting ( 'startupvideopath' )
Oo0o0000o0o0 = i1IiI1I11 . getSetting ( 'wizard' )
oOo0oooo00o = i1IiI1I11 . getSetting ( 'wizardurl1' )
oO0o0o0ooO0oO = i1IiI1I11 . getSetting ( 'wizardname1' )
oo0o0O00 = i1IiI1I11 . getSetting ( 'wizardurl2' )
oO = i1IiI1I11 . getSetting ( 'wizardname2' )
i1iiIIiiI111 = i1IiI1I11 . getSetting ( 'wizardurl3' )
oooOOOOO = i1IiI1I11 . getSetting ( 'wizardname3' )
i1iiIII111ii = i1IiI1I11 . getSetting ( 'wizardurl4' )
i1iIIi1 = i1IiI1I11 . getSetting ( 'wizardname4' )
ii11iIi1I = i1IiI1I11 . getSetting ( 'wizardurl5' )
iI111I11I1I1 = i1IiI1I11 . getSetting ( 'wizardname5' )
OOooO0OOoo = xbmcgui . Dialog ( )
iIii1 = xbmcgui . DialogProgress ( )
oOOoO0 = xbmc . translatePath ( 'special://home/' )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
iiI1IiI = os . path . join ( O0OoO000O0OO , 'addon_data' )
II = os . path . join ( oOOoO0 , 'CP_Profiles' )
ooOoOoo0O = os . path . join ( II , 'Master' )
OooO0 = os . path . join ( O0OoO000O0OO , 'Database' )
II11iiii1Ii = os . path . join ( O0OoO000O0OO , 'Thumbnails' )
OO0o = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
Ooo = xbmc . translatePath ( os . path . join ( 'special://xbmc' , 'addons' ) )
O0o0Oo = os . path . join ( OO0o , o0OO00 , 'default.py' )
Oo00OOOOO = os . path . join ( OO0o , o0OO00 , 'fanart.jpg' )
O0O = os . path . join ( OO0o , o0OO00 , 'resources' , 'addonxml' )
O00o0OO = os . path . join ( OO0o , o0OO00 , 'resources' , 'backup' )
I11i1 = os . path . join ( O0OoO000O0OO , 'guisettings.xml' )
iIi1ii1I1 = os . path . join ( O0OoO000O0OO , 'guifix.xml' )
o0 = 'http://www.noobsandnerds.com/TI/artwork/'
I11II1i = os . path . join ( OO0o , o0OO00 , 'icon_menu.png' )
IIIII = os . path . join ( O0OoO000O0OO , 'favourites.xml' )
ooooooO0oo = os . path . join ( O0OoO000O0OO , 'sources.xml' )
IIiiiiiiIi1I1 = os . path . join ( O0OoO000O0OO , 'advancedsettings.xml' )
I1IIIii = os . path . join ( O0OoO000O0OO , 'profiles.xml' )
oOoOooOo0o0 = os . path . join ( O0OoO000O0OO , 'RssFeeds.xml' )
OOOO = os . path . join ( O0OoO000O0OO , 'keymaps' , 'keyboard.xml' )
OOO00 = xbmc . translatePath ( os . path . join ( zip ) )
iiiiiIIii = os . path . join ( OOO00 , 'Community_Builds' , '' )
O000OO0 = os . path . join ( iiI1IiI , o0OO00 , 'startup.xml' )
I11iii1Ii = os . path . join ( iiI1IiI , o0OO00 , 'temp.xml' )
I1IIiiIiii = os . path . join ( iiI1IiI , o0OO00 , 'id.xml' )
O000oo0O = os . path . join ( OO0o , 'repository.totalinstaller' )
OOOOi11i1 = os . path . join ( OO0o , 'repository.totalrevolution' )
IIIii1II1II = os . path . join ( OO0o , 'plugin.program.totalrevolution' )
i1I1iI = os . path . join ( iiI1IiI , o0OO00 , 'idtemp.xml' )
oo0OooOOo0 = os . path . join ( iiI1IiI , o0OO00 , 'temp' )
o0O = os . path . join ( iiI1IiI , o0OO00 , 'ascii_results' )
O00oO = os . path . join ( iiI1IiI , o0OO00 , 'ascii_results1' )
I11i1I1I = os . path . join ( iiI1IiI , o0OO00 , 'ascii_results2' )
oO0Oo = os . path . join ( iiI1IiI , o0OO00 , 'guizip' )
oOOoo0Oo = os . path . join ( OO0o , o0OO00 , 'resources/' )
o00OO00OoO = os . path . join ( OO0o , o0OO00 , 'default.py' )
OOOO0OOoO0O0 = xbmc . getSkinDir ( )
O0Oo000ooO00 = xbmc . translatePath ( 'special://logpath/' )
oO0 = '/storage/backup'
Ii1iIiII1ii1 = '/storage/.restore/'
ooOooo000oOO = Net ( )
Oo0oOOo = os . path . join ( iiI1IiI , o0OO00 )
Oo0OoO00oOO0o = os . path . join ( Oo0oOOo , 'guinew.xml' )
OOO00O = os . path . join ( Oo0oOOo , 'guitemp' )
OOoOO0oo0ooO = os . path . join ( iiI1IiI , o0OO00 , 'scripts' )
O0o0O00Oo0o0 = os . path . join ( OOO00 , 'Database' )
O00O0oOO00O00 = os . path . join ( OO0o , 'packages' )
i1Oo00 = os . path . join ( O0OoO000O0OO , 'addontemp' )
i1i = os . path . join ( O0OoO000O0OO , '.cbcfg' )
iiI111I1iIiI = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' ]
IIIi1I1IIii1II = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' , 'guisettings.xml' , 'CP_Profiles' , 'temp' ]
O0ii1ii1ii = 0.0
oooooOoo0ooo = 0.0
I1I1IiI1 = '0'
III1iII1I1ii = [ '/storage/.kodi' , '/storage/.cache' , '/storage/.config' , '/storage/.ssh' ]
oOOo0 = '1889903'
if 54 - 54: II11iIiIIIiI - ii1ii11IIIiiI - O00OOOoOoo0O
def O000OOo00oo ( ) :
 iIii1 . create ( 'Checking dependencies' , '' , 'Please Wait...' )
 oo0OOo = [ ]
 if 64 - 64: oOO00Oo
 for i1iIIIi1i in os . listdir ( OO0o ) :
  if i1iIIIi1i != 'packages' :
   try :
    iI1iIIiiii = os . path . join ( OO0o , i1iIIIi1i , 'addon.xml' )
    i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
    OOooo0O00o = i1iI11i1ii11 . read ( )
    i1iI11i1ii11 . close ( )
    oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
    if 51 - 51: OoooO0Oo0O0 + III1IiiI % iiIi1i11 / o00O0OoO - iI1IiiIIIiIi . i1Iii1i1I
    for OOoO00 in oOOoOooOo :
     if 40 - 40: i11111IIIII * Iiii1i1 / o0oOo0 * iI1IiiIIIiIi
     if not 'xbmc.python' in OOoO00 and not OOoO00 in oo0OOo :
      oo0OOo . append ( OOoO00 )
      if debug == 'true' :
       print 'Script Requires --- ' + OOoO00
   except :
    pass
    if 81 - 81: ii1ii11IIIiiI
 return oo0OOo
 if 42 - 42: ii1ii11IIIiiI / o00O0OoO / oOO00Oo + i1Iii1i1I / O00OOOoOoo0O
 if 84 - 84: o0oOo0 * oO0OooOoO + II11iIiIIIiI
class O0ooO0Oo00o ( xbmcgui . WindowXMLDialog ) :
 if 77 - 77: iIii1I11I1II1 * ii1ii11IIIiiI
 def __init__ ( self , * args , ** kwargs ) :
  self . shut = kwargs [ 'close_time' ]
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  xbmc . executebuiltin ( "Skin.SetBool(AnimeWindowXMLDialogClose)" )
  if 95 - 95: o0Oo + i11iIiiIii
 def onFocus ( self , controlID ) :
  pass
  if 6 - 6: o0oOo0 / i11iIiiIii + i1Iii1i1I * III1IiiI
 def onClick ( self , controlID ) :
  if controlID == 12 :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 80 - 80: oO0OooOoO
 def onAction ( self , action ) :
  if action in [ 5 , 6 , 7 , 9 , 10 , 92 , 117 ] or action . getButtonCode ( ) in [ 275 , 257 , 261 ] :
   xbmc . Player ( ) . stop ( )
   self . _close_dialog ( )
   if 83 - 83: o00O0OoO . i11iIiiIii + oO0OooOoO . oOO00Oo * o00O0OoO
 def _close_dialog ( self ) :
  xbmc . executebuiltin ( "Skin.Reset(AnimeWindowXMLDialogClose)" )
  time . sleep ( .4 )
  self . close ( )
  if 53 - 53: oO0OooOoO
  if 31 - 31: ii1ii11IIIiiI
def o0OIiII ( name , url , mode , iconimage , fanart , video , description , skins , guisettingslink , artpack ) :
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 ii1iII1II += "&skins=" + urllib . quote_plus ( skins )
 ii1iII1II += "&guisettingslink=" + urllib . quote_plus ( guisettingslink )
 ii1iII1II += "&artpack=" + urllib . quote_plus ( artpack )
 if 48 - 48: oO0OooOoO * iI1IiiIIIiIi . o00O0OoO + III1IiiI
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 94 - 94: oOO00Oo * iI1IiiIIIiIi / II11iIiIIIiI / iI1IiiIIIiIi
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 if 87 - 87: II11iIiIIIiI . i11111IIIII
 if ( mode == None ) or ( mode == 'restore_option' ) or ( mode == 'backup_option' ) or ( mode == 'cb_root_menu' ) or ( mode == 'genres' ) or ( mode == 'grab_builds' ) or ( mode == 'community_menu' ) or ( mode == 'instructions' ) or ( mode == 'countries' ) or ( mode == 'update_build' ) or ( url == None ) or ( len ( url ) < 1 ) :
  if 75 - 75: o0oOo0 + O00OOOoOoo0O + oOO00Oo * o00O0OoO % III1IiiI . i1Iii1i1I
  OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = True )
  if 55 - 55: iiIi1i11 . o0Oo
 else :
  OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
  if 61 - 61: II11iIiIIIiI % i11111IIIII . II11iIiIIIiI
 return OoO0o
 if 100 - 100: Iiii1i1 * O0
 if 64 - 64: iiIi1i11 % iIii1I11I1II1 * III1IiiI
def o0iI11I1II ( handle , url , listitem , isFolder ) :
 xbmcplugin . addDirectoryItem ( handle , url , listitem , isFolder )
 if 40 - 40: iIii1I11I1II1 / O00OOOoOoo0O % OoooO0Oo0O0 + oO0OooOoO
 if 27 - 27: oO0OooOoO * O00OOOoOoo0O * iIii1I11I1II1
def oOo00oOoO000 ( name , url , mode , iconimage , fanart , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 if 93 - 93: oOO00Oo % i1IIi . iI1IiiIIIiIi . i11iIiiIii
 iconimage = I11II1i
 if 56 - 56: OoooO0Oo0O0 % O0 - o0Oo
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&author=" + urllib . quote_plus ( author )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 ii1iII1II += "&version=" + urllib . quote_plus ( version )
 ii1iII1II += "&buildname=" + urllib . quote_plus ( buildname )
 ii1iII1II += "&updated=" + urllib . quote_plus ( updated )
 ii1iII1II += "&skins=" + urllib . quote_plus ( skins )
 ii1iII1II += "&videoaddons=" + urllib . quote_plus ( videoaddons )
 ii1iII1II += "&audioaddons=" + urllib . quote_plus ( audioaddons )
 ii1iII1II += "&buildname=" + urllib . quote_plus ( buildname )
 ii1iII1II += "&programaddons=" + urllib . quote_plus ( programaddons )
 ii1iII1II += "&pictureaddons=" + urllib . quote_plus ( pictureaddons )
 ii1iII1II += "&sources=" + urllib . quote_plus ( sources )
 ii1iII1II += "&adult=" + urllib . quote_plus ( adult )
 if 100 - 100: iI1IiiIIIiIi - O0 % III1IiiI * iiIi1i11 + o0Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 88 - 88: OoooooooOO - ii1ii11IIIiiI * O0 * OoooooooOO . OoooooooOO
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , I111iI )
 if 56 - 56: o0Oo
 OoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
 if 54 - 54: Iiii1i1 / iiIi1i11 . III1IiiI % i1Iii1i1I
 return OoO0o
 if 57 - 57: i11iIiiIii . OoooO0Oo0O0 - iI1IiiIIIiIi - III1IiiI + O00OOOoOoo0O
def oO00oooOOoOo0 ( title , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' , zip_link = '' , repo_link = '' , repo_id = '' , addon_id = '' , provider_name = '' , forum = '' , data_path = '' ) :
 if len ( iconimage ) > 0 :
  if 74 - 74: iIii1I11I1II1 * OoooO0Oo0O0 + O00OOOoOoo0O / i1IIi / oO0OooOoO . II11iIiIIIiI
  iconimage = iconimage
 else :
  iconimage = 'DefaultFolder.png'
  if 62 - 62: OoooooooOO * o0Oo
 if fanart == '' :
  fanart = Oo00OOOOO
  if 58 - 58: O00OOOoOoo0O % oOO00Oo
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&zip_link=" + urllib . quote_plus ( zip_link )
 ii1iII1II += "&repo_link=" + urllib . quote_plus ( repo_link )
 ii1iII1II += "&data_path=" + urllib . quote_plus ( data_path )
 ii1iII1II += "&provider_name=" + str ( provider_name )
 ii1iII1II += "&forum=" + str ( forum )
 ii1iII1II += "&repo_id=" + str ( repo_id )
 ii1iII1II += "&addon_id=" + str ( addon_id )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 if 50 - 50: Iiii1i1 . oOO00Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( title , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 97 - 97: O0 + O00OOOoOoo0O
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 if 89 - 89: oOO00Oo + ii1ii11IIIiiI * o00O0OoO * iI1IiiIIIiIi
 o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
 if 37 - 37: OoooooooOO - O0 - oOO00Oo
 if 77 - 77: iiIi1i11 * iIii1I11I1II1
def oO00oOOoooO ( type , name , url , mode , iconimage = '' , fanart = '' , video = '' , description = '' ) :
 if not 'addon' in type :
  if 46 - 46: o0Oo - OoooooooOO - o00O0OoO * oO0OooOoO
  if len ( iconimage ) > 0 :
   iconimage = o0 + iconimage
   if 34 - 34: o00O0OoO - i1Iii1i1I / iiIi1i11 + OoooO0Oo0O0 * iI1IiiIIIiIi
  else :
   iconimage = I11II1i
   if 73 - 73: O00OOOoOoo0O . iI1IiiIIIiIi * OoooO0Oo0O0 % OoooO0Oo0O0 % OoooooooOO
 if 'addon' in type :
  if 63 - 63: iIii1I11I1II1 * i11iIiiIii % iIii1I11I1II1 * i11iIiiIii
  if len ( iconimage ) > 0 :
   iconimage = iconimage
  else :
   iconimage = 'DefaultFolder.png'
   if 32 - 32: iiIi1i11
   if 42 - 42: i11111IIIII * O0 % i1IIi . iiIi1i11 / oOO00Oo
   if 32 - 32: o0Oo * II11iIiIIIiI
 if fanart == '' :
  fanart = Oo00OOOOO
  if 78 - 78: iiIi1i11 - OoooooooOO - OoooO0Oo0O0 / o0oOo0 / oO0OooOoO
 ii1iII1II = sys . argv [ 0 ]
 ii1iII1II += "?url=" + urllib . quote_plus ( url )
 ii1iII1II += "&mode=" + str ( mode )
 ii1iII1II += "&name=" + urllib . quote_plus ( name )
 ii1iII1II += "&iconimage=" + urllib . quote_plus ( iconimage )
 ii1iII1II += "&fanart=" + urllib . quote_plus ( fanart )
 ii1iII1II += "&video=" + urllib . quote_plus ( video )
 ii1iII1II += "&description=" + urllib . quote_plus ( description )
 if 29 - 29: o0Oo % o0Oo
 OoO0o = True
 oO0o0Ooooo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if 94 - 94: iIii1I11I1II1 / II11iIiIIIiI % i1Iii1i1I * i1Iii1i1I * oO0OooOoO
 oO0o0Ooooo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 oO0o0Ooooo . setProperty ( "Fanart_Image" , fanart )
 oO0o0Ooooo . setProperty ( "Build.Video" , video )
 if 29 - 29: ii1ii11IIIiiI + O00OOOoOoo0O / oOO00Oo / iiIi1i11 * iIii1I11I1II1
 if 'folder' in type :
  OoO0o = o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = True )
  if 62 - 62: iiIi1i11 / III1IiiI - ii1ii11IIIiiI . o00O0OoO
 else :
  OoO0o = o0iI11I1II ( handle = int ( sys . argv [ 1 ] ) , url = ii1iII1II , listitem = oO0o0Ooooo , isFolder = False )
  if 11 - 11: OoooO0Oo0O0 . ii1ii11IIIiiI * i11111IIIII * OoooooooOO + o0oOo0
 return OoO0o
 if 33 - 33: O0 * oOO00Oo - Iiii1i1 % Iiii1i1
 if 18 - 18: Iiii1i1 / II11iIiIIIiI * Iiii1i1 + Iiii1i1 * i11iIiiIii * OoooO0Oo0O0
def I1II1 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Audio' , url + '&typex=audio' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Image (Picture)' , url + '&typex=image' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Program' , url + '&typex=program' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][PLUGIN][/COLOR] Video' , url + '&typex=video' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Movies (Used for library scanning)' , url + '&typex=movie%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] TV Shows (Used for library scanning)' , url + '&typex=tv%20show%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Artists (Used for library scanning)' , url + '&typex=artist%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][SCRAPER][/COLOR] Music Videos (Used for library scanning)' , url + '&typex=music%20video%20scraper' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] All Services' , url + '&typex=service' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][SERVICE][/COLOR] Weather Service' , url + '&typex=weather' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Repositories' , url + '&typex=repository' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Scripts (Program Add-ons)' , url + '&typex=executable' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Screensavers' , url + '&typex=screensaver' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Script Modules' , url + '&typex=script%20module' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Skins' , url + '&typex=skin' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Subtitles' , url + '&typex=subtitles' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][OTHER][/COLOR] Web Interface' , url + '&typex=web%20interface' , 'grab_addons' , '' , '' , '' , '' )
 if 86 - 86: iIii1I11I1II1 / O00OOOoOoo0O . oO0OooOoO
 if 19 - 19: OoooO0Oo0O0 % OoooooooOO % i11111IIIII * oOO00Oo % O0
def ooo ( ) :
 i1i1iI1iiiI ( )
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://outdated/",return)' )
 if 51 - 51: o0Oo % Iiii1i1 . III1IiiI / iIii1I11I1II1 / o00O0OoO . III1IiiI
 if 42 - 42: oOO00Oo + i1IIi - iI1IiiIIIiIi / i11111IIIII
def iiIiIIIiiI ( url ) :
 oO00oOOoooO ( 'folder' , 'African' , url + '&genre=african' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Arabic' , url + '&genre=arabic' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Asian' , url + '&genre=asian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Australian' , url + '&genre=australian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Austrian' , url + '&genre=austrian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Belgian' , url + '&genre=belgian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Brazilian' , url + '&genre=brazilian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Canadian' , url + '&genre=canadian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Chinese' , url + '&genre=chinese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Colombian' , url + '&genre=columbian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Croatian' , url + '&genre=croatian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Czech' , url + '&genre=czech' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Danish' , url + '&genre=danish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dominican' , url + '&genre=dominican' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dutch' , url + '&genre=dutch' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Egyptian' , url + '&genre=egyptian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Filipino' , url + '&genre=filipino' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Finnish' , url + '&genre=finnish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'French' , url + '&genre=french' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'German' , url + '&genre=german' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Greek' , url + '&genre=greek' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hebrew' , url + '&genre=hebrew' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hungarian' , url + '&genre=hungarian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Icelandic' , url + '&genre=icelandic' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Indian' , url + '&genre=indian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Irish' , url + '&genre=irish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Italian' , url + '&genre=italian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Japanese' , url + '&genre=japanese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Korean' , url + '&genre=korean' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Lebanese' , url + '&genre=lebanese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Mongolian' , url + '&genre=mongolian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Moroccan' , url + '&genre=moroccan' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Nepali' , url + '&genre=nepali' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'New Zealand' , url + '&genre=newzealand' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Norwegian' , url + '&genre=norwegian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Pakistani' , url + '&genre=pakistani' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Polish' , url + '&genre=polish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Portuguese' , url + '&genre=portuguese' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Romanian' , url + '&genre=romanian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Russian' , url + '&genre=russian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Singapore' , url + '&genre=singapore' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Spanish' , url + '&genre=spanish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swedish' , url + '&genre=swedish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swiss' , url + '&genre=swiss' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Syrian' , url + '&genre=syrian' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Tamil' , url + '&genre=tamil' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Thai' , url + '&genre=thai' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Turkish' , url + '&genre=turkish' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'UK' , url + '&genre=uk' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'USA' , url + '&genre=usa' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Vietnamese' , url + '&genre=vietnamese' , 'grab_addons' , '' , '' , '' , '' )
 if 12 - 12: O0 - oOO00Oo
 if 81 - 81: O00OOOoOoo0O - O00OOOoOoo0O . i1Iii1i1I
def o0OoOo00o0o ( url ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/AddonPortal/addondetails.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 25 - 25: Iiii1i1 / iIii1I11I1II1 % i1Iii1i1I
 IiiiiI1i1Iii = re . compile ( 'addon_types="(.+?)"' ) . findall ( OoOO0o )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 iiii111II = re . compile ( 'UID="(.+?)"' ) . findall ( OoOO0o )
 I11iIiI1I1i11 = re . compile ( 'id="(.+?)"' ) . findall ( OoOO0o )
 OOoooO00o0oo0 = re . compile ( 'provider_name="(.+?)"' ) . findall ( OoOO0o )
 O00O = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
 I1i11 = re . compile ( 'created="(.+?)"' ) . findall ( OoOO0o )
 IiIi1I1 = re . compile ( 'addon_types="(.+?)"' ) . findall ( OoOO0o )
 IiIIi1 = re . compile ( 'updated="(.+?)"' ) . findall ( OoOO0o )
 IIIIiii1IIii = re . compile ( 'downloads="(.+?)"' ) . findall ( OoOO0o )
 if 38 - 38: iiIi1i11 + oO0OooOoO % o0oOo0 % O00OOOoOoo0O - iI1IiiIIIiIi / OoooooooOO
 oOOoo0000O0o0 = re . compile ( 'description="(.+?)"' ) . findall ( OoOO0o )
 II1III = re . compile ( 'devbroke="(.+?)"' ) . findall ( OoOO0o )
 III1 = re . compile ( 'broken="(.+?)"' ) . findall ( OoOO0o )
 OooooO0oOOOO = re . compile ( 'deleted="(.+?)"' ) . findall ( OoOO0o )
 o0O00oOOoo = re . compile ( 'mainbranch_notes="(.+?)"' ) . findall ( OoOO0o )
 if 18 - 18: iI1IiiIIIiIi + i11111IIIII - O0
 o00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( OoOO0o )
 i1Ii1i1I11Iii = re . compile ( 'data_url="(.+?)"' ) . findall ( OoOO0o )
 I1i1i1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( OoOO0o )
 OoO0O00O0oo0O = re . compile ( 'genres="(.+?)"' ) . findall ( OoOO0o )
 I1IiI11 = re . compile ( 'forum="(.+?)"' ) . findall ( OoOO0o )
 iI1iiiiIii = re . compile ( 'repo_id="(.+?)"' ) . findall ( OoOO0o )
 iIiIiIiI = re . compile ( 'license="(.+?)"' ) . findall ( OoOO0o )
 i11OOoo = re . compile ( 'platform="(.+?)"' ) . findall ( OoOO0o )
 iIIiiiI = re . compile ( 'visible="(.+?)"' ) . findall ( OoOO0o )
 oo0 = re . compile ( 'script="(.+?)"' ) . findall ( OoOO0o )
 IiI111ii1ii = re . compile ( 'program_plugin="(.+?)"' ) . findall ( OoOO0o )
 O0OOo = re . compile ( 'script_module="(.+?)"' ) . findall ( OoOO0o )
 IiIII1 = re . compile ( 'video_plugin="(.+?)"' ) . findall ( OoOO0o )
 O0Oo000 = re . compile ( 'audio_plugin="(.+?)"' ) . findall ( OoOO0o )
 iiI11i1II = re . compile ( 'image_plugin="(.+?)"' ) . findall ( OoOO0o )
 OO0O0OOo0O = re . compile ( 'repository="(.+?)"' ) . findall ( OoOO0o )
 I1 = re . compile ( 'weather_service="(.+?)"' ) . findall ( OoOO0o )
 o0OooOOOOOO = re . compile ( 'skin="(.+?)"' ) . findall ( OoOO0o )
 OOooO0o0 = re . compile ( 'service="(.+?)"' ) . findall ( OoOO0o )
 iiIII1i = re . compile ( 'warning="(.+?)"' ) . findall ( OoOO0o )
 I1I = re . compile ( 'web_interface="(.+?)"' ) . findall ( OoOO0o )
 ooooO0oOoOOoO = re . compile ( 'movie_scraper="(.+?)"' ) . findall ( OoOO0o )
 I1i11i = re . compile ( 'tv_scraper="(.+?)"' ) . findall ( OoOO0o )
 IiIi = re . compile ( 'artist_scraper="(.+?)"' ) . findall ( OoOO0o )
 OOOOO0O00 = re . compile ( 'music_video_scraper="(.+?)"' ) . findall ( OoOO0o )
 Iii = re . compile ( 'subtitles="(.+?)"' ) . findall ( OoOO0o )
 iIIiIiI1I1 = re . compile ( 'requires="(.+?)"' ) . findall ( OoOO0o )
 ooO = re . compile ( 'modules="(.+?)"' ) . findall ( OoOO0o )
 ii = re . compile ( 'icon="(.+?)"' ) . findall ( OoOO0o )
 OO0O0Ooo = re . compile ( 'video_preview="(.+?)"' ) . findall ( OoOO0o )
 oOoO0 = re . compile ( 'video_guide="(.+?)"' ) . findall ( OoOO0o )
 Oo0 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( OoOO0o )
 oo0O0o00o0O = re . compile ( 'video_guide2="(.+?)"' ) . findall ( OoOO0o )
 I11i1II = re . compile ( 'video_guide3="(.+?)"' ) . findall ( OoOO0o )
 OooiiIi1i = re . compile ( 'video_guide4="(.+?)"' ) . findall ( OoOO0o )
 I1i11111i1i11 = re . compile ( 'video_guide5="(.+?)"' ) . findall ( OoOO0o )
 OOoOOO0 = re . compile ( 'video_guide6="(.+?)"' ) . findall ( OoOO0o )
 I1I1i = re . compile ( 'video_guide7="(.+?)"' ) . findall ( OoOO0o )
 I1IIIiIiIi = re . compile ( 'video_guide8="(.+?)"' ) . findall ( OoOO0o )
 IIIII1 = re . compile ( 'video_guide9="(.+?)"' ) . findall ( OoOO0o )
 iIi1Ii1i1iI = re . compile ( 'video_guide10="(.+?)"' ) . findall ( OoOO0o )
 IIiI1 = re . compile ( 'video_label1="(.+?)"' ) . findall ( OoOO0o )
 i1iI1 = re . compile ( 'video_label2="(.+?)"' ) . findall ( OoOO0o )
 ii1 = re . compile ( 'video_label3="(.+?)"' ) . findall ( OoOO0o )
 I1IiiI1ii1i = re . compile ( 'video_label4="(.+?)"' ) . findall ( OoOO0o )
 O0o = re . compile ( 'video_label5="(.+?)"' ) . findall ( OoOO0o )
 oO0OoO00o = re . compile ( 'video_label6="(.+?)"' ) . findall ( OoOO0o )
 II1iiiiII = re . compile ( 'video_label7="(.+?)"' ) . findall ( OoOO0o )
 O0OoOO0oo0 = re . compile ( 'video_label8="(.+?)"' ) . findall ( OoOO0o )
 oOO = re . compile ( 'video_label9="(.+?)"' ) . findall ( OoOO0o )
 O0o0OO0000ooo = re . compile ( 'video_label10="(.+?)"' ) . findall ( OoOO0o )
 if 4 - 4: iI1IiiIIIiIi
 if 51 - 51: ii1ii11IIIiiI - O0 % III1IiiI - oO0OooOoO
 if 31 - 31: i1Iii1i1I / II11iIiIIIiI - i1Iii1i1I - iiIi1i11
 I1iiIIIi11 = IiiiiI1i1Iii [ 0 ] if ( len ( IiiiiI1i1Iii ) > 0 ) else ''
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 Ii1I11ii1i = iiii111II [ 0 ] if ( len ( iiii111II ) > 0 ) else ''
 O0iIiIIIIIii = I11iIiI1I1i11 [ 0 ] if ( len ( I11iIiI1I1i11 ) > 0 ) else ''
 OOo0 = OOoooO00o0oo0 [ 0 ] if ( len ( OOoooO00o0oo0 ) > 0 ) else ''
 ii11I1 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 oO0oo = I1i11 [ 0 ] if ( len ( I1i11 ) > 0 ) else ''
 Ii111iIi1iIi = IiIi1I1 [ 0 ] if ( len ( IiIi1I1 ) > 0 ) else ''
 IIIIIo0ooOoO000oO = IiIIi1 [ 0 ] if ( len ( IiIIi1 ) > 0 ) else ''
 OOo = IIIIiii1IIii [ 0 ] if ( len ( IIIIiii1IIii ) > 0 ) else ''
 if 50 - 50: o0oOo0
 o0O0O0ooo0oOO = '[CR][CR][COLOR=dodgerblue]Description: [/COLOR]' + oOOoo0000O0o0 [ 0 ] if ( len ( oOOoo0000O0o0 ) > 0 ) else ''
 oo000 = II1III [ 0 ] if ( len ( II1III ) > 0 ) else ''
 iiOoO = III1 [ 0 ] if ( len ( III1 ) > 0 ) else ''
 Iiiiii111i1ii = '[CR]' + OooooO0oOOOO [ 0 ] if ( len ( OooooO0oOOOO ) > 0 ) else ''
 i1i1iII1 = '[CR][CR][COLOR=dodgerblue]User Notes: [/COLOR]' + o0O00oOOoo [ 0 ] if ( len ( o0O00oOOoo ) > 0 ) else ''
 if 25 - 25: iIii1I11I1II1 % i1Iii1i1I . o0oOo0
 IIIIi1 = o00O [ 0 ] if ( len ( o00O ) > 0 ) else ''
 iIi11iiIiI1I = i1Ii1i1I11Iii [ 0 ] if ( len ( i1Ii1i1I11Iii ) > 0 ) else ''
 Iiii = I1i1i1 [ 0 ] if ( len ( I1i1i1 ) > 0 ) else ''
 oooOOoooo = OoO0O00O0oo0O [ 0 ] if ( len ( OoO0O00O0oo0O ) > 0 ) else ''
 O0000OOO0 = '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]' + I1IiI11 [ 0 ] if ( len ( I1IiI11 ) > 0 ) else '[CR][CR][COLOR=dodgerblue]Support Forum: [/COLOR]No forum details given by developer'
 ooo0 = I1IiI11 [ 0 ] if ( len ( I1IiI11 ) > 0 ) else 'None'
 oO000oOo00o0o = iI1iiiiIii [ 0 ] if ( len ( iI1iiiiIii ) > 0 ) else ''
 license = iIiIiIiI [ 0 ] if ( len ( iIiIiIiI ) > 0 ) else ''
 O00oO0 = '[COLOR=orange]     Platform: [/COLOR]' + i11OOoo [ 0 ] if ( len ( i11OOoo ) > 0 ) else ''
 O0Oo00OoOo = iIIiiiI [ 0 ] if ( len ( iIIiiiI ) > 0 ) else ''
 ii1ii111 = oo0 [ 0 ] if ( len ( oo0 ) > 0 ) else ''
 i11111I1I = IiI111ii1ii [ 0 ] if ( len ( IiI111ii1ii ) > 0 ) else ''
 ii1Oo0000oOo = O0OOo [ 0 ] if ( len ( O0OOo ) > 0 ) else ''
 I11o0oO00oO0o0o0 = IiIII1 [ 0 ] if ( len ( IiIII1 ) > 0 ) else ''
 I1Iooooo = O0Oo000 [ 0 ] if ( len ( O0Oo000 ) > 0 ) else ''
 i11IIIiI1I = iiI11i1II [ 0 ] if ( len ( iiI11i1II ) > 0 ) else ''
 o0iiiI1I1iIIIi1 = OO0O0OOo0O [ 0 ] if ( len ( OO0O0OOo0O ) > 0 ) else ''
 IiiI1iiiiI1iI = OOooO0o0 [ 0 ] if ( len ( OOooO0o0 ) > 0 ) else ''
 OOOO0OOoO0O0 = o0OooOOOOOO [ 0 ] if ( len ( o0OooOOOOOO ) > 0 ) else ''
 iIiiiii1i = iiIII1i [ 0 ] if ( len ( iiIII1i ) > 0 ) else ''
 iiIi1IIiI = I1I [ 0 ] if ( len ( I1I ) > 0 ) else ''
 i1oO0OO0 = I1 [ 0 ] if ( len ( I1 ) > 0 ) else ''
 o0O0Oo00 = ooooO0oOoOOoO [ 0 ] if ( len ( ooooO0oOoOOoO ) > 0 ) else ''
 O0Oo0o000oO = I1i11i [ 0 ] if ( len ( I1i11i ) > 0 ) else ''
 oO0o00oOOooO0 = IiIi [ 0 ] if ( len ( IiIi ) > 0 ) else ''
 OOOoO000 = OOOOO0O00 [ 0 ] if ( len ( OOOOO0O00 ) > 0 ) else ''
 oOOOO = Iii [ 0 ] if ( len ( Iii ) > 0 ) else ''
 OOoO00 = iIIiIiI1I1 [ 0 ] if ( len ( iIIiIiI1I1 ) > 0 ) else ''
 Ii = ooO [ 0 ] if ( len ( ooO ) > 0 ) else ''
 Ii1ii111i1 = ii [ 0 ] if ( len ( ii ) > 0 ) else ''
 i1i1i1I = OO0O0Ooo [ 0 ] if ( len ( OO0O0Ooo ) > 0 ) else 'None'
 oOoo000 = oOoO0 [ 0 ] if ( len ( oOoO0 ) > 0 ) else 'None'
 OooOo00o = Oo0 [ 0 ] if ( len ( Oo0 ) > 0 ) else 'None'
 IiI11i1IIiiI = oo0O0o00o0O [ 0 ] if ( len ( oo0O0o00o0O ) > 0 ) else 'None'
 oOOo000oOoO0 = I11i1II [ 0 ] if ( len ( I11i1II ) > 0 ) else 'None'
 OoOo00o0OO = OooiiIi1i [ 0 ] if ( len ( OooiiIi1i ) > 0 ) else 'None'
 ii1IIIIiI11 = I1i11111i1i11 [ 0 ] if ( len ( I1i11111i1i11 ) > 0 ) else 'None'
 iI1IIIii = OOoOOO0 [ 0 ] if ( len ( OOoOOO0 ) > 0 ) else 'None'
 I1i11ii11 = I1I1i [ 0 ] if ( len ( I1I1i ) > 0 ) else 'None'
 OO00O0oOO = I1IIIiIiIi [ 0 ] if ( len ( I1IIIiIiIi ) > 0 ) else 'None'
 Ii1iI111 = IIIII1 [ 0 ] if ( len ( IIIII1 ) > 0 ) else 'None'
 O0oooo00o0Oo = iIi1Ii1i1iI [ 0 ] if ( len ( iIi1Ii1i1iI ) > 0 ) else 'None'
 I1iii = IIiI1 [ 0 ] if ( len ( IIiI1 ) > 0 ) else 'None'
 oO0o0O0Ooo0o = i1iI1 [ 0 ] if ( len ( i1iI1 ) > 0 ) else 'None'
 i1Ii11II = ii1 [ 0 ] if ( len ( ii1 ) > 0 ) else 'None'
 IioO0oOOO0Ooo = I1IiiI1ii1i [ 0 ] if ( len ( I1IiiI1ii1i ) > 0 ) else 'None'
 i1i1I = O0o [ 0 ] if ( len ( O0o ) > 0 ) else 'None'
 IiIIi1iII11I1Ii1 = oO0OoO00o [ 0 ] if ( len ( oO0OoO00o ) > 0 ) else 'None'
 o0o0 = II1iiiiII [ 0 ] if ( len ( II1iiiiII ) > 0 ) else 'None'
 oOo0oO = O0OoOO0oo0 [ 0 ] if ( len ( O0OoOO0oo0 ) > 0 ) else 'None'
 IIi1IIIIi = oOO [ 0 ] if ( len ( oOO ) > 0 ) else 'None'
 OOOoO = O0o0OO0000ooo [ 0 ] if ( len ( O0o0OO0000ooo ) > 0 ) else 'None'
 if 14 - 14: o00O0OoO . iIii1I11I1II1 . OoooooooOO . oO0OooOoO / oOO00Oo
 print "### Addon Details: " + i1iIIIi1i
 if 21 - 21: i11iIiiIii / i1IIi + o0Oo * iiIi1i11 . Iiii1i1
 if Iiiiii111i1ii != '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=red]This add-on is depreciated, it\'s no longer available.[/COLOR]'
  if 73 - 73: oO0OooOoO
 elif iiOoO == '' and oo000 == '' and iIiiiii1i == '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=lime]No reported problems[/COLOR]'
  if 24 - 24: O00OOOoOoo0O / OoooooooOO . oO0OooOoO . o0Oo % O0 % iI1IiiIIIiIi
 elif iiOoO == '' and oo000 == '' and iIiiiii1i != '' and Iiiiii111i1ii == '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR][COLOR=orange]Although there have been no reported problems there may be issues with this add-on, see below.[/COLOR]'
  if 5 - 5: OoooooooOO - ii1ii11IIIiiI + i11111IIIII - i1Iii1i1I . ii1ii11IIIiiI / o0oOo0
 elif iiOoO == '' and oo000 != '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by the add-on developer.[CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + oo000
  if 28 - 28: iI1IiiIIIiIi * iI1IiiIIIiIi - iIii1I11I1II1
 elif iiOoO != '' and oo000 == '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]User Comments: [/COLOR]' + iiOoO
  if 70 - 70: Iiii1i1
 elif iiOoO != '' and oo000 != '' :
  OoO = '[CR][CR][COLOR=dodgerblue]Status: [/COLOR]Marked as broken by both the add-on developer and a member of the community at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR][CR][COLOR=dodgerblue]Developer Comments: [/COLOR]' + oo000 + '[CR][COLOR=dodgerblue]User Comments: [/COLOR]' + iiOoO
  if 16 - 16: i1Iii1i1I - OoooooooOO % II11iIiIIIiI
  if 36 - 36: iiIi1i11
 O0oii111 = str ( '[COLOR=orange]Name: [/COLOR]' + i1iIIIi1i + '[COLOR=orange]     Author(s): [/COLOR]' + OOo0 + '[COLOR=orange][CR][CR]Version: [/COLOR]' + ii11I1 + '[COLOR=orange]     Created: [/COLOR]' + oO0oo + '[COLOR=orange]     Updated: [/COLOR]' + IIIIIo0ooOoO000oO + '[COLOR=orange][CR][CR]Repository: [/COLOR]' + oO000oOo00o0o + O00oO0 + '[COLOR=orange]     Add-on Type(s): [/COLOR]' + Ii111iIi1iIi + OOoO00 + OoO + Iiiiii111i1ii + iIiiiii1i + O0000OOO0 + o0O0O0ooo0oOO + i1i1iII1 )
 if 58 - 58: iiIi1i11 * oOO00Oo + O0 % iiIi1i11
 if 25 - 25: II11iIiIIIiI % OoooO0Oo0O0 * o0oOo0
 if os . path . exists ( os . path . join ( OO0o , O0iIiIIIIIii ) ) :
  if 'script.module' in O0iIiIIIIIii or 'repo' in O0iIiIIIIIii :
   oO00oOOoooO ( '' , '[COLOR=orange]Already installed[/COLOR]' , '' , '' , Ii1ii111i1 , '' , '' , '' )
  else :
   oO00oOOoooO ( '' , '[COLOR=orange]Already installed -[/COLOR] Click here to run the add-on' , O0iIiIIIIIii , 'run_addon' , Ii1ii111i1 , '' , '' , '' )
   if 6 - 6: i1Iii1i1I . i11111IIIII * O00OOOoOoo0O . i1IIi
   if 98 - 98: i1IIi
 if i1iIIIi1i == '' :
  oO00oOOoooO ( '' , '[COLOR=yellow]Sorry request failed due to high traffic on server, please try again[/COLOR]' , '' , '' , Ii1ii111i1 , '' , '' , '' )
  if 65 - 65: O00OOOoOoo0O / ii1ii11IIIiiI % i11111IIIII
  if 45 - 45: O00OOOoOoo0O
 elif i1iIIIi1i != '' :
  if 66 - 66: ii1ii11IIIiiI
  if ( iiOoO == '' ) and ( oo000 == '' ) and ( Iiiiii111i1ii == '' ) and ( iIiiiii1i == '' ) :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR] No problems reported' , O0oii111 , 'text_guide' , Ii1ii111i1 , '' , '' , O0oii111 )
   if 56 - 56: O0
  if ( iiOoO != '' and Iiiiii111i1ii == '' ) or ( oo000 != '' and Iiiiii111i1ii == '' ) or ( iIiiiii1i != '' and Iiiiii111i1ii == '' ) :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=orange] Possbile problems reported[/COLOR]' , O0oii111 , 'text_guide' , Ii1ii111i1 , '' , '' , O0oii111 )
   if 61 - 61: oOO00Oo / iiIi1i11 / II11iIiIIIiI * O0
  if Iiiiii111i1ii != '' :
   oO00oOOoooO ( 'addon' , '[COLOR=yellow][FULL DETAILS][/COLOR][COLOR=red] Add-on now depreciated[/COLOR]' , O0oii111 , 'text_guide' , Ii1ii111i1 , '' , '' , O0oii111 )
   if 23 - 23: III1IiiI - iiIi1i11 + o00O0OoO
   if 12 - 12: o0Oo / o0oOo0 % oOO00Oo / i11iIiiIii % OoooooooOO
  if Iiiiii111i1ii == '' :
   if 15 - 15: iIii1I11I1II1 % OoooooooOO - II11iIiIIIiI * iI1IiiIIIiIi + o00O0OoO
   if oO000oOo00o0o != '' and 'superrepo' not in oO000oOo00o0o :
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL - Recommended] [/COLOR]' + i1iIIIi1i , i1iIIIi1i , '' , 'addon_install_zero' , Ii1ii111i1 , '' , '' , o0O0O0ooo0oOO , I1iiIIIi11 , IIIIi1 , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , ooo0 , iIi11iiIiI1I )
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL - Backup Option] [/COLOR]' + i1iIIIi1i , i1iIIIi1i , '' , 'addon_install' , Ii1ii111i1 , '' , '' , o0O0O0ooo0oOO , Iiii , IIIIi1 , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , ooo0 , iIi11iiIiI1I )
    if 11 - 11: i1Iii1i1I * iI1IiiIIIiIi - O00OOOoOoo0O
   if oO000oOo00o0o == '' or 'superrepo' in oO000oOo00o0o :
    oO00oooOOoOo0 ( '[COLOR=lime][INSTALL] [/COLOR]' + i1iIIIi1i + ' - THIS IS NOT IN A SELF UPDATING REPO' , i1iIIIi1i , '' , 'addon_install' , '' , '' , '' , o0O0O0ooo0oOO , Iiii , IIIIi1 , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , ooo0 , iIi11iiIiI1I )
    if 66 - 66: O00OOOoOoo0O . i11iIiiIii - i1Iii1i1I * oOO00Oo + OoooooooOO * OoooO0Oo0O0
    if 74 - 74: II11iIiIIIiI
  if i1i1i1I != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  Preview' , OooOo00o , 'play_video' , '' , '' , '' , '' )
   if 61 - 61: II11iIiIIIiI - Iiii1i1 * oO0OooOoO % o0oOo0 * iIii1I11I1II1 + ii1ii11IIIiiI
  if OooOo00o != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + I1iii , OooOo00o , 'play_video' , '' , '' , '' , '' )
   if 71 - 71: o00O0OoO / o00O0OoO * III1IiiI * III1IiiI / oO0OooOoO
  if IiI11i1IIiiI != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oO0o0O0Ooo0o , IiI11i1IIiiI , 'play_video' , '' , '' , '' , '' )
   if 35 - 35: iiIi1i11 * oOO00Oo * o0Oo % II11iIiIIIiI . O00OOOoOoo0O
  if oOOo000oOoO0 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i1Ii11II , oOOo000oOoO0 , 'play_video' , '' , '' , '' , '' )
   if 58 - 58: o00O0OoO + oO0OooOoO * i1Iii1i1I * i11iIiiIii - iIii1I11I1II1
  if OoOo00o0OO != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IioO0oOOO0Ooo , OoOo00o0OO , 'play_video' , '' , '' , '' , '' )
   if 68 - 68: OoooooooOO % oO0OooOoO
  if ii1IIIIiI11 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + i1i1I , ii1IIIIiI11 , 'play_video' , '' , '' , '' , '' )
   if 26 - 26: oO0OooOoO % i11iIiiIii % iIii1I11I1II1 % o00O0OoO * o00O0OoO * OoooO0Oo0O0
  if iI1IIIii != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IiIIi1iII11I1Ii1 , iI1IIIii , 'play_video' , '' , '' , '' , '' )
   if 24 - 24: oO0OooOoO % Iiii1i1 - o0oOo0 + o0Oo * OoooO0Oo0O0
  if I1i11ii11 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + o0o0 , I1i11ii11 , 'play_video' , '' , '' , '' , '' )
   if 2 - 2: iI1IiiIIIiIi - i11111IIIII
  if OO00O0oOO != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + oOo0oO , OO00O0oOO , 'play_video' , '' , '' , '' , '' )
   if 83 - 83: III1IiiI % oOO00Oo % iI1IiiIIIiIi - oO0OooOoO * iiIi1i11 / OoooooooOO
  if Ii1iI111 != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + IIi1IIIIi , Ii1iI111 , 'play_video' , '' , '' , '' , '' )
   if 18 - 18: ii1ii11IIIiiI + iIii1I11I1II1 - oO0OooOoO - o0Oo
  if O0oooo00o0Oo != 'None' :
   oO00oOOoooO ( '' , '[COLOR=dodgerblue][VIDEO][/COLOR]  ' + OOOoO , O0oooo00o0Oo , 'play_video' , '' , '' , '' , '' )
   if 71 - 71: OoooooooOO
   if 33 - 33: Iiii1i1
def OOO0ooo ( url ) :
 oO00oOOoooO ( 'folder' , 'Anime' , url + '&genre=anime' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audiobooks' , url + '&genre=audiobooks' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comedy' , url + '&genre=comedy' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comics' , url + '&genre=comics' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Documentary' , url + '&genre=documentary' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Downloads' , url + '&genre=downloads' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Food' , url + '&genre=food' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Gaming' , url + '&genre=gaming' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Health' , url + '&genre=health' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'How To...' , url + '&genre=howto' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Kids' , url + '&genre=kids' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Live TV' , url + '&genre=livetv' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Movies' , url + '&genre=movies' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Music' , url + '&genre=music' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'News' , url + '&genre=news' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Photos' , url + '&genre=photos' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Podcasts' , url + '&genre=podcasts' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Radio' , url + '&genre=radio' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Religion' , url + '&genre=religion' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Space' , url + '&genre=space' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Sports' , url + '&genre=sports' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Technology' , url + '&genre=tech' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Trailers' , url + '&genre=trailers' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'TV Shows' , url + '&genre=tv' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Misc.' , url + '&genre=other' , 'grab_addons' , '' , '' , '' , '' )
 if 7 - 7: oOO00Oo + i1IIi . o0Oo / II11iIiIIIiI
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  oO00oOOoooO ( 'folder' , 'XXX' , url + '&genre=adult' , 'grab_addons' , '' , '' , '' , '' )
  if 22 - 22: o0oOo0 - o0oOo0 % iiIi1i11 . Iiii1i1 + III1IiiI
  if 63 - 63: o0Oo % Iiii1i1 * oOO00Oo + Iiii1i1 / II11iIiIIIiI % i1Iii1i1I
def iiI1i1Iii111 ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 forum = str ( forum )
 repo_id = str ( repo_id )
 i111I11i = 1
 ii1OoOO = 1
 iIII1I1i1i = 1
 o0OIIiI1I1 = xbmc . translatePath ( os . path . join ( OO0o , addon_id ) )
 if 15 - 15: iI1IiiIIIiIi * II11iIiIIIiI % OoooO0Oo0O0 * iIii1I11I1II1 - i11iIiiIii
 if os . path . exists ( o0OIIiI1I1 ) :
  Oo00OOOOoo0oo = 1
  if 80 - 80: Iiii1i1 * O00OOOoOoo0O * oO0OooOoO - O0 . O00OOOoOoo0O % o0Oo
 else :
  Oo00OOOOoo0oo = 0
  if 13 - 13: III1IiiI . o0Oo * III1IiiI + o0Oo
 OoOooo = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , name + '.zip' ) )
 oo00OOoOoO00 = xbmc . translatePath ( os . path . join ( OO0o , addon_id ) )
 if 15 - 15: i11111IIIII / O0 . oOO00Oo . i11iIiiIii
 iIii1 . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 if 59 - 59: Iiii1i1 - oOO00Oo - o0oOo0
 try :
  downloader . download ( repo_link , OoOooo , iIii1 )
  extract . all ( OoOooo , OO0o , iIii1 )
  if 48 - 48: i1IIi + o00O0OoO % O00OOOoOoo0O / II11iIiIIIiI - oOO00Oo
 except :
  if 67 - 67: III1IiiI % oOO00Oo . OoooooooOO + iiIi1i11 * o00O0OoO * O00OOOoOoo0O
  try :
   downloader . download ( zip_link , OoOooo , iIii1 )
   extract . all ( OoOooo , OO0o , iIii1 )
   if 36 - 36: O0 + II11iIiIIIiI
  except :
   if 5 - 5: II11iIiIIIiI * O00OOOoOoo0O
   try :
    if not os . path . exists ( oo00OOoOoO00 ) :
     os . makedirs ( oo00OOoOoO00 )
     if 46 - 46: o0oOo0
    OoOO0o = i1II1 ( data_path , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    I11iIiII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( OoOO0o )
    if 66 - 66: II11iIiIIIiI - oOO00Oo * i11111IIIII + O00OOOoOoo0O + oOO00Oo - iIii1I11I1II1
    for iiiI1ii11 in I11iIiII :
     ii1i = xbmc . translatePath ( os . path . join ( oo00OOoOoO00 , iiiI1ii11 ) )
     if 5 - 5: III1IiiI . OoooO0Oo0O0 . oO0OooOoO . OoooooooOO
     if addon_id not in iiiI1ii11 and '/' not in iiiI1ii11 :
      if 96 - 96: i11iIiiIii - iiIi1i11 % O0 / ii1ii11IIIiiI
      try :
       iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + iiiI1ii11 + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( data_path + iiiI1ii11 , ii1i , iIii1 )
       if 100 - 100: i1Iii1i1I / iI1IiiIIIiIi - OoooooooOO % oO0OooOoO - o0Oo % O00OOOoOoo0O
      except :
       print "failed to install" + iiiI1ii11
       if 60 - 60: iIii1I11I1II1 + i1IIi
     if '/' in iiiI1ii11 and '..' not in iiiI1ii11 and 'http' not in iiiI1ii11 :
      OooOOo0 = data_path + iiiI1ii11
      ooO000O ( ii1i , OooOOo0 )
      if 53 - 53: oOO00Oo . i1Iii1i1I / iI1IiiIIIiIi
   except :
    OOooO0OOoo . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=yellow]' + name , '[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    i111I11i = 0
    if 39 - 39: iI1IiiIIIiIi % O0 % O00OOOoOoo0O . i1IIi
 if i111I11i == 1 :
  time . sleep ( 1 )
  iIii1 . update ( 0 , "[COLOR=yellow]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  oOo00OooO0oO = xbmc . translatePath ( os . path . join ( OO0o , repo_id ) )
  if 16 - 16: i11111IIIII / II11iIiIIIiI + iiIi1i11 / iI1IiiIIIiIi
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( oOo00OooO0oO ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   IIIiiI1 ( repo_id )
   if 74 - 74: o00O0OoO - iiIi1i11 + i1IIi . o0Oo + iiIi1i11 - o00O0OoO
  xbmc . sleep ( 2000 )
  if 17 - 17: O0 . Iiii1i1 . O0 + O0 / II11iIiIIIiI . o0oOo0
  if os . path . exists ( o0OIIiI1I1 ) and Oo00OOOOoo0oo == 0 :
   OO00OOoO0o = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    i1II1 ( OO00OOoO0o )
   except :
    pass
    if 4 - 4: i1IIi - i11iIiiIii / i11iIiiIii / OoooooooOO
  OOOO0o ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 10 - 10: Iiii1i1 % o0Oo
  if ii1OoOO == 0 :
   OOooO0OOoo . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
   if 97 - 97: OoooooooOO - Iiii1i1
  if iIII1I1i1i == 0 :
   OOooO0OOoo . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
   if 58 - 58: iIii1I11I1II1 + O0
  if iIII1I1i1i != 0 and ii1OoOO != 0 and forum != 'None' :
   OOooO0OOoo . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=yellow]' + forum , '[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.' )
   if 30 - 30: o0oOo0 % i1Iii1i1I * iiIi1i11 - OoooO0Oo0O0 * iI1IiiIIIiIi % o0oOo0
  if iIII1I1i1i != 0 and ii1OoOO != 0 and forum == 'None' :
   OOooO0OOoo . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given.' )
   if 46 - 46: i11iIiiIii - O0 . III1IiiI
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 100 - 100: o0Oo / oOO00Oo * i1Iii1i1I . O0 / iiIi1i11
 if 83 - 83: Iiii1i1
def ii111Ii11iii ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 o0OIIiI1I1 = xbmc . translatePath ( os . path . join ( OO0o , addon_id ) )
 forum = str ( forum )
 if 62 - 62: iIii1I11I1II1
 if not os . path . exists ( o0OIIiI1I1 ) :
  OO0OoOOO0 = 1
  if 90 - 90: o0oOo0 + oO0OooOoO * OoooO0Oo0O0 / iI1IiiIIIiIi . oOO00Oo + oOO00Oo
 else :
  OO0OoOOO0 = 0
  if 40 - 40: o0oOo0 / O00OOOoOoo0O % i11iIiiIii % OoooO0Oo0O0 / o0Oo
 repo_id = str ( repo_id )
 oOo00OooO0oO = xbmc . translatePath ( os . path . join ( OO0o , repo_id ) )
 if 62 - 62: i1IIi - O00OOOoOoo0O
 if os . path . exists ( o0OIIiI1I1 ) :
  Oo00OOOOoo0oo = 1
  oo0O0oo = OOooO0OOoo . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 14 - 14: O0 / i1IIi / II11iIiIIIiI + iIii1I11I1II1
  if oo0O0oo == 1 :
   ooO00O00oOO ( o0OIIiI1I1 )
   OO0OoOOO0 = 1
 else :
  Oo00OOOOoo0oo = 0
  if 40 - 40: i1Iii1i1I . III1IiiI + o0Oo + OoooO0Oo0O0 + Iiii1i1
 if OO0OoOOO0 == 1 :
  if 26 - 26: iIii1I11I1II1
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( oOo00OooO0oO ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   IIIiiI1 ( repo_id )
   if 87 - 87: OoooO0Oo0O0 / OoooooooOO - II11iIiIIIiI % O00OOOoOoo0O % i11111IIIII % II11iIiIIIiI
  if not os . path . exists ( o0OIIiI1I1 ) :
   os . makedirs ( o0OIIiI1I1 )
   if 29 - 29: OoooooooOO . o0Oo % OoooO0Oo0O0 - i1Iii1i1I
  iiii = os . path . join ( OO0o , addon_id , 'addon.xml' )
  o0OO0Oo = os . path . join ( OO0o , addon_id , 'default.py' )
  if 3 - 3: Iiii1i1 - O0 % iIii1I11I1II1 / i11111IIIII . oOO00Oo
  shutil . copyfile ( O0O , iiii )
  if 3 - 3: O0 % OoooooooOO / iiIi1i11
  ooOo = open ( os . path . join ( iiii ) , mode = 'r' )
  o0oO0OoO0 = ooOo . read ( )
  ooOo . close ( )
  if 70 - 70: III1IiiI - III1IiiI
  if 57 - 57: o0Oo - oOO00Oo + ii1ii11IIIiiI % II11iIiIIIiI
  i1oo00OoO = re . compile ( 'testid[\s\S]*?' ) . findall ( o0oO0OoO0 )
  I11iIiI1I1i11 = i1oo00OoO [ 0 ] if ( len ( i1oo00OoO ) > 0 ) else 'None'
  iI = re . compile ( 'testname[\s\S]*?' ) . findall ( o0oO0OoO0 )
  oo00oO0o = iI [ 0 ] if ( len ( iI ) > 0 ) else 'None'
  Ii1IIi = re . compile ( 'testprovider[\s\S]*?' ) . findall ( o0oO0OoO0 )
  i111i11I1ii = Ii1IIi [ 0 ] if ( len ( Ii1IIi ) > 0 ) else 'None'
  OOooo = re . compile ( 'testprovides[\s\S]*?' ) . findall ( o0oO0OoO0 )
  oo0oOO = OOooo [ 0 ] if ( len ( OOooo ) > 0 ) else 'None'
  II1i11i1iIi11 = o0oO0OoO0 . replace ( I11iIiI1I1i11 , addon_id ) . replace ( oo00oO0o , name ) . replace ( i111i11I1ii , provider_name ) . replace ( oo0oOO , contenttypes )
  if 83 - 83: iI1IiiIIIiIi
  I1iI1I1 = open ( iiii , mode = 'w+' )
  I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
  I1iI1I1 . close ( )
  if 48 - 48: o0Oo / i11iIiiIii - oOO00Oo * III1IiiI / OoooooooOO
  OoOo = open ( o0OO0Oo , mode = 'w' )
  OoOo . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + addon_id + '"\nAddonName="' + name + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating. We recommend waiting but if you\'ve already tried that and it\'s not updating you can try re-installing via the CP backup method.",yeslabel="Install Option 2", nolabel="Wait...")\nif choice == 1: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.totalinstaller/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
  OoOo . close ( )
  if 17 - 17: iI1IiiIIIiIi . i11iIiiIii
  xbmc . sleep ( 1000 )
  if 5 - 5: OoooO0Oo0O0 + O0 + O0 . Iiii1i1 - o0oOo0
  if os . path . exists ( o0OIIiI1I1 ) and Oo00OOOOoo0oo == 0 :
   OO00OOoO0o = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    i1II1 ( OO00OOoO0o , 5 )
   except :
    pass
    if 63 - 63: III1IiiI
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  OOooO0OOoo . ok ( name + " Install Complete" , '[COLOR=dodgerblue]' + name + '[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.' )
  if 71 - 71: i1IIi . iI1IiiIIIiIi * i1Iii1i1I % OoooooooOO + iiIi1i11
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 36 - 36: i11111IIIII
 if 49 - 49: iiIi1i11 / OoooooooOO / o0Oo
def o0OooooOoOO ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 oOo00OooO0oO = xbmc . translatePath ( os . path . join ( OO0o , repo_id ) )
 o0OIIiI1I1 = xbmc . translatePath ( os . path . join ( OO0o , addon_id ) )
 if 19 - 19: i11111IIIII
 if os . path . exists ( o0OIIiI1I1 ) :
  if 78 - 78: iiIi1i11 % oOO00Oo
  oo0O0oo = OOooO0OOoo . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 39 - 39: OoooO0Oo0O0 + o0Oo - iIii1I11I1II1 - oOO00Oo
  if oo0O0oo == 1 :
   ooO00O00oOO ( o0OIIiI1I1 )
   if 7 - 7: i11111IIIII . O00OOOoOoo0O / OoooO0Oo0O0 . iiIi1i11 * o00O0OoO - oO0OooOoO
 if os . path . exists ( oOo00OooO0oO ) :
  if 37 - 37: Iiii1i1 . O00OOOoOoo0O / O0 * i1Iii1i1I
  if os . path . exists ( o0OIIiI1I1 ) :
   Oo00OOOOoo0oo = 1
   if 7 - 7: ii1ii11IIIiiI * o00O0OoO + oO0OooOoO % i11iIiiIii
  else :
   Oo00OOOOoo0oo = 0
   if 8 - 8: o0oOo0 * O0
  oo0O0oo = OOooO0OOoo . yesno ( 'WARNING!' , '[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?' )
  if 73 - 73: oOO00Oo / III1IiiI / o00O0OoO / ii1ii11IIIiiI
  if oo0O0oo == 1 :
   if 11 - 11: O00OOOoOoo0O + i11111IIIII - OoooooooOO / ii1ii11IIIiiI
   if 'video' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.video/?",return)' )
    if 34 - 34: o0oOo0
   elif 'executable' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.executable/?",return)' )
    if 45 - 45: o0oOo0 / II11iIiIIIiI / iI1IiiIIIiIi
   elif 'audio' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.audio/?",return)' )
    if 44 - 44: OoooO0Oo0O0 - iI1IiiIIIiIi / oO0OooOoO * ii1ii11IIIiiI * II11iIiIIIiI
  xbmc . sleep ( 2000 )
  if 73 - 73: oOO00Oo - o0Oo * i1IIi / i11iIiiIii * iiIi1i11 % oO0OooOoO
  if os . path . exists ( o0OIIiI1I1 ) and Oo00OOOOoo0oo == 0 :
   OO00OOoO0o = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   try :
    i1II1 ( OO00OOoO0o , 5 )
   except :
    pass
    if 56 - 56: OoooooooOO * II11iIiIIIiI . II11iIiIIIiI . OoooO0Oo0O0
 else :
  OOooO0OOoo . ok ( 'WARNING!' , '[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]' + repo_id + '[/COLOR]' )
  if 24 - 24: II11iIiIIIiI . o00O0OoO * iI1IiiIIIiIi % i1Iii1i1I / iiIi1i11
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 58 - 58: o0Oo - OoooO0Oo0O0 % O0 . o0Oo % ii1ii11IIIiiI % i11111IIIII
 if 87 - 87: III1IiiI - i11iIiiIii
def ooOoO ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 OOooO0OOoo . ok ( 'Add-on Not Approved' , 'Sorry there are no repository details for this add-on and it\'s been marked as potentially giving access to unlawful content. The most likely cause for this is the add-on has only been released via social media groups.' )
 if 23 - 23: o00O0OoO
 if 40 - 40: oOO00Oo - oO0OooOoO / II11iIiIIIiI
def iiIiI1ii ( sign ) :
 if 56 - 56: OoooooooOO - o00O0OoO - i1IIi
 if 8 - 8: Iiii1i1 / iiIi1i11 . o0Oo + OoooO0Oo0O0 / i11iIiiIii
 oO00oOOoooO ( 'folder' , '[COLOR=gold][TOP 100][/COLOR] Show the most downloaded add-ons' , 'popular' , 'grab_addons' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan][Manual Search][/COLOR] Type in author/name/content' , 'desc=' , 'search_addons' , '' , '' , '' , '' )
 if 31 - 31: o0oOo0 - iIii1I11I1II1 + i1Iii1i1I . II11iIiIIIiI / i11111IIIII % iIii1I11I1II1
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Genres' , 'p' , 'addon_genres' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Countries' , 'p' , 'addon_countries' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Filter Results][/COLOR] By Kodi Categories' , 'p' , 'addon_categories' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Install From Zip' , '' , 'install_from_zip' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Browse My Repositories' , '' , 'browse_repos' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=orange][Kodi Add-on Browser][/COLOR] Check For Add-on Updates' , '' , 'check_updates' , '' , '' , '' , '' )
 if 6 - 6: i11111IIIII * i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + oOO00Oo / i1IIi
 if 53 - 53: o00O0OoO + iIii1I11I1II1
def oOooo0Oo ( ) :
 for file in glob . glob ( os . path . join ( OO0o , '*' ) ) :
  i1iIIIi1i = str ( file ) . replace ( OO0o , '[COLOR=red]REMOVE [/COLOR]' ) . replace ( 'plugin.' , '[COLOR=dodgerblue](PLUGIN) [/COLOR]' ) . replace ( 'audio.' , '' ) . replace ( 'video.' , '' ) . replace ( 'skin.' , '[COLOR=yellow](SKIN) [/COLOR]' ) . replace ( 'repository.' , '[COLOR=orange](REPOSITORY) [/COLOR]' ) . replace ( 'script.' , '[COLOR=cyan](SCRIPT) [/COLOR]' ) . replace ( 'metadata.' , '[COLOR=orange](METADATA) [/COLOR]' ) . replace ( 'service.' , '[COLOR=pink](SERVICE) [/COLOR]' ) . replace ( 'weather.' , '[COLOR=green](WEATHER) [/COLOR]' ) . replace ( 'module.' , '[COLOR=orange](MODULE) [/COLOR]' )
  oo0O0o = ( os . path . join ( file , 'icon.png' ) )
  OO0oIiII1iiI = ( os . path . join ( file , 'fanart.jpg' ) )
  oO00oOOoooO ( '' , i1iIIIi1i , file , 'remove_addons' , oo0O0o , OO0oIiII1iiI , '' , '' )
  if 34 - 34: o0Oo . III1IiiI + i1IIi
  if 98 - 98: III1IiiI % i11111IIIII * i11iIiiIii % OoooO0Oo0O0
def iIiI1IIiii11 ( ) :
 i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 33 - 33: iIii1I11I1II1 / i1Iii1i1I - o0Oo * o00O0OoO
def o0o00oO0oo000 ( ) :
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 ii11I1 = float ( oO000o [ : 4 ] )
 if ii11I1 < 14 :
  o0Ooo0O0 = os . path . join ( O0Oo000ooO00 , 'xbmc.log' )
 else :
  o0Ooo0O0 = os . path . join ( O0Oo000ooO00 , 'kodi.log' )
  if 48 - 48: o00O0OoO - i11111IIIII + iIii1I11I1II1 + OoooooooOO
 try :
  IiI1i111IiIiIi1 = open ( o0Ooo0O0 , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
 except :
  try :
   IiI1i111IiIiIi1 = open ( os . path . join ( oOOoO0 , 'temp' , 'kodi.log' ) , mode = 'r' )
   o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
   IiI1i111IiIiIi1 . close ( )
  except :
   try :
    IiI1i111IiIiIi1 = open ( os . path . join ( oOOoO0 , 'temp' , 'xbmc.log' ) , mode = 'r' )
    o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
    IiI1i111IiIiIi1 . close ( )
   except :
    pass
    if 39 - 39: o00O0OoO - OoooO0Oo0O0
 OOO0o0OO0OO = re . compile ( 'External storage path = (.+?);' ) . findall ( o0oO0OoO0 )
 oOo0O = OOO0o0OO0OO [ 0 ] if ( len ( OOO0o0OO0OO ) > 0 ) else ''
 return oOo0O
 if 43 - 43: oOO00Oo . i1Iii1i1I . o00O0OoO + iIii1I11I1II1
 if 78 - 78: iIii1I11I1II1 % O00OOOoOoo0O + OoooO0Oo0O0 / i1IIi % oO0OooOoO + iiIi1i11
def OooOOOO0O0 ( sourcefile , destfile , message_header , message1 , message2 , message3 , exclude_dirs , exclude_files ) :
 i1IIi1i1Ii1 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 Iiio0Oo0oO = len ( sourcefile )
 iIII1iiIi11 = [ ]
 ooOo0O0O0oOO0 = [ ]
 if 10 - 10: II11iIiIIIiI + O0
 iIii1 . create ( message_header , message1 , message2 , message3 )
 if 43 - 43: iIii1I11I1II1 / oO0OooOoO % oOO00Oo - iiIi1i11
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 34 - 34: i11iIiiIii - oO0OooOoO / o0Oo % oOO00Oo
  for file in I1iiIi111I :
   ooOo0O0O0oOO0 . append ( file )
   if 33 - 33: iiIi1i11
 IiiiI111I = len ( ooOo0O0O0oOO0 )
 if 49 - 49: oOO00Oo * iI1IiiIIIiIi + o00O0OoO + i1Iii1i1I
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 30 - 30: oOO00Oo / iiIi1i11 / i11111IIIII % o0oOo0 + oO0OooOoO
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in exclude_dirs ]
  I1iiIi111I [ : ] = [ iiI1iii for iiI1iii in I1iiIi111I if iiI1iii not in exclude_files and not 'crashlog' in iiI1iii and not 'stacktrace' in iiI1iii ]
  if 79 - 79: ii1ii11IIIiiI * O00OOOoOoo0O . OoooooooOO - o00O0OoO * oOO00Oo
  for file in I1iiIi111I :
   if 78 - 78: i11111IIIII
   try :
    iIII1iiIi11 . append ( file )
    Oo0O0Oo00O = len ( iIII1iiIi11 ) / float ( IiiiI111I ) * 100
    iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % I1III111i , 'Please Wait' )
    iIoo0ooooO = os . path . join ( oO0O000oOo , file )
    if 12 - 12: oO0OooOoO
   except :
    print "Unable to backup file: " + file
    if 2 - 2: i1IIi - o0Oo + o00O0OoO . oO0OooOoO
   if not 'temp' in OoOOOO :
    if 25 - 25: III1IiiI
    if not o0OO00 in OoOOOO :
     if 34 - 34: O00OOOoOoo0O . iIii1I11I1II1 % O0
     try :
      iI11Ii111 = '01/01/1980'
      OOo00OO00Oo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iIoo0ooooO ) ) )
      if 23 - 23: Iiii1i1 - iiIi1i11 + iI1IiiIIIiIi - O00OOOoOoo0O * O00OOOoOoo0O . II11iIiIIIiI
      if OOo00OO00Oo > iI11Ii111 :
       i1IIi1i1Ii1 . write ( iIoo0ooooO , iIoo0ooooO [ Iiio0Oo0oO : ] )
       if 47 - 47: III1IiiI % iIii1I11I1II1
     except :
      print "Unable to backup file: " + file
      if 11 - 11: o0Oo % iI1IiiIIIiIi - ii1ii11IIIiiI - III1IiiI + oOO00Oo
 i1IIi1i1Ii1 . close ( )
 iIii1 . close ( )
 if 98 - 98: i1Iii1i1I + iI1IiiIIIiIi - ii1ii11IIIiiI
 if 79 - 79: iiIi1i11 / Iiii1i1 . O00OOOoOoo0O - OoooO0Oo0O0
def Ii1ii11IIIi ( sourcefile , destfile ) :
 i1IIi1i1Ii1 = zipfile . ZipFile ( destfile , 'w' , zipfile . ZIP_DEFLATED )
 Iiio0Oo0oO = len ( sourcefile )
 iIII1iiIi11 = [ ]
 ooOo0O0O0oOO0 = [ ]
 if 82 - 82: III1IiiI * iIii1I11I1II1 . oOO00Oo . OoooO0Oo0O0 + iiIi1i11 / o0Oo
 iIii1 . create ( "Backing Up Files" , "Archiving..." , '' , 'Please Wait' )
 if 58 - 58: Iiii1i1 / o0oOo0 + O0 + o0oOo0 . iIii1I11I1II1 + oO0OooOoO
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 37 - 37: o00O0OoO . II11iIiIIIiI % i11111IIIII * i1IIi
  for file in I1iiIi111I :
   ooOo0O0O0oOO0 . append ( file )
   if 71 - 71: II11iIiIIIiI / oOO00Oo + iiIi1i11
 IiiiI111I = len ( ooOo0O0O0oOO0 )
 if 48 - 48: Iiii1i1 + i1Iii1i1I
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( sourcefile ) :
  if 16 - 16: iIii1I11I1II1 % i11iIiiIii . O00OOOoOoo0O % o0oOo0 + III1IiiI . ii1ii11IIIiiI
  for file in I1iiIi111I :
   iIII1iiIi11 . append ( file )
   Oo0O0Oo00O = len ( iIII1iiIi11 ) / float ( IiiiI111I ) * 100
   iIii1 . update ( int ( Oo0O0Oo00O ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
   iIoo0ooooO = os . path . join ( oO0O000oOo , file )
   if 46 - 46: ii1ii11IIIiiI - oOO00Oo / O00OOOoOoo0O - OoooooooOO + III1IiiI
   if not 'temp' in OoOOOO :
    if 58 - 58: oOO00Oo / oOO00Oo + o0oOo0 + o00O0OoO - O00OOOoOoo0O . iiIi1i11
    if not o0OO00 in OoOOOO :
     if 15 - 15: o0oOo0 * O00OOOoOoo0O % i11111IIIII . O00OOOoOoo0O . o00O0OoO
     import time
     iI11Ii111 = '01/01/1980'
     OOo00OO00Oo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iIoo0ooooO ) ) )
     if 97 - 97: III1IiiI
     if OOo00OO00Oo > iI11Ii111 :
      i1IIi1i1Ii1 . write ( iIoo0ooooO , iIoo0ooooO [ Iiio0Oo0oO : ] )
 i1IIi1i1Ii1 . close ( )
 iIii1 . close ( )
 if 80 - 80: o0Oo . iI1IiiIIIiIi
 if 47 - 47: o00O0OoO + o0oOo0 + oO0OooOoO % i11iIiiIii
def OOoOoo00Oo ( ) :
 Iiii1iiiIiI1 = OOooO0OOoo . browse ( 3 , 'Select the folder you want to scan' , 'files' , '' , False , False )
 Iiio0Oo0oO = len ( Iiii1iiiIiI1 )
 iIII1iiIi11 = [ ]
 ooOo0O0O0oOO0 = [ ]
 if 27 - 27: iI1IiiIIIiIi + o0Oo * iIii1I11I1II1 . OoooooooOO * O00OOOoOoo0O
 iIii1 . create ( 'Checking File Structure' , '' , 'Please wait...' , '' )
 if 100 - 100: ii1ii11IIIiiI / i1IIi - o0Oo % iI1IiiIIIiIi - iIii1I11I1II1
 oo0O0oo = OOooO0OOoo . yesno ( 'Delete or Scan?' , 'Do you want to delete all filenames with special characters or would you rather just scan and view the results in the log?' , yeslabel = 'Delete' , nolabel = 'Scan' )
 if 17 - 17: o00O0OoO / oOO00Oo % II11iIiIIIiI
 o0o = open ( O00oO , mode = 'w+' )
 o00o0O0O00 = open ( I11i1I1I , mode = 'w+' )
 if 34 - 34: iiIi1i11 . II11iIiIIIiI
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( Iiii1iiiIiI1 ) :
  if 78 - 78: OoooO0Oo0O0 % o0Oo / OoooooooOO % iiIi1i11 - i1Iii1i1I
  for file in I1iiIi111I :
   ooOo0O0O0oOO0 . append ( file )
   if 2 - 2: iIii1I11I1II1
 IiiiI111I = len ( ooOo0O0O0oOO0 )
 if 45 - 45: OoooooooOO / i11iIiiIii
 for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( Iiii1iiiIiI1 ) :
  if 10 - 10: i1Iii1i1I - III1IiiI * iIii1I11I1II1 % iIii1I11I1II1 * i11111IIIII - OoooO0Oo0O0
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO ]
  I1iiIi111I [ : ] = [ iiI1iii for iiI1iii in I1iiIi111I ]
  if 97 - 97: oO0OooOoO % Iiii1i1 + Iiii1i1 - ii1ii11IIIiiI / iI1IiiIIIiIi * o0Oo
  for file in I1iiIi111I :
   if 17 - 17: iI1IiiIIIiIi
   iIII1iiIi11 . append ( file )
   Oo0O0Oo00O = len ( iIII1iiIi11 ) / float ( IiiiI111I ) * 100
   iIii1 . update ( 0 , "Checking for non ASCII files" , '[COLOR yellow]%s[/COLOR]' % I1III111i , 'Please Wait' )
   if 39 - 39: o0oOo0 . oO0OooOoO
   try :
    file . encode ( 'ascii' )
    if 45 - 45: III1IiiI * O00OOOoOoo0O / iIii1I11I1II1
   except UnicodeDecodeError :
    o00ooOoO0 = ( str ( oO0O000oOo ) + '/' + str ( file ) ) . replace ( '\\' , '/' ) . replace ( ':/' , ':\\' )
    if 15 - 15: iiIi1i11 * o00O0OoO / OoooO0Oo0O0 * oOO00Oo
    print " non-ASCII file status logged successfully: " + o00ooOoO0
    if oo0O0oo != 1 :
     o0o . write ( '[COLOR=dodgerblue]Non-ASCII File:[/COLOR]\n' )
     for o000Oo0 in o0O0OO0o ( o00ooOoO0 , 75 ) :
      o0o . write ( o000Oo0 + '[CR]' )
     o0o . write ( '\n' )
    if oo0O0oo == 1 :
     try :
      os . remove ( o00ooOoO0 )
      print "### SUCCESS - deleted " + o00ooOoO0
      o0o . write ( '[COLOR=dodgerblue]SUCCESSFULLY DELETED:[/COLOR]\n' )
      for o000Oo0 in o0O0OO0o ( o00ooOoO0 , 75 ) :
       o0o . write ( o000Oo0 + '[CR]' )
      o0o . write ( '\n' )
      if 54 - 54: O00OOOoOoo0O . III1IiiI % i11iIiiIii / OoooooooOO + i11111IIIII % III1IiiI
     except :
      print "######## FAILED TO REMOVE: " + o00ooOoO0
      print "######## Make sure you manually remove this file ##########"
      o00o0O0O00 . write ( '[COLOR=red]FAILED TO DELETE:[/COLOR]\n' )
      for o000Oo0 in o0O0OO0o ( o00ooOoO0 , 75 ) :
       o00o0O0O00 . write ( o000Oo0 + '[CR]' )
      o00o0O0O00 . write ( '\n' )
      if 36 - 36: III1IiiI
 o00o0O0O00 . close ( )
 o0o . close ( )
 if 74 - 74: OoooooooOO
 if 72 - 72: O0 + o0Oo - i1Iii1i1I - ii1ii11IIIiiI
 o0o = open ( O00oO , mode = 'r' )
 o0i1I11iI1iiI = o0o . read ( )
 o0o . close ( )
 o00o0O0O00 = open ( I11i1I1I , mode = 'r' )
 I1ii = o00o0O0O00 . read ( )
 o00o0O0O00 . close ( )
 if o0i1I11iI1iiI == '' and I1ii == '' :
  OOooO0OOoo . ok ( 'No Special Characters Found' , 'Great news, all filenames in the path you scanned are ASCII based - no special characters found.' )
 else :
  oO0o = open ( o0O , mode = 'w+' )
  oO0o . write ( o0i1I11iI1iiI + '\n\n' + I1ii )
  oO0o . close ( )
  I1I1 = open ( o0O , mode = 'r' )
  O0Oo0 = I1I1 . read ( )
  I1I1 . close ( )
  OOooO0OO0 ( 'Final Results' , O0Oo0 )
  os . remove ( o0O )
 os . remove ( O00oO )
 os . remove ( I11i1I1I )
 if 5 - 5: i1Iii1i1I
 if 62 - 62: O00OOOoOoo0O . OoooooooOO . iiIi1i11 . ii1ii11IIIiiI * i1Iii1i1I
def OOOOOo ( ) :
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] How to create and share my build' , '' , 'instructions_1' , '' , '' , '' , 'Back Up Your Full System' )
 oO00oOOoooO ( '' , 'Create [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Community Build (for sharing on CP)' , 'url' , 'community_backup' , '' , '' , '' , 'Back Up Your Full System' )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , 'Create OpenELEC Backup (full backup can only be used on OpenELEC)' , 'none' , 'openelec_backup' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=gold]-----------------------------------------------------------------[/COLOR]' , '' , '' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create Universal Build (local backups only)' , 'none' , 'community_backup_2' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create Full Backup (will only work on THIS device)' , 'local' , 'local_backup' , '' , '' , '' , 'Back Up Your Full System' )
 oO00oOOoooO ( '' , 'Backup Addons Only' , 'addons' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addons' )
 oO00oOOoooO ( '' , 'Backup Addon Data Only' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Back Up Your Addon Userdata' )
 oO00oOOoooO ( '' , 'Backup Guisettings.xml' , I11i1 , 'restore_backup' , '' , '' , '' , 'Back Up Your guisettings.xml' )
 if 77 - 77: iI1IiiIIIiIi / oO0OooOoO - iI1IiiIIIiIi / iiIi1i11
 if os . path . exists ( IIIII ) :
  oO00oOOoooO ( '' , 'Backup Favourites.xml' , IIIII , 'restore_backup' , '' , '' , '' , 'Back Up Your favourites.xml' )
  if 97 - 97: iiIi1i11 / III1IiiI . oO0OooOoO
 if os . path . exists ( ooooooO0oo ) :
  oO00oOOoooO ( '' , 'Backup Source.xml' , ooooooO0oo , 'restore_backup' , '' , '' , '' , 'Back Up Your sources.xml' )
  if 44 - 44: iI1IiiIIIiIi % o00O0OoO . Iiii1i1
 if os . path . exists ( IIiiiiiiIi1I1 ) :
  oO00oOOoooO ( '' , 'Backup Advancedsettings.xml' , IIiiiiiiIi1I1 , 'restore_backup' , '' , '' , '' , 'Back Up Your advancedsettings.xml' )
  if 18 - 18: iIii1I11I1II1 + o00O0OoO * o0Oo - iiIi1i11 / o0Oo
 if os . path . exists ( OOOO ) :
  oO00oOOoooO ( '' , 'Backup Advancedsettings.xml' , OOOO , 'restore_backup' , '' , '' , '' , 'Back Up Your keyboard.xml' )
  if 78 - 78: o00O0OoO . i11111IIIII
 if os . path . exists ( oOoOooOo0o0 ) :
  oO00oOOoooO ( '' , 'Backup RssFeeds.xml' , oOoOooOo0o0 , 'restore_backup' , '' , '' , '' , 'Back Up Your RssFeeds.xml' )
  if 38 - 38: O00OOOoOoo0O + i11111IIIII
  if 15 - 15: II11iIiIIIiI + o00O0OoO . o0oOo0 - iIii1I11I1II1 / O0 % iIii1I11I1II1
def oO0O ( ) :
 oO00oOOoooO ( 'folder' , 'Backup My Content' , 'none' , 'backup_option' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Restore My Content' , 'none' , 'restore_option' , '' , '' , '' , '' )
 if 79 - 79: OoooooooOO - i11111IIIII * i11111IIIII . O00OOOoOoo0O
 if 100 - 100: oO0OooOoO * o00O0OoO % o0Oo / OoooO0Oo0O0
def OOoo0oOO00 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://repos/",return)' )
 if 46 - 46: i11iIiiIii - o00O0OoO
 if 95 - 95: oO0OooOoO
def oo000oO ( localbuildcheck , localversioncheck , id , welcometext , livemsg ) :
 O0OOO0 ( )
 if livemsg != 'none' :
  try :
   exec menuitem
   oO00oOOoooO ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  except :
   pass
 if ( O0oo0OO0 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) :
  oO00oOOoooO ( '' , welcometext , 'show' , 'user_info' , '' , '' , '' , '' )
  if 8 - 8: i11iIiiIii / oO0OooOoO + oOO00Oo * iI1IiiIIIiIi % i11111IIIII . o00O0OoO
  if id != 'None' :
   if 6 - 6: i11111IIIII % II11iIiIIIiI . II11iIiIIIiI - OoooO0Oo0O0 / o00O0OoO . i1IIi
   if id != 'Local' :
    oO0O0oO = IiIII ( localbuildcheck , localversioncheck , id )
    if 13 - 13: oOO00Oo % III1IiiI / Iiii1i1 % Iiii1i1 % O0
    if oO0O0oO == True :
     if 90 - 90: i11111IIIII . o0oOo0 / iIii1I11I1II1
     if not 'Partially installed' in localbuildcheck :
      oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]' + localbuildcheck + ':[/COLOR] [COLOR=lime]NEW VERSION AVAILABLE[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
      if 28 - 28: i11111IIIII + III1IiiI - o0oOo0 / iIii1I11I1II1 - o0Oo
     if '(Partially installed)' in localbuildcheck :
      oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo2' , '' , '' , '' , '' )
    else :
     oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]' + localbuildcheck + '[/COLOR]' , id , 'showinfo' , '' , '' , '' , '' )
     if 45 - 45: O0 / i1IIi * III1IiiI * ii1ii11IIIiiI
   else :
    if 35 - 35: OoooO0Oo0O0 / i1Iii1i1I % o0Oo + iIii1I11I1II1
    if localbuildcheck == 'Incomplete' :
     oO00oOOoooO ( '' , '[COLOR=darkcyan]Your last restore is not yet completed[/COLOR]' , 'url' , oO00o ( ) , '' , '' , '' , '' )
     if 36 - 36: Iiii1i1 . oO0OooOoO % o0oOo0
    else :
     oO00oOOoooO ( '' , '[COLOR=darkcyan]Current Build Installed: [/COLOR][COLOR=dodgerblue]Local Build (' + localbuildcheck + ')[/COLOR]' , '' , '' , '' , '' , '' , '' )
  OoooooooO = 0
  if 4 - 4: II11iIiIIIiI + oOO00Oo
  if os . path . exists ( II ) :
   for i1iIIIi1i in os . listdir ( II ) :
    if i1iIIIi1i != 'Master' :
     OoooooooO += 1
     if 17 - 17: ii1ii11IIIiiI * O00OOOoOoo0O
   if OoooooooO > 1 :
    oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Switch Build Profile[/COLOR]' , localbuildcheck , 'switch_profile_menu' , '' , '' , '' , '' )
    if 15 - 15: i11iIiiIii / o0oOo0 % o0Oo
  oO00oOOoooO ( '' , '[COLOR=orange]---------------------------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 71 - 71: Iiii1i1 / OoooO0Oo0O0 * iIii1I11I1II1
 if oo00 == 'true' and not 'elc' in welcometext :
  oO00oOOoooO ( '' , welcometext , 'None' , 'addon_settings' , '' , '' , '' , '' )
  if 57 - 57: iiIi1i11 + Iiii1i1 % OoooO0Oo0O0 . ii1ii11IIIiiI / ii1ii11IIIiiI * O0
 if not 'elc' in welcometext and not "UNABLE" in welcometext :
  oO00oOOoooO ( '' , welcometext , 'None' , 'register' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=yellow]Settings[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , '' )
 if 6 - 6: i1IIi - oO0OooOoO * oOO00Oo . ii1ii11IIIiiI
 oO00oOOoooO ( 'folder' , 'Install Content' , welcometext , 'install_content' , '' , '' , '' , '' )
 if 68 - 68: oOO00Oo
 if 20 - 20: Iiii1i1 - Iiii1i1
 if 37 - 37: i11111IIIII
 if 37 - 37: II11iIiIIIiI / i11111IIIII * O0
 if 73 - 73: i1Iii1i1I * i1Iii1i1I / o0oOo0
 if 43 - 43: OoooO0Oo0O0 . i1IIi . i11111IIIII + O0 * iI1IiiIIIiIi * O0
 if 41 - 41: OoooO0Oo0O0 + iI1IiiIIIiIi % OoooooooOO . OoooO0Oo0O0 + i1Iii1i1I . i1Iii1i1I
 if i1111 == 'true' :
  oO00oOOoooO ( 'folder' , 'Tutorials' , '' , 'tutorial_root_menu' , '' , '' , '' , '' )
  if 31 - 31: i11iIiiIii + oO0OooOoO . i1Iii1i1I * O00OOOoOoo0O
 if i1 == 'true' :
  oO00oOOoooO ( 'folder' , 'Maintenance' , 'none' , 'tools' , '' , '' , '' , '' )
  if 66 - 66: O00OOOoOoo0O + i1IIi % oO0OooOoO . O0 * OoooO0Oo0O0 % OoooO0Oo0O0
  if 87 - 87: iiIi1i11 + oOO00Oo . i1Iii1i1I - OoooooooOO
def iiiiI1IiI1I1 ( ) :
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 19 - 19: iI1IiiIIIiIi
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 55 - 55: iiIi1i11 % iiIi1i11 / O0 % i1Iii1i1I - oOO00Oo . II11iIiIIIiI
 iiiii1I1III1 = O000OOo00oo ( )
 i1oO00O = i1II1 ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' , 10 )
 if 77 - 77: i11iIiiIii % i1IIi % i11111IIIII
 iIii1 . create ( 'Backing Up Add-ons' , '' , 'Please Wait...' )
 if 15 - 15: iIii1I11I1II1 . O0
 for i1iIIIi1i in os . listdir ( OO0o ) :
  if 70 - 70: iI1IiiIIIiIi . i11iIiiIii % iI1IiiIIIiIi . O0 - iIii1I11I1II1
  if 26 - 26: iiIi1i11
  if not 'totalinstaller' in i1iIIIi1i and not 'plugin.program.tbs' in i1iIIIi1i and not 'packages' in i1iIIIi1i and os . path . isdir ( os . path . join ( OO0o , i1iIIIi1i ) ) :
   if 76 - 76: i1IIi * OoooooooOO * O0 + Iiii1i1 * Iiii1i1
   if 35 - 35: oOO00Oo
   if i1iIIIi1i in i1oO00O and not i1iIIIi1i in iiiii1I1III1 and not 'repo.' in i1iIIIi1i and not 'repository.' in i1iIIIi1i and os . path . isdir ( os . path . join ( OO0o , i1iIIIi1i ) ) :
    if 73 - 73: O0 - OoooO0Oo0O0
    if 2 - 2: oO0OooOoO / Iiii1i1
    if not 'service.xbmc.versioncheck' in i1iIIIi1i and not 'packages' in i1iIIIi1i and os . path . isdir ( os . path . join ( OO0o , i1iIIIi1i ) ) :
     if 54 - 54: i1IIi . o00O0OoO - OoooO0Oo0O0 + o0oOo0 + II11iIiIIIiI / II11iIiIIIiI
     try :
      iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
      os . makedirs ( os . path . join ( i1Oo00 , i1iIIIi1i ) )
      if 22 - 22: o0oOo0 . iIii1I11I1II1
      iiii = os . path . join ( i1Oo00 , i1iIIIi1i , 'addon.xml' )
      o0OO0Oo = os . path . join ( i1Oo00 , i1iIIIi1i , 'default.py' )
      ooOo = open ( os . path . join ( OO0o , i1iIIIi1i , 'addon.xml' ) , mode = 'r' )
      o0oO0OoO0 = ooOo . read ( )
      ooOo . close ( )
      if 12 - 12: iI1IiiIIIiIi
      iI = re . compile ( ' name="(.+?)"' ) . findall ( o0oO0OoO0 )
      Ii1IIi = re . compile ( 'provider-name="(.+?)"' ) . findall ( o0oO0OoO0 )
      Oo = re . compile ( '<addon[\s\S]*?">' ) . findall ( o0oO0OoO0 )
      ii1IIi1ii = re . compile ( '<description[\s\S]*?<\/description>' ) . findall ( o0oO0OoO0 )
      oo00oO0o = iI [ 0 ] if ( len ( iI ) > 0 ) else 'None'
      OOoooO00o0oo0 = Ii1IIi [ 0 ] if ( len ( Ii1IIi ) > 0 ) else 'Anonymous'
      oo0OoOOooO = Oo [ 0 ] if ( len ( Oo ) > 0 ) else 'None'
      oOOoo0000O0o0 = ii1IIi1ii [ 0 ] if ( len ( ii1IIi1ii ) > 0 ) else 'None'
      if 60 - 60: Iiii1i1
      oOO0o00o0Oo0O = '<addon id="' + i1iIIIi1i + '" name="' + oo00oO0o + '" version="0" provider-name="' + OOoooO00o0oo0 + '">'
      O0oii111 = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
      if 41 - 41: ii1ii11IIIiiI - oO0OooOoO + iI1IiiIIIiIi
      if oo0OoOOooO != 'None' :
       II1i11i1iIi11 = o0oO0OoO0 . replace ( oOOoo0000O0o0 , O0oii111 ) . replace ( oo0OoOOooO , oOO0o00o0Oo0O )
       if 11 - 11: III1IiiI + iIii1I11I1II1
      else :
       II1i11i1iIi11 = o0oO0OoO0 . replace ( oOOoo0000O0o0 , O0oii111 )
       if 10 - 10: O0
      I1iI1I1 = open ( iiii , mode = 'w+' )
      I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
      I1iI1I1 . close ( )
      OoOo = open ( o0OO0Oo , mode = 'w+' )
      OoOo . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + i1iIIIi1i + '"\nAddonName="' + oo00oO0o + '"\ndialog=xbmcgui.Dialog()\ndialog.ok(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating so we recommend waiting a few minutes to see if it updates naturally. If it hasn\'t updated after 5mins please try reinstalling via the Community Portal add-on")\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
      OoOo . close ( )
      if 68 - 68: iiIi1i11 + III1IiiI . O0 . iI1IiiIIIiIi % i1IIi % iiIi1i11
     except :
      print "### Failed to backup: " + i1iIIIi1i
      if 50 - 50: i11111IIIII + oOO00Oo
      if 96 - 96: ii1ii11IIIiiI
   else :
    try :
     shutil . copytree ( os . path . join ( OO0o , i1iIIIi1i ) , os . path . join ( i1Oo00 , i1iIIIi1i ) )
    except :
     print "### Failed to copy: " + i1iIIIi1i
     if 92 - 92: II11iIiIIIiI / i11iIiiIii + OoooO0Oo0O0
 iIii1 . close ( )
 if 87 - 87: O00OOOoOoo0O % iIii1I11I1II1
 o0OO0OOO0O = "Creating Backup"
 Iii1I = "Archiving..."
 oOoOOOOoOO0o = ""
 iiI1i1I1II = "Please Wait"
 if 58 - 58: iiIi1i11 . oOO00Oo + o0Oo % II11iIiIIIiI - ii1ii11IIIiiI
 OooOOOO0O0 ( i1Oo00 , i1i , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , '' , '' )
 if 50 - 50: i1Iii1i1I % oO0OooOoO - o0oOo0 . i1IIi + O0 % i1Iii1i1I
 try :
  shutil . rmtree ( i1Oo00 )
  if 10 - 10: i1Iii1i1I . i1IIi + iI1IiiIIIiIi
 except :
  print "### COMMUNITY BUILDS: Failed to remove temp addons folder - manual delete required ###"
  if 66 - 66: ii1ii11IIIiiI % oOO00Oo
  if 21 - 21: O00OOOoOoo0O - OoooooooOO % i11iIiiIii
def Oo00O0OO ( url ) :
 iIii1 . create ( 'Cleaning Temp Paths' , '' , 'Please wait...' )
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 77 - 77: III1IiiI - II11iIiIIIiI - iIii1I11I1II1
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 16 - 16: ii1ii11IIIiiI / i1Iii1i1I / i1IIi . i1Iii1i1I + III1IiiI
 extract . all ( i1i , i1Oo00 , iIii1 )
 if 26 - 26: iIii1I11I1II1 + i1IIi / O00OOOoOoo0O % OoooO0Oo0O0
 for i1iIIIi1i in os . listdir ( i1Oo00 ) :
  if 44 - 44: OoooooooOO . oO0OooOoO . iiIi1i11 % OoooooooOO
  if not 'totalinstaller' in i1iIIIi1i and not 'plugin.program.tbs' in i1iIIIi1i :
   if not os . path . exists ( os . path . join ( OO0o , i1iIIIi1i ) ) :
    os . rename ( os . path . join ( i1Oo00 , i1iIIIi1i ) , os . path . join ( OO0o , i1iIIIi1i ) )
    iIii1 . update ( 0 , "Installing: [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    print "### Successfully installed: " + i1iIIIi1i
    if 86 - 86: i11iIiiIii + O0 * i11111IIIII - ii1ii11IIIiiI * iiIi1i11 + O0
   else :
    print "### " + i1iIIIi1i + " Already exists on system"
    if 95 - 95: iIii1I11I1II1 . Iiii1i1 % i1Iii1i1I - Iiii1i1 * oO0OooOoO
    if 89 - 89: i1Iii1i1I . o0Oo
def ooOoo0OoOO ( welcometext ) :
 II111 ( 'disclaimer.xml' )
 oO00oOOoooO ( 'folder' , 'I have read and understand the disclaimer.' , welcometext , 'CB_Menu' , '' , '' , '' , '' )
 if 94 - 94: i1Iii1i1I % o0oOo0 . III1IiiI
 if 85 - 85: iiIi1i11 * i1IIi % o0Oo - o0oOo0
def I11I1ii1i ( welcometext ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  oOo0O = o0o00oO0oo000 ( )
  II11Ii111II1 = os . path . join ( oOo0O , 'Download' )
  try :
   if not os . path . exists ( II11Ii111II1 ) :
    os . makedirs ( II11Ii111II1 )
  except :
   print "### Failed to make download folder"
   if 72 - 72: i1Iii1i1I % oOO00Oo % III1IiiI + o00O0OoO % i11iIiiIii + O0
  if not os . path . exists ( '/data/data/com.rechild.advancedtaskkiller' ) :
   oo0O0oo = OOooO0OOoo . yesno ( 'Advanced Task Killer Required' , 'To be able to us features such as the backup/restore and community builds you need the Advanced Task Killer app installed. Would you like to download it now?' )
   if oo0O0oo == 1 :
    iIii1 . create ( 'Downloading APK file' , '' , '' , '' )
    try :
     downloader . download ( 'https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk' , os . path . join ( II11Ii111II1 , 'AdvancedTaskKiller.apk' ) )
     OOooO0OOoo . ok ( 'Download Complete' , "The apk file has now been downloaded, you'll find this in your downloads folder. Just install this exactly the same as you would any other apk file - click on it and then click through the setup screen. The file is called AdvancedTaskKiller.apk" )
    except :
     try :
      downloader . download ( 'https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk' , os . path . join ( 'storage' , 'emulated' , 'legacy' , 'Download' , 'AdvancedTaskKiller.apk' ) )
      OOooO0OOoo . ok ( 'Download Complete' , "The AdvancedTaskKiller.apk file has now been downloaded, you'll find this in your downloads folder. You'll need a File Manager app to install this file, we recommend installing ES File Explorer - just do a search for this on your box/stick." )
     except :
      OOooO0OOoo . ok ( 'Download Failed' , 'It wasn\'t possible to download the Advanced Task Killer, without it you will almost certainly run into problems so make sure you get it installed otherwise you\'ll need to manually force close and switching profiles may fail.' )
      if 65 - 65: iIii1I11I1II1 % III1IiiI + O0 / OoooooooOO
      if 52 - 52: iI1IiiIIIiIi % iiIi1i11 * o0Oo % o00O0OoO + iiIi1i11 / i1Iii1i1I
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 oo000o = float ( oO000o [ : 2 ] )
 ii11I1 = int ( oo000o )
 print "#### Welcome: " + welcometext
 if 95 - 95: III1IiiI - o0oOo0 * o00O0OoO / ii1ii11IIIiiI / oO0OooOoO + O0
 if not 'elc' in welcometext :
  oO00oOOoooO ( '' , '[COLOR=orange]To access community builds you must be logged in[/COLOR]' , 'settings' , 'addon_settings' , '' , '' , '' , 'Register at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
  if 37 - 37: o00O0OoO . Iiii1i1 + iiIi1i11 + o00O0OoO . i11111IIIII / iI1IiiIIIiIi
 if o0oOOo0O0Ooo == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show My Private List[/COLOR]' , '&visibility=private' , 'grab_builds' , '' , '' , '' , '' )
  if 29 - 29: i11111IIIII . o0oOo0 - oO0OooOoO
 if ( ( O0oo0OO0 . replace ( '%20' , ' ' ) in welcometext ) and ( 'elc' in welcometext ) ) :
  if 68 - 68: iIii1I11I1II1 + oO0OooOoO / III1IiiI
  if ( ii11I1 < 14 ) or ( iiIIIII1i1iI == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Gotham Compatible Builds[/COLOR]' , '&xbmc=gotham&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 91 - 91: O00OOOoOoo0O % iIii1I11I1II1 . o0Oo
  if ( ii11I1 == 14 ) or ( iiIIIII1i1iI == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Helix Compatible Builds[/COLOR]' , '&xbmc=helix&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 70 - 70: o00O0OoO % oO0OooOoO % O0 . i1IIi / Iiii1i1
  if ( ii11I1 == 15 ) or ( iiIIIII1i1iI == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Isengard Compatible Builds[/COLOR]' , '&xbmc=isengard&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
  if ( ii11I1 == 16 ) or ( iiIIIII1i1iI == 'true' ) :
   oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Show All Jarvis Compatible Builds[/COLOR]' , '&xbmc=jarvis&visibility=public' , 'grab_builds' , '' , '' , '' , '' )
   if 100 - 100: OoooO0Oo0O0 * i11iIiiIii % III1IiiI / II11iIiIIIiI / o0oOo0 + OoooO0Oo0O0
  if Oo0o0000o0o0 == 'false' :
   oO00oOOoooO ( '' , '[COLOR=gold]How to fix builds broken on other wizards![/COLOR]' , '' , 'instructions_5' , '' , '' , '' , '' )
  if oOo0oooo00o != '' and Oo0o0000o0o0 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + oO0o0o0ooO0oO + ' Builds[/COLOR]' , '&id=1' , 'grab_builds' , '' , '' , '' , '' )
  if oo0o0O00 != '' and Oo0o0000o0o0 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + oO + ' Builds[/COLOR]' , '&id=2' , 'grab_builds' , '' , '' , '' , '' )
  if i1iiIIiiI111 != '' and Oo0o0000o0o0 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + oooOOOOO + ' Builds[/COLOR]' , '&id=3' , 'grab_builds' , '' , '' , '' , '' )
  if i1iiIII111ii != '' and Oo0o0000o0o0 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + i1iIIi1 + ' Builds[/COLOR]' , '&id=4' , 'grab_builds' , '' , '' , '' , '' )
  if ii11iIi1I != '' and Oo0o0000o0o0 == 'true' :
   oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]Show ' + iI111I11I1I1 + ' Builds[/COLOR]' , '&id=5' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Create My Own Community Build' , 'url' , 'backup_option' , '' , '' , '' , 'Back Up Your Full System' )
 if 59 - 59: Iiii1i1 - i11111IIIII
 if 14 - 14: iIii1I11I1II1 - iIii1I11I1II1
def i111i1I1ii1i ( skin ) :
 O0Oooo = '<onleft>%s</onleft>'
 I11iI1I = '<onright>%s</onright>'
 Iii1iiIi1II1 = '<onup>%s</onup>'
 Oo000o = '<ondown>%s</ondown>'
 OO00oo = '<control type="button" id="%s">'
 if 84 - 84: o0oOo0 + i11iIiiIii - iiIi1i11 * o0oOo0
 if 33 - 33: o0oOo0 % i1IIi - III1IiiI . O0 / O0
 oo00o0 = [
 ( '65' , '140' ) ,
 ( '66' , '164' ) ,
 ( '67' , '162' ) ,
 ( '68' , '142' ) ,
 ( '69' , '122' ) ,
 ( '70' , '143' ) ,
 ( '71' , '144' ) ,
 ( '72' , '145' ) ,
 ( '73' , '127' ) ,
 ( '74' , '146' ) ,
 ( '75' , '147' ) ,
 ( '76' , '148' ) ,
 ( '77' , '166' ) ,
 ( '78' , '165' ) ,
 ( '79' , '128' ) ,
 ( '80' , '129' ) ,
 ( '81' , '120' ) ,
 ( '82' , '123' ) ,
 ( '83' , '141' ) ,
 ( '84' , '124' ) ,
 ( '85' , '126' ) ,
 ( '86' , '163' ) ,
 ( '87' , '121' ) ,
 ( '88' , '161' ) ,
 ( '89' , '125' ) ,
 ( '90' , '160' ) ]
 if 17 - 17: iI1IiiIIIiIi / iIii1I11I1II1 - ii1ii11IIIiiI + o0Oo % iiIi1i11
 for III1III11II , iIi1iI in oo00o0 :
  OO0Oo = open ( skin ) . read ( )
  IIiiiiiIiIIi = OO0Oo . replace ( OO00oo % III1III11II , OO00oo % iIi1iI ) . replace ( O0Oooo % III1III11II , O0Oooo % iIi1iI ) . replace ( I11iI1I % III1III11II , I11iI1I % iIi1iI ) . replace ( Iii1iiIi1II1 % III1III11II , Iii1iiIi1II1 % iIi1iI ) . replace ( Oo000o % III1III11II , Oo000o % iIi1iI )
  iiI1iii = open ( skin , mode = 'w' )
  iiI1iii . write ( IIiiiiiIiIIi )
  iiI1iii . close ( )
  if 26 - 26: oOO00Oo
def IiIioO0Oo00oo ( u , skin ) :
 O0Oooo = '<onleft>%s</onleft>'
 I11iI1I = '<onright>%s</onright>'
 Iii1iiIi1II1 = '<onup>%s</onup>'
 Oo000o = '<ondown>%s</ondown>'
 OO00oo = '<control type="button" id="%s">'
 if 75 - 75: iIii1I11I1II1 * i11iIiiIii - OoooooooOO . O00OOOoOoo0O
 if u < 49 :
  OOOO0O00Ooooo = u + 61
  if 2 - 2: i1IIi * III1IiiI - III1IiiI + OoooooooOO % O00OOOoOoo0O / O00OOOoOoo0O
 else :
  OOOO0O00Ooooo = u + 51
  if 3 - 3: OoooooooOO
 OO0Oo = open ( skin ) . read ( )
 IIiiiiiIiIIi = OO0Oo . replace ( O0Oooo % u , O0Oooo % OOOO0O00Ooooo ) . replace ( I11iI1I % u , I11iI1I % OOOO0O00Ooooo ) . replace ( Iii1iiIi1II1 % u , Iii1iiIi1II1 % OOOO0O00Ooooo ) . replace ( Oo000o % u , Oo000o % OOOO0O00Ooooo ) . replace ( OO00oo % u , OO00oo % OOOO0O00Ooooo )
 iiI1iii = open ( skin , mode = 'w' )
 iiI1iii . write ( IIiiiiiIiIIi )
 iiI1iii . close ( )
 if 71 - 71: i11111IIIII + i1IIi - i1Iii1i1I - i11iIiiIii . o00O0OoO - o0oOo0
def OOoOOOO00 ( description ) :
 IIii1III = os . path . join ( II , 'extracted' )
 ooooOoo0OO = os . path . join ( II , 'temp' )
 Oo0O0000Oo00o = os . path . join ( IIii1III , 'userdata' , '.cbcfg' )
 II1 = os . path . join ( II , description , 'addonlist' )
 iio00 = open ( II1 , 'w+' )
 iIiiiII = [ ]
 if 5 - 5: OoooooooOO / oOO00Oo % o00O0OoO % ii1ii11IIIiiI * i1Iii1i1I + iIii1I11I1II1
 if not os . path . exists ( os . path . join ( II , description ) ) :
  os . makedirs ( os . path . join ( II , description ) )
  if o0oO0 == 'true' :
   print "### (line 1147) Created: " + os . path . join ( II , description )
 if not os . path . exists ( ooOoOoo0O ) :
  os . makedirs ( ooOoOoo0O )
  if o0oO0 == 'true' :
   print "### (line 1450) Created: " + ooOoOoo0O
 if os . path . exists ( ooooOoo0OO ) :
  shutil . rmtree ( ooooOoo0OO )
  if o0oO0 == 'true' :
   print "### (line 1453) Removed: " + ooooOoo0OO
   if 11 - 11: Iiii1i1 % i11iIiiIii % III1IiiI . i11111IIIII
 if os . path . exists ( Oo0O0000Oo00o ) :
  if not os . path . exists ( ooooOoo0OO ) :
   os . makedirs ( ooooOoo0OO )
   if o0oO0 == 'true' :
    print "### (line 1458) Created: " + ooooOoo0OO
  extract . all ( Oo0O0000Oo00o , ooooOoo0OO , iIii1 )
  print "### NEW STYLE BUILD"
  if o0oO0 == 'true' :
   print "### (line 1461) Extracted " + Oo0O0000Oo00o + " to: " + ooooOoo0OO
 elif os . path . exists ( os . path . join ( IIii1III , 'addons' ) ) :
  os . rename ( os . path . join ( IIii1III , 'addons' ) , ooooOoo0OO )
  print "### OLD BUILD - RENAMED ADDONS FOLDER"
  if o0oO0 == 'true' :
   print "### (line 1465) renamed " + os . path . join ( IIii1III , 'addons' ) + " to " + ooooOoo0OO
   if 92 - 92: oO0OooOoO
 iIii1 . create ( 'Copying Addons' , '' , '' , '' )
 if 45 - 45: O0 % o0Oo - i1Iii1i1I . ii1ii11IIIiiI
 for i1iIIIi1i in os . listdir ( Ooo ) :
  iIiiiII . append ( i1iIIIi1i )
  if 42 - 42: i1Iii1i1I / oOO00Oo + II11iIiIIIiI . II11iIiIIIiI % iiIi1i11
 for i1iIIIi1i in os . listdir ( OO0o ) :
  iIiiiII . append ( i1iIIIi1i )
  if 16 - 16: i1IIi + ii1ii11IIIiiI % O00OOOoOoo0O + iI1IiiIIIiIi * II11iIiIIIiI
 if os . path . exists ( ooOoOoo0O ) :
  for i1iIIIi1i in os . listdir ( ooOoOoo0O ) :
   if not i1iIIIi1i in iIiiiII :
    iIiiiII . append ( i1iIIIi1i )
    if 3 - 3: i11iIiiIii
    if 81 - 81: o0Oo . OoooooooOO * iI1IiiIIIiIi . III1IiiI - O0 * III1IiiI
 if not os . path . exists ( os . path . join ( ooOoOoo0O , 'backups' ) ) :
  os . makedirs ( os . path . join ( ooOoOoo0O , 'backups' ) )
  if o0oO0 == 'true' :
   print "### Created: " + os . path . join ( ooOoOoo0O , 'backups' )
 for i1iIIIi1i in os . listdir ( ooooOoo0OO ) :
  try :
   if 72 - 72: oO0OooOoO - iiIi1i11 + o0Oo - o00O0OoO
   if 91 - 91: oO0OooOoO
   iio00 . write ( i1iIIIi1i + '|' )
   if o0oO0 == 'true' :
    print "### Added: " + os . path . join ( ooOoOoo0O , 'backups' , i1iIIIi1i )
    print "### Added " + i1iIIIi1i + " to " + iio00
  except :
   pass
   if 53 - 53: ii1ii11IIIiiI % oOO00Oo / iiIi1i11 % i11111IIIII % ii1ii11IIIiiI % OoooooooOO
  if not i1iIIIi1i in iIiiiII :
   try :
    os . rename ( os . path . join ( ooooOoo0OO , i1iIIIi1i ) , os . path . join ( ooOoOoo0O , i1iIIIi1i ) )
    iIii1 . update ( 0 , "Configuring" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
    if o0oO0 == 'true' :
     print "### Renamed from " + os . path . join ( ooooOoo0OO , i1iIIIi1i ) + " to " + os . path . join ( ooOoOoo0O , i1iIIIi1i )
   except :
    pass
    if 31 - 31: o0Oo
 iio00 . close ( )
 shutil . rmtree ( ooooOoo0OO )
 shutil . rmtree ( IIii1III )
 if 73 - 73: o0oOo0 . O0 / oOO00Oo - OoooooooOO % i11iIiiIii
 if 80 - 80: iI1IiiIIIiIi / o0oOo0 % O0 . II11iIiIIIiI
def oOiI111I1III ( ) :
 i111IiiI1Ii = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 72 - 72: O0 . O00OOOoOoo0O * II11iIiIIIiI + OoooO0Oo0O0 - oOO00Oo
 if not os . path . exists ( zip ) :
  OOooO0OOoo . ok ( 'Download/Storage Path Check' , 'The download location you have stored does not exist .\nPlease update the addon settings and try again.' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  if 40 - 40: ii1ii11IIIiiI + ii1ii11IIIiiI
  if 94 - 94: i1Iii1i1I * iIii1I11I1II1 . o00O0OoO
def IiiI11I1IIiI ( ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/menu_check'
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1iI1i = re . compile ( 'd="(.+?)"' ) . findall ( OoOO0o )
 o0o0OoO0OOO0 = i1iI1i [ 0 ] if ( len ( i1iI1i ) > 0 ) else ''
 if o0o0OoO0OOO0 != '' :
  return o0o0OoO0OOO0
 else :
  return "none"
  if 79 - 79: III1IiiI % oOO00Oo % O00OOOoOoo0O
  if 45 - 45: o0Oo * iiIi1i11 % ii1ii11IIIiiI
def IiIII ( localbuildcheck , localversioncheck , id ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/Community_Builds/buildupdate.php?id=%s' % ( id )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 24 - 24: o0oOo0 - o00O0OoO * III1IiiI
 if id != 'None' :
  O00OoOoO = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
  ooO0o0oo = O00OoOoO [ 0 ] if ( len ( O00OoOoO ) > 0 ) else ''
  if 79 - 79: i11111IIIII % ii1ii11IIIiiI
  if localversioncheck < ooO0o0oo :
   return True
   if 81 - 81: i11iIiiIii + i11iIiiIii * ii1ii11IIIiiI + i11111IIIII
 else :
  return False
  if 32 - 32: O0 . OoooooooOO
  if 15 - 15: o0Oo . ii1ii11IIIiiI
def oO00o ( ) :
 IiI1i111IiIiIi1 = open ( I1IIiiIiii , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 if 17 - 17: i11iIiiIii / II11iIiIIIiI . ii1ii11IIIiiI / o0Oo
 Ii1 = re . compile ( 'name="(.+?)"' ) . findall ( o0oO0OoO0 )
 oOooOOOOo0o = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
 if 97 - 97: OoooO0Oo0O0 / o0Oo % O0 + i1IIi - o0oOo0
 if oOooOOOOo0o == "Incomplete" :
  oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "Finish Restore Process" , 'If you\'re certain the correct skin has now been set click OK' , 'to finish the install process, once complete XBMC/Kodi will' , ' then close. Do you want to finish the install process?' , yeslabel = 'Yes' , nolabel = 'No' )
  if 38 - 38: oOO00Oo % Iiii1i1 + i11iIiiIii + i1Iii1i1I + o0oOo0 / i11iIiiIii
  if oo0O0oo == 1 :
   o0OOOOOo0 ( )
   if 57 - 57: iIii1I11I1II1 + iIii1I11I1II1
  elif oo0O0oo == 0 :
   return
   if 56 - 56: III1IiiI + o0oOo0
def Ii1Ii1 ( ) :
 i111IiiI1Ii = xbmc . translatePath ( os . path . join ( zip , 'testCBFolder' ) )
 if 35 - 35: i11iIiiIii - III1IiiI % i11iIiiIii
 try :
  os . makedirs ( i111IiiI1Ii )
  os . removedirs ( i111IiiI1Ii )
  OOooO0OOoo . ok ( '[COLOR=lime]SUCCESS[/COLOR]' , 'Great news, the path you chose is writeable.' , 'Some of these builds are rather big, we recommend a minimum of 1GB storage space.' )
  if 48 - 48: ii1ii11IIIiiI % o00O0OoO * oOO00Oo % III1IiiI % i11iIiiIii . i1Iii1i1I
 except :
  OOooO0OOoo . ok ( '[COLOR=red]CANNOT WRITE TO PATH[/COLOR]' , 'Kodi cannot write to the path you\'ve chosen. Please click OK in the settings menu to save the path then try again. Some devices give false results, we recommend using a USB stick as the backup path.' )
  if 68 - 68: i1Iii1i1I + II11iIiIIIiI % iI1IiiIIIiIi / i11iIiiIii % O00OOOoOoo0O
  if 94 - 94: i11iIiiIii / Iiii1i1 / II11iIiIIIiI
def o0O0OO0o ( s , n ) :
 for I1iII in range ( 0 , len ( s ) , n ) :
  yield s [ I1iII : I1iII + n ]
  if 29 - 29: i1IIi % i1Iii1i1I / i11111IIIII + O00OOOoOoo0O - iiIi1i11 - OoooO0Oo0O0
  if 69 - 69: iIii1I11I1II1 . oO0OooOoO . i1IIi - oOO00Oo
def o00OoOO0O0 ( data ) :
 data = data . replace ( '</p><p>' , '[CR][CR]' ) . replace ( '&ndash;' , '-' ) . replace ( '&mdash;' , '-' ) . replace ( "\n" , " " ) . replace ( "\r" , " " ) . replace ( "&rsquo;" , "'" ) . replace ( "&rdquo;" , '"' ) . replace ( "</a>" , " " ) . replace ( "&hellip;" , '...' ) . replace ( "&lsquo;" , "'" ) . replace ( "&ldquo;" , '"' )
 data = " " . join ( data . split ( ) )
 I1i1II1 = re . compile ( r'< script[^<>]*?>.*?< / script >' )
 data = I1i1II1 . sub ( '' , data )
 I1i1II1 = re . compile ( r'< style[^<>]*?>.*?< / style >' )
 data = I1i1II1 . sub ( '' , data )
 I1i1II1 = re . compile ( r'' )
 data = I1i1II1 . sub ( '' , data )
 I1i1II1 = re . compile ( r'<[^<]*?>' )
 data = I1i1II1 . sub ( '' , data )
 data = data . replace ( '&nbsp;' , ' ' )
 return data
 if 89 - 89: ii1ii11IIIiiI / ii1ii11IIIiiI
def iIIIiiiiIiI1III ( ) :
 if 26 - 26: i1IIi
 i111IiiI1Ii = xbmc . translatePath ( 'special://home/userdata/Database' )
 I1iiIi111I = glob . glob ( os . path . join ( i111IiiI1Ii , 'Textures*.db' ) )
 i111I1 = 0
 OooIi = ''
 if 92 - 92: III1IiiI / iiIi1i11 . OoooO0Oo0O0
 if 30 - 30: iI1IiiIIIiIi . OoooO0Oo0O0 / iiIi1i11
 for file in I1iiIi111I :
  i1II11IiiiI = int ( re . compile ( 'extures(.+?).db' ) . findall ( file ) [ 0 ] )
  if i111I1 < i1II11IiiiI :
   i111I1 = i1II11IiiiI
   OooIi = file
   if 7 - 7: OoooO0Oo0O0 / oO0OooOoO - o00O0OoO + i1IIi + iI1IiiIIIiIi
 i11i11i = xbmc . translatePath ( OooIi )
 iiI1iI = database . connect ( i11i11i , timeout = 10 , detect_types = database . PARSE_DECLTYPES , check_same_thread = False )
 iiI1iI . row_factory = database . Row
 Ooo00O0 = iiI1iI . cursor ( )
 if 70 - 70: o0Oo - o0oOo0 - ii1ii11IIIiiI - O00OOOoOoo0O . i11iIiiIii % i1IIi
 if 1 - 1: III1IiiI / i1IIi
 O0oo0 = datetime . datetime . today ( ) - datetime . timedelta ( days = 14 )
 iii1iiii11I = 10
 if 56 - 56: i1Iii1i1I . Iiii1i1
 if 3 - 3: iI1IiiIIIiIi + Iiii1i1 . i1IIi / iiIi1i11 % Iiii1i1
 O0oo00oOOO0o = [ ]
 II1i = [ ]
 if 6 - 6: i11111IIIII * i11111IIIII * O0 / iiIi1i11 + O0
 Ooo00O0 . execute ( "SELECT idtexture FROM sizes WHERE usecount < ? AND lastusetime < ?" , ( iii1iiii11I , str ( O0oo0 ) ) )
 if 51 - 51: oOO00Oo - O00OOOoOoo0O + II11iIiIIIiI / o00O0OoO % O00OOOoOoo0O
 for iIiii1Ii1I1II in Ooo00O0 :
  O0oo00oOOO0o . append ( iIiii1Ii1I1II [ "idtexture" ] )
  if 14 - 14: ii1ii11IIIiiI
 for id in O0oo00oOOO0o :
  Ooo00O0 . execute ( "SELECT cachedurl FROM texture WHERE id = ?" , ( id , ) )
  for iIiii1Ii1I1II in Ooo00O0 :
   II1i . append ( iIiii1Ii1I1II [ "cachedurl" ] )
   if 36 - 36: III1IiiI + O00OOOoOoo0O + i1Iii1i1I + o0Oo
 print "### Community Portal Automatic Cache Removal: %d Old Textures removed" % len ( II1i )
 if 39 - 39: III1IiiI / II11iIiIIIiI
 if 9 - 9: III1IiiI - Iiii1i1 % O0 . i1IIi . o0Oo / o0Oo
 for id in O0oo00oOOO0o :
  Ooo00O0 . execute ( "DELETE FROM sizes   WHERE idtexture = ?" , ( id , ) )
  Ooo00O0 . execute ( "DELETE FROM texture WHERE id        = ?" , ( id , ) )
  if 82 - 82: o00O0OoO / o0oOo0 * o00O0OoO % i11iIiiIii * oO0OooOoO
 Ooo00O0 . execute ( "VACUUM" )
 iiI1iI . commit ( )
 Ooo00O0 . close ( )
 if 83 - 83: ii1ii11IIIiiI + iiIi1i11 - oOO00Oo + iIii1I11I1II1 % II11iIiIIIiI
 if 23 - 23: oOO00Oo + iI1IiiIIIiIi % O00OOOoOoo0O % o0Oo % OoooooooOO
 OOOOoo00OO0O0Ooo0 = xbmc . translatePath ( 'special://home/userdata/Thumbnails' )
 for ooOOO00oOOooO in II1i :
  i111IiiI1Ii = os . path . join ( OOOOoo00OO0O0Ooo0 , ooOOO00oOOooO )
  try :
   os . remove ( i111IiiI1Ii )
  except :
   pass
   if 46 - 46: iIii1I11I1II1 . i11iIiiIii - O00OOOoOoo0O % O0 / oO0OooOoO * i1IIi
   if 66 - 66: O0
   if 52 - 52: ii1ii11IIIiiI * OoooooooOO
def O0OOO0 ( ) :
 if os . path . exists ( os . path . join ( II , 'extracted' ) ) :
  try :
   shutil . rmtree ( os . path . join ( II , 'extracted' ) )
  except :
   print "### Unsuccessful Community Build Install detected, unabled to remove extracted folder"
   if 12 - 12: O0 + i11111IIIII * i1IIi . ii1ii11IIIiiI
 if os . path . exists ( os . path . join ( II , 'temp' ) ) :
  try :
   shutil . rmtree ( os . path . join ( II , 'temp' ) )
  except :
   print "### Unsuccessful Community Build Install detected, unabled to remove temp folder"
   if 71 - 71: Iiii1i1 - oOO00Oo - iiIi1i11
   if 28 - 28: iIii1I11I1II1
def iI11II1i1I1 ( ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Clear All Known Cache?' , 'This will clear all known cache files and can help if you\'re encountering kick-outs during playback as well as other random issues. There is no harm in using this.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 72 - 72: i1Iii1i1I - OoooooooOO
 if oo0O0oo == 1 :
  II1iII1i1i ( )
  o00oO0O0oo0o ( )
  if 46 - 46: O00OOOoOoo0O - O0
  if 70 - 70: o00O0OoO + II11iIiIIIiI * iIii1I11I1II1 . o0Oo * o00O0OoO
def ii1i11ii ( url ) :
 oO00oOOoooO ( 'folder' , 'African' , str ( url ) + '&genre=african' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Arabic' , str ( url ) + '&genre=arabic' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Asian' , str ( url ) + '&genre=asian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Australian' , str ( url ) + '&genre=australian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Austrian' , str ( url ) + '&genre=austrian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Belgian' , str ( url ) + '&genre=belgian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Brazilian' , str ( url ) + '&genre=brazilian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Canadian' , str ( url ) + '&genre=canadian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Columbian' , str ( url ) + '&genre=columbian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Czech' , str ( url ) + '&genre=czech' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Danish' , str ( url ) + '&genre=danish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dominican' , str ( url ) + '&genre=dominican' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Dutch' , str ( url ) + '&genre=dutch' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Egyptian' , str ( url ) + '&genre=egyptian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Filipino' , str ( url ) + '&genre=filipino' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Finnish' , str ( url ) + '&genre=finnish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'French' , str ( url ) + '&genre=french' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'German' , str ( url ) + '&genre=german' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Greek' , str ( url ) + '&genre=greek' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hebrew' , str ( url ) + '&genre=hebrew' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Hungarian' , str ( url ) + '&genre=hungarian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Icelandic' , str ( url ) + '&genre=icelandic' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Indian' , str ( url ) + '&genre=indian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Irish' , str ( url ) + '&genre=irish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Italian' , str ( url ) + '&genre=italian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Japanese' , str ( url ) + '&genre=japanese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Korean' , str ( url ) + '&genre=korean' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Lebanese' , str ( url ) + '&genre=lebanese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Mongolian' , str ( url ) + '&genre=mongolian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Nepali' , str ( url ) + '&genre=nepali' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'New Zealand' , str ( url ) + '&genre=newzealand' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Norwegian' , str ( url ) + '&genre=norwegian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Pakistani' , str ( url ) + '&genre=pakistani' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Polish' , str ( url ) + '&genre=polish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Portuguese' , str ( url ) + '&genre=portuguese' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Romanian' , str ( url ) + '&genre=romanian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Russian' , str ( url ) + '&genre=russian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Singapore' , str ( url ) + '&genre=singapore' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Spanish' , str ( url ) + '&genre=spanish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swedish' , str ( url ) + '&genre=swedish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Swiss' , str ( url ) + '&genre=swiss' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Syrian' , str ( url ) + '&genre=syrian' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Tamil' , str ( url ) + '&genre=tamil' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Thai' , str ( url ) + '&genre=thai' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Turkish' , str ( url ) + '&genre=turkish' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'UK' , str ( url ) + '&genre=uk' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'USA' , str ( url ) + '&genre=usa' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Vietnamese' , str ( url ) + '&genre=vietnamese' , 'grab_builds' , '' , '' , '' , '' )
 if 11 - 11: II11iIiIIIiI - O0
 if 77 - 77: II11iIiIIIiI . i11iIiiIii / i1IIi % i1Iii1i1I % i1Iii1i1I
def OOooo000OooO ( ) :
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
 o0o0OoOo = 1
 oOiI111I1III ( )
 oo0O0oo = OOooO0OOoo . yesno ( 'Are you sure?!!!' , 'This is method is very dated and is only left here for LOCAL installs. For online backups you really should be using the NaN backup option which creates a much smaller file and allows for a much more reliable install process.' )
 if oo0O0oo == 0 :
  return
 IiI1 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
 iiIiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 IIiiiI1iI = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 100 - 100: o0oOo0 / o0oOo0 - iiIi1i11 % iiIi1i11 * III1IiiI / i11111IIIII
 if not os . path . exists ( IiI1 ) :
  os . makedirs ( IiI1 )
  if 32 - 32: o0Oo + OoooO0Oo0O0 - III1IiiI + OoooO0Oo0O0 / i1IIi * III1IiiI
 o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
 if ( not o0OoOoooo0 ) :
  return False , 0
  if 85 - 85: oOO00Oo / Iiii1i1
 o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
 ooO0 = xbmc . translatePath ( os . path . join ( IiI1 , o0OOoOo0oo + '.zip' ) )
 o0Iiii = [ o0OO00 ]
 I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 i1111iI1 = [ o0OO00 , 'cache' , 'system' , 'Thumbnails' , "peripheral_data" , 'library' , 'keymaps' ]
 Oo0oOOOOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
 o0OO0OOO0O = "Creating full backup of existing build"
 iii = "Creating Community Build"
 Iii1I = "Archiving..."
 oOoOOOOoOO0o = ""
 iiI1i1I1II = "Please Wait"
 if 51 - 51: Iiii1i1 + o0oOo0 * O00OOOoOoo0O + OoooO0Oo0O0 - ii1ii11IIIiiI
 if i1i1II == 'true' :
  OooOOOO0O0 ( oOOoO0 , iiIiII , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
  if 4 - 4: OoooO0Oo0O0 + ii1ii11IIIiiI / Iiii1i1 / oOO00Oo % iiIi1i11 + iiIi1i11
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
 if 66 - 66: i1IIi % i1Iii1i1I . iiIi1i11 - III1IiiI % O00OOOoOoo0O / iiIi1i11
 if oo0O0oo == 0 :
  i1111iI1 = [ o0OO00 , 'cache' , 'system' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
  if 26 - 26: i1Iii1i1I * iI1IiiIIIiIi . Iiii1i1 - II11iIiIIIiI
 elif oo0O0oo == 1 :
  pass
  if 59 - 59: OoooooooOO - i1Iii1i1I + o0Oo / iiIi1i11 * o0Oo + ii1ii11IIIiiI
 OO0 ( oOOoO0 )
 OooOOOO0O0 ( oOOoO0 , ooO0 , iii , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , i1111iI1 , Oo0oOOOOo )
 time . sleep ( 1 )
 if 35 - 35: o00O0OoO
 o00oo = xbmc . translatePath ( os . path . join ( IiI1 , o0OOoOo0oo + '_guisettings.zip' ) )
 O0oO0oo0O = zipfile . ZipFile ( o00oo , mode = 'w' )
 if 82 - 82: OoooooooOO . iI1IiiIIIiIi
 try :
  O0oO0oo0O . write ( I11i1 , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
 except :
  o0o0OoOo = 0
  if 26 - 26: III1IiiI + i11111IIIII - oO0OooOoO . oO0OooOoO + OoooO0Oo0O0 + O00OOOoOoo0O
 try :
  O0oO0oo0O . write ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
 except :
  pass
  if 68 - 68: O0
 O0oO0oo0O . close ( )
 if 76 - 76: OoooO0Oo0O0
 if i1i1II == 'true' :
  ooO000OO = zipfile . ZipFile ( IIiiiI1iI , mode = 'w' )
  try :
   ooO000OO . write ( I11i1 , 'guisettings.xml' , zipfile . ZIP_DEFLATED )
  except :
   o0o0OoOo = 0
   if 43 - 43: o0oOo0 * Iiii1i1 % iiIi1i11
  try :
   ooO000OO . write ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , 'profiles.xml' , zipfile . ZIP_DEFLATED )
  except :
   pass
  ooO000OO . close ( )
  if 38 - 38: II11iIiIIIiI
 if o0o0OoOo == 0 :
  OOooO0OOoo . ok ( "FAILED!" , 'The guisettings.xml file could not be found on your system, please reboot and try again.' , '' , '' )
  if 34 - 34: O00OOOoOoo0O
 else :
  OOooO0OOoo . ok ( "SUCCESS!" , 'You Are Now Backed Up. Remember this should only be used for local backup purposes and is not recommended for sharing online. Use the far superior NaN CP backup method for online use.' )
  if 70 - 70: iIii1I11I1II1 * i11111IIIII - iiIi1i11 / II11iIiIIIiI % III1IiiI
  if i1i1II == 'true' :
   OOooO0OOoo . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + iiIiII , '[/COLOR]Universal Backup: [COLOR=dodgerblue]' + ooO0 + '[/COLOR]' )
   if 66 - 66: OoooooooOO + o0oOo0 * i1Iii1i1I
  else :
   OOooO0OOoo . ok ( "Build Location" , 'Universal Backup:[CR][COLOR=dodgerblue]' + ooO0 + '[/COLOR]' )
   if 2 - 2: i1Iii1i1I . ii1ii11IIIiiI / III1IiiI
   if 41 - 41: ii1ii11IIIiiI . Iiii1i1 * i11111IIIII * Iiii1i1
def ooOO ( ) :
 oOiI111I1III ( )
 if 86 - 86: iI1IiiIIIiIi . iiIi1i11 / i11111IIIII - OoooooooOO
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
  if 45 - 45: iiIi1i11
 oo0O0oo = OOooO0OOoo . yesno ( 'Create noobsandnerds Build' , 'This backup will only work if you share your build on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal with the rest of the community. It will not work with any other installer/wizard, do you wish to continue?' )
 if 25 - 25: iiIi1i11 % O0
 if oo0O0oo == 1 :
  iIii1 . create ( 'Checking File Structure' , '' , 'Please wait' , '' )
  if not os . path . exists ( oO0Oo ) :
   os . makedirs ( oO0Oo )
   if 44 - 44: Iiii1i1 . iI1IiiIIIiIi * oO0OooOoO / i11111IIIII + iIii1I11I1II1
  o0o0OoOo = 1
  IiI1 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
  iiIiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
  IIiiiI1iI = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
  if 14 - 14: O0 % i11111IIIII % iI1IiiIIIiIi * III1IiiI
  if not os . path . exists ( IiI1 ) :
   os . makedirs ( IiI1 )
   if 65 - 65: o00O0OoO % III1IiiI + OoooO0Oo0O0
  o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
  if 86 - 86: iIii1I11I1II1 / O0 . Iiii1i1 % iIii1I11I1II1 % II11iIiIIIiI
  if ( not o0OoOoooo0 ) :
   return False , 0
   if 86 - 86: i11iIiiIii - oOO00Oo . o0oOo0 * II11iIiIIIiI / iI1IiiIIIiIi % oOO00Oo
  o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
  ooO0 = xbmc . translatePath ( os . path . join ( IiI1 , o0OOoOo0oo + '.zip' ) )
  if 61 - 61: oOO00Oo + O00OOOoOoo0O
  if 15 - 15: O00OOOoOoo0O * III1IiiI + iiIi1i11 . o00O0OoO % o0Oo - o0oOo0
  o0Iiii = [ o0OO00 ]
  I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
  i1111iI1 = [ o0OO00 , 'cache' , 'system' , 'addons' , 'Thumbnails' , 'CP_Profiles' , "peripheral_data" , 'library' , 'keymaps' , 'script.module.metahandler' , 'script.artistslideshow' , 'ArtistSlideshow' ]
  Oo0oOOOOo = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , "Textures13.db" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'advancedsettings.xml' , 'Thumbs.db' , '.gitignore' ]
  o0OO0OOO0O = "Creating full backup of existing build"
  iii = "Creating Community Build"
  Iii1I = "Archiving..."
  oOoOOOOoOO0o = ""
  iiI1i1I1II = "Please Wait"
  if 13 - 13: O00OOOoOoo0O % O00OOOoOoo0O % II11iIiIIIiI % o0Oo * i1IIi % o00O0OoO
  if 82 - 82: i11111IIIII . O00OOOoOoo0O / o0oOo0 + i1Iii1i1I - o0oOo0
  if i1i1II == 'true' :
   OooOOOO0O0 ( oOOoO0 , iiIiII , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
   if 55 - 55: o0oOo0 % II11iIiIIIiI % oOO00Oo
  oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "Do you want to include your addon_data folder?" , 'This contains ALL addon settings including passwords but may also contain important information such as skin shortcuts. We recommend MANUALLY removing the addon_data folders that aren\'t required.' , yeslabel = 'Yes' , nolabel = 'No' )
  if 29 - 29: i11111IIIII / iIii1I11I1II1 + OoooO0Oo0O0 % i1Iii1i1I % o00O0OoO
  if 46 - 46: iIii1I11I1II1
  if oo0O0oo == 0 :
   i1111iI1 = [ o0OO00 , 'cache' , 'system' , 'addons' , 'peripheral_data' , 'library' , 'keymaps' , 'addon_data' , 'Thumbnails' ]
   if 70 - 70: i1IIi . o00O0OoO
  elif oo0O0oo == 1 :
   pass
   if 74 - 74: o00O0OoO
   if 58 - 58: iIii1I11I1II1 * ii1ii11IIIiiI * Iiii1i1 * o0oOo0 . OoooooooOO
  iiiiI1IiI1I1 ( )
  OO0 ( oOOoO0 )
  OooOOOO0O0 ( oOOoO0 , ooO0 , iii , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , i1111iI1 , Oo0oOOOOo )
  if 6 - 6: OoooO0Oo0O0 - III1IiiI * i11iIiiIii + O00OOOoOoo0O / o0oOo0 % iiIi1i11
  if 38 - 38: iiIi1i11 % i11111IIIII % oO0OooOoO - II11iIiIIIiI - iIii1I11I1II1
  try :
   os . remove ( i1i )
  except :
   pass
   if 9 - 9: oOO00Oo % OoooO0Oo0O0 . OoooO0Oo0O0
  try :
   os . remove ( i1Oo00 )
  except :
   pass
   if 28 - 28: OoooooooOO % III1IiiI + OoooO0Oo0O0 + O0 . Iiii1i1
  time . sleep ( 1 )
  if 80 - 80: i11iIiiIii % OoooO0Oo0O0
  if 54 - 54: oOO00Oo + o00O0OoO - iIii1I11I1II1 % o0oOo0 % i11111IIIII
  o00oo = xbmc . translatePath ( os . path . join ( IiI1 , o0OOoOo0oo + '_guisettings.zip' ) )
  if 19 - 19: OoooO0Oo0O0 / iIii1I11I1II1 % i1IIi . OoooooooOO
  try :
   shutil . copyfile ( I11i1 , os . path . join ( oO0Oo , 'guisettings.xml' ) )
   if o0oO0 == 'true' :
    print "### Successfully copied guisettings to : " + os . path . join ( oO0Oo , 'guisettings.xml' )
  except :
   if o0oO0 == 'true' :
    print "### FAILED TO copy guisettings to : " + os . path . join ( oO0Oo , 'guisettings.xml' )
   o0o0OoOo = 0
   if 57 - 57: o0oOo0 . II11iIiIIIiI - ii1ii11IIIiiI - i11iIiiIii * Iiii1i1 / oOO00Oo
  try :
   shutil . copyfile ( xbmc . translatePath ( os . path . join ( oOOoO0 , 'userdata' , 'profiles.xml' ) ) , xbmc . translatePath ( os . path . join ( oO0Oo , 'profiles.xml' ) ) )
   print "### Successfully copied profiles to : " + os . path . join ( oO0Oo , 'profiles.xml' )
  except :
   pass
   if 79 - 79: OoooO0Oo0O0 + oOO00Oo % II11iIiIIIiI * oOO00Oo
  iiii11IiIiI = os . path . join ( iiI1IiI , 'script.skinshortcuts' )
  if os . path . exists ( iiii11IiIiI ) :
   try :
    shutil . copytree ( os . path . join ( iiI1IiI , 'script.skinshortcuts' ) , os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' ) )
    if o0oO0 == 'true' :
     print "### Successfully copied skinshortcuts to : " + os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' )
   except :
    OOooO0OOoo . ok ( 'Failed to copy Skin Shortcuts' , 'There was an error trying to backup your script.skinshortcuts, please try again and if you continue to receive this message upload a log and send details to the noobsandnerds forum.' )
    if o0oO0 == 'true' :
     print "### FAILED to copy skinshortcuts to: " + os . path . join ( oO0Oo , 'addon_data' , 'script.skinshortcuts' )
     if 8 - 8: Iiii1i1 + ii1ii11IIIiiI
  if os . path . exists ( os . path . join ( iiI1IiI , OOOO0OOoO0O0 ) ) :
   try :
    shutil . copytree ( os . path . join ( iiI1IiI , OOOO0OOoO0O0 ) , os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 ) )
    if o0oO0 == 'true' :
     print "### Successfully copied skin data to : " + os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 )
   except :
    OOooO0OOoo . ok ( 'Failed to copy skin data' , 'There was an error trying to backup your skin data, please try again and if you continue to receive this message upload a log and send details to the noobsandnerds forum.' )
    if o0oO0 == 'true' :
     print "### FAILED to copy skin data to: " + os . path . join ( oO0Oo , 'addon_data' , OOOO0OOoO0O0 )
     if 9 - 9: iiIi1i11 + oOO00Oo
  Ii1ii11IIIi ( oO0Oo , o00oo )
  if 8 - 8: iiIi1i11 * II11iIiIIIiI / i1Iii1i1I - ii1ii11IIIiiI - OoooooooOO
  if 100 - 100: III1IiiI . iIii1I11I1II1 . iIii1I11I1II1
  if 55 - 55: III1IiiI
  if 37 - 37: i11111IIIII / i11iIiiIii / II11iIiIIIiI
  if i1i1II == 'true' :
   Ii1ii11IIIi ( oO0Oo , IIiiiI1iI )
   if 97 - 97: Iiii1i1 . o00O0OoO / o0Oo
   if 83 - 83: o00O0OoO - OoooO0Oo0O0 * III1IiiI
  if os . path . exists ( oO0Oo ) :
   shutil . rmtree ( oO0Oo )
   if 90 - 90: II11iIiIIIiI * o0Oo
  if o0o0OoOo == 0 :
   OOooO0OOoo . ok ( 'ERROR' , 'There was an error backing up your guisettings.xml, you cannot share a build without one so please try again. If this keeps happening please upload a log and contact the noobsandnerds forum with details.' )
   if 75 - 75: OoooO0Oo0O0 - O00OOOoOoo0O * i11iIiiIii . OoooooooOO - II11iIiIIIiI . o00O0OoO
  else :
   OOooO0OOoo . ok ( "SUCCESS!" , 'You Are Now Backed Up and can share this build with the community.' )
   if 6 - 6: o00O0OoO * III1IiiI / OoooooooOO % iI1IiiIIIiIi * oOO00Oo
   if i1i1II == 'true' :
    OOooO0OOoo . ok ( "Build Locations" , 'Full Backup (only used to restore on this device): [COLOR=dodgerblue]' + iiIiII , '[/COLOR]Universal Backup (this will ONLY work for sharing on the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] portal):[CR][COLOR=dodgerblue]' + ooO0 + '[/COLOR]' )
    if 28 - 28: i11111IIIII * o0Oo % i11111IIIII
   else :
    OOooO0OOoo . ok ( "Build Location" , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Backup (this will ONLY work for sharing on the Community Portal):[CR][COLOR=dodgerblue]' + ooO0 + '[/COLOR]' )
    if 95 - 95: O0 / o00O0OoO . Iiii1i1
    if 17 - 17: o00O0OoO
def o0OO0OO000OO ( url , video ) :
 O0OOO0 ( )
 I1II1I11I1I = 'http://noobsandnerds.com/TI/Community_Builds/community_builds_premium.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 O00o0000OO = re . compile ( 'path="(.+?)"' ) . findall ( OoOO0o )
 O0Ooo0O0OO = re . compile ( 'myart="(.+?)"' ) . findall ( OoOO0o )
 iiI1iiii1Iii = re . compile ( 'artpack="(.+?)"' ) . findall ( OoOO0o )
 OO0O0Ooo = re . compile ( 'videopreview="(.+?)"' ) . findall ( OoOO0o )
 OoOOOOOoOo0 = re . compile ( 'videoguide1="(.+?)"' ) . findall ( OoOO0o )
 iIi = re . compile ( 'videoguide2="(.+?)"' ) . findall ( OoOO0o )
 oOo = re . compile ( 'videoguide3="(.+?)"' ) . findall ( OoOO0o )
 ooOo0o = re . compile ( 'videoguide4="(.+?)"' ) . findall ( OoOO0o )
 III = re . compile ( 'videoguide5="(.+?)"' ) . findall ( OoOO0o )
 IiiI = re . compile ( 'videolabel1="(.+?)"' ) . findall ( OoOO0o )
 OoOoO00o00 = re . compile ( 'videolabel2="(.+?)"' ) . findall ( OoOO0o )
 OOooooO0o0O0 = re . compile ( 'videolabel3="(.+?)"' ) . findall ( OoOO0o )
 oO0ooo00o0o000Oo = re . compile ( 'videolabel4="(.+?)"' ) . findall ( OoOO0o )
 Oooo00OOo = re . compile ( 'videolabel5="(.+?)"' ) . findall ( OoOO0o )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 iIiII = re . compile ( 'author="(.+?)"' ) . findall ( OoOO0o )
 O00O = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
 ii1IIi1ii = re . compile ( 'description="(.+?)"' ) . findall ( OoOO0o )
 OooOO = re . compile ( 'DownloadURL="(.+?)"' ) . findall ( OoOO0o )
 iio0oo0Oo = re . compile ( 'UpdateURL="(.+?)"' ) . findall ( OoOO0o )
 i1i1I1II = re . compile ( 'UpdateDate="(.+?)"' ) . findall ( OoOO0o )
 o0o0oO = re . compile ( 'UpdateDesc="(.+?)"' ) . findall ( OoOO0o )
 IiIIi1 = re . compile ( 'updated="(.+?)"' ) . findall ( OoOO0o )
 O00o = re . compile ( 'defaultskin="(.+?)"' ) . findall ( OoOO0o )
 o0o0ooOo00 = re . compile ( 'skins="(.+?)"' ) . findall ( OoOO0o )
 OO00oO0OoO0o = re . compile ( 'videoaddons="(.+?)"' ) . findall ( OoOO0o )
 I11I111i1I1 = re . compile ( 'audioaddons="(.+?)"' ) . findall ( OoOO0o )
 iii1 = re . compile ( 'programaddons="(.+?)"' ) . findall ( OoOO0o )
 O0Ooo0O = re . compile ( 'pictureaddons="(.+?)"' ) . findall ( OoOO0o )
 iii1oOo0OoOOOo0 = re . compile ( 'sources="(.+?)"' ) . findall ( OoOO0o )
 OOoo00 = re . compile ( 'adult="(.+?)"' ) . findall ( OoOO0o )
 I1I1O0O = re . compile ( 'guisettings="(.+?)"' ) . findall ( OoOO0o )
 OO0ooO00o = re . compile ( 'thumb="(.+?)"' ) . findall ( OoOO0o )
 I1iii1 = re . compile ( 'fanart="(.+?)"' ) . findall ( OoOO0o )
 iIiiiIIiii = re . compile ( 'openelec="(.+?)"' ) . findall ( OoOO0o )
 if 91 - 91: oOO00Oo . i1Iii1i1I % II11iIiIIIiI - i1Iii1i1I . III1IiiI % i11iIiiIii
 iIiO0O = O0Ooo0O0OO [ 0 ] if ( len ( O0Ooo0O0OO ) > 0 ) else ''
 oOOoooo = iiI1iiii1Iii [ 0 ] if ( len ( iiI1iiii1Iii ) > 0 ) else ''
 i111IiiI1Ii = O00o0000OO [ 0 ] if ( len ( O00o0000OO ) > 0 ) else ''
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 O0oIi1iIiIi1I11 = iIiII [ 0 ] if ( len ( iIiII ) > 0 ) else ''
 ii11I1 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 O0oii111 = ii1IIi1ii [ 0 ] if ( len ( ii1IIi1ii ) > 0 ) else 'No information available'
 IIIIIo0ooOoO000oO = IiIIi1 [ 0 ] if ( len ( IiIIi1 ) > 0 ) else ''
 ii1I11 = O00o [ 0 ] if ( len ( O00o ) > 0 ) else ''
 OOO0 = o0o0ooOo00 [ 0 ] if ( len ( o0o0ooOo00 ) > 0 ) else ''
 I1Ii1 = OO00oO0OoO0o [ 0 ] if ( len ( OO00oO0OoO0o ) > 0 ) else ''
 O0oo0oOoO00 = I11I111i1I1 [ 0 ] if ( len ( I11I111i1I1 ) > 0 ) else ''
 i1ii1iIi = iii1 [ 0 ] if ( len ( iii1 ) > 0 ) else ''
 I1I1Ii = O0Ooo0O [ 0 ] if ( len ( O0Ooo0O ) > 0 ) else ''
 iI1IIII1 = iii1oOo0OoOOOo0 [ 0 ] if ( len ( iii1oOo0OoOOOo0 ) > 0 ) else ''
 Oo0o = OOoo00 [ 0 ] if ( len ( OOoo00 ) > 0 ) else ''
 OoO000oo000o0 = I1I1O0O [ 0 ] if ( len ( I1I1O0O ) > 0 ) else 'None'
 i1Ii1I1Ii11iI = OooOO [ 0 ] if ( len ( OooOO ) > 0 ) else 'None'
 i1ii111i = iio0oo0Oo [ 0 ] if ( len ( iio0oo0Oo ) > 0 ) else 'None'
 i1ii1i1Ii11 = i1i1I1II [ 0 ] if ( len ( i1i1I1II ) > 0 ) else 'None'
 O0O0Oo0O0oo = o0o0oO [ 0 ] if ( len ( o0o0oO ) > 0 ) else 'None'
 i1i1i1I = OO0O0Ooo [ 0 ] if ( len ( OO0O0Ooo ) > 0 ) else 'None'
 OooOo00o = OoOOOOOoOo0 [ 0 ] if ( len ( OoOOOOOoOo0 ) > 0 ) else 'None'
 IiI11i1IIiiI = iIi [ 0 ] if ( len ( iIi ) > 0 ) else 'None'
 oOOo000oOoO0 = oOo [ 0 ] if ( len ( oOo ) > 0 ) else 'None'
 OoOo00o0OO = ooOo0o [ 0 ] if ( len ( ooOo0o ) > 0 ) else 'None'
 ii1IIIIiI11 = III [ 0 ] if ( len ( III ) > 0 ) else 'None'
 I1iii = IiiI [ 0 ] if ( len ( IiiI ) > 0 ) else 'None'
 oO0o0O0Ooo0o = OoOoO00o00 [ 0 ] if ( len ( OoOoO00o00 ) > 0 ) else 'None'
 i1Ii11II = OOooooO0o0O0 [ 0 ] if ( len ( OOooooO0o0O0 ) > 0 ) else 'None'
 IioO0oOOO0Ooo = oO0ooo00o0o000Oo [ 0 ] if ( len ( oO0ooo00o0o000Oo ) > 0 ) else 'None'
 i1i1I = Oooo00OOo [ 0 ] if ( len ( Oooo00OOo ) > 0 ) else 'None'
 oo0O0o = OO0ooO00o [ 0 ] if ( len ( OO0ooO00o ) > 0 ) else 'None'
 OO0oIiII1iiI = I1iii1 [ 0 ] if ( len ( I1iii1 ) > 0 ) else 'None'
 o0O0 = iIiiiIIiii [ 0 ] if ( len ( iIiiiIIiii ) > 0 ) else 'None'
 if 82 - 82: III1IiiI / OoooooooOO % i1Iii1i1I
 IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'w+' )
 IiI1i111IiIiIi1 . write ( 'id="' + str ( video ) + '"\nname="' + i1iIIIi1i + '"\nversion="' + ii11I1 + '"' )
 IiI1i111IiIiIi1 . close ( )
 if 65 - 65: O0 . III1IiiI
 oOoO0Iii1II1ii = open ( I1IIiiIiii , mode = 'r' )
 ooOo00 = oOoO0Iii1II1ii . read ( )
 oOoO0Iii1II1ii . close ( )
 if 98 - 98: ii1ii11IIIiiI . iIii1I11I1II1 % OoooooooOO % II11iIiIIIiI - OoooO0Oo0O0
 i1oo00OoO = re . compile ( 'id="(.+?)"' ) . findall ( ooOo00 )
 oO0I1I1i1I1I1I1 = i1oo00OoO [ 0 ] if ( len ( i1oo00OoO ) > 0 ) else 'None'
 iI11IiIiiII1 = re . compile ( 'version="(.+?)"' ) . findall ( ooOo00 )
 I1I1IiI1 = iI11IiIiiII1 [ 0 ] if ( len ( iI11IiIiiII1 ) > 0 ) else 'None'
 I11iii1i , ii1i1Iii , oO00oO00O0Oo = url . partition ( '&' )
 print "### Community Build Details:"
 print "### Name: " + i1iIIIi1i
 print "### URL: " + i1Ii1I1Ii11iI
 oO00oOOoooO ( '' , '[COLOR=yellow]IMPORTANT:[/COLOR] Install Instructions' , '' , 'instructions_2' , '' , '' , '' , '' )
 oOo00oOoO000 ( '[COLOR=yellow]Description:[/COLOR] This contains important info from the build author' , 'None' , 'description' , '' , OO0oIiII1iiI , i1iIIIi1i , O0oIi1iIiIi1I11 , ii11I1 , O0oii111 , IIIIIo0ooOoO000oO , OOO0 , I1Ii1 , O0oo0oOoO00 , i1ii1iIi , I1I1Ii , iI1IIII1 , Oo0o )
 if 88 - 88: III1IiiI - i1IIi % i11iIiiIii % oO0OooOoO * OoooooooOO
 if oO0I1I1i1I1I1I1 == I11iii1i and I1I1IiI1 != ii11I1 :
  oO00oOOoooO ( '' , '[COLOR=orange]----------------- UPDATE AVAILABLE ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  o0OIiII ( '[COLOR=dodgerblue]1. Update:[/COLOR] Overwrite My Library & Profiles' , i1Ii1I1Ii11iI , 'update_community' , oo0O0o , '' , 'update' , i1iIIIi1i , ii1I11 , OoO000oo000o0 , oOOoooo )
  o0OIiII ( '[COLOR=dodgerblue]2. Update:[/COLOR] Keep My Library & Profiles' , i1Ii1I1Ii11iI , 'update_community' , oo0O0o , '' , 'updatelibprofile' , i1iIIIi1i , ii1I11 , OoO000oo000o0 , oOOoooo )
  o0OIiII ( '[COLOR=dodgerblue]3. Update:[/COLOR] Keep My Library Only' , i1Ii1I1Ii11iI , 'update_community' , oo0O0o , '' , 'updatelibrary' , i1iIIIi1i , ii1I11 , OoO000oo000o0 , oOOoooo )
  o0OIiII ( '[COLOR=dodgerblue]4. Update:[/COLOR] Keep My Profiles Only' , i1Ii1I1Ii11iI , 'update_community' , oo0O0o , '' , 'updateprofiles' , i1iIIIi1i , ii1I11 , OoO000oo000o0 , oOOoooo )
  if 40 - 40: II11iIiIIIiI
 if i1i1i1I != 'None' or OooOo00o != 'None' or IiI11i1IIiiI != 'None' or oOOo000oOoO0 != 'None' or OoOo00o0OO != 'None' or ii1IIIIiI11 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]------------------ VIDEO GUIDES -----------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 47 - 47: O00OOOoOoo0O
 if i1i1i1I != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] Preview[/COLOR]' , i1i1i1I , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 65 - 65: O0 + Iiii1i1 % iI1IiiIIIiIi * o0Oo / o0oOo0 / O00OOOoOoo0O
 if OooOo00o != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + I1iii + '[/COLOR]' , OooOo00o , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 71 - 71: i11iIiiIii / O00OOOoOoo0O . III1IiiI
 if IiI11i1IIiiI != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + oO0o0O0Ooo0o + '[/COLOR]' , IiI11i1IIiiI , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 33 - 33: III1IiiI
 if oOOo000oOoO0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + i1Ii11II + '[/COLOR]' , oOOo000oOoO0 , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 39 - 39: ii1ii11IIIiiI + O0 + o0oOo0 * oO0OooOoO % O0 - O0
 if OoOo00o0OO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + IioO0oOOO0Ooo + '[/COLOR]' , OoOo00o0OO , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 41 - 41: i11111IIIII % oOO00Oo
 if ii1IIIIiI11 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=orange]Video:[/COLOR][COLOR=white] ' + i1i1I + '[/COLOR]' , ii1IIIIiI11 , 'play_video' , '' , OO0oIiII1iiI , '' , '' )
  if 67 - 67: O0 % Iiii1i1
 if oO0I1I1i1I1I1I1 != I11iii1i :
  oO00oOOoooO ( '' , '[COLOR=orange]------------------ INSTALL OPTIONS ------------------[/COLOR]' , 'None' , '' , '' , '' , '' , '' )
  if 35 - 35: o0Oo . O00OOOoOoo0O + OoooooooOO % II11iIiIIIiI % iiIi1i11
 if i1Ii1I1Ii11iI == 'None' :
  o0OIiII ( '[COLOR=orange]Sorry this build is currently unavailable[/COLOR]' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 39 - 39: iI1IiiIIIiIi
 if oO0I1I1i1I1I1I1 != I11iii1i :
  if I1IiiiIiI ( ) and o0O0 != 'None' :
   if 60 - 60: iiIi1i11
   o0OIiII ( '[COLOR=darkcyan]OpenELEC FRESH INSTALL[/COLOR]' , o0O0 , 'restore_openelec' , oo0O0o , OO0oIiII1iiI , OoO000oo000o0 , i1iIIIi1i , '' , '' , '' )
   if 62 - 62: Iiii1i1 * o00O0OoO
   if 74 - 74: O00OOOoOoo0O . iIii1I11I1II1
  o0OIiII ( '[COLOR=dodgerblue]Standard Install[/COLOR]' , i1Ii1I1Ii11iI , 'restore_community' , oo0O0o , OO0oIiII1iiI , 'merge' , i1iIIIi1i , ii1I11 , OoO000oo000o0 , oOOoooo )
  if 87 - 87: o0oOo0
  if 41 - 41: O00OOOoOoo0O . iIii1I11I1II1 % o0oOo0 + O0
  if 22 - 22: oOO00Oo + II11iIiIIIiI . o0oOo0 + OoooO0Oo0O0 * i1Iii1i1I . i11iIiiIii
  if 90 - 90: iiIi1i11 * O00OOOoOoo0O - II11iIiIIIiI + oOO00Oo
 if OoO000oo000o0 != 'None' :
  if 53 - 53: OoooooooOO . OoooooooOO + oOO00Oo - i1Iii1i1I + iiIi1i11
  oO00oOOoooO ( '' , '[COLOR=dodgerblue](Optional) Apply guisettings.xml fix[/COLOR]' , OoO000oo000o0 , 'guisettingsfix' , '' , OO0oIiII1iiI , '' , '' )
  if 44 - 44: Iiii1i1 - i11111IIIII
  if 100 - 100: III1IiiI . ii1ii11IIIiiI - iI1IiiIIIiIi + O0 * ii1ii11IIIiiI
def oOoOO ( url ) :
 if 20 - 20: o0oOo0 . ii1ii11IIIiiI * i1Iii1i1I
 i1oO00O = ''
 if url == 'create_pack' :
  i1oO00O = i1II1 ( 'http://noobsandnerds.com/TI/AddonPortal/approved.php' , 10 )
  OO = xbmcgui . Dialog ( ) . browse ( 3 , 'Select the folder you want to store this file in' , 'files' , '' , False , False )
  o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this keyword" )
  if 23 - 23: oO0OooOoO * i1Iii1i1I
  if ( not o0OoOoooo0 ) :
   return False , 0
   if 80 - 80: Iiii1i1 / i11iIiiIii + OoooooooOO
  o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
 iIii1 . create ( 'Backing Up Addons & Repositories' , '' , 'Please Wait...' )
 if 38 - 38: OoooO0Oo0O0 % o0oOo0 + i1IIi * OoooooooOO * III1IiiI
 if not os . path . exists ( i1Oo00 ) :
  os . makedirs ( i1Oo00 )
  if 83 - 83: iIii1I11I1II1 - o0oOo0 - Iiii1i1 / ii1ii11IIIiiI - O0
  if 81 - 81: iI1IiiIIIiIi - III1IiiI * OoooO0Oo0O0 / Iiii1i1
 for i1iIIIi1i in os . listdir ( OO0o ) :
  if not 'metadata' in i1iIIIi1i and not 'module' in i1iIIIi1i and not 'script.common' in i1iIIIi1i and not 'packages' in i1iIIIi1i and not 'service.xbmc.versioncheck' in i1iIIIi1i and os . path . isdir ( os . path . join ( OO0o , i1iIIIi1i ) ) :
   try :
    iIii1 . update ( 0 , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % i1iIIIi1i , 'Please Wait...' )
    if 21 - 21: ii1ii11IIIiiI
    if 63 - 63: o00O0OoO . O0 * o00O0OoO + iIii1I11I1II1
    if i1iIIIi1i in i1oO00O or url != 'create_pack' :
     if 46 - 46: i1IIi + oO0OooOoO * i1IIi - iI1IiiIIIiIi
     if not os . path . exists ( os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) ) :
      os . makedirs ( os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) )
     shutil . copyfile ( os . path . join ( OO0o , i1iIIIi1i , 'addon.xml' ) , os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i , 'addon.xml' ) )
    if not i1iIIIi1i in i1oO00O :
     shutil . copytree ( os . path . join ( OO0o , i1iIIIi1i ) , os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i ) )
     if 79 - 79: oO0OooOoO - III1IiiI * OoooO0Oo0O0 - O00OOOoOoo0O . OoooO0Oo0O0
    iiII1IIii1i1 = os . path . join ( i1Oo00 , 'addons' , i1iIIIi1i , 'addon.xml' )
    if 38 - 38: i1Iii1i1I * OoooooooOO
    if 2 - 2: III1IiiI - i11iIiiIii
    if 98 - 98: III1IiiI + OoooooooOO - Iiii1i1 % i11iIiiIii / oOO00Oo . OoooooooOO
    ooo0o0OOo0O = open ( iiII1IIii1i1 , mode = 'r' )
    o0oO0OoO0 = ooo0o0OOo0O . read ( )
    ooo0o0OOo0O . close ( )
    if 52 - 52: OoooooooOO / i11111IIIII % oO0OooOoO
    if 40 - 40: o0Oo % o0oOo0 % i11111IIIII + ii1ii11IIIiiI
    Oo = re . compile ( '<addon[\s\S]*?">' ) . findall ( o0oO0OoO0 )
    oo0OoOOooO = Oo [ 0 ] if ( len ( Oo ) > 0 ) else 'None'
    OOOOOOooo = re . compile ( 'version="[\s\S]*?"' ) . findall ( oo0OoOOooO )
    O0O0O = OOOOOOooo [ 0 ] if ( len ( OOOOOOooo ) > 0 ) else '0'
    if 3 - 3: iI1IiiIIIiIi / II11iIiIIIiI
    if 8 - 8: iI1IiiIIIiIi + o0Oo . o0Oo . O00OOOoOoo0O
    OOOOooO0 = str ( oo0OoOOooO ) . replace ( O0O0O , 'version="0.0.0.1"' )
    II1i11i1iIi11 = o0oO0OoO0 . replace ( oo0OoOOooO , OOOOooO0 )
    if 86 - 86: i11111IIIII
    OoOo = open ( iiII1IIii1i1 , mode = 'w' )
    OoOo . write ( str ( II1i11i1iIi11 ) )
    OoOo . close ( )
    if 43 - 43: o0Oo / i1Iii1i1I / o0oOo0 + iIii1I11I1II1 + OoooooooOO
   except :
    if o0oO0 == 'true' :
     print "### Failed to create: " + i1iIIIi1i + ' ###'
     if 33 - 33: oO0OooOoO - i11111IIIII - o0oOo0
 if url == 'create_pack' :
  i1111iI1 = [ '.svn' , '.git' ]
  Oo0oOOOOo = [ '.DS_Store' , 'Thumbs.db' , '.gitignore' ]
  oO00oOoo00o0 = os . path . join ( OO , o0OOoOo0oo + '.zip' )
  OooOOOO0O0 ( i1Oo00 , oO00oOoo00o0 , 'Creating Addons Archive' , '' , '' , '' , i1111iI1 , Oo0oOOOOo )
  try :
   shutil . rmtree ( i1Oo00 )
  except :
   pass
  OOooO0OOoo . ok ( 'New Keyword Created' , 'Please read the instructions on how to share this keyword with the community. Your zip file can be found at:' , '[COLOR=dodgerblue]' + oO00oOoo00o0 + '[/COLOR]' )
  if 41 - 41: III1IiiI / iiIi1i11 + i1Iii1i1I + o0oOo0
  if 13 - 13: i11iIiiIii - i11iIiiIii . iIii1I11I1II1
def Iii1I11 ( name ) :
 if 94 - 94: iI1IiiIIIiIi / Iiii1i1 . o0Oo . i1Iii1i1I - OoooooooOO / iIii1I11I1II1
 IiI1i111IiIiIi1 = open ( I1IIiiIiii , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 Ii1 = re . compile ( 'name="(.+?)"' ) . findall ( o0oO0OoO0 )
 oOooOOOOo0o = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else 'None'
 iIiiiII = [ ]
 if 47 - 47: i11111IIIII
 if 76 - 76: ii1ii11IIIiiI * iIii1I11I1II1 + OoooO0Oo0O0 - o0oOo0 - o00O0OoO / i1IIi
 if oOooOOOOo0o == 'None' or 'unknown' :
  OOooO0OOoo . ok ( 'No Profile Set' , "There's no profile name set to the build you're currently running. Please enter a name for this build so we can save it and make sure no data is lost." )
  o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
  if ( not o0OoOoooo0 ) :
   return False , 0
  o0OoOoooo0 = o0OoOoooo0 . replace ( ' ' , '_' )
  o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
  os . makedirs ( os . path . join ( II , o0OOoOo0oo ) )
  iIOoo0ooo0oo = o0OOoOo0oo
  IiI1i111IiIiIi1 = open ( I1IIiiIiii , 'w' )
  II1i11i1iIi11 = o0oO0OoO0 . replace ( 'id="None"' , 'id="Local"' ) . replace ( 'name="None"' , 'name="' + str ( iIOoo0ooo0oo ) + '"' )
  IiI1i111IiIiIi1 . write ( II1i11i1iIi11 )
  IiI1i111IiIiIi1 . close ( )
  if 21 - 21: i11111IIIII - o0Oo % OoooooooOO + oOO00Oo
  if 92 - 92: o0oOo0 + i11111IIIII
  for Oooo in os . listdir ( Ooo ) :
   iIiiiII . append ( Oooo )
   if 87 - 87: i11111IIIII . i1IIi % OoooooooOO * i11iIiiIii
  o0oOo = open ( os . path . join ( II , o0OOoOo0oo , 'addonlist' ) , mode = 'w+' )
  for Oooo in os . listdir ( OO0o ) :
   if not Oooo in iIiiiII and Oooo != 'plugin.program.totalinstaller' and Oooo != 'script.module.addon.common' and Oooo != 'packages' :
    o0oOo . write ( Oooo + '|' )
  o0oOo . close ( )
  if 51 - 51: oO0OooOoO . III1IiiI . ii1ii11IIIiiI % oO0OooOoO
  o0Iiii = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' ]
  o0OO0OOO0O = "Creating backup of existing build"
  Iii1I = "Archiving..."
  oOoOOOOoOO0o = ""
  iiI1i1I1II = "Please Wait"
  OooOOOO0O0 ( oOOoO0 , os . path . join ( II , o0OOoOo0oo , 'build.zip' ) , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
  if 41 - 41: O00OOOoOoo0O - iiIi1i11 + o0oOo0 - i1IIi
  if 6 - 6: oO0OooOoO
  if 7 - 7: i1IIi
 else :
  iIOoo0ooo0oo = oOooOOOOo0o . replace ( ' ' , '_' ) . replace ( ':' , '-' ) . replace ( "'" , '' )
  if 63 - 63: iIii1I11I1II1 + i11111IIIII % i1IIi / o0Oo % oO0OooOoO
  o0oOo = open ( os . path . join ( II , iIOoo0ooo0oo , 'addonlist' ) , mode = 'w+' )
  for Oooo in os . listdir ( OO0o ) :
   if not Oooo in iIiiiII and Oooo != 'plugin.program.totalinstaller' and Oooo != 'script.module.addon.common' and Oooo != 'packages' :
    o0oOo . write ( Oooo + '|' )
  o0oOo . close ( )
  if 60 - 60: oOO00Oo . O00OOOoOoo0O % Iiii1i1 / o0Oo / O0
  o0Iiii = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' ]
  o0OO0OOO0O = "Creating backup of existing build"
  Iii1I = "Archiving..."
  oOoOOOOoOO0o = ""
  iiI1i1I1II = "Please Wait"
  OooOOOO0O0 ( oOOoO0 , os . path . join ( II , iIOoo0ooo0oo , 'build.zip' ) , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
 return iIOoo0ooo0oo
 if 19 - 19: i11iIiiIii . o0Oo + oO0OooOoO / iiIi1i11 . OoooO0Oo0O0 * o0oOo0
 if 59 - 59: iIii1I11I1II1 / OoooO0Oo0O0 % o0oOo0
def Ooooo0oOOoO000 ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 Oo00o00Oo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 50 - 50: o0oOo0 % II11iIiIIIiI
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Oo00o00Oo ) :
  IiIIIi1i1I1Ii1IIii = 0
  IiIIIi1i1I1Ii1IIii += len ( I1iiIi111I )
  if 80 - 80: i11iIiiIii
  if IiIIIi1i1I1Ii1IIii >= 0 :
   if 29 - 29: o0Oo . iiIi1i11 + oO0OooOoO . II11iIiIIIiI
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
    if 29 - 29: iI1IiiIIIiIi - O0 . o0oOo0 / OoooO0Oo0O0 / i1IIi . O00OOOoOoo0O
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
    if 36 - 36: ii1ii11IIIiiI - O0 * o0Oo / OoooO0Oo0O0 / iiIi1i11
    if 33 - 33: OoooooooOO % OoooO0Oo0O0 . O0 / OoooO0Oo0O0
def O0OoOo ( ) :
 for OOOOoO0 in glob . glob ( os . path . join ( O0Oo000ooO00 , 'xbmc_crashlog*.*' ) ) :
  IiiIiIIi1 = OOOOoO0
  os . remove ( OOOOoO0 )
  OOooO0OOoo = xbmcgui . Dialog ( )
  OOooO0OOoo . ok ( "Crash Logs Deleted" , "Your old crash logs have now been deleted." )
  if 40 - 40: i1Iii1i1I . O00OOOoOoo0O * O0
  if 6 - 6: o0Oo - oO0OooOoO . o0Oo + o00O0OoO . iiIi1i11
def oo0O ( ) :
 print '############################################################       DELETING PACKAGES             ###############################################################'
 Iii1iI1iiIii = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 if 21 - 21: ii1ii11IIIiiI % iIii1I11I1II1 . ii1ii11IIIiiI
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Iii1iI1iiIii ) :
  IiIIIi1i1I1Ii1IIii = 0
  IiIIIi1i1I1Ii1IIii += len ( I1iiIi111I )
  if 99 - 99: oOO00Oo * iiIi1i11 % III1IiiI * III1IiiI + OoooooooOO
  if IiIIIi1i1I1Ii1IIii > 0 :
   if 82 - 82: o00O0OoO / O00OOOoOoo0O - iiIi1i11 / o0oOo0
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
    if 50 - 50: iiIi1i11 + ii1ii11IIIiiI . i11iIiiIii + OoooO0Oo0O0 + i11iIiiIii
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
    if 31 - 31: III1IiiI * Iiii1i1 . O00OOOoOoo0O * o00O0OoO
    if 28 - 28: i11111IIIII + o0Oo - II11iIiIIIiI % iiIi1i11 . o00O0OoO + o0Oo
def O0oO0 ( path ) :
 oo0O0oo = OOooO0OOoo . yesno ( 'Are you certain?' , 'This will completely wipe this folder, are you absolutely certain you want to continue? There is NO going back after this!' )
 if oo0O0oo == 1 :
  iIii1 . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
  shutil . rmtree ( path , ignore_errors = True )
  iIii1 . close ( )
  xbmc . executebuiltin ( 'container.Refresh' )
  if 65 - 65: iiIi1i11 + Iiii1i1 - iI1IiiIIIiIi
  if 53 - 53: o0Oo
def oOo0ooo0O ( url ) :
 for i1iIIIi1i in os . listdir ( II ) :
  if i1iIIIi1i != 'Master' and i1iIIIi1i != url . replace ( ' ' , '_' ) . replace ( "'" , '' ) . replace ( ':' , '-' ) :
   oO00oOOoooO ( '' , '[COLOR=darkcyan]DELETE[/COLOR] ' + i1iIIIi1i . replace ( '_' , ' ' ) , os . path . join ( II , i1iIIIi1i ) , 'delete_path' , '' , '' , '' , '' )
   if 76 - 76: o00O0OoO % i11111IIIII / i11111IIIII / ii1ii11IIIiiI % III1IiiI . iIii1I11I1II1
   if 85 - 85: iI1IiiIIIiIi
def Oo0O0OooOooo0 ( ) :
 print '############################################################       DELETING USERDATA             ###############################################################'
 Oo00o00Oo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , '' ) )
 if 81 - 81: III1IiiI - iiIi1i11
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Oo00o00Oo ) :
  IiIIIi1i1I1Ii1IIii = 0
  IiIIIi1i1I1Ii1IIii += len ( I1iiIi111I )
  if 21 - 21: II11iIiIIIiI * oOO00Oo + OoooooooOO . Iiii1i1 % III1IiiI
  if IiIIIi1i1I1Ii1IIii >= 0 :
   if 50 - 50: O00OOOoOoo0O - III1IiiI + iIii1I11I1II1 - ii1ii11IIIiiI . II11iIiIIIiI
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
    if 8 - 8: iI1IiiIIIiIi
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
    if 30 - 30: i1IIi
    if 61 - 61: Iiii1i1 / Iiii1i1
def O000OOo00oo ( ) :
 iIii1 . create ( 'Checking dependencies' , '' , 'Please Wait...' )
 oo0OOo = [ ]
 if 26 - 26: i11111IIIII . O0 * i11111IIIII - oOO00Oo * II11iIiIIIiI
 for i1iIIIi1i in os . listdir ( OO0o ) :
  if i1iIIIi1i != 'packages' :
   try :
    iI1iIIiiii = os . path . join ( OO0o , i1iIIIi1i , 'addon.xml' )
    i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
    OOooo0O00o = i1iI11i1ii11 . read ( )
    i1iI11i1ii11 . close ( )
    oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
    if 6 - 6: O00OOOoOoo0O . oO0OooOoO * o0Oo . o0Oo / iI1IiiIIIiIi
    for OOoO00 in oOOoOooOo :
     if 14 - 14: Iiii1i1 % i11111IIIII - O0 / Iiii1i1
     if not 'xbmc.python' in OOoO00 and not OOoO00 in oo0OOo :
      oo0OOo . append ( OOoO00 )
      print 'Script Requires --- ' + OOoO00
   except :
    pass
    if 91 - 91: i11iIiiIii % Iiii1i1 * III1IiiI - OoooO0Oo0O0 . Iiii1i1
 return oo0OOo
 if 28 - 28: i11iIiiIii
 if 51 - 51: o0Oo + o0oOo0 * O0 . iI1IiiIIIiIi
def OOOO0o ( name , addon_id ) :
 iIII1I1i1i = 1
 i111I11i = 1
 iI1iIIiiii = xbmc . translatePath ( os . path . join ( OO0o , addon_id , 'addon.xml' ) )
 i1iI11i1ii11 = open ( iI1iIIiiii , mode = 'r' )
 OOooo0O00o = i1iI11i1ii11 . read ( )
 i1iI11i1ii11 . close ( )
 oOOoOooOo = re . compile ( 'import addon="(.+?)"' ) . findall ( OOooo0O00o )
 if 82 - 82: iiIi1i11 * OoooO0Oo0O0 % iI1IiiIIIiIi . iiIi1i11
 for OOoO00 in oOOoOooOo :
  if 43 - 43: ii1ii11IIIiiI . o0oOo0 * II11iIiIIIiI
  if not 'xbmc.python' in OOoO00 :
   print 'Script Requires --- ' + OOoO00
   iio00O0o00oo = xbmc . translatePath ( os . path . join ( OO0o , OOoO00 ) )
   if 19 - 19: o0Oo
   if not os . path . exists ( iio00O0o00oo ) :
    I1II1I11I1I = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( OOoO00 )
    OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
    O00O = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
    o00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( OoOO0o )
    i1Ii1i1I11Iii = re . compile ( 'data_url="(.+?)"' ) . findall ( OoOO0o )
    I1i1i1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( OoOO0o )
    iI1iiiiIii = re . compile ( 'repo_id="(.+?)"' ) . findall ( OoOO0o )
    oOOoo = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
    ii11I1 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
    I1I1i11 = o00O [ 0 ] if ( len ( o00O ) > 0 ) else ''
    oOo0Oo00O = i1Ii1i1I11Iii [ 0 ] if ( len ( i1Ii1i1I11Iii ) > 0 ) else ''
    i1io0o00O = I1i1i1 [ 0 ] if ( len ( I1i1i1 ) > 0 ) else ''
    iiiI1ii = iI1iiiiIii [ 0 ] if ( len ( iI1iiiiIii ) > 0 ) else ''
    oOoooOooOOoO = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , oOOoo + '.zip' ) )
    if 90 - 90: i1Iii1i1I * iI1IiiIIIiIi - i1Iii1i1I + ii1ii11IIIiiI + o00O0OoO % O0
    iIii1 . create ( 'Downloading Dependencies' , 'Installing [COLOR=yellow]' + oOOoo , '' , '' )
    if 11 - 11: iiIi1i11 % Iiii1i1 * O00OOOoOoo0O
    try :
     downloader . download ( I1I1i11 , oOoooOooOOoO , iIii1 )
     extract . all ( oOoooOooOOoO , OO0o , iIii1 )
     if 58 - 58: OoooooooOO - o00O0OoO + iIii1I11I1II1 * i11iIiiIii
    except :
     if 80 - 80: i1IIi . o0Oo - III1IiiI + iiIi1i11 + i1Iii1i1I % III1IiiI
     try :
      downloader . download ( i1io0o00O , oOoooOooOOoO , iIii1 )
      extract . all ( oOoooOooOOoO , OO0o , iIii1 )
      if 13 - 13: oO0OooOoO / O00OOOoOoo0O / O00OOOoOoo0O + o0oOo0
     except :
      if 49 - 49: O0 / oO0OooOoO * o0Oo - OoooooooOO . oO0OooOoO % i11111IIIII
      try :
       if 13 - 13: III1IiiI . iIii1I11I1II1 . iiIi1i11 . i11111IIIII
       if not os . path . exists ( iio00O0o00oo ) :
        os . makedirs ( iio00O0o00oo )
        if 58 - 58: o00O0OoO
       OoOO0o = i1II1 ( oOo0Oo00O , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
       I11iIiII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( OoOO0o )
       if 7 - 7: oO0OooOoO / i11111IIIII % o00O0OoO + o0Oo - O0
       for iiiI1ii11 in I11iIiII :
        ii1i = xbmc . translatePath ( os . path . join ( iio00O0o00oo , iiiI1ii11 ) )
        if 45 - 45: o0Oo / i1Iii1i1I + III1IiiI + i11111IIIII
        if addon_id not in iiiI1ii11 and '/' not in iiiI1ii11 :
         if 15 - 15: o0Oo % ii1ii11IIIiiI
         try :
          iIii1 . update ( 0 , '' , 'Downloading [COLOR=yellow]' + iiiI1ii11 + '[/COLOR]' , 'Please wait...' )
          downloader . download ( oOo0Oo00O + iiiI1ii11 , ii1i , iIii1 )
          if 66 - 66: III1IiiI * i11iIiiIii . Iiii1i1
         except :
          print "failed to install" + iiiI1ii11
          if 92 - 92: III1IiiI
        if '/' in iiiI1ii11 and '..' not in iiiI1ii11 and 'http' not in iiiI1ii11 :
         OooOOo0 = oOo0Oo00O + iiiI1ii11
         ooO000O ( ii1i , OooOOo0 )
         if 81 - 81: oOO00Oo % o0Oo - i1Iii1i1I / i11iIiiIii
      except :
       OOooO0OOoo . ok ( "Error downloading dependency" , 'There was an error downloading [COLOR=dodgerblue]' + oOOoo + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' )
       i111I11i = 0
       iIII1I1i1i = 0
       if 73 - 73: O0 * Iiii1i1 . i1IIi
    if i111I11i == 1 :
     time . sleep ( 1 )
     iIii1 . update ( 0 , "[COLOR=yellow]" + oOOoo + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Please wait...' )
     time . sleep ( 1 )
     OO00OOoO0o = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( OOoO00 )
     try :
      i1II1 ( OO00OOoO0o , 5 )
     except :
      pass
 iIii1 . close ( )
 time . sleep ( 1 )
 if 51 - 51: ii1ii11IIIiiI - i1Iii1i1I % O0 - O00OOOoOoo0O
 if 53 - 53: i1Iii1i1I / i1IIi / i1IIi
def o0oo00O ( name , url , buildname , author , version , description , updated , skins , videoaddons , audioaddons , programaddons , pictureaddons , sources , adult ) :
 OOooO0OO0 ( buildname + '     v.' + version , '[COLOR=yellow][B]Author:   [/B][/COLOR]' + author + '[COLOR=yellow][B]               Last Updated:   [/B][/COLOR]' + updated + '[COLOR=yellow][B]               Adult Content:   [/B][/COLOR]' + adult + '[CR][CR][COLOR=yellow][B]Description:[CR][/B][/COLOR]' + description +
 '[CR][CR][COLOR=blue][B]Skins:   [/B][/COLOR]' + skins + '[CR][CR][COLOR=blue][B]Video Addons:   [/B][/COLOR]' + videoaddons + '[CR][CR][COLOR=blue][B]Audio Addons:   [/B][/COLOR]' + audioaddons +
 '[CR][CR][COLOR=blue][B]Program Addons:   [/B][/COLOR]' + programaddons + '[CR][CR][COLOR=blue][B]Picture Addons:   [/B][/COLOR]' + pictureaddons + '[CR][CR][COLOR=blue][B]Sources:   [/B][/COLOR]' + sources +
 '[CR][CR][COLOR=orange]Disclaimer: [/COLOR]These are community builds and they may overwrite some of your existing settings, '
 'It\'s purely the responsibility of the user to choose whether or not they wish to install these builds, the individual who uploads the build should state what\'s included and then it\'s the users decision to decide whether or not that content is suitable for them.' )
 if 36 - 36: iiIi1i11 * ii1ii11IIIiiI - OoooO0Oo0O0 + i1Iii1i1I
 if 13 - 13: ii1ii11IIIiiI % iIii1I11I1II1 - oO0OooOoO / o0Oo
def iII111iiiI11i ( path ) :
 iIii1 . create ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "Wiping..." , '' , 'Please Wait' )
 shutil . rmtree ( path , ignore_errors = True )
 if 4 - 4: o0oOo0 % i11111IIIII . Iiii1i1
def o0OOOOOo0 ( ) :
 os . remove ( I1IIiiIiii )
 os . rename ( i1I1iI , I1IIiiIiii )
 xbmc . executebuiltin ( 'UnloadSkin' )
 xbmc . executebuiltin ( "ReloadSkin" )
 OOooO0OOoo . ok ( "Local Restore Complete" , 'XBMC/Kodi will now close.' , '' , '' )
 xbmc . executebuiltin ( "Quit" )
 if 91 - 91: OoooO0Oo0O0 + iIii1I11I1II1 % i11111IIIII
 if 90 - 90: o0oOo0 - o00O0OoO . ii1ii11IIIiiI + ii1ii11IIIiiI
def OO0 ( url ) :
 iIii1 . create ( "Changing Physical Paths To Special" , "Renaming paths..." , '' , 'Please Wait' )
 if 45 - 45: O00OOOoOoo0O / OoooooooOO . Iiii1i1 % O0 * OoooO0Oo0O0 * II11iIiIIIiI
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( url ) :
  if 65 - 65: oOO00Oo + Iiii1i1 - O0
  for file in I1iiIi111I :
   if 30 - 30: i11111IIIII - i1Iii1i1I - ii1ii11IIIiiI
   if file . endswith ( ".xml" ) or file . endswith ( ".hash" ) or file . endswith ( "properies" ) :
    iIii1 . update ( 0 , "Fixing" , file , 'Please Wait' )
    OO0Oo = open ( ( os . path . join ( oO0000O0Oo00O , file ) ) ) . read ( )
    ii11 = oOOoO0 . replace ( ':' , '%3a' ) . replace ( '\\' , '%5c' )
    oOOooooO = oOOoO0 . replace ( '\\' , '\\\\' )
    o000Ooo00o00O = OO0Oo . replace ( oOOoO0 , 'special://home/' ) . replace ( ii11 , 'special://home/' ) . replace ( oOOooooO , 'special://home/' )
    iiI1iii = open ( ( os . path . join ( oO0000O0Oo00O , file ) ) , mode = 'w' )
    iiI1iii . write ( str ( o000Ooo00o00O ) )
    iiI1iii . close ( )
    if 80 - 80: i1Iii1i1I
    if 3 - 3: OoooO0Oo0O0 * o00O0OoO
def Oo00O ( ) :
 if os . path . exists ( i1Oo00 ) :
  shutil . rmtree ( i1Oo00 )
 o0Iiii = [ ]
 I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
 o0OO0OOO0O = "Creating full backup of existing build"
 iii = "Creating Community Build"
 Iii1I = "Archiving..."
 oOoOOOOoOO0o = ""
 iiI1i1I1II = "Please Wait"
 if 44 - 44: o0oOo0 * o00O0OoO
 OooOOOO0O0 ( oOOoO0 , myfullbackup , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
 if 12 - 12: iI1IiiIIIiIi . o0Oo % oOO00Oo
def I11i1I11 ( ) :
 I1iIiiI11 = 0
 i1ii1111iiI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
 iiIIIII = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
 iiI1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 iii11i1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 IIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 I1I1IIiiI1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 oooOOO0o0O0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 iiiI1IiI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 Ii111IIIIii = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 O00oIii1iIIiii1ii = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 Ii1iii11I = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
 Ii11iIiiI = os . path . join ( oOOoO0 , 'temp' )
 iIii1 . create ( 'Calculating Used Space' , '' , 'Please wait' , '' )
 if 3 - 3: oO0OooOoO / iiIi1i11
 if 48 - 48: o0oOo0 . OoooO0Oo0O0
 if os . path . exists ( i1ii1111iiI ) :
  I1iIiiI11 = IiiIIIIi ( i1ii1111iiI , I1iIiiI11 )
 if os . path . exists ( iiIIIII ) :
  I1iIiiI11 = IiiIIIIi ( iiIIIII , I1iIiiI11 )
 if os . path . exists ( iiI1 ) :
  I1iIiiI11 = IiiIIIIi ( iiI1 , I1iIiiI11 )
 if os . path . exists ( iii11i1 ) :
  I1iIiiI11 = IiiIIIIi ( iii11i1 , I1iIiiI11 )
 if os . path . exists ( IIi ) :
  I1iIiiI11 = IiiIIIIi ( IIi , I1iIiiI11 )
 if os . path . exists ( I1I1IIiiI1 ) :
  I1iIiiI11 = IiiIIIIi ( I1I1IIiiI1 , I1iIiiI11 )
 if os . path . exists ( oooOOO0o0O0 ) :
  I1iIiiI11 = IiiIIIIi ( oooOOO0o0O0 , I1iIiiI11 )
 if os . path . exists ( iiiI1IiI ) :
  I1iIiiI11 = IiiIIIIi ( iiiI1IiI , I1iIiiI11 )
 if os . path . exists ( Ii111IIIIii ) :
  I1iIiiI11 = IiiIIIIi ( Ii111IIIIii , I1iIiiI11 )
 if os . path . exists ( O00oIii1iIIiii1ii ) :
  I1iIiiI11 = IiiIIIIi ( O00oIii1iIIiii1ii , I1iIiiI11 )
 if os . path . exists ( Ii1iii11I ) :
  I1iIiiI11 = IiiIIIIi ( Ii1iii11I , I1iIiiI11 )
 if os . path . exists ( Ii11iIiiI ) :
  I1iIiiI11 = IiiIIIIi ( Ii11iIiiI , I1iIiiI11 )
 I1iIiiI11 = IiiIIIIi ( II11iiii1Ii , I1iIiiI11 )
 I1iIiiI11 = IiiIIIIi ( O00O0oOO00O00 , I1iIiiI11 ) / 1000000
 oo0O0oo = OOooO0OOoo . yesno ( 'Results' , 'You can free up [COLOR=dodgerblue]' + str ( I1iIiiI11 ) + 'MB[/COLOR] of space if you run this cleanup program. Would you like to run the cleanup procedure?' )
 if oo0O0oo == 1 :
  II1iII1i1i ( )
  try :
   shutil . rmtree ( O00O0oOO00O00 )
  except :
   pass
  oo0O0oo = OOooO0OOoo . yesno ( 'Thumbnail Cleanup' , 'We highly recommend only wiping your OLD unused thumbnails. Do you want to clear just the old ones or all thumbnails?' , yeslabel = 'ALL' , nolabel = 'OLD ONLY' )
  if oo0O0oo == 1 :
   IiIIIi ( )
   iII111iiiI11i ( II11iiii1Ii )
   Oo0iII ( )
  else :
   iIIIiiiiIiI1III ( )
   if 73 - 73: iI1IiiIIIiIi / o0Oo / OoooooooOO + o0Oo
   if 57 - 57: iiIi1i11 . iI1IiiIIIiIi % oOO00Oo
def I1I11 ( url ) :
 oO00oOOoooO ( 'folder' , 'Anime' , str ( url ) + '&genre=anime' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audiobooks' , str ( url ) + '&genre=audiobooks' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comedy' , str ( url ) + '&genre=comedy' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Comics' , str ( url ) + '&genre=comics' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Documentary' , str ( url ) + '&genre=documentary' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Downloads' , str ( url ) + '&genre=downloads' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Food' , str ( url ) + '&genre=food' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Gaming' , str ( url ) + '&genre=gaming' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Health' , str ( url ) + '&genre=health' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'How To...' , str ( url ) + '&genre=howto' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Kids' , str ( url ) + '&genre=kids' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Live TV' , str ( url ) + '&genre=livetv' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Movies' , str ( url ) + '&genre=movies' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Music' , str ( url ) + '&genre=music' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'News' , str ( url ) + '&genre=news' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Photos' , str ( url ) + '&genre=photos' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Podcasts' , str ( url ) + '&genre=podcasts' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Radio' , str ( url ) + '&genre=radio' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Religion' , str ( url ) + '&genre=religion' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Space' , str ( url ) + '&genre=space' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Sports' , str ( url ) + '&genre=sports' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Technology' , str ( url ) + '&genre=tech' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Trailers' , str ( url ) + '&genre=trailers' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'TV Shows' , str ( url ) + '&genre=tv' , 'grab_builds' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Misc.' , str ( url ) + '&genre=other' , 'grab_builds' , '' , '' , '' , '' )
 if 9 - 9: iiIi1i11
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  oO00oOOoooO ( 'folder' , 'XXX' , str ( url ) + '&genre=adult' , 'grab_builds' , '' , '' , '' , '' )
  if 38 - 38: o00O0OoO . ii1ii11IIIiiI . i11iIiiIii * OoooooooOO + i1Iii1i1I
  if 49 - 49: II11iIiIIIiI - ii1ii11IIIiiI / Iiii1i1 / oOO00Oo % III1IiiI
def IiiIIIIi ( path , size ) :
 for IIiOoO0000o , OOiii1IiiIiIIiI , o0OoOOoOOoo in os . walk ( path ) :
  for iiI1iii in o0OoOOoOOoo :
   iIii1 . update ( 0 , "Calulating..." , '[COLOR=dodgerblue]' + iiI1iii + '[/COLOR]' , 'Please Wait' )
   oo0O0 = os . path . join ( IIiOoO0000o , iiI1iii )
   size += os . path . getsize ( oo0O0 )
 return size
 if 34 - 34: oO0OooOoO - i11111IIIII % O00OOOoOoo0O % iI1IiiIIIiIi / o0oOo0
def OooO0O0Ooo ( default = "" , heading = "" , hidden = False ) :
 Ii1II = xbmc . Keyboard ( default , heading , hidden )
 if 44 - 44: oOO00Oo / OoooO0Oo0O0 . II11iIiIIIiI + O00OOOoOoo0O
 Ii1II . doModal ( )
 if ( Ii1II . isConfirmed ( ) ) :
  return unicode ( Ii1II . getText ( ) , "utf-8" )
 return default
 if 32 - 32: i11111IIIII - o0oOo0 * i1Iii1i1I * o00O0OoO
 if 84 - 84: iI1IiiIIIiIi + OoooO0Oo0O0 % o0Oo + i11iIiiIii
def i1iI11Ii1i ( ) :
 Iii1Iii = [ ]
 iiI11111II = sys . argv [ 2 ]
 if len ( iiI11111II ) >= 2 :
  I1ii1i11iI1 = sys . argv [ 2 ]
  IiOOo0 = I1ii1i11iI1 . replace ( '?' , '' )
  if ( I1ii1i11iI1 [ len ( I1ii1i11iI1 ) - 1 ] == '/' ) :
   I1ii1i11iI1 = I1ii1i11iI1 [ 0 : len ( I1ii1i11iI1 ) - 2 ]
  o0O0O0O00o = IiOOo0 . split ( '&' )
  Iii1Iii = { }
  for OoOooOo00o in range ( len ( o0O0O0O00o ) ) :
   iI1IIi = { }
   iI1IIi = o0O0O0O00o [ OoOooOo00o ] . split ( '=' )
   if ( len ( iI1IIi ) ) == 2 :
    Iii1Iii [ iI1IIi [ 0 ] ] = iI1IIi [ 1 ]
    if 10 - 10: OoooO0Oo0O0 / iI1IiiIIIiIi * i1IIi % O0 + o00O0OoO
 return Iii1Iii
 if 25 - 25: Iiii1i1 - iI1IiiIIIiIi / O0 . OoooooooOO % o0Oo . i1IIi
def Ii1i ( ) :
 i111IiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
 iIii1 = xbmcgui . DialogProgress ( )
 iIii1 . create ( "Gotham Addon Fix" , "Please wait whilst your addons" , '' , 'are being made Gotham compatible.' )
 if 49 - 49: III1IiiI + III1IiiI + i11iIiiIii % i1Iii1i1I
 for OOOOoO0 in glob . glob ( os . path . join ( i111IiiI1Ii , '*.*' ) ) :
  if 39 - 39: o00O0OoO / i1Iii1i1I + i1IIi % iiIi1i11
  for file in glob . glob ( os . path . join ( OOOOoO0 , '*.*' ) ) :
   if 51 - 51: O0 % oO0OooOoO % i11iIiiIii + iiIi1i11 . OoooooooOO
   if 'addon.xml' in file :
    iIii1 . update ( 0 , "Fixing" , file , 'Please Wait' )
    OO0Oo = open ( file ) . read ( )
    o000Ooo00o00O = OO0Oo . replace ( 'addon="xbmc.python" version="1.0"' , 'addon="xbmc.python" version="2.1.0"' ) . replace ( 'addon="xbmc.python" version="2.0"' , 'addon="xbmc.python" version="2.1.0"' )
    iiI1iii = open ( file , mode = 'w' )
    iiI1iii . write ( str ( o000Ooo00o00O ) )
    iiI1iii . close ( )
    if 14 - 14: II11iIiIIIiI + i11iIiiIii - III1IiiI % i11111IIIII
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( "Your addons have now been made compatible" , "If you still find you have addons that aren't working please run the addon so it throws up a script error, upload a log and post details on the relevant support forum." )
 if 1 - 1: III1IiiI + Iiii1i1 . o0Oo
 if 47 - 47: i1Iii1i1I . O00OOOoOoo0O
def o0oOO0 ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 I11II11IiI11 = xbmcgui . Dialog ( ) . yesno ( 'Convert Addons To Gotham' , 'This will edit your addon.xml files so they show as Gotham compatible. It\'s doubtful this will have any effect on whether or not they work but it will get rid of the annoying incompatible pop-up message. Do you wish to continue?' )
 if 97 - 97: o0oOo0 / iIii1I11I1II1 % o0oOo0 / o0Oo * i1Iii1i1I % O00OOOoOoo0O
 if I11II11IiI11 == 1 :
  Ii1i ( )
  if 17 - 17: iIii1I11I1II1
  if 89 - 89: i1IIi . i1IIi
def i1IIII1111 ( url ) :
 if 84 - 84: O0 % iI1IiiIIIiIi . iI1IiiIIIiIi . i1Iii1i1I * o00O0OoO
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  Oo0o = 'yes'
  if 43 - 43: O00OOOoOoo0O . OoooO0Oo0O0 % i1IIi
 else :
  Oo0o = 'no'
  if 61 - 61: o0Oo + III1IiiI % Iiii1i1 % iIii1I11I1II1 - OoooooooOO
 if url == 'popular' :
  iIIiI1 = 'http://noobsandnerds.com/TI/AddonPortal/popular.php?adult=%s' % ( Oo0o )
 elif url != 'popular' :
  iIIiI1 = 'http://noobsandnerds.com/TI/AddonPortal/sortby_bak.php?sortx=name&user=%s&adult=%s&%s' % ( O0oo0OO0 , Oo0o , url )
  if 4 - 4: OoooooooOO + i1Iii1i1I % O0 + iIii1I11I1II1 % i1Iii1i1I * i11iIiiIii
 OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 32 - 32: O00OOOoOoo0O + o0oOo0 + iI1IiiIIIiIi + o0Oo
 I11iIiII = re . compile ( 'name="(.+?)"  <br> downloads="(.+?)"  <br> icon="(.+?)"  <br> broken="(.+?)"  <br> UID="(.+?)"  <br>' , re . DOTALL ) . findall ( OoOO0o )
 if I11iIiII == [ ] :
  if 26 - 26: i1Iii1i1I - II11iIiIIIiI + o0Oo + oOO00Oo
  I11iIiII = re . compile ( 'name="(.+?)" <br> downloads="(.+?)" <br> icon="(.+?)" <br> broken="(.+?)" <br> UID="(.+?)" <br>' , re . DOTALL ) . findall ( OoOO0o )
  if 37 - 37: oOO00Oo * iiIi1i11 + o0Oo . OoooO0Oo0O0 * OoooooooOO
 if I11iIiII != [ ] and url != 'popular' :
  OoooOO0 ( iIIiI1 , 'addons' )
  if 69 - 69: oO0OooOoO + i1Iii1i1I
  for i1iIIIi1i , OOo , Ii1ii111i1 , iiOoO , oooOOO in I11iIiII :
   if 4 - 4: O0 / o00O0OoO . ii1ii11IIIiiI - o0oOo0 / iiIi1i11
   if iiOoO == '0' :
    oO00oOOoooO ( 'addonfolder' , i1iIIIi1i + '[COLOR=lime] [' + OOo + ' downloads][/COLOR]' , oooOOO , 'addon_final_menu' , Ii1ii111i1 , '' , '' )
    if 25 - 25: o00O0OoO * O00OOOoOoo0O - II11iIiIIIiI . o0oOo0 . III1IiiI
   if iiOoO == '1' :
    oO00oOOoooO ( 'addonfolder' , '[COLOR=red]' + i1iIIIi1i + ' [REPORTED AS BROKEN][/COLOR]' , oooOOO , 'addon_final_menu' , Ii1ii111i1 , '' , '' )
    if 89 - 89: O0 * o00O0OoO * ii1ii11IIIiiI
 elif I11iIiII != [ ] and url == 'popular' :
  for i1iIIIi1i , OOo , Ii1ii111i1 , iiOoO , oooOOO in I11iIiII :
   if 3 - 3: iiIi1i11 / i1Iii1i1I * iIii1I11I1II1 + oO0OooOoO / oOO00Oo / i11111IIIII
   if iiOoO == '0' :
    oO00oOOoooO ( 'addonfolder' , i1iIIIi1i + '[COLOR=lime] [' + OOo + ' downloads][/COLOR]' , oooOOO , 'addon_final_menu' , Ii1ii111i1 , '' , '' )
    if 25 - 25: O00OOOoOoo0O + ii1ii11IIIiiI % iI1IiiIIIiIi % iiIi1i11 / III1IiiI
   if iiOoO == '1' :
    oO00oOOoooO ( 'addonfolder' , '[COLOR=red]' + i1iIIIi1i + ' [REPORTED AS BROKEN][/COLOR]' , oooOOO , 'addon_final_menu' , Ii1ii111i1 , '' , '' )
    if 91 - 91: ii1ii11IIIiiI / ii1ii11IIIiiI . oO0OooOoO . o0oOo0 - o0Oo
 elif '&redirect' in url :
  oo0O0oo = OOooO0OOoo . yesno ( 'No Content Found' , 'This add-on cannot be found on the Add-on Portal.' , '' , 'Would you like to remove this item from your setup?' )
  if 23 - 23: o0Oo
  if oo0O0oo == 1 :
   print "### Need to add remove function to code still"
   if 7 - 7: i1Iii1i1I % OoooO0Oo0O0
 else :
  OOooO0OOoo . ok ( 'No Content Found' , 'Sorry no content can be found that matches' , 'your search criteria.' , '' )
  if 64 - 64: Iiii1i1 + i11iIiiIii
  if 35 - 35: O00OOOoOoo0O + i1IIi % iiIi1i11
def o0OOo0Ooo0 ( url ) :
 if zip == '' :
  OOooO0OOoo . ok ( 'Storage/Download Folder Not Set' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' , '' , '' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  if 3 - 3: II11iIiIIIiI / o0oOo0 + o0oOo0 . OoooO0Oo0O0
 if i1IiI1I11 . getSetting ( 'adult' ) == 'true' :
  Oo0o = ''
  if 50 - 50: iIii1I11I1II1 * III1IiiI
 else :
  Oo0o = 'no'
  if 85 - 85: i1IIi
 if not 'id=' in url :
  iIIiI1 = 'http://noobsandnerds.com/TI/Community_Builds/sortby.php?sortx=name&orderx=ASC&adult=%s&%s' % ( Oo0o , url )
  OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  if 100 - 100: OoooooooOO / o00O0OoO % ii1ii11IIIiiI + iI1IiiIIIiIi
  I11iIiII = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> Thumbnail="(.+?)"  <br> Fanart="(.+?)"  <br> downloads="(.+?)"  <br> <br>' , re . DOTALL ) . findall ( OoOO0o )
  if I11iIiII == [ ] :
   if 42 - 42: II11iIiIIIiI / i11111IIIII . iI1IiiIIIiIi * o0Oo
   I11iIiII = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> Thumbnail="(.+?)" <br> Fanart="(.+?)" <br> downloads="(.+?)" <br> <br>' , re . DOTALL ) . findall ( OoOO0o )
  OoooOO0 ( url , 'communitybuilds' )
  if 54 - 54: O00OOOoOoo0O * i1Iii1i1I + ii1ii11IIIiiI
  for i1iIIIi1i , id , oOOOo , o0OOOoO0O , OOo in I11iIiII :
   o0OIiII ( i1iIIIi1i + '[COLOR=lime] (' + OOo + ' downloads)[/COLOR]' , id + url , 'community_menu' , oOOOo , o0OOOoO0O , id , '' , '' , '' , '' )
   if 74 - 74: i1IIi / O00OOOoOoo0O - II11iIiIIIiI . i11111IIIII % OoooO0Oo0O0 - i11111IIIII
 if 'id=1' in url : iIIiI1 = oOo0oooo00o
 if 'id=2' in url : iIIiI1 = oo0o0O00
 if 'id=3' in url : iIIiI1 = i1iiIIiiI111
 if 'id=4' in url : iIIiI1 = i1iiIII111ii
 if 'id=5' in url : iIIiI1 = ii11iIi1I
 if 86 - 86: II11iIiIIIiI
 OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I11iIiII = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OoOO0o )
 if 88 - 88: Iiii1i1 * o0Oo
 for i1iIIIi1i , url , oo0O0o , OO0oIiII1iiI , O0oii111 in I11iIiII :
  if not 'viewport' in i1iIIIi1i :
   oO00oOOoooO ( 'addon' , i1iIIIi1i , url , 'restore_local_CB' , oo0O0o , OO0oIiII1iiI , O0oii111 , '' )
   if 30 - 30: O00OOOoOoo0O / III1IiiI / iI1IiiIIIiIi * oOO00Oo * III1IiiI . o0Oo
   if 93 - 93: O00OOOoOoo0O
def o0OoOo0o0OOoO0 ( url ) :
 iIIiI1 = 'http://noobsandnerds.com/TI/HardwarePortal/sortby.php?sortx=Added&orderx=DESC&%s' % ( url )
 OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 30 - 30: iI1IiiIIIiIi % o00O0OoO + oOO00Oo
 I11iIiII = re . compile ( 'name="(.+?)"  <br> id="(.+?)"  <br> thumb="(.+?)"  <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 if I11iIiII == [ ] :
  if 65 - 65: iIii1I11I1II1 . i1Iii1i1I / iI1IiiIIIiIi
  I11iIiII = re . compile ( 'name="(.+?)" <br> id="(.+?)" <br> thumb="(.+?)" <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 OoooOO0 ( iIIiI1 , 'hardware' )
 if 12 - 12: o0Oo + Iiii1i1
 for i1iIIIi1i , id , oOooooO in I11iIiII :
  oO00oOOoooO ( 'folder2' , i1iIIIi1i , id , 'hardware_final_menu' , oOooooO , '' , '' )
  if 79 - 79: OoooO0Oo0O0 - iIii1I11I1II1 % i1IIi / II11iIiIIIiI + oO0OooOoO
  if 95 - 95: III1IiiI
def i11ii ( url ) :
 iIIiI1 = 'http://noobsandnerds.com/TI/LatestNews/sortby.php?sortx=item_date&orderx=DESC&%s' % ( url )
 OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 39 - 39: i1IIi . OoooO0Oo0O0 / o00O0OoO / o00O0OoO
 I11iIiII = re . compile ( 'name="(.+?)"  <br> date="(.+?)"  <br> source="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 if I11iIiII == [ ] :
  if 100 - 100: OoooooooOO - OoooooooOO + i11111IIIII
  I11iIiII = re . compile ( 'name="(.+?)" <br> date="(.+?)" <br> source="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 for i1iIIIi1i , iIiIi1i1Iiii , OOO00000O , id in I11iIiII :
  if 23 - 23: II11iIiIIIiI - O0
  if "OpenELEC" in OOO00000O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIiIi1i1Iiii + ')' , id , 'news_menu' , '' , '' , '' )
   if 33 - 33: OoooO0Oo0O0
  if "Official" in OOO00000O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIiIi1i1Iiii + ')' , id , 'news_menu' , '' , '' , '' )
   if 54 - 54: o0oOo0 * OoooO0Oo0O0 . oO0OooOoO / iiIi1i11 % iiIi1i11
  if "Raspbmc" in OOO00000O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIiIi1i1Iiii + ')' , id , 'news_menu' , '' , '' , '' )
   if 25 - 25: i11iIiiIii + OoooO0Oo0O0 - OoooooooOO . O0 % Iiii1i1
  if "XBMC4Xbox" in OOO00000O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIiIi1i1Iiii + ')' , id , 'news_menu' , '' , '' , '' )
   if 53 - 53: i1IIi
  if "noobsandnerds" in OOO00000O :
   oO00oOOoooO ( '' , i1iIIIi1i + '  (' + iIiIi1i1Iiii + ')' , id , 'news_menu' , '' , '' , '' )
   if 59 - 59: oOO00Oo + o0Oo % OoooooooOO - iIii1I11I1II1
   if 9 - 9: i1IIi - O00OOOoOoo0O
def Oo00o0OOo0OO ( url ) :
 iIIiI1 = 'http://noobsandnerds.com/TI/TutorialPortal/sortby.php?sortx=Name&orderx=ASC&%s' % ( url )
 OoOO0o = i1II1 ( iIIiI1 , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 if 18 - 18: o0oOo0 - i11111IIIII / oO0OooOoO / OoooO0Oo0O0
 I11iIiII = re . compile ( 'name="(.+?)"  <br> about="(.+?)"  <br> id="(.+?)"  <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 if I11iIiII == [ ] :
  if 31 - 31: Iiii1i1 * o0Oo + o0oOo0
  I11iIiII = re . compile ( 'name="(.+?)" <br> about="(.+?)" <br> id="(.+?)" <br><br>' , re . DOTALL ) . findall ( OoOO0o )
 OoooOO0 ( iIIiI1 , 'tutorials' )
 if 48 - 48: O0
 for i1iIIIi1i , iIIIi11iIiIii , id in I11iIiII :
  oO00oOOoooO ( 'folder' , i1iIIIi1i , id , 'tutorial_final_menu' , '' , '' , iIIIi11iIiIii )
  if 61 - 61: OoooooooOO . iI1IiiIIIiIi % III1IiiI * OoooooooOO
  if 96 - 96: iI1IiiIIIiIi - oO0OooOoO % O00OOOoOoo0O * o0Oo * o0Oo . II11iIiIIIiI
def oOO0O0O ( url , local ) :
 oOiI111I1III ( )
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'This will over-write your existing guisettings.xml.' , 'Are you sure this is the build you have installed?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 81 - 81: i11iIiiIii % i1IIi % oO0OooOoO % o0Oo + o0Oo % OoooO0Oo0O0
 if oo0O0oo == 1 :
  i1iiiI1I ( url , local )
  if 98 - 98: iiIi1i11
def OoOOoOo ( path ) :
 if 37 - 37: iIii1I11I1II1 . o0Oo % ii1ii11IIIiiI % OoooooooOO . OoooooooOO / O0
 IiI1i111IiIiIi1 = open ( I11i1 , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 if 25 - 25: oO0OooOoO % oO0OooOoO - iI1IiiIIIiIi . O0
 O00O0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( o0oO0OoO0 )
 ii11i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( o0oO0OoO0 )
 iIiI1I = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( o0oO0OoO0 )
 iIOOO0O00 = O00O0 [ 0 ] if ( len ( O00O0 ) > 0 ) else ''
 Oo0O000OoO00 = ii11i1i [ 0 ] if ( len ( ii11i1i ) > 0 ) else ''
 oOO00OoOo = iIiI1I [ 0 ] if ( len ( iIiI1I ) > 0 ) else ''
 if 83 - 83: i1IIi
 if 43 - 43: iiIi1i11 / o0Oo
 oOoO0Iii1II1ii = open ( path , mode = 'r' )
 ooOo00 = oOoO0Iii1II1ii . read ( )
 oOoO0Iii1II1ii . close ( )
 if 46 - 46: OoooO0Oo0O0 % i11111IIIII + OoooooooOO * iI1IiiIIIiIi
 iIO0oooooO = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOo00 )
 IIi1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOo00 )
 II11II = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOo00 )
 i1ii11 = iIO0oooooO [ 0 ] if ( len ( iIO0oooooO ) > 0 ) else ''
 IIIo00O = IIi1 [ 0 ] if ( len ( IIi1 ) > 0 ) else ''
 ii1I1I1 = II11II [ 0 ] if ( len ( II11II ) > 0 ) else ''
 II1i11i1iIi11 = o0oO0OoO0 . replace ( iIOOO0O00 , i1ii11 ) . replace ( oOO00OoOo , ii1I1I1 ) . replace ( Oo0O000OoO00 , IIIo00O )
 if 84 - 84: o0Oo * O0 * III1IiiI
 print "### Attempting to create new guisettings at: " + path
 I1iI1I1 = open ( path , mode = 'w+' )
 I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
 I1iI1I1 . close ( )
 if 39 - 39: oO0OooOoO * o0Oo - iIii1I11I1II1
 if 25 - 25: OoooooooOO . iI1IiiIIIiIi % i1Iii1i1I . i11111IIIII
def i1iiiI1I ( url , local ) :
 ooo000 = False
 oooOoO0oo0o0 = 0
 IiIIIii1i1iI = 1
 if 99 - 99: iIii1I11I1II1 - III1IiiI - O00OOOoOoo0O / iIii1I11I1II1 * II11iIiIIIiI - III1IiiI
 if os . path . exists ( Oo0OoO00oOO0o ) :
  os . remove ( Oo0OoO00oOO0o )
  if 72 - 72: i11111IIIII % i1IIi / iIii1I11I1II1
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 95 - 95: O0 . ii1ii11IIIiiI
 if os . path . exists ( I1IIIii ) :
  os . remove ( I1IIIii )
  if 89 - 89: i1IIi
 if not os . path . exists ( OOO00O ) :
  os . makedirs ( OOO00O )
  if 19 - 19: o0oOo0 / oOO00Oo % i11111IIIII - iI1IiiIIIiIi
  if 14 - 14: OoooO0Oo0O0 - i11iIiiIii * Iiii1i1
 try :
  shutil . copyfile ( I11i1 , Oo0OoO00oOO0o )
  if 39 - 39: OoooooooOO
 except :
  print "No guisettings found, most likely due to a previously failed attempt at install"
  if 19 - 19: i11iIiiIii
 if local != 1 :
  oOOOOOoOOoo0 = os . path . join ( OOO00 , 'guifix.zip' )
  if 93 - 93: oO0OooOoO * O00OOOoOoo0O % oOO00Oo
  try :
   iIii1 . create ( 'Downloading Skin Fix' , '' , '' , '' )
   downloader . download ( url , oOOOOOoOOoo0 )
  except :
   print "Failed to download guisettings"
 else :
  oOOOOOoOOoo0 = xbmc . translatePath ( url )
 if o0oO0 == 'true' :
  print "### lib=" + oOOOOOoOOoo0
  if 67 - 67: oOO00Oo + II11iIiIIIiI . o0oOo0 - i1IIi . O00OOOoOoo0O
 I1iI1 = str ( os . path . getsize ( oOOOOOoOOoo0 ) )
 iIii1 . create ( "Installing Skin Fix" , "Checking " , '' , 'Please Wait' )
 if 9 - 9: II11iIiIIIiI - o0oOo0 * i1Iii1i1I / i11iIiiIii / II11iIiIIIiI % III1IiiI
 extract . all ( oOOOOOoOOoo0 , OOO00O )
 if 16 - 16: i1Iii1i1I - i1IIi + oOO00Oo * iIii1I11I1II1 + III1IiiI . III1IiiI
 if os . path . exists ( os . path . join ( OOO00O , 'script.skinshortcuts' ) ) :
  try :
   shutil . rmtree ( os . path . join ( iiI1IiI , 'script.skinshortcuts' ) )
  except :
   pass
  os . rename ( os . path . join ( OOO00O , 'script.skinshortcuts' ) , os . path . join ( iiI1IiI , 'script.skinshortcuts' ) )
  if 85 - 85: Iiii1i1 . i11111IIIII - o0oOo0 / oO0OooOoO * Iiii1i1
 if os . path . exists ( os . path . join ( OOO00O , 'addon_data' ) ) :
  shutil . move ( os . path . join ( OOO00O , 'addon_data' ) , O0OoO000O0OO )
  if 98 - 98: iIii1I11I1II1 + i11iIiiIii * OoooO0Oo0O0 / Iiii1i1 / o0oOo0 - O0
 if local != 'library' or local != 'updatelibrary' or local != 'fresh' :
  if 42 - 42: i1Iii1i1I
  try :
   ooo0o0OOo0O = open ( os . path . join ( OOO00O , 'profiles.xml' ) , mode = 'r' )
   Oo0OOo0o0o0o0 = ooo0o0OOo0O . read ( )
   ooo0o0OOo0O . close ( )
   if 95 - 95: ii1ii11IIIiiI
   if os . path . exists ( os . path . join ( OOO00O , 'profiles.xml' ) ) :
    if 68 - 68: iIii1I11I1II1 . iIii1I11I1II1 / O00OOOoOoo0O - oO0OooOoO - iIii1I11I1II1
    if local == None :
     oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "KODI PROFILES DETECTED" , 'This build has profiles included (standard Kodi profiles, not CP Profiles), would you like to overwrite your existing profiles or keep the ones you have?' , '' , '' , nolabel = 'Keep my profiles' , yeslabel = 'Use new profiles' )
     if 75 - 75: o0oOo0 . o0Oo * oO0OooOoO
    if local != None :
     oo0O0oo = 1
     if 99 - 99: iIii1I11I1II1 * OoooO0Oo0O0 + i11111IIIII
    if oo0O0oo == 1 :
     I1iI1I1 = open ( I1IIIii , mode = 'w' )
     time . sleep ( 1 )
     I1iI1I1 . write ( Oo0OOo0o0o0o0 )
     time . sleep ( 1 )
     I1iI1I1 . close ( )
     IiIIIii1i1iI = 0
     if 70 - 70: i1IIi % o0oOo0 . OoooO0Oo0O0 - i11111IIIII + iiIi1i11
  except :
   print "no profiles.xml file"
   if 84 - 84: III1IiiI + oO0OooOoO * oO0OooOoO % oOO00Oo / i1Iii1i1I + o0oOo0
   if 9 - 9: i1Iii1i1I
 try :
  os . rename ( os . path . join ( OOO00O , 'guisettings.xml' ) , iIi1ii1I1 )
 except :
  OOooO0OOoo . ok ( 'FILE MISSING' , 'No guisettings.xml could be found in your zip file. Please double check this file is a valid zip and hasn\'t become corrupt.' )
 if local != 'fresh' :
  iIi11I1II = OOooO0OOoo . yesno ( "Keep Kodi Settings?" , 'Do you want to keep your existing KODI settings (weather, screen calibration, PVR etc.) or wipe and install the ones in this build?' , nolabel = 'Keep my settings' , yeslabel = 'Replace my settings' )
  if 93 - 93: OoooO0Oo0O0 - o0oOo0 % OoooO0Oo0O0
 if local == 'fresh' :
  iIi11I1II = 1
  if 12 - 12: iiIi1i11 + ii1ii11IIIiiI * o00O0OoO + iI1IiiIIIiIi + i11111IIIII
 if iIi11I1II == 1 :
  if 58 - 58: i1Iii1i1I * iI1IiiIIIiIi - i11iIiiIii % OoooO0Oo0O0
  if os . path . exists ( I11i1 ) :
   if 3 - 3: Iiii1i1 . o00O0OoO % oO0OooOoO * o0Oo % i1IIi * ii1ii11IIIiiI
   try :
    print "### Attempting to remove guisettings"
    os . remove ( I11i1 )
    ooo000 = True
    if 5 - 5: oO0OooOoO * i1IIi % iI1IiiIIIiIi
   except :
    print "### Problem removing guisettings"
    ooo000 = False
    if 55 - 55: o0Oo + i1Iii1i1I
   try :
    print "### Attempting to replace guisettings with new"
    os . rename ( iIi1ii1I1 , I11i1 )
    ooo000 = True
    if 85 - 85: III1IiiI + i1Iii1i1I % i1Iii1i1I / o00O0OoO . o0Oo - O00OOOoOoo0O
   except :
    print "### Failed to replace guisettings with new"
    ooo000 = False
    if 19 - 19: o00O0OoO / i1Iii1i1I + i11111IIIII
    if 76 - 76: iIii1I11I1II1 / Iiii1i1 - OoooO0Oo0O0 % oOO00Oo % iiIi1i11 + OoooooooOO
 if iIi11I1II == 0 :
  IiI1i111IiIiIi1 = open ( Oo0OoO00oOO0o , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
  if 10 - 10: ii1ii11IIIiiI * o00O0OoO / II11iIiIIIiI - Iiii1i1
  O00O0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( o0oO0OoO0 )
  ii11i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( o0oO0OoO0 )
  iIiI1I = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( o0oO0OoO0 )
  iIOOO0O00 = O00O0 [ 0 ] if ( len ( O00O0 ) > 0 ) else ''
  Oo0O000OoO00 = ii11i1i [ 0 ] if ( len ( ii11i1i ) > 0 ) else ''
  oOO00OoOo = iIiI1I [ 0 ] if ( len ( iIiI1I ) > 0 ) else ''
  if 11 - 11: i11111IIIII % OoooO0Oo0O0 / o0oOo0 . i11iIiiIii + iiIi1i11 - oO0OooOoO
  if 50 - 50: i1IIi * III1IiiI / i11iIiiIii / i11iIiiIii / III1IiiI
  oOoO0Iii1II1ii = open ( iIi1ii1I1 , mode = 'r' )
  ooOo00 = oOoO0Iii1II1ii . read ( )
  oOoO0Iii1II1ii . close ( )
  if 84 - 84: OoooO0Oo0O0 - i1Iii1i1I + OoooO0Oo0O0
  iIO0oooooO = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOo00 )
  IIi1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOo00 )
  II11II = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOo00 )
  i1ii11 = iIO0oooooO [ 0 ] if ( len ( iIO0oooooO ) > 0 ) else ''
  IIIo00O = IIi1 [ 0 ] if ( len ( IIi1 ) > 0 ) else ''
  ii1I1I1 = II11II [ 0 ] if ( len ( II11II ) > 0 ) else ''
  II1i11i1iIi11 = o0oO0OoO0 . replace ( iIOOO0O00 , i1ii11 ) . replace ( oOO00OoOo , ii1I1I1 ) . replace ( Oo0O000OoO00 , IIIo00O )
  if 63 - 63: o00O0OoO * o0oOo0 % oO0OooOoO % Iiii1i1 + o0Oo * II11iIiIIIiI
  I1iI1I1 = open ( Oo0OoO00oOO0o , mode = 'w+' )
  I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
  I1iI1I1 . close ( )
  if 96 - 96: i11111IIIII
  if 99 - 99: iIii1I11I1II1 - o0oOo0
  if os . path . exists ( I11i1 ) :
   if 79 - 79: o0Oo + III1IiiI % o00O0OoO % III1IiiI
   try :
    os . remove ( I11i1 )
    ooo000 = True
    if 56 - 56: OoooO0Oo0O0 + III1IiiI . ii1ii11IIIiiI + OoooooooOO * OoooO0Oo0O0 - O0
   except :
    ooo000 = False
    if 35 - 35: iiIi1i11 . o00O0OoO . Iiii1i1 - o00O0OoO % o00O0OoO + Iiii1i1
  try :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   os . remove ( iIi1ii1I1 )
   ooo000 = True
   if 99 - 99: oOO00Oo + iiIi1i11
  except :
   ooo000 = False
   if 34 - 34: Iiii1i1 * oOO00Oo . o0Oo % i11iIiiIii
   if 61 - 61: iIii1I11I1II1 + III1IiiI * o00O0OoO - i1IIi % III1IiiI
 if ooo000 == True or local == None :
  if 76 - 76: III1IiiI / O00OOOoOoo0O
  try :
   IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'r' )
   o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
   IiI1i111IiIiIi1 . close ( )
   if 12 - 12: Iiii1i1
   OO0oOo = re . compile ( 'id="(.+?)"' ) . findall ( o0oO0OoO0 )
   IIiIi1II1IiI = re . compile ( 'name="(.+?)"' ) . findall ( o0oO0OoO0 )
   oo0OoO = re . compile ( 'version="(.+?)"' ) . findall ( o0oO0OoO0 )
   I11iIiiI = OO0oOo [ 0 ] if ( len ( OO0oOo ) > 0 ) else ''
   OO000oo0o = IIiIi1II1IiI [ 0 ] if ( len ( IIiIi1II1IiI ) > 0 ) else ''
   ooO0o0oo = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
   if 4 - 4: Iiii1i1 * o0Oo % o0Oo / OoooooooOO
   I1iI1I1 = open ( I1IIiiIiii , mode = 'w+' )
   I1iI1I1 . write ( 'id="' + str ( I11iIiiI ) + '"\nname="' + OO000oo0o + '"\nversion="' + ooO0o0oo + '"\ngui="' + I1iI1 + '"' )
   I1iI1I1 . close ( )
   if 52 - 52: III1IiiI + Iiii1i1 * Iiii1i1 * II11iIiIIIiI - iIii1I11I1II1 + OoooO0Oo0O0
   IiI1i111IiIiIi1 = open ( O000OO0 , mode = 'r' )
   o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
   IiI1i111IiIiIi1 . close ( )
   if 34 - 34: i1Iii1i1I / ii1ii11IIIiiI / II11iIiIIIiI
   O0O0O = re . compile ( 'version="(.+?)"' ) . findall ( o0oO0OoO0 )
   I1I1IiI1 = O0O0O [ 0 ] if ( len ( O0O0O ) > 0 ) else ''
   II1i11i1iIi11 = o0oO0OoO0 . replace ( I1I1IiI1 , ooO0o0oo )
   if 92 - 92: Iiii1i1 % i1Iii1i1I % oOO00Oo . o0Oo - OoooO0Oo0O0 - oOO00Oo
   I1iI1I1 = open ( O000OO0 , mode = 'w' )
   I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
   I1iI1I1 . close ( )
   os . remove ( I11iii1Ii )
   if 40 - 40: o0Oo / OoooooooOO + ii1ii11IIIiiI * ii1ii11IIIiiI
  except :
   I1iI1I1 = open ( I1IIiiIiii , mode = 'w+' )
   I1iI1I1 . write ( 'id="None"\nname="Unknown"\nversion="Unknown"\ngui="' + I1iI1 + '"' )
   I1iI1I1 . close ( )
   if 9 - 9: iIii1I11I1II1
   if 57 - 57: o0oOo0 / iI1IiiIIIiIi % oOO00Oo % i11iIiiIii
 if os . path . exists ( os . path . join ( OOO00O , 'profiles.xml' ) ) :
  os . remove ( os . path . join ( OOO00O , 'profiles.xml' ) )
  time . sleep ( 1 )
  if 95 - 95: Iiii1i1 - oOO00Oo
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 65 - 65: i11iIiiIii - OoooooooOO / O0 * i11111IIIII % o00O0OoO
 o00o00 = xbmc . translatePath ( os . path . join ( iiI1IiI , o0OO00 , 'notification.txt' ) )
 if 72 - 72: i1IIi
 if os . path . exists ( o00o00 ) :
  os . remove ( o00o00 )
  if 21 - 21: Iiii1i1 . iiIi1i11 / i11iIiiIii * i1IIi
 if ooo000 == True :
  IiIIIi ( )
  Oo0iII ( )
  if 82 - 82: o0oOo0 * II11iIiIIIiI % i11iIiiIii * i1IIi . iiIi1i11
  if 89 - 89: i11111IIIII - i1IIi - i11111IIIII
def oOOo00OOOO ( url ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/HardwarePortal/hardwaredetails.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 ooOo0Ooo0 = re . compile ( 'manufacturer="(.+?)"' ) . findall ( OoOO0o )
 OoOOOOOoOo0 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( OoOO0o )
 iIi = re . compile ( 'video_guide2="(.+?)"' ) . findall ( OoOO0o )
 oOo = re . compile ( 'video_guide3="(.+?)"' ) . findall ( OoOO0o )
 ooOo0o = re . compile ( 'video_guide4="(.+?)"' ) . findall ( OoOO0o )
 III = re . compile ( 'video_guide5="(.+?)"' ) . findall ( OoOO0o )
 IiiI = re . compile ( 'video_label1="(.+?)"' ) . findall ( OoOO0o )
 OoOoO00o00 = re . compile ( 'video_label2="(.+?)"' ) . findall ( OoOO0o )
 OOooooO0o0O0 = re . compile ( 'video_label3="(.+?)"' ) . findall ( OoOO0o )
 oO0ooo00o0o000Oo = re . compile ( 'video_label4="(.+?)"' ) . findall ( OoOO0o )
 Oooo00OOo = re . compile ( 'video_label5="(.+?)"' ) . findall ( OoOO0o )
 IIIiIii111IIi = re . compile ( 'shops="(.+?)"' ) . findall ( OoOO0o )
 ii1IIi1ii = re . compile ( 'description="(.+?)"' ) . findall ( OoOO0o )
 oo0IiIIiIi11ii = re . compile ( 'screenshot1="(.+?)"' ) . findall ( OoOO0o )
 II11IiIIiiiii = re . compile ( 'screenshot2="(.+?)"' ) . findall ( OoOO0o )
 oooOOo0o0OOO = re . compile ( 'screenshot3="(.+?)"' ) . findall ( OoOO0o )
 IiiiII = re . compile ( 'screenshot4="(.+?)"' ) . findall ( OoOO0o )
 OoOo00OoOO00 = re . compile ( 'screenshot5="(.+?)"' ) . findall ( OoOO0o )
 oO0oOOoOo000O = re . compile ( 'screenshot6="(.+?)"' ) . findall ( OoOO0o )
 II1o0O0OO = re . compile ( 'screenshot7="(.+?)"' ) . findall ( OoOO0o )
 oOoO0o = re . compile ( 'screenshot8="(.+?)"' ) . findall ( OoOO0o )
 i1II = re . compile ( 'screenshot9="(.+?)"' ) . findall ( OoOO0o )
 OOOoooOo00O = re . compile ( 'screenshot10="(.+?)"' ) . findall ( OoOO0o )
 iiIIiI1I = re . compile ( 'screenshot11="(.+?)"' ) . findall ( OoOO0o )
 oOoO0oOO0o = re . compile ( 'screenshot12="(.+?)"' ) . findall ( OoOO0o )
 oO0000oo0o0o0 = re . compile ( 'screenshot13="(.+?)"' ) . findall ( OoOO0o )
 i1I1 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( OoOO0o )
 O0ooO0o = re . compile ( 'added="(.+?)"' ) . findall ( OoOO0o )
 i11OOoo = re . compile ( 'platform="(.+?)"' ) . findall ( OoOO0o )
 IiII1111I = re . compile ( 'chipset="(.+?)"' ) . findall ( OoOO0o )
 iiIIii111Ii = re . compile ( 'official_guide="(.+?)"' ) . findall ( OoOO0o )
 OO000oooOo000 = re . compile ( 'official_preview="(.+?)"' ) . findall ( OoOO0o )
 OO0ooO00o = re . compile ( 'thumbnail="(.+?)"' ) . findall ( OoOO0o )
 o0oO0o0Oo0 = re . compile ( 'stock_rom="(.+?)"' ) . findall ( OoOO0o )
 i1I1iiiI = re . compile ( 'CPU="(.+?)"' ) . findall ( OoOO0o )
 i1IiIi1I1i = re . compile ( 'GPU="(.+?)"' ) . findall ( OoOO0o )
 Ii11I1 = re . compile ( 'RAM="(.+?)"' ) . findall ( OoOO0o )
 OO00OO = re . compile ( 'flash="(.+?)"' ) . findall ( OoOO0o )
 IiIiIi11iiIi1 = re . compile ( 'wifi="(.+?)"' ) . findall ( OoOO0o )
 OoOoO0O00oo = re . compile ( 'bluetooth="(.+?)"' ) . findall ( OoOO0o )
 ooo0o0oooo = re . compile ( 'LAN="(.+?)"' ) . findall ( OoOO0o )
 o0OoIiiiiiiI111i = re . compile ( 'xbmc_version="(.+?)"' ) . findall ( OoOO0o )
 iiIIIIiI11II1 = re . compile ( 'pros="(.+?)"' ) . findall ( OoOO0o )
 IiI1i11i1iI = re . compile ( 'cons="(.+?)"' ) . findall ( OoOO0o )
 o0oo0O0OO0 = re . compile ( 'library_scan="(.+?)"' ) . findall ( OoOO0o )
 IIiI = re . compile ( '4k="(.+?)"' ) . findall ( OoOO0o )
 i11I1Ii1Iiii1 = re . compile ( '1080="(.+?)"' ) . findall ( OoOO0o )
 o0oooOoOoOo = re . compile ( '720="(.+?)"' ) . findall ( OoOO0o )
 OO0O = re . compile ( '3D="(.+?)"' ) . findall ( OoOO0o )
 oo0ooOoo00Ooo = re . compile ( 'DTS="(.+?)"' ) . findall ( OoOO0o )
 IIiii111I1 = re . compile ( 'BootTime="(.+?)"' ) . findall ( OoOO0o )
 iiii1i1 = re . compile ( 'CopyFiles="(.+?)"' ) . findall ( OoOO0o )
 OOooooO0 = re . compile ( 'CopyVideo="(.+?)"' ) . findall ( OoOO0o )
 I1II = re . compile ( 'EthernetTest="(.+?)"' ) . findall ( OoOO0o )
 I1Ii11iI11ii = re . compile ( 'Slideshow="(.+?)"' ) . findall ( OoOO0o )
 oOo0 = re . compile ( 'total_review="(.+?)"' ) . findall ( OoOO0o )
 ii1II = re . compile ( 'whufclee_review="(.+?)"' ) . findall ( OoOO0o )
 OOo00o0o0O0oo = re . compile ( 'CB_Premium="(.+?)"' ) . findall ( OoOO0o )
 if 15 - 15: iiIi1i11
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 o0oOOO0 = ooOo0Ooo0 [ 0 ] if ( len ( ooOo0Ooo0 ) > 0 ) else ''
 OooOo00o = OoOOOOOoOo0 [ 0 ] if ( len ( OoOOOOOoOo0 ) > 0 ) else 'None'
 IiI11i1IIiiI = iIi [ 0 ] if ( len ( iIi ) > 0 ) else 'None'
 oOOo000oOoO0 = oOo [ 0 ] if ( len ( oOo ) > 0 ) else 'None'
 OoOo00o0OO = ooOo0o [ 0 ] if ( len ( ooOo0o ) > 0 ) else 'None'
 ii1IIIIiI11 = III [ 0 ] if ( len ( III ) > 0 ) else 'None'
 I1iii = IiiI [ 0 ] if ( len ( IiiI ) > 0 ) else 'None'
 oO0o0O0Ooo0o = OoOoO00o00 [ 0 ] if ( len ( OoOoO00o00 ) > 0 ) else 'None'
 i1Ii11II = OOooooO0o0O0 [ 0 ] if ( len ( OOooooO0o0O0 ) > 0 ) else 'None'
 IioO0oOOO0Ooo = oO0ooo00o0o000Oo [ 0 ] if ( len ( oO0ooo00o0o000Oo ) > 0 ) else 'None'
 i1i1I = Oooo00OOo [ 0 ] if ( len ( Oooo00OOo ) > 0 ) else 'None'
 i1Iii = IIIiIii111IIi [ 0 ] if ( len ( IIIiIii111IIi ) > 0 ) else ''
 O0oii111 = ii1IIi1ii [ 0 ] if ( len ( ii1IIi1ii ) > 0 ) else ''
 oOOo0OOOOo0o = oo0IiIIiIi11ii [ 0 ] if ( len ( oo0IiIIiIi11ii ) > 0 ) else ''
 I1i1iiii = II11IiIIiiiii [ 0 ] if ( len ( II11IiIIiiiii ) > 0 ) else ''
 O00OIIIIIi1 = oooOOo0o0OOO [ 0 ] if ( len ( oooOOo0o0OOO ) > 0 ) else ''
 o0oIi1iiiii = IiiiII [ 0 ] if ( len ( IiiiII ) > 0 ) else ''
 O00o0 = OoOo00OoOO00 [ 0 ] if ( len ( OoOo00OoOO00 ) > 0 ) else ''
 IIiIiIi1II = oO0oOOoOo000O [ 0 ] if ( len ( oO0oOOoOo000O ) > 0 ) else ''
 oO00 = II1o0O0OO [ 0 ] if ( len ( II1o0O0OO ) > 0 ) else ''
 IiiIIiii = oOoO0o [ 0 ] if ( len ( oOoO0o ) > 0 ) else ''
 iIIIii111 = i1II [ 0 ] if ( len ( i1II ) > 0 ) else ''
 I1111IiII1 = OOOoooOo00O [ 0 ] if ( len ( OOOoooOo00O ) > 0 ) else ''
 IiiII = iiIIiI1I [ 0 ] if ( len ( iiIIiI1I ) > 0 ) else ''
 OO00OO0 = oOoO0oOO0o [ 0 ] if ( len ( oOoO0oOO0o ) > 0 ) else ''
 Ooii = oO0000oo0o0o0 [ 0 ] if ( len ( oO0000oo0o0o0 ) > 0 ) else ''
 i11iII1 = i1I1 [ 0 ] if ( len ( i1I1 ) > 0 ) else ''
 oOooo = O0ooO0o [ 0 ] if ( len ( O0ooO0o ) > 0 ) else ''
 O00oO0 = i11OOoo [ 0 ] if ( len ( i11OOoo ) > 0 ) else ''
 i11iI1111ii1I = IiII1111I [ 0 ] if ( len ( IiII1111I ) > 0 ) else ''
 OoOo0 = iiIIii111Ii [ 0 ] if ( len ( iiIIii111Ii ) > 0 ) else 'None'
 iiIIii = OO000oooOo000 [ 0 ] if ( len ( OO000oooOo000 ) > 0 ) else 'None'
 oOooooO = OO0ooO00o [ 0 ] if ( len ( OO0ooO00o ) > 0 ) else ''
 O000oo00o000o = o0oO0o0Oo0 [ 0 ] if ( len ( o0oO0o0Oo0 ) > 0 ) else ''
 O0000ooO = i1I1iiiI [ 0 ] if ( len ( i1I1iiiI ) > 0 ) else ''
 O00OoO = i1IiIi1I1i [ 0 ] if ( len ( i1IiIi1I1i ) > 0 ) else ''
 I11i11 = Ii11I1 [ 0 ] if ( len ( Ii11I1 ) > 0 ) else ''
 oooo0OOO00O00 = OO00OO [ 0 ] if ( len ( OO00OO ) > 0 ) else ''
 i11I111I1 = IiIiIi11iiIi1 [ 0 ] if ( len ( IiIiIi11iiIi1 ) > 0 ) else ''
 OOOoO000o0O0O = OoOoO0O00oo [ 0 ] if ( len ( OoOoO0O00oo ) > 0 ) else ''
 oO0oOO = ooo0o0oooo [ 0 ] if ( len ( ooo0o0oooo ) > 0 ) else ''
 oO000o = o0OoIiiiiiiI111i [ 0 ] if ( len ( o0OoIiiiiiiI111i ) > 0 ) else ''
 Oo0O = iiIIIIiI11II1 [ 0 ] if ( len ( iiIIIIiI11II1 ) > 0 ) else ''
 i1iIi1iiii1ii = IiI1i11i1iI [ 0 ] if ( len ( IiI1i11i1iI ) > 0 ) else ''
 oO0oOo = o0oo0O0OO0 [ 0 ] if ( len ( o0oo0O0OO0 ) > 0 ) else ''
 IIiIiii = IIiI [ 0 ] if ( len ( IIiI ) > 0 ) else ''
 OOo0OO = i11I1Ii1Iiii1 [ 0 ] if ( len ( i11I1Ii1Iiii1 ) > 0 ) else ''
 ooIIi111I = o0oooOoOoOo [ 0 ] if ( len ( o0oooOoOoOo ) > 0 ) else ''
 ooo00oOoo000O = OO0O [ 0 ] if ( len ( OO0O ) > 0 ) else ''
 oO0OoO0O0o = oo0ooOoo00Ooo [ 0 ] if ( len ( oo0ooOoo00Ooo ) > 0 ) else ''
 iii1i = IIiii111I1 [ 0 ] if ( len ( IIiii111I1 ) > 0 ) else ''
 i111iiI11iI = iiii1i1 [ 0 ] if ( len ( iiii1i1 ) > 0 ) else ''
 Oo0OO0oO0O = OOooooO0 [ 0 ] if ( len ( OOooooO0 ) > 0 ) else ''
 iIIii = I1II [ 0 ] if ( len ( I1II ) > 0 ) else ''
 o000oo = I1Ii11iI11ii [ 0 ] if ( len ( I1Ii11iI11ii ) > 0 ) else ''
 O0Ooo0o = oOo0 [ 0 ] if ( len ( oOo0 ) > 0 ) else ''
 Iii1 = ii1II [ 0 ] if ( len ( ii1II ) > 0 ) else 'None'
 iiIIi1i111i = OOo00o0o0O0oo [ 0 ] if ( len ( OOo00o0o0O0oo ) > 0 ) else ''
 iII = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + oOooo + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + o0oOOO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + O00oO0 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + i11iI1111ii1I + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0000ooO + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + O00OoO + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + I11i11 + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oooo0OOO00O00 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + i11I111I1 + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + OOOoO000o0O0O + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + oO0oOO + '[CR][CR][COLOR=yellow]About: [/COLOR]' + O0oii111 + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + Oo0O + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + i1iIi1iiii1ii + '[CR][CR][COLOR=yellow]Benchmark Results:[/COLOR][CR][CR][COLOR=dodgerblue]Boot Time:[/COLOR][CR]' + iii1i + '[CR][CR][COLOR=dodgerblue]Time taken to scan 1,000 movies (local NFO files):[/COLOR][CR]' + oO0oOo + '[CR][CR][COLOR=dodgerblue]Copy 4,000 files (660.8MB) locally:[/COLOR][CR]' + i111iiI11iI + '[CR][CR][COLOR=dodgerblue]Copy a MP4 file (339.4MB) locally:[/COLOR][CR]' + Oo0OO0oO0O + '[CR][CR][COLOR=dodgerblue]Ethernet Speed - Copy MP4 (339.4MB) from SMB share to device:[/COLOR][CR]' + iIIii + '[CR][CR][COLOR=dodgerblue]4k Playback:[/COLOR][CR]' + IIiIiii + '[CR][CR][COLOR=dodgerblue]1080p Playback:[/COLOR][CR]' + OOo0OO + '[CR][CR][COLOR=dodgerblue]720p Playback:[/COLOR][CR]' + ooIIi111I + '[CR][CR][COLOR=dodgerblue]Audio Playback:[/COLOR][CR]' + oO0OoO0O0o + '[CR][CR][COLOR=dodgerblue]Image Slideshow:[/COLOR][CR]' + o000oo )
 OoOo0Oo00Oo = str ( '[COLOR=dodgerblue]Added: [/COLOR]' + oOooo + '[CR][COLOR=dodgerblue]Manufacturer: [/COLOR]' + o0oOOO0 + '[CR][COLOR=dodgerblue]Supported Roms: [/COLOR]' + O00oO0 + '[CR][COLOR=dodgerblue]Chipset: [/COLOR]' + i11iI1111ii1I + '[CR][COLOR=dodgerblue]CPU: [/COLOR]' + O0000ooO + '[CR][COLOR=dodgerblue]GPU: [/COLOR]' + O00OoO + '[CR][COLOR=dodgerblue]RAM: [/COLOR]' + I11i11 + '[CR][COLOR=dodgerblue]Flash: [/COLOR]' + oooo0OOO00O00 + '[CR][COLOR=dodgerblue]Wi-Fi: [/COLOR]' + i11I111I1 + '[CR][COLOR=dodgerblue]Bluetooth: [/COLOR]' + OOOoO000o0O0O + '[CR][COLOR=dodgerblue]LAN: [/COLOR]' + oO0oOO + '[CR][CR][COLOR=yellow]About: [/COLOR]' + O0oii111 + '[CR][CR][COLOR=yellow]Summary:[/COLOR][CR][CR][COLOR=dodgerblue]Pros:[/COLOR]    ' + Oo0O + '[CR][CR][COLOR=dodgerblue]Cons:[/COLOR]  ' + i1iIi1iiii1ii + '[CR][CR][COLOR=orange]4k Playback:[/COLOR]  ' + IIiIiii + '[CR][CR][COLOR=orange]1080p Playback:[/COLOR]  ' + OOo0OO + '[CR][CR][COLOR=orange]720p Playback:[/COLOR]  ' + ooIIi111I + '[CR][CR][COLOR=orange]DTS Compatibility:[/COLOR]  ' + oO0OoO0O0o + '[CR][CR][COLOR=orange]Time taken to scan 100 movies:[/COLOR]  ' + oO0oOo )
 if 27 - 27: ii1ii11IIIiiI
 if O0oii111 != '' and i1Iii != '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , iII , 'text_guide' , '' , Oo00OOOOO , '' , '' )
 if O0oii111 != '' and i1Iii == '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  Official Description' , OoOo0Oo00Oo , 'text_guide' , '' , Oo00OOOOO , '' , '' )
 if Iii1 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Benchmark Review' , Iii1 , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if iiIIii != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Preview' , iiIIii , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if OoOo0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]   Official Video Guide' , OoOo0 , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if OooOo00o != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1iii , OooOo00o , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if IiI11i1IIiiI != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO0o0O0Ooo0o , IiI11i1IIiiI , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if oOOo000oOoO0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1Ii11II , oOOo000oOoO0 , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if OoOo00o0OO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IioO0oOOO0Ooo , OoOo00o0OO , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if ii1IIIIiI11 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1i1I , ii1IIIIiI11 , 'play_video' , '' , Oo00OOOOO , '' , '' )
  if 88 - 88: iiIi1i11 . II11iIiIIIiI * i11111IIIII - iIii1I11I1II1 % III1IiiI
  if 80 - 80: iI1IiiIIIiIi - OoooO0Oo0O0 . iI1IiiIIIiIi / i11iIiiIii + O0 . i11111IIIII
def III11i ( ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'hardware' , 'manual_search' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime]All Devices[/COLOR]' , '' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Game Consoles' , 'device=Console' , '' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] HTPC' , 'device=HTPC' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Phones' , 'device=Phone' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Set Top Boxes' , 'device=STB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Hardware][/COLOR] Tablets' , 'device=Tablet' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Remotes/Keyboards' , 'device=Remote' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Gaming Controllers' , 'device=Controller' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Accessories][/COLOR] Dongles' , 'device=Dongle' , 'grab_hardware' , '' , '' , '' , '' )
 if 54 - 54: Iiii1i1 / oOO00Oo
 if 39 - 39: iiIi1i11 % III1IiiI * OoooO0Oo0O0 - O0 + o0Oo + oOO00Oo
def oooOo ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Allwinner Devices' , str ( url ) + '&chip=Allwinner' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] AMLogic Devices' , str ( url ) + '&chip=AMLogic' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Intel Devices' , str ( url ) + '&chip=Intel' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow][CPU][/COLOR] Rockchip Devices' , str ( url ) + '&chip=Rockchip' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Android' , str ( url ) + '&platform=Android' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] iOS' , str ( url ) + '&platform=iOS' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Linux' , str ( url ) + '&platform=Linux' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] OpenELEC' , str ( url ) + '&platform=OpenELEC' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] OSX' , str ( url ) + '&platform=OSX' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Pure Linux' , str ( url ) + '&platform=Custom_Linux' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][Platform][/COLOR] Windows' , str ( url ) + '&platform=Windows' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 4GB' , str ( url ) + '&flash=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 8GB' , str ( url ) + '&flash=8GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 16GB' , str ( url ) + '&flash=16GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 32GB' , str ( url ) + '&flash=32GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange][Flash Storage][/COLOR] 64GB' , str ( url ) + '&flash=64GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 1GB' , str ( url ) + '&ram=1GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 2GB' , str ( url ) + '&ram=2GB' , 'grab_hardware' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][RAM][/COLOR] 4GB' , str ( url ) + '&ram=4GB' , 'grab_hardware' , '' , '' , '' , '' )
 if 91 - 91: o0Oo - i1Iii1i1I / ii1ii11IIIiiI - ii1ii11IIIiiI / iI1IiiIIIiIi - i11111IIIII
 if 14 - 14: iiIi1i11 / oOO00Oo + iI1IiiIIIiIi / OoooooooOO - o00O0OoO
 if 88 - 88: iI1IiiIIIiIi / OoooooooOO % O00OOOoOoo0O - i1IIi
def iIiIi111 ( ) :
 OOOO0OOoO0O0 = xbmc . getSkinDir ( )
 i111IiiI1Ii = xbmc . translatePath ( os . path . join ( OO0o , OOOO0OOoO0O0 ) )
 if 1 - 1: Iiii1i1 * O00OOOoOoo0O
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( i111IiiI1Ii ) :
  if 100 - 100: OoooO0Oo0O0 / O0 / o0oOo0 + OoooO0Oo0O0
  for iiI1iii in I1iiIi111I :
   if 48 - 48: OoooooooOO . i1Iii1i1I + O0
   if 'DialogKeyboard.xml' in iiI1iii :
    OOOO0OOoO0O0 = os . path . join ( oO0000O0Oo00O , iiI1iii )
    OO0Oo = open ( OOOO0OOoO0O0 ) . read ( )
    IIiiiiiIiIIi = OO0Oo . replace ( '<control type="label" id="310"' , '<control type="edit" id="312"' )
    iiI1iii = open ( OOOO0OOoO0O0 , mode = 'w' )
    iiI1iii . write ( IIiiiiiIiIIi )
    iiI1iii . close ( )
    i111i1I1ii1i ( OOOO0OOoO0O0 )
    if 85 - 85: oO0OooOoO - iI1IiiIIIiIi
    for OoOooOo00o in range ( 48 , 58 ) :
     IiIioO0Oo00oo ( OoOooOo00o , OOOO0OOoO0O0 )
     if 93 - 93: i11111IIIII / i11iIiiIii - III1IiiI + ii1ii11IIIiiI / i1IIi
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( "Skin Changes Successful" , 'A BIG thank you to Mikey1234 for this fix. The code used for this function was ported from the Xunity Maintenance add-on' )
 xbmc . executebuiltin ( 'ReloadSkin()' )
 if 62 - 62: OoooO0Oo0O0 / OoooooooOO * o0Oo - i1IIi
def OO0oOOo0o ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 I11II11IiI11 = xbmcgui . Dialog ( ) . yesno ( 'Convert This Skin To Kodi (Helix)?' , 'This will fix the problem with a blank on-screen keyboard showing in skins designed for Gotham (being run on Kodi). This will only affect the currently running skin.' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Fix' )
 if 46 - 46: OoooooooOO
 if I11II11IiI11 == 1 :
  iIiIi111 ( )
  if 23 - 23: i1IIi
  if 31 - 31: II11iIiIIIiI - iIii1I11I1II1 / o00O0OoO . ii1ii11IIIiiI
def oOOo0O0Oo ( ) :
 if OOooO0OOoo . yesno ( "Hide Passwords" , "This will hide all your passwords in your" , "add-on settings, are you sure you wish to continue?" ) :
  for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( OO0o ) :
   for iiI1iii in I1iiIi111I :
    if iiI1iii == 'settings.xml' :
     III1I1I1iiIi = open ( os . path . join ( oO0000O0Oo00O , iiI1iii ) ) . read ( )
     I11iIiII = re . compile ( '<setting id=(.+?)>' ) . findall ( III1I1I1iiIi )
     for iIi1i1I1I in I11iIiII :
      if 'pass' in iIi1i1I1I :
       if not 'option="hidden"' in iIi1i1I1I :
        try :
         i11iiiI = iIi1i1I1I . replace ( '/' , ' option="hidden"/' )
         iiI1iii = open ( os . path . join ( oO0000O0Oo00O , iiI1iii ) , mode = 'w' )
         iiI1iii . write ( str ( III1I1I1iiIi ) . replace ( iIi1i1I1I , i11iiiI ) )
         iiI1iii . close ( )
        except :
         pass
  OOooO0OOoo . ok ( "Passwords Hidden" , "Your passwords will now show as stars (hidden), if you want to undo this please use the option to unhide passwords." )
  if 100 - 100: i11111IIIII / OoooO0Oo0O0 - i1Iii1i1I
  if 85 - 85: iI1IiiIIIiIi + Iiii1i1 . iiIi1i11 . O0 . O00OOOoOoo0O * oO0OooOoO
def oooOoooO000o ( url ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/Community_Builds/guisettings.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I1I1O0O = re . compile ( 'guisettings="(.+?)"' ) . findall ( OoOO0o )
 OoO000oo000o0 = I1I1O0O [ 0 ] if ( len ( I1I1O0O ) > 0 ) else 'None'
 if 55 - 55: i1IIi * OoooooooOO % O0 % i1Iii1i1I . iIii1I11I1II1 / O00OOOoOoo0O
 i1iiiI1I ( OoO000oo000o0 , O0oIIiIiiiii11 )
 if 58 - 58: OoooooooOO / iIii1I11I1II1
 if 25 - 25: O0 % i11iIiiIii + iI1IiiIIIiIi + iiIi1i11
def II11IIOOOOO0oOOoO ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keywords' , '' , 'nan_menu' , '' , '' , '' , '' )
 if 42 - 42: o0Oo + i11iIiiIii / ii1ii11IIIiiI
 if iI111iI == 'true' and IiII != '' and iI1Ii11111iIi != '' :
  oO00oOOoooO ( '' , 'Install ' + iI1Ii11111iIi + ' keyword' , IiII , 'keywords' , '' , '' , '' , '' )
  if 64 - 64: i11111IIIII
 if o00 == 'true' :
  oO00oOOoooO ( 'folder' , 'Install Add-ons' , oOOo0 , 'addonmenu' , '' , '' , '' , '' )
  if 80 - 80: o0Oo - i11iIiiIii / ii1ii11IIIiiI / O00OOOoOoo0O + O00OOOoOoo0O
 if Oo0oO0ooo == 'true' :
  oO00oOOoooO ( 'folder' , 'Community Builds' , url , 'community' , '' , '' , '' , '' )
  if 89 - 89: O0 + i11111IIIII * Iiii1i1
  if 30 - 30: O00OOOoOoo0O
def IIIII11 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://install/",return)' )
 if 48 - 48: Iiii1i1 / o0oOo0 . iIii1I11I1II1
 if 72 - 72: i1IIi . oOO00Oo
def IIIiiI1 ( repo_id ) :
 ii1OoOO = 1
 I1II1I11I1I = 'http://noobsandnerds.com/TI/AddonPortal/dependencyinstall.php?id=%s' % ( repo_id )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 O00O = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
 o00O = re . compile ( 'repo_url="(.+?)"' ) . findall ( OoOO0o )
 i1Ii1i1I11Iii = re . compile ( 'data_url="(.+?)"' ) . findall ( OoOO0o )
 I1i1i1 = re . compile ( 'zip_url="(.+?)"' ) . findall ( OoOO0o )
 iI1iiiiIii = re . compile ( 'repo_id="(.+?)"' ) . findall ( OoOO0o )
 iIIiiIiII1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 ii11I1 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 I1I1i11 = o00O [ 0 ] if ( len ( o00O ) > 0 ) else ''
 oOo0Oo00O = i1Ii1i1I11Iii [ 0 ] if ( len ( i1Ii1i1I11Iii ) > 0 ) else ''
 i1io0o00O = I1i1i1 [ 0 ] if ( len ( I1i1i1 ) > 0 ) else ''
 iiiI1ii = iI1iiiiIii [ 0 ] if ( len ( iI1iiiiIii ) > 0 ) else ''
 Oo00OOO0 = xbmc . translatePath ( os . path . join ( O00O0oOO00O00 , iiiI1ii + '.zip' ) )
 iiIIii1iII1i = xbmc . translatePath ( os . path . join ( OO0o , iiiI1ii ) )
 if 55 - 55: i11iIiiIii * O0
 iIii1 . create ( 'Installing Repository' , 'Please wait...' , '' )
 if 86 - 86: O0 + O00OOOoOoo0O
 try :
  downloader . download ( I1I1i11 , Oo00OOO0 , iIii1 )
  extract . all ( Oo00OOO0 , OO0o , iIii1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 99 - 99: O0 + i11111IIIII + o0oOo0 - o0oOo0 * OoooO0Oo0O0 / i11111IIIII
 except :
  if 82 - 82: oOO00Oo - iiIi1i11
  try :
   downloader . download ( i1io0o00O , Oo00OOO0 , iIii1 )
   extract . all ( Oo00OOO0 , OO0o , iIii1 )
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if 84 - 84: i1Iii1i1I % i1IIi % ii1ii11IIIiiI % oO0OooOoO
  except :
   if 94 - 94: o0oOo0 * O0
   try :
    if 60 - 60: i1Iii1i1I / i1Iii1i1I - o0oOo0 / OoooooooOO + O0
    if not os . path . exists ( iiIIii1iII1i ) :
     os . makedirs ( iiIIii1iII1i )
     if 55 - 55: ii1ii11IIIiiI % O0 / OoooooooOO
    OoOO0o = i1II1 ( oOo0Oo00O , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    I11iIiII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( OoOO0o )
    if 49 - 49: o0Oo . ii1ii11IIIiiI * OoooooooOO % i11iIiiIii + iIii1I11I1II1 * i1IIi
    for iiiI1ii11 in I11iIiII :
     ii1i = xbmc . translatePath ( os . path . join ( iiIIii1iII1i , iiiI1ii11 ) )
     if 88 - 88: OoooO0Oo0O0 * i1Iii1i1I + oO0OooOoO
     if O0iIiIIIIIii not in iiiI1ii11 and '/' not in iiiI1ii11 :
      if 62 - 62: OoooooooOO
      try :
       iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + iiiI1ii11 + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( oOo0Oo00O + iiiI1ii11 , ii1i , iIii1 )
       if 33 - 33: O0 . i11iIiiIii % oOO00Oo
      except :
       print "failed to install" + iiiI1ii11
       if 50 - 50: o0oOo0
     if '/' in iiiI1ii11 and '..' not in iiiI1ii11 and 'http' not in iiiI1ii11 :
      OooOOo0 = oOo0Oo00O + iiiI1ii11
      ooO000O ( ii1i , OooOOo0 )
      if 81 - 81: i11iIiiIii * iIii1I11I1II1 / II11iIiIIIiI * iiIi1i11
   except :
    OOooO0OOoo . ok ( "Error downloading repository" , 'There was an error downloading[CR][COLOR=dodgerblue]' + iIIiiIiII1i + '[/COLOR]. Please consider updating the add-on portal with details or report the error on the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' )
    ii1OoOO = 0
    if 83 - 83: i11iIiiIii - o0Oo * i11iIiiIii
    if 59 - 59: i1Iii1i1I - OoooooooOO / o0oOo0 + OoooO0Oo0O0 . oOO00Oo - i1Iii1i1I
 if ii1OoOO == 1 :
  time . sleep ( 1 )
  iIii1 . update ( 0 , "[COLOR=yellow]" + iIIiiIiII1i + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing dependencies' )
  time . sleep ( 1 )
  OO00OOoO0o = 'http://noobsandnerds.com/TI/AddonPortal/downloadcount.php?id=%s' % ( repo_id )
  try :
   i1II1 ( OO00OOoO0o , 5 )
  except :
   pass
   if 29 - 29: III1IiiI
   if 26 - 26: O0 % iiIi1i11 - i11111IIIII . iiIi1i11
def OOo0O0 ( ) :
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  What is Community Builds?' , 'url' , 'instructions_3' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Creating a Community Build' , 'url' , 'instructions_1' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue][TEXT GUIDE][/COLOR]  Installing a Community Build' , 'url' , 'instructions_2' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Add Your Own Guides @ [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR]' , 'K0XIxEodUhc' , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Community Builds FULL GUIDE' , "ewuxVfKZ3Fs" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  IMPORTANT initial settings' , "1vXniHsEMEg" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Install a Community Build' , "kLsVOapuM1A" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  Fixing a half installed build (guisettings.xml fix)' , "X8QYLziFzQU" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 1)' , "3rMScZF2h_U" , 'play_video' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=lime][VIDEO GUIDE][/COLOR]  [COLOR=yellow](OLD METHOD)[/COLOR]Create a Community Build (part 2)' , "C2IPhn0OSSw" , 'play_video' , '' , '' , '' , '' )
 if 24 - 24: o0Oo / iIii1I11I1II1 / O0 . iIii1I11I1II1 - ii1ii11IIIiiI . iIii1I11I1II1
 if 8 - 8: OoooO0Oo0O0 % ii1ii11IIIiiI % III1IiiI . OoooO0Oo0O0 * OoooO0Oo0O0
def oooooo0 ( ) :
 OOooO0OO0 ( 'Creating A Backup To Share' ,
 '[COLOR=gold]THE OPTIONS:[/COLOR][CR]There are 3 options when choosing to create a backup, we shall explain here the differences between them:[CR][CR]'
 '[COLOR=dodgerblue]1. noobsandnerds Community Build[/COLOR] - This is by far the best way to create a build that you want to share with others, it will create a zip file for you to share that can only be used on with this add-on. The size of the zip will be incredibly small compared to other backup options out there and it will also do lots of other clever stuff too such as error checking against the Addon Portal and the addons will always be updated via the relevant developer repositories. Added to this when it comes to updating it\'s a breeze, only the new addons not already on the system will be installed and for the majority of builds Kodi won\'t even have to restart after installing![CR][CR]'
 '[COLOR=dodgerblue]2. Universal Build[/COLOR] - This was the original method created by TotalXBMC, we would really only recommend this if for some strange reason you want your build available on other inferior wizards. The zip size is much larger and every time someone wants to update their build they have to download and install the whole thing again which can be very frustrating and time consuming. The whole build is backed up in full with the exception of the packages and thumbnails folder. Just like the option above all physical paths (so long as they exist somewhere in the Kodi environment) will be changed to special paths so they work on all devices.[CR][CR]'
 '[COLOR=dodgerblue]3. Full Backup[/COLOR] - It\'s highly unlikely you will ever want to use this option and it\'s more for the geeks out there. It will create a complete backup of your setup and not do any extra clever stuff. Things like packages will remain intact as will temp cache files, be warned the size could be VERY large![CR][CR]'
 '[CR][COLOR=gold]CREATING A COMMUNITY BUILD:[/COLOR][CR][CR][COLOR=blue][B]Step 1:[/COLOR] Remove any sensitive data[/B][CR]Make sure you\'ve removed any sensitive data such as passwords and usernames in your addon_data folder.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Backup your system[/B][CR]Choose the backup option you want from the list on the previous page, if you\'re sharing this via the CP Addon then please use the noobsandnerds backup option, this will create two zip files that you need to upload to a server.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip files to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it. [COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Submit the build[/B]'
 '[CR]Create a thread on the Community Builds section of the forum at [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR].[CR]Full details can be found on there of the template you should use when posting, once you\'ve created your support thread (NOT BEFORE) you can request to become a member of the Community Builder group and you\'ll then be able to add your build via the web form. As soon as you\'ve successfully added the details your build will be live, if you can\'t find it in the CP addon make sure you have XXX enabled (if you marked it as having adult content) and also make sure you\'re running the same version of Kodi that you said it was compatible with. If you\'re running another version then you can select the option to "show all community builds" in the addon settings and that will show even the builds that aren\'t marked as compatible with your version of Kodi.'
 '[CR][CR][COLOR=gold]PRIVATE BUILDS[/COLOR][CR]If you aren\'t interested in sharing your build with the community you can still use our system for private builds. Just follow the instructions above but you will not need to create a support thread and you WILL require a minimum of 5 useful (not spam) posts on the forum. The 5 post rule only applies to users that wish to use the private builds option. Once you have 5 posts you\'ll be able to access the web form and in there you can enter up to 3 IP addresses that you want to be able to view your build(s). Anybody caught disobeying the forum rules will be banned so please make sure you understand the forum rules before posting, we welcome everyone but there is strictly no spamming or nonsense posts just saying something like "Thanks" in order to bump up your post count. The site rules even have examples of how you can get to 5 posts without receiving a ban.' )
 if 26 - 26: iiIi1i11 + II11iIiIIIiI
 if 71 - 71: o0Oo . o0oOo0
def iI1i11II1i1i ( ) :
 OOooO0OO0 ( 'Installing a build' , '[COLOR=dodgerblue][B]Step 1 (Optional):[/COLOR] Backup your system[/B][CR]When selecting an install option you\'ll be asked if you want to create a backup - we strongly recommend creating a backup of your system in case you don\'t like the build and want to revert back. Remember your backup may be quite large so if you\'re using a device with a very small amount of storage we recommend using a USB stick or SD card as the storage location otherwise you may run out of space and the install may fail.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Choose an install method:[/B][CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]1. Overwrite my current setup & install new build:[/COLOR] This copy over the whole build[CR]As the title suggests this will overwrite your existing setup with the one created by the community builder. We recommend using the wipe option in the maintenance section before running this, that will completely wipe your existing settings and will ensure you don\'t have any conflicting data left on the device. Once you\'ve wiped please restart Kodi and install the build, you can of course use this install option 1 without wiping but you may encounter problems. If you choose to do this DO NOT bombard the community builder with questions on how to fix certain things, they will expect you to have installed over a clean setup and if you\'ve installed over another build the responsibility for bug tracking lies solely with you!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]2. Install:[/COLOR] Keep my library & profiles[CR]This will install a build over the top of your existing setup so you won\'t lose anything already installed in Kodi. Your library and any profiles you may have setup will also remain unchanged.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]3. Install:[/COLOR] Keep my library only[CR]This will do exactly the same as number 2 (above) but it will delete any profiles you may have and replace them with the ones the build author has created.'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=gold]4. Install:[/COLOR] Keep my profiles only[CR]Again, the same as number 2 but your library will be replaced with the one created by the build author. If you\'ve spent a long time setting up your library and have it just how you want it then use this with caution and make sure you do a backup!'
 '[CR][CR]-------------------------------------------------------[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Replace or keep settings?[/B][CR]When completing the install process you\'ll be asked if you want to keep your existing Kodi settings or replace with the ones in the build. If you choose to keep your settings then only the important skin related settings are copied over from the build. All your other Kodi settings such as screen calibration, region, audio output, resolution etc. will remain intact. Choosing to replace your settings could possibly cause a few issues, unless the build author has specifically recommended you replace the settings with theirs we would always recommend keeping your own.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4: [/COLOR][COLOR=red]VERY IMPORTANT[/COLOR][/B][CR]For the install to complete properly Kodi MUST force close, this means forcing it to close via your operating system rather than elegantly via the Kodi menu. By default this add-on will attempt to make your operating system force close Kodi but there are systems that will not allow this (devices that do not allow Kodi to have root permissions).'
 ' Once the final step of the install process has been completed you\'ll see a dialog explaining Kodi is attempting a force close, please be patient and give it a minute. If after a minute Kodi hasn\'t closed or restarted you will need to manually force close. The recommended solution for force closing is to go into your operating system menu and make it force close the Kodi app but if you dont\'t know how to do that you can just pull the power from the unit.'
 ' Pulling the power is fairly safe these days, on most set top boxes it\'s the only way to switch them off - they rarely have a power switch. Even though it\'s considered fairly safe nowadays you do this at your own risk and we would always recommend force closing via the operating system menu.' )
 if 61 - 61: o00O0OoO * iI1IiiIIIiIi + o00O0OoO - II11iIiIIIiI % O00OOOoOoo0O . i1Iii1i1I
 if 51 - 51: iiIi1i11 / o00O0OoO
def O0OOO00O0OO0 ( ) :
 OOooO0OO0 ( 'What is a noobsandnerds keyword?' , '[COLOR=gold]WHAT IS A KEYWORD?[/COLOR][CR]The noobsandnerds keywords are based on the ingenious TLBB keyword system that was introduced years ago. It\'s nothing new and unlike certain other people out there we\'re not going to claim it as our idea. If you\'re already familiar with TLBB Keywords or even some of the copies out there like Cloudwords you will already know how this works but for those of you that don\'t have one of those devices we\'ll just go through the details...'
 '[CR][CR]Anyone in the community can make their own keywords and share them with others, it\'s a simple word you type in and then the content you uploaded to the web is downloaded and installed. Previously keywords have mostly been used for addon packs, this is a great way to get whole packs of addons in one go without the need to install a whole new build. We are taking this to the next level and will be introducing artwork packs and also addon fixes. More details will be available in the Community Portal section of the forum on www.noobsandnerds.com'
 '[CR][CR][CR][COLOR=gold]HOW DO I FIND A KEYWORD?[/COLOR][CR]The full list of noobsandnerds keywords can be found on the forum, in the Community Portal section you\'ll see a section for the keywords at the top of the page. Just find the pack you would like to install then using this addon type the keyword in when prompted (after clicking "Install a noobsandnerds keyword"). Your content will now be installed, if installing addon packs please be patient while each addon updates to the latest version directly from the developers repo.'
 '[CR][CR][CR][COLOR=gold]CAN I USE OTHER KEYWORDS?[/COLOR] (Cloudwords, TLBB etc.)[CR]Yes you can, just go to the addon settings and enter the url shortener that particular company use. Again you will find full details of supported keywords on the forum.' )
 if 5 - 5: III1IiiI + iI1IiiIIIiIi
 if 48 - 48: Iiii1i1 * i1IIi - OoooO0Oo0O0 / o0Oo + i11iIiiIii - i1IIi
def oOo0Oi1i1III11IiIi ( ) :
 OOooO0OO0 ( 'How to create a keyword?' , '[COLOR=gold]NaN MAKE IT EASY![/COLOR][CR]The keywords can now be made very simply by anyone. We\'ve not locked this down to just our addon and others can use this on similar systems for creating keywords if they want...'
 '[CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Use a vanilla Kodi setup[/B][CR]You will require a complete fresh install of Kodi with absolutely nothing else installed and running the default skin. Decide what kind of pack you want to create, lets say we want to create a kids pack... Add all the kid related addons you want and make sure you also have the relevant repository installed too. In the unlikely event you\'ve found an addon that doesn\'t belong in a repository that\'s fine the system will create a full backup of that addon too (just means it won\'t auto update with future updates to the addon).'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Create the backup[/B][CR]Using this addon create your backup, currently only addon packs are supported but soon more packs will be added. When you create the keyword you\'ll be asked for a location to store the zip file that will be created and a name, this can be anywhwere you like and can be called whatever you want - you do not need to add the zip extension, that will automatically be added for you so in our example here we would call it "kids".'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Upload the zips[/B][CR]Upload the two zip file to a server that Kodi can access, it has to be a direct link and not somewhere that asks for captcha - archive.org and copy.com are two good examples. Do not use Dropbox unless you have a paid account, they have a fair useage policy and the chances are you\'ll find within 24 hours your download has been blocked and nobody can download it.[CR][CR][COLOR=lime]Top Tip: [/COLOR]The vast majority of problems occur when the wrong download URL has been entered in the online form, a good download URL normally ends in "=1" or "zip=true". Please double check when you copy the URL into a web browser it immediately starts downloading without the need to press any other button.'
 '[CR][CR][COLOR=dodgerblue][B]Step 4:[/COLOR] Create the keyword[/B][CR]Copy the download URL to your clipboard and then go to www.urlshortbot.com. In here you need to enter the URL in the "Long URL" field and then in the "Custom Keyword" field you need to enter "noobs" (without the quotation marks) followed by your keyword. We recommend always using a random test keyword for testing because once you have a keyword you can\'t change it, also when uploading make sure it\'s a link you can edit and still keep the same URL - that way it\'s easy to keep up to date and you can still use the same keyword. In our example of kids we would set the custom keyword as "noobskids". The noobs bit is ignored and is only for helping the addon know what to look for, the user would just type in "kids" for the kids pack to be installed.' )
 if 99 - 99: oO0OooOoO - iIii1I11I1II1
 if 24 - 24: o0Oo - i1IIi - O0 % Iiii1i1 - iIii1I11I1II1 . o00O0OoO
def II1iii1iII ( ) :
 OOooO0OO0 ( 'Adding Third Party Wizards' , '[COLOR=gold]ONE WIZARD TO RULE THEM ALL![/COLOR][CR]Did you know the vast majority of wizards out there (every single one we\'ve tested) has just been a copy/paste of very old code created by the team here? We\'ve noticed a lot of the users installing builds via these third party wizards have run into many different problems so we thought we\'d take it upon ourselves to help out...'
 '[CR][CR][CR][COLOR=gold]WHAT BENEFITS DOES THIS HAVE?[/COLOR][CR]We\'ve added extra code that checks for common errors, unfortunately there are some people out there using inferior programs to create their backups and that is causing problems in their wizards. If such a problem exists when trying to use another wizard you can try adding the details to this addon and it automatically fixes any corrupt files it finds. Of course there are other benefits... installing code from an unknown source can give the author access to your system so make sure you always trust the author(s). Why take the risk of installing wizards created by anonymous usernames on social media sites when you can install from a trusted source like noobsandnerds and you\'ll also be safe in the knowledge that any new updates and improvements will be made here first - we do not copy/paste code, we are actively creating new exciting solutions!'
 '[CR][CR][CR][COLOR=gold]ADDING 3RD PARTY WIZARDS TO THIS ADDON[/COLOR][CR][CR][COLOR=dodgerblue][B]Step 1:[/COLOR] Enabling 3rd Party Wizards[/B][CR]In the addon settings under the Community Builds section you have the option to enable third party community builds, if you click on this you will be able to enter details of up to 5 different wizards.'
 '[CR][CR][COLOR=dodgerblue][B]Step 2:[/COLOR] Enter the URL[/B][CR]As virtually all wizards use exactly the same structure all you need to do is find out what URL they are looking up in the code, you can open the default.py file of the wizard in a text editor and search for "http" and you will more than likely find the URL straight away. Try entering it in a web address, it should show the details for all the builds in that wizard in a text based page. If the page is blank don\'t worry it may just be locked from web browsers and can only be opened in Kodi, try it out and see if it works.'
 '[CR][CR][COLOR=dodgerblue][B]Step 3:[/COLOR] Enter the name[/B][CR]Give the wizard a name, now when you go into the Community Builds section you\'ll have the official noobsandnerds builds as an option and also any new ones you\'ve added.' )
 if 7 - 7: i11111IIIII * i1IIi . iI1IiiIIIiIi % o0oOo0 * O00OOOoOoo0O . iIii1I11I1II1
 if 77 - 77: iIii1I11I1II1 + oO0OooOoO % iI1IiiIIIiIi . II11iIiIIIiI + OoooooooOO
def OO000oOO0o00 ( url = 'http://www.iplocation.net/' , inc = 1 ) :
 I11iIiII = re . compile ( "<td width='80'>(.+?)</td><td>(.+?)</td><td>(.+?)</td><td>.+?</td><td>(.+?)</td>" ) . findall ( ooOooo000oOO . http_GET ( url ) . content )
 for i1iI1iI1i1iI1I1II , iiI11II , Oo0OOooO00OO , Ii1i1 in I11iIiII :
  if inc < 2 : OOooO0OOoo = xbmcgui . Dialog ( ) ; OOooO0OOoo . ok ( 'Check My IP' , "[B][COLOR gold]Your IP Address is: [/COLOR][/B] %s" % i1iI1iI1i1iI1I1II , '[B][COLOR gold]Your IP is based in: [/COLOR][/B] %s' % Oo0OOooO00OO , '[B][COLOR gold]Your Service Provider is:[/COLOR][/B] %s' % Ii1i1 )
  inc = inc + 1
  if 6 - 6: iIii1I11I1II1 * oO0OooOoO
  if 38 - 38: o0Oo
def iiiii1i1 ( url ) :
 if not os . path . exists ( O00O0oOO00O00 ) :
  os . makedirs ( O00O0oOO00O00 )
  if 87 - 87: i11111IIIII - O0 + o0Oo / OoooooooOO * i1Iii1i1I / i1IIi
 II11II1i = ''
 o0OOoOo0oo = 'Enter Keyword'
 o0o0OOooo0Oo = iIiII1 ( o0OOoOo0oo )
 II11II1i = url + o0o0OOooo0Oo
 oOOOOOoOOoo0 = os . path . join ( O00O0oOO00O00 , o0o0OOooo0Oo + '.zip' )
 if 9 - 9: OoooO0Oo0O0 - i11111IIIII
 if o0o0OOooo0Oo != '' :
  o0o0OoOo00oOoo0oO = OOooO0OOoo . yesno ( 'Backup existing setup' , 'Installing certain keywords can result in some existing settings or add-ons to be replaced. Would you like to create a backup before proceeding?' )
  if 35 - 35: Iiii1i1 - i1IIi / i11111IIIII
  if o0o0OoOo00oOoo0oO == 1 :
   iI1IiiiiI ( )
   if 12 - 12: i11iIiiIii . o00O0OoO * iiIi1i11 % i1IIi . o0oOo0
  try :
   if o0oO0 == 'true' :
    print "### Attempting download " + II11II1i + " to " + oOOOOOoOOoo0
   iIii1 . create ( "Web Installer" , "Downloading " , '' , 'Please Wait' )
   downloader . download ( II11II1i , oOOOOOoOOoo0 )
   print "### Keyword " + o0o0OOooo0Oo + " Successfully downloaded"
   iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
   if 58 - 58: i1Iii1i1I % iIii1I11I1II1 . iIii1I11I1II1 / o00O0OoO
   if zipfile . is_zipfile ( oOOOOOoOOoo0 ) :
    if 79 - 79: ii1ii11IIIiiI / iiIi1i11 - i1IIi + i1IIi - i11111IIIII + i11111IIIII
    try :
     extract . all ( oOOOOOoOOoo0 , oOOoO0 , iIii1 )
     xbmc . executebuiltin ( 'UpdateLocalAddons' )
     xbmc . executebuiltin ( 'UpdateAddonRepos' )
     OOooO0OOoo . ok ( "[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]" , "" , "Content now installed" , "" )
     iIii1 . close ( )
     if 67 - 67: ii1ii11IIIiiI * ii1ii11IIIiiI / OoooooooOO
    except :
     OOooO0OOoo . ok ( "Error with zip" , 'There was an error trying to install this file. It may possibly be corrupt, either try again or contact the author of this keyword.' )
     print "### Unable to install keyword (passed zip check): " + o0o0OOooo0Oo
   else :
    OOooO0OOoo . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
    if 79 - 79: oOO00Oo % iIii1I11I1II1 / oO0OooOoO / iI1IiiIIIiIi / iI1IiiIIIiIi + O0
  except :
   OOooO0OOoo . ok ( "Keyword Error" , 'The keyword you typed could not be installed. Please check the spelling and if you continue to receive this message it probably means that keyword is no longer available.' )
   print "### Unable to install keyword (unknown error, most likely a typo in keyword entry): " + o0o0OOooo0Oo
   if 46 - 46: i1IIi / i11111IIIII
 if os . path . exists ( oOOOOOoOOoo0 ) :
  os . remove ( oOOOOOoOOoo0 )
  if 84 - 84: O00OOOoOoo0O / iIii1I11I1II1 + III1IiiI % o0oOo0 + III1IiiI - iIii1I11I1II1
  if 27 - 27: O0 / oOO00Oo * o0Oo
def Oo0iII ( ) :
 if 41 - 41: o0oOo0
 if not os . path . exists ( OOoOO0oo0ooO ) :
  os . makedirs ( OOoOO0oo0ooO )
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 ii11I1 = float ( oO000o [ : 4 ] )
 if xbmc . getCondVisibility ( 'system.platform.windows' ) :
  if ii11I1 < 14 :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'win_xbmc.bat' ) , 'w+' )
    I1iI1I1 . write ( '@ECHO off\nTASKKILL /im XBMC.exe /f\ntskill XBMC.exe\nXBMC.exe' )
    I1iI1I1 . close ( )
    os . system ( os . path . join ( OOoOO0oo0ooO , 'win_xbmc.bat' ) )
   except :
    print "### Failed to run win_xbmc.bat"
  else :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'win_kodi.bat' ) , 'w+' )
    I1iI1I1 . write ( '@ECHO off\nTASKKILL /im Kodi.exe /f\ntskill Kodi.exe\nKodi.exe' )
    I1iI1I1 . close ( )
    os . system ( os . path . join ( OOoOO0oo0ooO , 'win_kodi.bat' ) )
   except :
    print "### Failed to run win_kodi.bat"
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  if ii11I1 < 14 :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) , 'w+' )
    I1iI1I1 . write ( 'killall -9 XBMC\nXBMC' )
    I1iI1I1 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod 755 ' + os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'osx_xbmc.sh' ) )
   except :
    print "### Failed to run osx_xbmc.sh"
  else :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) , 'w+' )
    I1iI1I1 . write ( 'killall -9 Kodi\nKodi' )
    I1iI1I1 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod 755 ' + os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'osx_kodi.sh' ) )
   except :
    print "### Failed to run osx_kodi.sh"
    if 11 - 11: i1IIi / Iiii1i1 * OoooO0Oo0O0 * Iiii1i1 * o0oOo0 - i11iIiiIii
 elif xbmc . getCondVisibility ( 'system.platform.android' ) :
  if os . path . exists ( '/data/data/com.rechild.advancedtaskkiller' ) :
   OOooO0OOoo . ok ( 'Attempting to force close' , 'On the following screen please press the big button at the top which says "KILL selected apps". Kodi will restart, please be patient while your system updates the necessary files and your skin will automatically switch once fully updated.' )
   try :
    xbmc . executebuiltin ( 'StartAndroidActivity(com.rechild.advancedtaskkiller)' )
   except :
    print "### Failed to run Advanced Task Killer. Make sure you have it installed, you can download from https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk"
  else :
   OOooO0OOoo . ok ( 'Advanced Task Killer Not Found' , "The Advanced Task Killer app cannot be found on this system. Please make sure you actually installed it after downloading. We can't do everything for you - on Android you do have to physically click on the download to install an app." )
  try :
   os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell kill org.xbmc' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc,kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.kodi());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc.xbmc());' )
  except :
   pass
  try :
   os . system ( 'Process.killProcess(android.os.Process.org.xbmc());' )
  except :
   pass
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  if ii11I1 < 14 :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) , 'w+' )
    I1iI1I1 . write ( 'killall XBMC\nkillall -9 xbmc.bin\nXBMC' )
    I1iI1I1 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod a+x ' + os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'linux_xbmc' ) )
   except :
    print "### Failed to run: linux_xbmc"
  else :
   try :
    I1iI1I1 = open ( os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) , 'w+' )
    I1iI1I1 . write ( 'killall Kodi\nkillall -9 kodi.bin\nkodi' )
    I1iI1I1 . close ( )
   except :
    pass
   try :
    os . system ( 'chmod a+x ' + os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) )
   except :
    pass
   try :
    os . system ( os . path . join ( OOoOO0oo0ooO , 'linux_kodi' ) )
   except :
    print "### Failed to run: linux_kodi"
 else :
  try :
   os . system ( 'killall AppleTV' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop kodi' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop xbmc' )
  except :
   pass
   if 96 - 96: OoooO0Oo0O0 % OoooO0Oo0O0
   if 1 - 1: o0Oo . iI1IiiIIIiIi
def II11IIII1 ( ) :
 xbmc . executebuiltin ( 'ReplaceWindow(settings)' )
 if 33 - 33: iI1IiiIIIiIi + O00OOOoOoo0O - OoooO0Oo0O0 + iIii1I11I1II1 % i1IIi * i11111IIIII
 if 21 - 21: O0 * o0oOo0 % ii1ii11IIIiiI
def iI1IiiiiI ( ) :
 oOiI111I1III ( )
 if 14 - 14: O0 / Iiii1i1 / o0oOo0 + i11111IIIII - i11111IIIII
 IiI1 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , '' ) )
 iiIiII = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup.zip' ) )
 IIiiiI1iI = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' , 'my_full_backup_GUI_Settings.zip' ) )
 if 10 - 10: O0 - OoooO0Oo0O0 / Iiii1i1 % O00OOOoOoo0O / OoooooooOO / iI1IiiIIIiIi
 if not os . path . exists ( IiI1 ) :
  os . makedirs ( IiI1 )
  if 73 - 73: o0oOo0 + i11111IIIII % oOO00Oo . OoooO0Oo0O0 / iiIi1i11 . Iiii1i1
 o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
 if 76 - 76: o00O0OoO . OoooO0Oo0O0 * OoooooooOO % i1Iii1i1I
 if ( not o0OoOoooo0 ) :
  return False , 0
  if 24 - 24: OoooooooOO
 o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
 ooO0 = xbmc . translatePath ( os . path . join ( IiI1 , o0OOoOo0oo + '.zip' ) )
 o0Iiii = [ o0OO00 ]
 I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
 o0OO0OOO0O = "Creating full backup of existing build"
 iii = "Creating Community Build"
 Iii1I = "Archiving..."
 oOoOOOOoOO0o = ""
 iiI1i1I1II = "Please Wait"
 if 83 - 83: O0 / ii1ii11IIIiiI
 OooOOOO0O0 ( oOOoO0 , iiIiII , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
 OOooO0OOoo . ok ( 'Full Backup Complete' , 'You can locate your backup at:[COLOR=dodgerblue]' , iiIiII + '[/COLOR]' )
 if 62 - 62: o00O0OoO
 if 73 - 73: iI1IiiIIIiIi % ii1ii11IIIiiI * iiIi1i11
def oooo0O ( ) :
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 ii11I1 = float ( oO000o [ : 4 ] )
 if 9 - 9: O0
 if ii11I1 < 14 :
  ii111I1I1I = os . path . join ( O0Oo000ooO00 , 'xbmc.log' )
  OOooO0OO0 ( 'XBMC Log' , ii111I1I1I )
  if 34 - 34: OoooO0Oo0O0 % i1IIi - ii1ii11IIIiiI
 else :
  ii111I1I1I = os . path . join ( O0Oo000ooO00 , 'kodi.log' )
  OOooO0OO0 ( 'Kodi Log' , ii111I1I1I )
  if 18 - 18: o0Oo + Iiii1i1 - i1Iii1i1I % oO0OooOoO / O00OOOoOoo0O % O0
  if 59 - 59: O0 . oOO00Oo % OoooO0Oo0O0 * III1IiiI + o00O0OoO
def o00o ( ) :
 OOooO0OOoo . ok ( "Restore local guisettings fix" , "You should [COLOR=lime]ONLY[/COLOR] use this option if the guisettings fix is failing to download via the addon. Installing via this method means you do not receive notifications of updates" )
 IiIiIiiI ( )
 if 83 - 83: O00OOOoOoo0O
 if 84 - 84: iI1IiiIIIiIi
def oOOoO00OoooOo0 ( mode ) :
 if not mode . endswith ( "premium" ) and not mode . endswith ( "public" ) and not mode . endswith ( "private" ) :
  o0OoOoooo0 = OooO0O0Ooo ( heading = "Search for content" )
  if 4 - 4: i1Iii1i1I % OoooO0Oo0O0
  if ( not o0OoOoooo0 ) :
   return False , 0
   if 9 - 9: O0 * iI1IiiIIIiIi
  o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
  if 54 - 54: o00O0OoO % o00O0OoO - o0oOo0
  if mode == 'tutorials' :
   Oo00o0OOo0OO ( 'name=' + o0OOoOo0oo )
   if 32 - 32: oOO00Oo % oO0OooOoO / oOO00Oo . iiIi1i11 . oOO00Oo
  if mode == 'hardware' :
   o0OoOo0o0OOoO0 ( 'name=' + o0OOoOo0oo )
   if 29 - 29: OoooooooOO % oO0OooOoO % i11iIiiIii - II11iIiIIIiI
  if mode == 'news' :
   i11ii ( 'name=' + o0OOoOo0oo )
   if 5 - 5: OoooO0Oo0O0 . oO0OooOoO . i1IIi
 if mode . endswith ( "premium" ) or mode . endswith ( "public" ) or mode . endswith ( "private" ) :
  oO00oOOoooO ( 'folder' , 'Search By Name' , mode + '&name=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Uploader' , mode + '&author=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Audio Addons Installed' , mode + '&audio=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Picture Addons Installed' , mode + '&pics=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Program Addons Installed' , mode + '&progs=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Video Addons Installed' , mode + '&vids=' , 'search_builds' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , 'Search By Skins Installed' , mode + '&skins=' , 'search_builds' , '' , '' , '' , '' )
  if 35 - 35: oOO00Oo + ii1ii11IIIiiI - OoooO0Oo0O0
  if 24 - 24: oO0OooOoO
def iI11Ii1Ii ( ) :
 oO00oOOoooO ( '' , 'Install a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , 'http://urlshortbot.com/noobs' , 'keywords' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Create a [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword' , 'create_pack' , 'create_keyword' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Installing a keyword' , '' , 'instructions_3' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][INSTRUCTIONS][/COLOR] Creating a keyword' , '' , 'instructions_4' , '' , '' , '' , '' )
 if 21 - 21: OoooO0Oo0O0 * iI1IiiIIIiIi - i11iIiiIii
 if 63 - 63: Iiii1i1 * O0 / i11iIiiIii / iIii1I11I1II1
def IIII1i1I ( url ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/LatestNews/LatestNews.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 iIiII = re . compile ( 'author="(.+?)"' ) . findall ( OoOO0o )
 O0OoooIiiI11Iii = re . compile ( 'date="(.+?)"' ) . findall ( OoOO0o )
 IiIi1I1 = re . compile ( 'content="(.+?)###END###"' ) . findall ( OoOO0o )
 if 42 - 42: o00O0OoO + i1IIi - iI1IiiIIIiIi / i11111IIIII . i1Iii1i1I
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 O0oIi1iIiIi1I11 = iIiII [ 0 ] if ( len ( iIiII ) > 0 ) else ''
 iIiIi1i1Iiii = O0OoooIiiI11Iii [ 0 ] if ( len ( O0OoooIiiI11Iii ) > 0 ) else ''
 o0oO0OoO0 = IiIi1I1 [ 0 ] if ( len ( IiIi1I1 ) > 0 ) else ''
 II111i = o00OoOO0O0 ( o0oO0OoO0 )
 O0oii111 = str ( '[COLOR=orange]Source: [/COLOR]' + O0oIi1iIiIi1I11 + '     [COLOR=orange]Date: [/COLOR]' + iIiIi1i1Iiii + '[CR][CR][COLOR=lime]Details: [/COLOR][CR]' + II111i )
 if 41 - 41: o0Oo % iiIi1i11
 OOooO0OO0 ( i1iIIIi1i , O0oii111 )
 if 30 - 30: i11iIiiIii * II11iIiIIIiI . oO0OooOoO + OoooO0Oo0O0 / oOO00Oo % Iiii1i1
 if 78 - 78: OoooO0Oo0O0 + OoooooooOO - o0Oo * O00OOOoOoo0O * i1Iii1i1I
def I1I1i1 ( url ) :
 if I1ii11iIi11i == 'true' :
  oO00oOOoooO ( '' , '[COLOR=orange]Latest ' + I1IiiI + ' news[/COLOR]' , I1IiiI , 'notify_msg' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'news' , 'manual_search' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime][All News][/COLOR] From all sites' , str ( url ) + '' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Official Kodi.tv News' , str ( url ) + '&author=Official%20Kodi' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'OpenELEC News' , str ( url ) + '&author=OpenELEC' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Raspbmc News' , str ( url ) + '&author=Raspbmc' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] News' , str ( url ) + '&author=noobsandnerds' , 'grab_news' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'XBMC4Xbox News' , str ( url ) + '&author=XBMC4Xbox' , 'grab_news' , '' , '' , '' , '' )
 if 36 - 36: o0Oo / II11iIiIIIiI % iIii1I11I1II1 / O0 . OoooO0Oo0O0
 if 53 - 53: oOO00Oo % OoooooooOO - III1IiiI - i1IIi / ii1ii11IIIiiI
def i1111II1iIII ( title , message , times , icon ) :
 icon = oOOoo0Oo + icon
 xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," + times + "," + icon + ")" )
 if 41 - 41: i11111IIIII * OoooooooOO . o0oOo0 % i11iIiiIii
def IiI ( url ) :
 o00o00 = xbmc . translatePath ( os . path . join ( iiI1IiI , o0OO00 , 'notification.txt' ) )
 if 93 - 93: O00OOOoOoo0O + o00O0OoO
 if not os . path . exists ( o00o00 ) :
  IiI1i111IiIiIi1 = open ( o00o00 , mode = 'w' )
  IiI1i111IiIiIi1 . write ( '20150101000000' )
  IiI1i111IiIiIi1 . close ( )
  if 27 - 27: iIii1I11I1II1 * o00O0OoO
 iiI1iiiii = open ( o00o00 , 'r' ) . read ( )
 if 53 - 53: oOO00Oo / II11iIiIIIiI / i1Iii1i1I + iI1IiiIIIiIi - ii1ii11IIIiiI
 I1II1I11I1I = 'http://noobsandnerds.com/TI/Community_Builds/notify?reseller=%s' % ( I1IiiI )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 IIIiIIIi111iI = re . compile ( 'notify="(.+?)"' ) . findall ( OoOO0o )
 O0OoooIiiI11Iii = re . compile ( 'date="(.+?)"' ) . findall ( OoOO0o )
 II1IIII1i1i = IIIiIIIi111iI [ 0 ] if ( len ( IIIiIIIi111iI ) > 0 ) else 'No news items available'
 IiIiI1i1ii = O0OoooIiiI11Iii [ 0 ] if ( len ( O0OoooIiiI11Iii ) > 0 ) else ''
 iiii1I1IiI = IiIiI1i1ii . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
 if 49 - 49: OoooO0Oo0O0 + III1IiiI * i1Iii1i1I * o0oOo0 / o0Oo . OoooO0Oo0O0
 if int ( iiI1iiiii ) < int ( iiii1I1IiI ) :
  IiI1i111IiIiIi1 = open ( o00o00 , mode = 'w' )
  IiI1i111IiIiIi1 . write ( iiii1I1IiI )
  IiI1i111IiIiIi1 . close ( )
  OOooO0OOoo . ok ( 'Latest ' + I1IiiI + ' News' , II1IIII1i1i )
  if 80 - 80: o0Oo % i11111IIIII / o00O0OoO * ii1ii11IIIiiI - III1IiiI / III1IiiI
 else :
  OOooO0OOoo . ok ( 'Latest ' + I1IiiI + ' News' , II1IIII1i1i )
  if 13 - 13: II11iIiIIIiI
  if 70 - 70: i1Iii1i1I
def OooO00Oo ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(filemanager,return)' )
 return
 if 81 - 81: OoooO0Oo0O0 - ii1ii11IIIiiI * III1IiiI
 if 81 - 81: i1Iii1i1I - iI1IiiIIIiIi - iiIi1i11 % i11111IIIII % oOO00Oo . iIii1I11I1II1
def OOoOo00O0 ( ) :
 xbmc . executebuiltin ( 'ActivateWindow(systeminfo)' )
 if 86 - 86: iIii1I11I1II1 * i1Iii1i1I * iI1IiiIIIiIi / ii1ii11IIIiiI % o0oOo0 - O0
 if 63 - 63: OoooO0Oo0O0
def i1II1 ( url , t ) :
 II1IiiI = urllib2 . Request ( url )
 II1IiiI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 10.0; WOW64; Windows NT 5.1; en-GB; rv:1.9.0.3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 Gecko/2008092417 Firefox/3.0.3' )
 if 100 - 100: o0Oo - iiIi1i11
 OOOOo0ooOOO0 = urllib2 . urlopen ( II1IiiI , timeout = t )
 OoOO0o = OOOOo0ooOOO0 . read ( )
 OOOOo0ooOOO0 . close ( )
 return OoOO0o . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
 if 91 - 91: i11iIiiIii + iI1IiiIIIiIi % iI1IiiIIIiIi + oOO00Oo
 if 15 - 15: OoooO0Oo0O0 . o0Oo - Iiii1i1 - i1IIi
def O00 ( ) :
 import tarfile
 if 77 - 77: o0Oo / iIii1I11I1II1 * iI1IiiIIIiIi * iIii1I11I1II1 + OoooO0Oo0O0
 if not os . path . exists ( oO0 ) :
  os . makedirs ( oO0 )
  if 78 - 78: i11111IIIII / i1Iii1i1I * iI1IiiIIIiIi . iiIi1i11 . III1IiiI - Iiii1i1
 iIii1 . create ( "Creating Backup" , "Adding files... " , '' , 'Please Wait' )
 I1IiI11IiIiIi = tarfile . open ( os . path . join ( oO0 , ooOoOO ( ) + '.tar' ) , 'w' )
 if 42 - 42: o00O0OoO
 for iIi1I in III1iII1I1ii :
  iIii1 . update ( 0 , "Backing Up" , '[COLOR blue]%s[/COLOR]' % iIi1I , 'Please Wait' )
  I1IiI11IiIiIi . add ( iIi1I )
  if 14 - 14: iiIi1i11 * o0Oo - OoooO0Oo0O0
 I1IiI11IiIiIi . close ( )
 iIii1 . close ( )
 if 10 - 10: i1Iii1i1I % Iiii1i1 * OoooO0Oo0O0 * O0 * i11iIiiIii % Iiii1i1
 if 68 - 68: OoooooooOO * O00OOOoOoo0O
def I1IiiiIiI ( ) :
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 ii11I1 = float ( oO000o [ : 4 ] )
 if ii11I1 < 14 :
  o0Ooo0O0 = os . path . join ( O0Oo000ooO00 , 'xbmc.log' )
 else :
  o0Ooo0O0 = os . path . join ( O0Oo000ooO00 , 'kodi.log' )
  if 9 - 9: Iiii1i1
 try :
  IiI1i111IiIiIi1 = open ( o0Ooo0O0 , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
 except :
  try :
   IiI1i111IiIiIi1 = open ( os . path . join ( oOOoO0 , 'temp' , 'kodi.log' ) , mode = 'r' )
   o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
   IiI1i111IiIiIi1 . close ( )
  except :
   try :
    IiI1i111IiIiIi1 = open ( os . path . join ( oOOoO0 , 'temp' , 'xbmc.log' ) , mode = 'r' )
    o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
    IiI1i111IiIiIi1 . close ( )
   except :
    pass
    if 36 - 36: Iiii1i1 / O00OOOoOoo0O + O00OOOoOoo0O * o0oOo0 / iiIi1i11 * O0
 if 'OpenELEC' in o0oO0OoO0 :
  return True
  if 17 - 17: ii1ii11IIIiiI / o0oOo0 % o0Oo
  if 47 - 47: II11iIiIIIiI * ii1ii11IIIiiI / oOO00Oo * o0Oo
def OOo0iIiiI11II11 ( ) :
 xbmc . executebuiltin ( 'RunAddon(service.openelec.settings)' )
 if 75 - 75: Iiii1i1 - i1Iii1i1I . III1IiiI
 if 88 - 88: i1Iii1i1I - OoooooooOO . o0oOo0 - oOO00Oo / O00OOOoOoo0O % o00O0OoO
def o00O00o ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Install:[/COLOR]  Installation tutorials (e.g. flashing a new OS)' , str ( url ) + '&thirdparty=InstallTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Add-on Tools:[/COLOR]  Add-on maintenance and coding tutorials' , str ( url ) + '&thirdparty=AddonTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Audio Tools:[/COLOR]  Audio related tutorials' , str ( url ) + '&thirdparty=AudioTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Gaming Tools:[/COLOR]  Integrate a gaming section into your setup' , str ( url ) + '&thirdparty=GamingTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Image Tools:[/COLOR]  Tutorials to assist with your pictures/photos' , str ( url ) + '&thirdparty=ImageTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Library Tools:[/COLOR]  Music and Video Library Tutorials' , str ( url ) + '&thirdparty=LibraryTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Skinning Tools:[/COLOR]  All your skinning advice' , str ( url ) + '&thirdparty=SkinningTools' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Video Tools:[/COLOR]  All video related tools' , str ( url ) + '&thirdparty=VideoTools' , 'grab_tutorials' , '' , '' , '' , '' )
 if 69 - 69: i1IIi . iI1IiiIIIiIi
 if 96 - 96: iI1IiiIIIiIi
def II111 ( xmlfile ) :
 if 59 - 59: iiIi1i11 + O00OOOoOoo0O * ii1ii11IIIiiI % i1IIi * ii1ii11IIIiiI
 if 'http' in xmlfile :
  oOoOo0oOoo0 = 'none'
  OOOOooO0oOoO = xmlfile [ - 10 : ]
  OOOOooO0oOoO = OOOOooO0oOoO [ : - 4 ]
  IIoOoOoo0 = os . path . join ( iiI1IiI , o0OO00 , 'latest' )
  if 4 - 4: III1IiiI . o00O0OoO
  if os . path . exists ( IIoOoOoo0 ) :
   ooo0o0OOo0O = open ( IIoOoOoo0 , mode = 'r' )
   oOoOo0oOoo0 = ooo0o0OOo0O . read ( )
   ooo0o0OOo0O . close ( )
   if 67 - 67: OoooO0Oo0O0 * oOO00Oo % iIii1I11I1II1 / i11111IIIII
  if oOoOo0oOoo0 == OOOOooO0oOoO :
   OOOOooO0oOoO = oOoOo0oOoo0
   if 34 - 34: III1IiiI - oO0OooOoO - oOO00Oo + i1Iii1i1I + Iiii1i1
  else :
   iIii1 . create ( 'Grabbing Latest Updates' , '' , '' , '' )
   downloader . download ( xmlfile , os . path . join ( OO0o , o0OO00 , 'resources' , 'skins' , 'DefaultSkin' , 'media' , 'latest.jpg' ) )
   I1iI1I1 = open ( IIoOoOoo0 , mode = 'w+' )
   I1iI1I1 . write ( OOOOooO0oOoO )
   I1iI1I1 . close ( )
  xmlfile = 'latest.xml'
 oo0OOoOO = O0ooO0Oo00o ( xmlfile , i1IiI1I11 . getAddonInfo ( 'path' ) , 'DefaultSkin' , close_time = 34 )
 oo0OOoOO . doModal ( )
 del oo0OOoOO
 if 28 - 28: O0 * o0oOo0 - oOO00Oo + iIii1I11I1II1 + III1IiiI
 if 92 - 92: OoooooooOO % o0Oo * O00OOOoOoo0O - o00O0OoO
def ooO000O ( recursive_location , remote_path ) :
 if not os . path . exists ( recursive_location ) :
  os . makedirs ( recursive_location )
  if 80 - 80: i11iIiiIii % iiIi1i11 - II11iIiIIIiI % iiIi1i11
 OoOO0o = i1II1 ( remote_path , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 I11iIiII = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( OoOO0o )
 if 89 - 89: iI1IiiIIIiIi * o00O0OoO + O00OOOoOoo0O / i11iIiiIii
 for iiiI1ii11 in I11iIiII :
  ii1i = xbmc . translatePath ( os . path . join ( recursive_location , iiiI1ii11 ) )
  if 68 - 68: OoooooooOO * o00O0OoO
  if '/' not in iiiI1ii11 :
   if 86 - 86: oOO00Oo / O00OOOoOoo0O
   try :
    iIii1 . update ( 0 , "Downloading [COLOR=yellow]" + iiiI1ii11 + '[/COLOR]' , '' , 'Please wait...' )
    downloader . download ( remote_path + iiiI1ii11 , ii1i , iIii1 )
    if 40 - 40: i1Iii1i1I
   except :
    print "failed to install" + iiiI1ii11
    if 62 - 62: o0oOo0 / iiIi1i11
  if '/' in iiiI1ii11 and '..' not in iiiI1ii11 and 'http' not in iiiI1ii11 :
   O0o0O0OoOo0 = remote_path + iiiI1ii11
   ooO000O ( ii1i , O0o0O0OoOo0 )
   if 92 - 92: o00O0OoO % Iiii1i1
  else :
   pass
   if 18 - 18: o0oOo0 + Iiii1i1 / iiIi1i11 / III1IiiI + iIii1I11I1II1 % i11111IIIII
   if 94 - 94: o00O0OoO
def iI11IiiI1 ( ) :
 OOooO0OOoo . ok ( "Register to unlock features" , "To get the most out of this addon please register at the [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] forum for free." , 'www.noobsandnerds.com' )
 if 83 - 83: III1IiiI / iIii1I11I1II1
 if 68 - 68: Iiii1i1 - O00OOOoOoo0O . i11iIiiIii + oOO00Oo
def Oo0oo ( ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Delete Addon_Data Folder?' , 'This will free up space by deleting your addon_data folder. This contains all addon related settings including username and password info.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 33 - 33: o0Oo / o00O0OoO . II11iIiIIIiI
 if oo0O0oo == 1 :
  Oo0O0OooOooo0 ( )
  OOooO0OOoo . ok ( "Addon_Data Removed" , '' , 'Your addon_data folder has now been removed.' , '' )
  if 89 - 89: i1Iii1i1I + i1IIi - i11111IIIII + o0oOo0 . oO0OooOoO
def ooO00O00oOO ( url ) :
 Oo00oOOO0 = str ( url ) . replace ( OO0o , iiI1IiI )
 if 13 - 13: O0 + iIii1I11I1II1 % oO0OooOoO + iIii1I11I1II1
 if OOooO0OOoo . yesno ( "Remove" , '' , "Do you want to Remove" ) :
  if 85 - 85: o0Oo * iIii1I11I1II1 . i1Iii1i1I / i1Iii1i1I
  for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( url ) :
   if 43 - 43: o0Oo
   for iiI1iii in I1iiIi111I :
    os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
    if 78 - 78: ii1ii11IIIiiI % oO0OooOoO + O00OOOoOoo0O / o0Oo
   for I1III111i in OoOOOO :
    shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
  os . rmdir ( url )
  if 34 - 34: oOO00Oo % OoooO0Oo0O0 + iI1IiiIIIiIi * o00O0OoO / III1IiiI
  try :
   if 18 - 18: o0oOo0
   for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Oo00oOOO0 ) :
    if 92 - 92: ii1ii11IIIiiI % iIii1I11I1II1 / i11111IIIII * i1Iii1i1I . i1IIi + III1IiiI
    for iiI1iii in I1iiIi111I :
     os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
     if 24 - 24: i11111IIIII . i1Iii1i1I * i11111IIIII % i11iIiiIii . i11iIiiIii + i1IIi
    for I1III111i in OoOOOO :
     shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
     if 64 - 64: iIii1I11I1II1 / i11111IIIII / II11iIiIIIiI - OoooO0Oo0O0
   os . rmdir ( Oo00oOOO0 )
   if 100 - 100: i11111IIIII + i1IIi * ii1ii11IIIiiI
  except :
   pass
   if 64 - 64: III1IiiI * i11iIiiIii . II11iIiIIIiI
  OOo0OO00 = os . path . join ( O0OoO000O0OO , 'Database' , 'Addons16.db' )
  if 20 - 20: i1IIi
  try :
   os . remove ( OOo0OO00 )
   if 15 - 15: o0Oo . II11iIiIIIiI . O0 . oO0OooOoO / o00O0OoO . O00OOOoOoo0O
  except :
   pass
   if 3 - 3: O00OOOoOoo0O
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  o00Oo0O ( )
  OOooO0OOoo . ok ( 'Add-on removed' , 'You may have to restart Kodi to repopulate' , 'your add-on database. Until you restart you\'ll' , 'find your add-on is still showing even though it\'s deleted' )
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 63 - 63: i11111IIIII + o0Oo * III1IiiI
  if 52 - 52: O00OOOoOoo0O % OoooO0Oo0O0 * II11iIiIIIiI % OoooooooOO - ii1ii11IIIiiI
def i1I1I111iiII ( ) :
 oOiI111I1III ( )
 O000OOOoOooO = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to DELETE' , 'files' , '.zip' , False , False , OOO00 )
 if 71 - 71: i11111IIIII - i1IIi
 if O000OOOoOooO != OOO00 :
  oOO00o0 = ntpath . basename ( O000OOOoOooO )
  oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Delete Backup File' , 'This will completely remove ' + oOO00o0 , 'Are you sure you want to delete?' , '' , nolabel = 'No, Cancel' , yeslabel = 'Yes, Delete' )
  if 29 - 29: oO0OooOoO - i1Iii1i1I / III1IiiI % OoooooooOO % i1Iii1i1I + i11111IIIII
  if oo0O0oo == 1 :
   os . remove ( O000OOOoOooO )
   if 44 - 44: O0 / O0
   if 25 - 25: oOO00Oo + iIii1I11I1II1 + i11111IIIII + OoooO0Oo0O0 / Iiii1i1 - i1IIi
def Ii1I11Ii1iI ( ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Remove All Crash Logs?' , 'There is absolutely no harm in doing this, these are log files generated when Kodi crashes and are only used for debugging purposes.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 61 - 61: oOO00Oo * OoooO0Oo0O0 - i1IIi + o00O0OoO % oOO00Oo + OoooooooOO
 if oo0O0oo == 1 :
  O0OoOo ( )
  OOooO0OOoo . ok ( "Crash Logs Removed" , '' , 'Your crash log files have now been removed.' , '' )
  if 64 - 64: i1Iii1i1I . o0oOo0 % iI1IiiIIIiIi
  if 21 - 21: Iiii1i1 / III1IiiI
def o00Oo0O ( ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Delete Packages Folder' , 'Do you want to clean the packages folder? This will free up space by deleting the old zip install files of your addons. Keeping these files can also sometimes cause problems when reinstalling addons' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 82 - 82: iIii1I11I1II1 - i1Iii1i1I . i1IIi . i11111IIIII % i11iIiiIii * iIii1I11I1II1
 if oo0O0oo == 1 :
  oo0O ( )
  OOooO0OOoo . ok ( "Packages Removed" , '' , 'Your zip install files have now been removed.' , '' )
  if 58 - 58: OoooO0Oo0O0 % i11iIiiIii + O00OOOoOoo0O / o00O0OoO - OoooooooOO
  if 62 - 62: ii1ii11IIIiiI . O00OOOoOoo0O
def o00oO0O0oo0o ( ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Clear Cached Images?' , 'This will clear your textures13.db file and remove your Thumbnails folder. These will automatically be repopulated after a restart.' , nolabel = 'Cancel' , yeslabel = 'Delete' )
 if 22 - 22: o0oOo0 . i11iIiiIii . OoooooooOO . i1IIi
 if oo0O0oo == 1 :
  IiIIIi ( )
  iII111iiiI11i ( II11iiii1Ii )
  if 12 - 12: O00OOOoOoo0O % iiIi1i11 + III1IiiI . O0 % iIii1I11I1II1
  oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Quit Kodi Now?' , 'Cache has been successfully deleted.' , 'You must now restart Kodi, would you like to quit now?' , '' , nolabel = 'I\'ll restart later' , yeslabel = 'Yes, quit' )
  if 41 - 41: OoooooooOO
  if oo0O0oo == 1 :
   try :
    xbmc . executebuiltin ( "RestartApp" )
    if 13 - 13: o00O0OoO + Iiii1i1 - Iiii1i1 % III1IiiI / o00O0OoO
   except :
    Oo0iII ( )
    if 4 - 4: o0Oo + iiIi1i11 - i11111IIIII + i1Iii1i1I
    if 78 - 78: iI1IiiIIIiIi
def IiIIIi ( ) :
 i11Ii = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  i1iii1I1I = database . connect ( i11Ii )
  Oo0O0o0Oo0Oo = i1iii1I1I . cursor ( )
  Oo0O0o0Oo0Oo . execute ( "DROP TABLE IF EXISTS path" )
  Oo0O0o0Oo0Oo . execute ( "VACUUM" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( "DROP TABLE IF EXISTS sizes" )
  Oo0O0o0Oo0Oo . execute ( "VACUUM" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( "DROP TABLE IF EXISTS texture" )
  Oo0O0o0Oo0Oo . execute ( "VACUUM" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  i1iii1I1I . commit ( )
 except :
  pass
  if 10 - 10: oO0OooOoO . II11iIiIIIiI + II11iIiIIIiI / Iiii1i1 / i11iIiiIii / Iiii1i1
  if 89 - 89: o0oOo0 . ii1ii11IIIiiI * OoooooooOO + O00OOOoOoo0O / O0
def o0O0ooooO0 ( name , url , description ) :
 if 'Backup' in name :
  oOiI111I1III ( )
  i11Ii1iiiI1I = open ( url ) . read ( )
  II1iiI11I = os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] )
  iiI1iii = open ( II1iiI11I , mode = 'w' )
  iiI1iii . write ( i11Ii1iiiI1I )
  iiI1iii . close ( )
  if 43 - 43: O00OOOoOoo0O / iIii1I11I1II1
 else :
  if 'guisettings.xml' in description :
   OO0Oo = open ( os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   ooO00Oo = '<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>' % OOOO0OOoO0O0
   I11iIiII = re . compile ( ooO00Oo ) . findall ( OO0Oo )
   if 3 - 3: OoooO0Oo0O0 % II11iIiIIIiI . O0 % oOO00Oo . oOO00Oo - i1Iii1i1I
   for type , oo0OooOoOo , iIIii1i1iIiI in I11iIiII :
    iIIii1i1iIiI = iIIii1i1iIiI . replace ( '&quot;' , '' ) . replace ( '&amp;' , '&' )
    xbmc . executebuiltin ( "Skin.Set%s(%s,%s)" % ( type . title ( ) , oo0OooOoOo , iIIii1i1iIiI ) )
    if 53 - 53: ii1ii11IIIiiI + i11iIiiIii / iIii1I11I1II1
  else :
   II1iiI11I = os . path . join ( url )
   i11Ii1iiiI1I = open ( os . path . join ( OOO00 , description . split ( 'Your ' ) [ 1 ] ) ) . read ( )
   iiI1iii = open ( II1iiI11I , mode = 'w' )
   iiI1iii . write ( i11Ii1iiiI1I )
   iiI1iii . close ( )
   if 1 - 1: i11111IIIII % i1IIi
 OOooO0OOoo . ok ( "Restore Complete" , "" , 'All Done !' , '' )
 if 41 - 41: ii1ii11IIIiiI * ii1ii11IIIiiI / i1Iii1i1I + OoooO0Oo0O0 . oOO00Oo
 if 84 - 84: i11iIiiIii + ii1ii11IIIiiI * o0Oo + OoooO0Oo0O0 / iI1IiiIIIiIi
def oOoooOOO0 ( name , url , video , description , skins , guisettingslink , artpack ) :
 I1Iiii1i1iI = 1
 O000O = 0
 OOoO00OOo = os . path . join ( oOOoO0 , 'CP_Profiles' )
 iiiiiiii = os . path . join ( OOoO00OOo , 'list.txt' )
 iIiiiII = [ ]
 O000OOOoOooO = description . replace ( ' ' , '_' ) . replace ( "'" , "" ) . replace ( ":" , "-" )
 if 74 - 74: OoooO0Oo0O0 % Iiii1i1 - ii1ii11IIIiiI * o00O0OoO . OoooooooOO * ii1ii11IIIiiI
 if not os . path . exists ( OOoO00OOo ) :
  os . makedirs ( OOoO00OOo )
  if 99 - 99: O00OOOoOoo0O . i1Iii1i1I - OoooooooOO - O0
 ii1Ii1111 = os . path . join ( OOoO00OOo , O000OOOoOooO )
 if not os . path . exists ( ii1Ii1111 ) :
  os . makedirs ( ii1Ii1111 )
 else :
  O000O = OOooO0OOoo . yesno ( 'Profile Already Exists' , 'This build is already installed on your system, would you like to remove the old one and reinstall?' )
  if O000O == 1 :
   try :
    shutil . rmtree ( ii1Ii1111 )
    os . makedirs ( ii1Ii1111 )
   except :
    pass
  else :
   I1Iiii1i1iI = 2
   if 24 - 24: OoooO0Oo0O0 % i11111IIIII - ii1ii11IIIiiI % iIii1I11I1II1 . o0oOo0
 if I1Iiii1i1iI == 1 :
  oOOOOOoOOoo0 = os . path . join ( iiiiiIIii , O000OOOoOooO + '_gui.zip' )
  if o0oO0 == 'true' :
   print "### Download path = " + oOOOOOoOOoo0
   if 97 - 97: III1IiiI - Iiii1i1 * i1Iii1i1I - o0oOo0 * Iiii1i1
  iIii1 . create ( "Community Builds" , "Downloading Skin Tweaks" , '' , 'Please Wait' )
  try :
   downloader . download ( guisettingslink , oOOOOOoOOoo0 )
   if o0oO0 == 'true' :
    print "### successfully downloaded guisettings.xml"
  except :
   OOooO0OOoo . ok ( 'Problem Detected' , 'Sorry there was a problem downloading the guisettings file. Please check your storage location, if you\'re certain that\'s ok please notify the build author on the relevant support thread.' )
   if o0oO0 == 'true' :
    print "### FAILED to download " + guisettingslink
    if 90 - 90: iI1IiiIIIiIi . O00OOOoOoo0O
    if 89 - 89: Iiii1i1 - ii1ii11IIIiiI - oOO00Oo
  if zipfile . is_zipfile ( oOOOOOoOOoo0 ) :
   I1iI1 = str ( os . path . getsize ( oOOOOOoOOoo0 ) )
  else :
   I1iI1 = '0'
   if 44 - 44: OoooooooOO
  iIii1 . create ( "Community Builds" , "Downloading " + description , '' , 'Please Wait' )
  oOOOOOoOOoo0 = os . path . join ( iiiiiIIii , O000OOOoOooO + '.zip' )
  if 82 - 82: O00OOOoOoo0O . O00OOOoOoo0O
  if not os . path . exists ( iiiiiIIii ) :
   os . makedirs ( iiiiiIIii )
   if 10 - 10: II11iIiIIIiI * OoooO0Oo0O0 . III1IiiI . OoooooooOO . iiIi1i11 * OoooO0Oo0O0
   if 80 - 80: Iiii1i1 + o00O0OoO . Iiii1i1 + iiIi1i11
  OoI11II = os . path . join ( II , 'extracted' )
  downloader . download ( url , oOOOOOoOOoo0 , iIii1 )
  iIii1 . create ( "Community Builds" , "Extracting " + description , '' , 'Please Wait' )
  extract . all ( oOOOOOoOOoo0 , OoI11II , iIii1 )
  if os . path . exists ( os . path . join ( OoI11II , 'userdata' , '.cbcfg' ) ) :
   try :
    os . makedirs ( os . path . join ( iiI1IiI , o0OO00 , 'updating' ) )
   except :
    pass
  if o0oO0 == 'true' :
   print "### Downloaded build to: " + oOOOOOoOOoo0
   print "### Extracted build to: " + OoI11II
   if 5 - 5: OoooooooOO - i11111IIIII / OoooO0Oo0O0 % II11iIiIIIiI / Iiii1i1 . OoooO0Oo0O0
  IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
  if 86 - 86: OoooooooOO - i11111IIIII - o00O0OoO * oO0OooOoO
  OO0oOo = re . compile ( 'id="(.+?)"' ) . findall ( o0oO0OoO0 )
  IIiIi1II1IiI = re . compile ( 'name="(.+?)"' ) . findall ( o0oO0OoO0 )
  oo0OoO = re . compile ( 'version="(.+?)"' ) . findall ( o0oO0OoO0 )
  if 61 - 61: oO0OooOoO / i11iIiiIii - O00OOOoOoo0O
  I11iIiiI = OO0oOo [ 0 ] if ( len ( OO0oOo ) > 0 ) else ''
  OO000oo0o = IIiIi1II1IiI [ 0 ] if ( len ( IIiIi1II1IiI ) > 0 ) else ''
  ooO0o0oo = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
  if 32 - 32: i11iIiiIii
  print "### Build name details to store in ti_id: " + OO000oo0o
  if 57 - 57: iIii1I11I1II1
  o0OOoOO0oOO = os . path . join ( OoI11II , 'userdata' , 'addon_data' , 'ti_id' )
  OooO00OOOOoo = os . path . join ( o0OOoOO0oOO , 'id.xml' )
  if not os . path . exists ( o0OOoOO0oOO ) :
   os . makedirs ( o0OOoOO0oOO )
   if 22 - 22: iI1IiiIIIiIi - II11iIiIIIiI % OoooO0Oo0O0 % o0oOo0 % i11111IIIII
  I1iI1I1 = open ( OooO00OOOOoo , mode = 'w+' )
  I1iI1I1 . write ( 'id="' + str ( I11iIiiI ) + '"\nname="' + OO000oo0o + '"\nversion="' + ooO0o0oo + '"\ngui="' + I1iI1 + '"' )
  I1iI1I1 . close ( )
  if 72 - 72: i1IIi
  O000OO0 = os . path . join ( o0OOoOO0oOO , 'startup.xml' )
  I1iI1I1 = open ( O000OO0 , mode = 'w+' )
  I1iI1I1 . write ( 'date="01011001"\nversion="' + ooO0o0oo + '"' )
  I1iI1I1 . close ( )
  if 72 - 72: o0oOo0 + oO0OooOoO . O0 - i1Iii1i1I / OoooooooOO . Iiii1i1
  iiiiiiI = open ( OooO00OOOOoo , 'r' )
  iI111iiI1II = iiiiiiI . read ( )
  iiiiiiI . close ( )
  print "### ti_id/id.xml contents: " + iI111iiI1II
  if 96 - 96: O00OOOoOoo0O * O0 - oO0OooOoO . o0oOo0 - iI1IiiIIIiIi
  if 84 - 84: III1IiiI * oOO00Oo * oOO00Oo - i1Iii1i1I
  III1Ii = OOooO0OOoo . yesno ( "Keep Kodi Settings?" , 'Do you want to keep your existing KODI settings (weather, screen calibration, PVR etc.) or wipe and install the ones supplied in this build?' , yeslabel = 'Replace my settings' , nolabel = 'Keep my settings' )
  if III1Ii == 0 :
   OoOOoOo ( os . path . join ( II , 'extracted' , 'userdata' , 'guisettings.xml' ) )
   if 90 - 90: o0Oo
  for Oooo in os . listdir ( Ooo ) :
   iIiiiII . append ( Oooo )
   if 27 - 27: iIii1I11I1II1 - III1IiiI
   if 73 - 73: iiIi1i11 . II11iIiIIIiI + II11iIiIIIiI % II11iIiIIIiI % O0
  o0oOo = open ( os . path . join ( ii1Ii1111 , 'addonlist' ) , mode = 'w+' )
  for Oooo in os . listdir ( OO0o ) :
   if not Oooo in iIiiiII and Oooo != 'plugin.program.totalinstaller' and Oooo != 'script.module.addon.common' and Oooo != 'packages' :
    o0oOo . write ( Oooo + '|' )
  o0oOo . close ( )
  if o0oO0 == 'true' :
   print "### Created addonlist to: " + os . path . join ( ii1Ii1111 , 'addonlist' )
  o0Iiii = [ 'addons' , 'cache' , 'CP_Profiles' , 'system' , 'temp' , 'Thumbnails' ]
  I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' , 'addons*.db' , 'textures13.db' , '.cbcfg' ]
  o0OO0OOO0O = "Creating Profile Data File"
  Iii1I = "Archiving..."
  oOoOOOOoOO0o = ""
  iiI1i1I1II = "Please Wait"
  OooOOOO0O0 ( OoI11II , os . path . join ( ii1Ii1111 , 'build.zip' ) , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
  if o0oO0 == 'true' :
   print "### Created: " + os . path . join ( ii1Ii1111 , 'build.zip' )
   if 8 - 8: i1Iii1i1I . iI1IiiIIIiIi - i1IIi % ii1ii11IIIiiI / o00O0OoO
  if IIiIiII11i == 'false' :
   os . remove ( oOOOOOoOOoo0 )
   if o0oO0 == 'true' :
    print "### removed: " + oOOOOOoOOoo0
  OOoOOOO00 ( O000OOOoOooO )
  OO00OOoO0o = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( I11iIiiI )
  if not 'update' in video :
   try :
    i1II1 ( OO00OOoO0o , 5 )
   except :
    pass
    if 13 - 13: II11iIiIIIiI / O00OOOoOoo0O . OoooO0Oo0O0 . iiIi1i11
    if 31 - 31: oOO00Oo
  oOO00 ( ii1Ii1111 )
  if 75 - 75: O00OOOoOoo0O + iI1IiiIIIiIi . i11iIiiIii / iI1IiiIIIiIi
  if 32 - 32: iI1IiiIIIiIi + i11111IIIII + OoooO0Oo0O0
  if 79 - 79: i1IIi / iI1IiiIIIiIi
  if 81 - 81: iIii1I11I1II1
def o000oO0oOOO ( url ) :
 i1iiii11I1 = 0
 o0OOoo = 0
 print "### Local Build Restore Location: " + url
 if 71 - 71: II11iIiIIIiI
 II111 ( 'noobsandnerds.xml' )
 if 98 - 98: oOO00Oo * II11iIiIIIiI - iI1IiiIIIiIi . o0oOo0
 oOiI111I1III ( )
 if 2 - 2: II11iIiIIIiI - o0oOo0 % iIii1I11I1II1
 if url == 'local' :
  O000OOOoOooO = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.zip' , False , False , OOO00 )
  if O000OOOoOooO == '' :
   i1iiii11I1 = 1
   if 88 - 88: Iiii1i1 - ii1ii11IIIiiI
 if i1iiii11I1 == 1 :
  print "### No file selected, quitting restore process ###"
  return
  if 79 - 79: i1Iii1i1I
 if url != 'local' :
  iIii1 . create ( "Community Builds" , "Downloading build." , '' , 'Please Wait' )
  O000OOOoOooO = os . path . join ( iiiiiIIii , ooOoOO ( ) + '.zip' )
  if 45 - 45: oO0OooOoO + i1Iii1i1I . o00O0OoO . O0 * i1IIi - iI1IiiIIIiIi
  if not os . path . exists ( iiiiiIIii ) :
   os . makedirs ( iiiiiIIii )
   if 48 - 48: OoooO0Oo0O0 + II11iIiIIIiI
  downloader . download ( url , O000OOOoOooO , iIii1 )
  if 76 - 76: OoooO0Oo0O0
 if os . path . exists ( Oo0OoO00oOO0o ) :
  if os . path . exists ( I11i1 ) :
   os . remove ( Oo0OoO00oOO0o )
  else :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   if 98 - 98: oO0OooOoO + o0Oo - OoooO0Oo0O0 . iI1IiiIIIiIi
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 51 - 51: iI1IiiIIIiIi + i11iIiiIii * ii1ii11IIIiiI % II11iIiIIIiI / o0Oo - iIii1I11I1II1
  if 20 - 20: Iiii1i1 . o00O0OoO . iI1IiiIIIiIi + o00O0OoO - iiIi1i11 * III1IiiI
 if not os . path . exists ( I11iii1Ii ) :
  IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'w+' )
  if 82 - 82: ii1ii11IIIiiI
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 78 - 78: oO0OooOoO / o00O0OoO - i11iIiiIii + OoooO0Oo0O0 * II11iIiIIIiI
  if 17 - 17: O00OOOoOoo0O
 try :
  os . rename ( I11i1 , Oo0OoO00oOO0o )
  if 72 - 72: i1Iii1i1I . II11iIiIIIiI - i11iIiiIii / o0Oo
 except :
  OOooO0OOoo . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit XBMC and try again' , '' )
  return
  if 64 - 64: III1IiiI
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'We highly recommend backing up your existing build before installing any builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
 if oo0O0oo == 0 :
  oOoOo00o00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
  if 79 - 79: o00O0OoO - O00OOOoOoo0O + Iiii1i1 / o0Oo * OoooooooOO
  if not os . path . exists ( oOoOo00o00 ) :
   os . makedirs ( oOoOo00o00 )
   if 26 - 26: oO0OooOoO * i1Iii1i1I + oOO00Oo / O0 + i1IIi - o00O0OoO
  o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
  if ( not o0OoOoooo0 ) :
   return False , 0
   if 56 - 56: iiIi1i11
  o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
  ooO0 = xbmc . translatePath ( os . path . join ( oOoOo00o00 , o0OOoOo0oo + '.zip' ) )
  o0Iiii = [ o0OO00 ]
  I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
  o0OO0OOO0O = "Creating full backup of existing build"
  Iii1I = "Archiving..."
  oOoOOOOoOO0o = ""
  iiI1i1I1II = "Please Wait"
  if 76 - 76: i1IIi % iIii1I11I1II1 - oOO00Oo + i11111IIIII - o00O0OoO
  OooOOOO0O0 ( oOOoO0 , ooO0 , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
 OOOo00o = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'Would you like to keep your existing database files or overwrite? Overwriting will wipe any existing music or video library you may have scanned in.' , nolabel = 'Overwrite' , yeslabel = 'Keep Existing' )
 if OOOo00o == 1 :
  if os . path . exists ( O0o0O00Oo0o0 ) :
   shutil . rmtree ( O0o0O00Oo0o0 )
   if 100 - 100: iIii1I11I1II1 - O00OOOoOoo0O
  try :
   shutil . copytree ( OooO0 , O0o0O00Oo0o0 , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 28 - 28: II11iIiIIIiI . O0 . o00O0OoO
  except :
   o0OOoo = xbmcgui . Dialog ( ) . yesno ( i1iIIIi1i , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if o0OOoo == 1 : pass
   if o0OOoo == 0 : i1iiii11I1 = 1 ; return
   if 60 - 60: oO0OooOoO + Iiii1i1 / III1IiiI % OoooooooOO - i1IIi
  ooO0 = xbmc . translatePath ( os . path . join ( OOO00 , 'Database.zip' ) )
  Ii1ii11IIIi ( O0o0O00Oo0o0 , ooO0 )
  if 57 - 57: o0oOo0
 if i1iiii11I1 == 1 :
  print "### User decided to exit restore function ###"
  return
  if 99 - 99: II11iIiIIIiI + Iiii1i1 % o0oOo0 - oOO00Oo
 else :
  time . sleep ( 1 )
  ooo0o0OOo0O = open ( O0o0Oo , mode = 'r' )
  Oo0OOo0o0o0o0 = ooo0o0OOo0O . read ( )
  ooo0o0OOo0O . close ( )
  if 52 - 52: OoooO0Oo0O0
  if 93 - 93: i1Iii1i1I . i11iIiiIii
  print "### Checking zip file structure ###"
  I1i1IO0OOoooO = zipfile . ZipFile ( O000OOOoOooO )
  if 'xbmc.log' in I1i1IO0OOoooO . namelist ( ) or 'kodi.log' in I1i1IO0OOoooO . namelist ( ) or '.git' in I1i1IO0OOoooO . namelist ( ) or '.svn' in I1i1IO0OOoooO . namelist ( ) :
   print "### Whoever created this build has used completely the wrong backup method, lets try and fix it! ###"
   OOooO0OOoo . ok ( 'Fixing Bad Zip' , 'Whoever created this build has used the wrong backup method, please wait while we fix it - this could take some time! Click OK to proceed' )
   ooO0OOoOoOO00 = zipfile . ZipFile ( O000OOOoOooO , 'r' )
   o0O00 = os . path . join ( iiiiiIIii , 'fixed.zip' )
   ii1IiI111II = zipfile . ZipFile ( o0O00 , 'w' )
   if 8 - 8: iiIi1i11
   iIii1 . create ( "Fixing Build" , "Checking " , '' , 'Please Wait' )
   if 44 - 44: ii1ii11IIIiiI % i11iIiiIii . Iiii1i1 - O0 / i1Iii1i1I . o0oOo0
   for Oooo in ooO0OOoOoOO00 . infolist ( ) :
    buffer = ooO0OOoOoOO00 . read ( Oooo . filename )
    iIiI1I1IIi1 = str ( Oooo . filename )
    if 77 - 77: oO0OooOoO - oOO00Oo . OoooO0Oo0O0
    if ( Oooo . filename [ - 4 : ] != '.log' ) and not '.git' in iIiI1I1IIi1 and not '.svn' in iIiI1I1IIi1 :
     ii1IiI111II . writestr ( Oooo , buffer )
     iIii1 . update ( 0 , "Fixing..." , '[COLOR yellow]%s[/COLOR]' % Oooo . filename , 'Please Wait' )
     if 63 - 63: III1IiiI
   iIii1 . close ( )
   ii1IiI111II . close ( )
   ooO0OOoOoOO00 . close ( )
   O000OOOoOooO = o0O00
   if 79 - 79: OoooO0Oo0O0 - III1IiiI - oOO00Oo . iiIi1i11
  iIii1 . create ( "Restoring Backup Build" , "Checking " , '' , 'Please Wait' )
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  if 65 - 65: i11iIiiIii . ii1ii11IIIiiI % i1Iii1i1I + i11111IIIII - i11iIiiIii
  try :
   extract . all ( O000OOOoOooO , oOOoO0 , iIii1 )
  except :
   OOooO0OOoo . ok ( 'ERROR IN BUILD ZIP' , 'Please contact the build author, there are errors in this zip file that has caused the install process to fail. Most likely cause is it contains files with special characters in the name.' )
   return
   if 60 - 60: Iiii1i1
  time . sleep ( 1 )
  if 14 - 14: II11iIiIIIiI % III1IiiI * i1Iii1i1I - i11iIiiIii / OoooO0Oo0O0 * i11iIiiIii
  if OOOo00o == 1 :
   extract . all ( ooO0 , OooO0 , iIii1 )
   if 95 - 95: iIii1I11I1II1 + O00OOOoOoo0O . o0Oo + O00OOOoOoo0O * o00O0OoO + iiIi1i11
   if o0OOoo != 1 :
    shutil . rmtree ( O0o0O00Oo0o0 )
    if 14 - 14: iI1IiiIIIiIi - O0
  OoOO0Ooo = open ( O0o0Oo , mode = 'w+' )
  OoOO0Ooo . write ( Oo0OOo0o0o0o0 )
  OoOO0Ooo . close ( )
  try :
   os . rename ( I11i1 , iIi1ii1I1 )
   if 95 - 95: ii1ii11IIIiiI - i11111IIIII % Iiii1i1
  except :
   print "NO GUISETTINGS DOWNLOADED"
   if 27 - 27: iIii1I11I1II1 / o0Oo % O00OOOoOoo0O / o0Oo * iI1IiiIIIiIi
  time . sleep ( 1 )
  IiI1i111IiIiIi1 = open ( Oo0OoO00oOO0o , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
  O00O0 = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( o0oO0OoO0 )
  iIOOO0O00 = O00O0 [ 0 ] if ( len ( O00O0 ) > 0 ) else ''
  ii11i1i = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( o0oO0OoO0 )
  Oo0O000OoO00 = ii11i1i [ 0 ] if ( len ( ii11i1i ) > 0 ) else ''
  iIiI1I = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( o0oO0OoO0 )
  oOO00OoOo = iIiI1I [ 0 ] if ( len ( iIiI1I ) > 0 ) else ''
  if 13 - 13: i1Iii1i1I . i1Iii1i1I + i11iIiiIii % O0 % Iiii1i1 + i11111IIIII
  try :
   oOoO0Iii1II1ii = open ( iIi1ii1I1 , mode = 'r' )
   ooOo00 = oOoO0Iii1II1ii . read ( )
   oOoO0Iii1II1ii . close ( )
   iIO0oooooO = re . compile ( '<skinsettings>[\s\S]*?<\/skinsettings>' ) . findall ( ooOo00 )
   i1ii11 = iIO0oooooO [ 0 ] if ( len ( iIO0oooooO ) > 0 ) else ''
   IIi1 = re . compile ( '<skin default[\s\S]*?<\/skin>' ) . findall ( ooOo00 )
   IIIo00O = IIi1 [ 0 ] if ( len ( IIi1 ) > 0 ) else ''
   II11II = re . compile ( '<lookandfeel>[\s\S]*?<\/lookandfeel>' ) . findall ( ooOo00 )
   ii1I1I1 = II11II [ 0 ] if ( len ( II11II ) > 0 ) else ''
   II1i11i1iIi11 = o0oO0OoO0 . replace ( iIOOO0O00 , i1ii11 ) . replace ( oOO00OoOo , ii1I1I1 ) . replace ( Oo0O000OoO00 , IIIo00O )
   I1iI1I1 = open ( Oo0OoO00oOO0o , mode = 'w+' )
   I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
   I1iI1I1 . close ( )
   if 42 - 42: i1IIi + i1Iii1i1I . OoooooooOO + OoooO0Oo0O0 . o00O0OoO / iI1IiiIIIiIi
  except :
   print "### NO GUISETTINGS DOWNLOADED"
   if 1 - 1: oOO00Oo
  if os . path . exists ( I11i1 ) :
   os . remove ( I11i1 )
   if 95 - 95: iiIi1i11 / i1IIi % ii1ii11IIIiiI . Iiii1i1 + Iiii1i1
  os . rename ( Oo0OoO00oOO0o , I11i1 )
  try :
   os . remove ( iIi1ii1I1 )
   if 80 - 80: O0 + OoooO0Oo0O0 + iiIi1i11
  except :
   pass
   if 95 - 95: OoooO0Oo0O0
  os . makedirs ( OOO00O )
  time . sleep ( 1 )
  Oo0iII ( )
  if 98 - 98: i11111IIIII * i1Iii1i1I . OoooooooOO . O0
  if 89 - 89: i1Iii1i1I / O0 % OoooooooOO - O0 . ii1ii11IIIiiI
  if 32 - 32: o0oOo0
  if 26 - 26: O0 * iI1IiiIIIiIi - o0Oo - i1Iii1i1I / iIii1I11I1II1
  if 57 - 57: OoooO0Oo0O0 - ii1ii11IIIiiI * iIii1I11I1II1
  if 26 - 26: ii1ii11IIIiiI % o0oOo0 % oOO00Oo % O00OOOoOoo0O . i1Iii1i1I % O0
  if 91 - 91: oO0OooOoO . II11iIiIIIiI . III1IiiI - OoooooooOO / O00OOOoOoo0O
  if 30 - 30: o00O0OoO % oOO00Oo + i1IIi * OoooooooOO * ii1ii11IIIiiI - oO0OooOoO
  if 55 - 55: ii1ii11IIIiiI
  if 20 - 20: o0oOo0 * Iiii1i1 * oOO00Oo - o0oOo0
  if 32 - 32: iI1IiiIIIiIi * III1IiiI
  if 85 - 85: i11iIiiIii . ii1ii11IIIiiI + ii1ii11IIIiiI
  if 28 - 28: II11iIiIIIiI
  if 62 - 62: II11iIiIIIiI + OoooooooOO / i1Iii1i1I
  if 60 - 60: iI1IiiIIIiIi / O00OOOoOoo0O . o00O0OoO % iiIi1i11
  if 61 - 61: O0 . iI1IiiIIIiIi . O0 * i11iIiiIii * oO0OooOoO / Iiii1i1
  if 69 - 69: o00O0OoO
  if 17 - 17: o00O0OoO
  if 38 - 38: Iiii1i1 % iiIi1i11
def IiIiIiiI ( ) :
 oOiI111I1III ( )
 iii1I1i = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the guisettings zip file you want to restore' , 'files' , '.zip' , False , False , OOO00 )
 if 16 - 16: Iiii1i1 % iIii1I11I1II1 . i1IIi
 if iii1I1i == '' :
  return
  if 72 - 72: o0oOo0 * iiIi1i11
 else :
  O0oIIiIiiiii11 = 1
  oOO0O0O ( iii1I1i , O0oIIiIiiiii11 )
  if 69 - 69: III1IiiI - i11iIiiIii
  if 29 - 29: iI1IiiIIIiIi + i1Iii1i1I % OoooO0Oo0O0 + o00O0OoO * II11iIiIIIiI - i11iIiiIii
def IiI11i1IiI1 ( name , url , video ) :
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option for first time install or if you\'re encountering any issues with your device. This will wipe all your Kodi settings, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if oo0O0oo == 0 :
  return
  if 88 - 88: iiIi1i11 - O0 % oOO00Oo
 elif oo0O0oo == 1 :
  if 63 - 63: o0oOo0 * III1IiiI + o0oOo0 * iI1IiiIIIiIi + II11iIiIIIiI / OoooO0Oo0O0
  oOOOOOoOOoo0 = '/storage/openelec_temp/'
  iiOOOO00oO = '/storage/.restore/'
  i111IiiI1Ii = os . path . join ( iiOOOO00oO , ooOoOO ( ) + '.tar' )
  if not os . path . exists ( iiOOOO00oO ) :
   try :
    os . makedirs ( iiOOOO00oO )
   except :
    pass
  try :
   iIii1 . create ( 'Downloading Build' , 'Please wait' , '' , '' )
   downloader . download ( url , i111IiiI1Ii )
   ooo000 = True
  except :
   ooo000 = False
  time . sleep ( 2 )
  if 72 - 72: iiIi1i11 . O00OOOoOoo0O / oO0OooOoO
  if ooo000 == True :
   if 69 - 69: iiIi1i11 * oO0OooOoO - o0oOo0 - i1IIi + i11iIiiIii
   try :
    IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'r' )
    o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
    IiI1i111IiIiIi1 . close ( )
    if 50 - 50: OoooooooOO * i1IIi / III1IiiI
    OO0oOo = re . compile ( 'id="(.+?)"' ) . findall ( o0oO0OoO0 )
    I11iIiiI = OO0oOo [ 0 ] if ( len ( OO0oOo ) > 0 ) else ''
    if 83 - 83: i1IIi
   except :
    pass
   if I11iIiiI != '' :
    OO00OOoO0o = 'http://noobsandnerds.com/TI/Community_Builds/downloadcount.php?id=%s' % ( I11iIiiI )
   try :
    i1II1 ( OO00OOoO0o , 5 )
   except :
    pass
    if 38 - 38: OoooooooOO * iIii1I11I1II1
    if 54 - 54: OoooooooOO . Iiii1i1
   if not os . path . exists ( oOOOOOoOOoo0 ) :
    try :
     os . makedirs ( oOOOOOoOOoo0 )
    except :
     pass
     if 71 - 71: iI1IiiIIIiIi
   OOooO0OOoo . ok ( "Download Complete - Press OK To Reboot" , 'Once you press OK your device will attempt to reboot, if it hasn\'t rebooted within 30 seconds please pull the power to manually shutdown. When booting you may see lines of text, don\'t worry this is normal update behaviour!' )
   xbmc . executebuiltin ( 'Reboot' )
   if 31 - 31: o00O0OoO . i11iIiiIii . ii1ii11IIIiiI * II11iIiIIIiI % iI1IiiIIIiIi . oOO00Oo
   if 92 - 92: OoooooooOO / O0 * i1IIi + iIii1I11I1II1
def o00O00O0O0 ( ) :
 i1iiii11I1 = 0
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( 'Full Wipe And New Install' , 'This is a great option if you\'re encountering any issues with your device. This will wipe all your Kodi settings and restore with whatever is in the backup, do you wish to continue?' , nolabel = 'Cancel' , yeslabel = 'Accept' )
 if oo0O0oo == 0 :
  return
  if 87 - 87: OoooO0Oo0O0
 elif oo0O0oo == 1 :
  O000OOOoOooO = xbmcgui . Dialog ( ) . browse ( 1 , 'Select the backup file you want to restore' , 'files' , '.tar' , False , False , oO0 )
  if O000OOOoOooO == '' :
   i1iiii11I1 = 1
   if 60 - 60: i11iIiiIii / i1IIi * iiIi1i11
  if i1iiii11I1 == 1 :
   print "### No file selected, quitting restore process ###"
   return
  i111IiiI1Ii = os . path . join ( Ii1iIiII1ii1 , ooOoOO ( ) + '.tar' )
  if not os . path . exists ( Ii1iIiII1ii1 ) :
   try :
    os . makedirs ( Ii1iIiII1ii1 )
   except :
    pass
  iIii1 . create ( 'Copying File To Restore Folder' , '' , 'Please wait...' )
  shutil . copyfile ( O000OOOoOooO , i111IiiI1Ii )
  xbmc . executebuiltin ( 'Reboot' )
  if 89 - 89: iIii1I11I1II1 * oOO00Oo + O00OOOoOoo0O . i11iIiiIii + OoooO0Oo0O0
  if 1 - 1: o0Oo . o00O0OoO . OoooO0Oo0O0
def ii11iI11I111I ( ) :
 oO00o ( )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore a locally stored OpenELEC Backup[/COLOR]' , '' , 'restore_local_OE' , '' , '' , '' , 'Restore A Full OE System Backup' )
  if 44 - 44: i1IIi - OoooO0Oo0O0 + OoooO0Oo0O0 . o00O0OoO / iiIi1i11
 oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore A Locally stored build[/COLOR]' , 'local' , 'restore_local_CB' , '' , '' , '' , 'Restore A Full System Backup' )
 oO00oOOoooO ( '' , '[COLOR=dodgerblue]Restore Local guisettings file[/COLOR]' , 'url' , 'LocalGUIDialog' , '' , '' , '' , 'Back Up Your Full System' )
 if 48 - 48: OoooO0Oo0O0 . O0 . o0Oo * oOO00Oo / i1Iii1i1I
 if os . path . exists ( os . path . join ( OOO00 , 'addons.zip' ) ) :
  oO00oOOoooO ( '' , 'Restore Your Addons' , 'addons' , 'restore_zip' , '' , '' , '' , 'Restore Your Addons' )
  if 61 - 61: II11iIiIIIiI - Iiii1i1
 if os . path . exists ( os . path . join ( OOO00 , 'addon_data.zip' ) ) :
  oO00oOOoooO ( '' , 'Restore Your Addon UserData' , 'addon_data' , 'restore_zip' , '' , '' , '' , 'Restore Your Addon UserData' )
  if 51 - 51: i1Iii1i1I * o0oOo0 / O0 / O0
 if os . path . exists ( os . path . join ( OOO00 , 'guisettings.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Guisettings.xml' , I11i1 , 'restore_backup' , '' , '' , '' , 'Restore Your guisettings.xml' )
  if 52 - 52: OoooooooOO % O0
 if os . path . exists ( os . path . join ( OOO00 , 'favourites.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Favourites.xml' , IIIII , 'restore_backup' , '' , '' , '' , 'Restore Your favourites.xml' )
  if 56 - 56: III1IiiI - i1IIi * OoooooooOO - oO0OooOoO
 if os . path . exists ( os . path . join ( OOO00 , 'sources.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Source.xml' , ooooooO0oo , 'restore_backup' , '' , '' , '' , 'Restore Your sources.xml' )
  if 28 - 28: i1IIi / o00O0OoO . oOO00Oo
 if os . path . exists ( os . path . join ( OOO00 , 'advancedsettings.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Advancedsettings.xml' , IIiiiiiiIi1I1 , 'restore_backup' , '' , '' , '' , 'Restore Your advancedsettings.xml' )
  if 11 - 11: II11iIiIIIiI * OoooooooOO - i11iIiiIii
 if os . path . exists ( os . path . join ( OOO00 , 'keyboard.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore Advancedsettings.xml' , OOOO , 'restore_backup' , '' , '' , '' , 'Restore Your keyboard.xml' )
  if 13 - 13: i11iIiiIii . O0 / iiIi1i11 * i1IIi
 if os . path . exists ( os . path . join ( OOO00 , 'RssFeeds.xml' ) ) :
  oO00oOOoooO ( '' , 'Restore RssFeeds.xml' , oOoOooOo0o0 , 'restore_backup' , '' , '' , '' , 'Restore Your RssFeeds.xml' )
  if 14 - 14: i11111IIIII + i11111IIIII . o00O0OoO / iI1IiiIIIiIi . iIii1I11I1II1
  if 10 - 10: oO0OooOoO . iiIi1i11 / i1Iii1i1I
def I1IIoooooOO0 ( url ) :
 oOiI111I1III ( )
 if 'addons' in url :
  OOO0o0O = xbmc . translatePath ( os . path . join ( OOO00 , 'addons.zip' ) )
  I111i = OO0o
  if 39 - 39: OoooO0Oo0O0
 else :
  OOO0o0O = xbmc . translatePath ( os . path . join ( OOO00 , 'addon_data.zip' ) )
  I111i = iiI1IiI
  if 81 - 81: O00OOOoOoo0O . oOO00Oo
 if 'Backup' in i1iIIIi1i :
  oo0O ( )
  iIii1 . create ( "Creating Backup" , "Backing Up" , '' , 'Please Wait' )
  i1IIi1i1Ii1 = zipfile . ZipFile ( OOO0o0O , 'w' , zipfile . ZIP_DEFLATED )
  Iiio0Oo0oO = len ( I111i )
  iIII1iiIi11 = [ ]
  ooOo0O0O0oOO0 = [ ]
  for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( I111i ) :
   for file in I1iiIi111I :
    ooOo0O0O0oOO0 . append ( file )
  IiiiI111I = len ( ooOo0O0O0oOO0 )
  for oO0O000oOo , OoOOOO , I1iiIi111I in os . walk ( I111i ) :
   for file in I1iiIi111I :
    iIII1iiIi11 . append ( file )
    Oo0O0Oo00O = len ( iIII1iiIi11 ) / float ( IiiiI111I ) * 100
    iIii1 . update ( int ( Oo0O0Oo00O ) , "Backing Up" , '[COLOR yellow]%s[/COLOR]' % file , 'Please Wait' )
    iIoo0ooooO = os . path . join ( oO0O000oOo , file )
    if not 'temp' in OoOOOO :
     if not o0OO00 in OoOOOO :
      import time
      iI11Ii111 = '01/01/1980'
      OOo00OO00Oo = time . strftime ( '%d/%m/%Y' , time . gmtime ( os . path . getmtime ( iIoo0ooooO ) ) )
      if OOo00OO00Oo > iI11Ii111 :
       i1IIi1i1Ii1 . write ( iIoo0ooooO , iIoo0ooooO [ Iiio0Oo0oO : ] )
  i1IIi1i1Ii1 . close ( )
  iIii1 . close ( )
  OOooO0OOoo . ok ( "Backup Complete" , "You Are Now Backed Up" , '' , '' )
  if 37 - 37: i1Iii1i1I + Iiii1i1 * iI1IiiIIIiIi + i11111IIIII
 else :
  iIii1 . create ( "Extracting Zip" , "Checking " , '' , 'Please Wait' )
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( OOO0o0O , I111i , iIii1 )
  time . sleep ( 1 )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 39 - 39: O0 * II11iIiIIIiI - o0Oo + iI1IiiIIIiIi / oO0OooOoO
  if 'Backup' in i1iIIIi1i :
   OOooO0OOoo . ok ( "Install Complete" , 'Kodi will now close. Just re-open Kodi and wait for all the updates to complete.' )
   Oo0iII ( )
   if 66 - 66: o0oOo0 + III1IiiI % OoooooooOO
  else :
   OOooO0OOoo . ok ( "SUCCESS!" , "You Are Now Restored" , '' , '' )
   if 23 - 23: III1IiiI . O00OOOoOoo0O + iIii1I11I1II1
   if 17 - 17: i11111IIIII
def iiI ( url ) :
 xbmc . executebuiltin ( 'RunAddon(' + url + ')' )
 if 14 - 14: iiIi1i11 + oO0OooOoO % iiIi1i11 . III1IiiI * o0oOo0
 if 54 - 54: o0oOo0 * o00O0OoO - Iiii1i1
def iIiII1 ( title ) :
 i1iI1iii111 = ''
 Ii1II = xbmc . Keyboard ( i1iI1iii111 , title )
 Ii1II . doModal ( )
 if Ii1II . isConfirmed ( ) :
  i1iI1iii111 = Ii1II . getText ( ) . replace ( ' ' , '%20' )
  if i1iI1iii111 == None :
   return False
 return i1iI1iii111
 if 98 - 98: O0 + oOO00Oo
 if 23 - 23: i1Iii1i1I / i1Iii1i1I
def i1III1II11Ii ( url ) :
 o0OoOoooo0 = OooO0O0Ooo ( heading = "Search for add-ons" )
 if 34 - 34: i11111IIIII - oO0OooOoO % iI1IiiIIIiIi
 if ( not o0OoOoooo0 ) : return False , 0
 if 91 - 91: II11iIiIIIiI * II11iIiIIIiI / i11111IIIII + II11iIiIIIiI
 if 94 - 94: o0oOo0 - i1IIi . O0 / o0Oo
 o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
 url += o0OOoOo0oo
 i1IIII1111 ( url )
 if 37 - 37: OoooO0Oo0O0 * Iiii1i1 * o0Oo * O0
 if 35 - 35: o0Oo - OoooO0Oo0O0 * i1Iii1i1I + i11111IIIII / i1IIi
def II1o0o00O ( url ) :
 o0OoOoooo0 = OooO0O0Ooo ( heading = "Search for content" )
 if 59 - 59: Iiii1i1 * i1Iii1i1I
 if 31 - 31: o00O0OoO / O0
 if ( not o0OoOoooo0 ) : return False , 0
 if 57 - 57: i1IIi % o0oOo0
 if 69 - 69: oOO00Oo
 o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
 url += o0OOoOo0oo
 o0OOo0Ooo0 ( url )
 if 69 - 69: Iiii1i1
 if 83 - 83: iIii1I11I1II1 . oOO00Oo + Iiii1i1 . OoooooooOO / o0oOo0 + oO0OooOoO
def o0o0O0oOOoO0 ( url ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/Community_Builds/community_builds.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 5 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 iIiII = re . compile ( 'author="(.+?)"' ) . findall ( OoOO0o )
 O00O = re . compile ( 'version="(.+?)"' ) . findall ( OoOO0o )
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 O0oIi1iIiIi1I11 = iIiII [ 0 ] if ( len ( iIiII ) > 0 ) else ''
 ii11I1 = O00O [ 0 ] if ( len ( O00O ) > 0 ) else ''
 OOooO0OOoo . ok ( i1iIIIi1i , 'Author: [COLOR=dodgerblue]' + O0oIi1iIiIi1I11 + '[/COLOR]      Latest Version: [COLOR=dodgerblue]' + ii11I1 + '[/COLOR]' , '' , 'Click OK to view the build page.' )
 try :
  o0OO0OO000OO ( url + '&visibility=homepage' , url )
 except :
  return
  print "### Could not find build No. " + url
  OOooO0OOoo . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private or servers may be busy. Please try manually searching via the Community Builds section' )
  if 3 - 3: i11111IIIII % i1IIi % O00OOOoOoo0O + OoooO0Oo0O0
  if 41 - 41: O00OOOoOoo0O / iIii1I11I1II1
def O0O0o0OOOooo0 ( url ) :
 OOooO0OOoo . ok ( "This build is not complete" , 'The guisettings.xml file was not copied over during the last install process. Click OK to go to the build page and complete Install Step 2 (guisettings fix).' )
 if 18 - 18: o0Oo
 try :
  o0OO0OO000OO ( url + '&visibility=homepage' , url )
  if 32 - 32: iIii1I11I1II1 * o0Oo . iiIi1i11 * iIii1I11I1II1
 except :
  return
  print "### Could not find build No. " + url
  OOooO0OOoo . ok ( 'Build Not Found' , 'Sorry we couldn\'t find the build, it may be it\'s marked as private. Please try manually searching via the Community Builds section' )
  if 92 - 92: III1IiiI - o0oOo0 . OoooooooOO * III1IiiI / II11iIiIIIiI
  if 16 - 16: o00O0OoO / OoooooooOO - i11111IIIII % o0Oo % o00O0OoO
def oOoooO0O0oOO ( ) :
 I1II1I11I1I = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( O0oo0OO0 , I1i1iiI1 )
 OoOO0o = i1II1 ( I1II1I11I1I , 5 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 i1111ii = re . compile ( 'posts="(.+?)"' ) . findall ( OoOO0o )
 IIii1iiI1iIi1 = re . compile ( 'messages="(.+?)"' ) . findall ( OoOO0o )
 iiiI11i = re . compile ( 'unread="(.+?)"' ) . findall ( OoOO0o )
 Ooo0O0O0o = re . compile ( 'email="(.+?)"' ) . findall ( OoOO0o )
 Oo0oo0o = IIii1iiI1iIi1 [ 0 ] if ( len ( IIii1iiI1iIi1 ) > 0 ) else ''
 o0OO0o0O00O0O = iiiI11i [ 0 ] if ( len ( iiiI11i ) > 0 ) else ''
 O0OO = Ooo0O0O0o [ 0 ] if ( len ( Ooo0O0O0o ) > 0 ) else ''
 OoO0o00O0oOOo = i1111ii [ 0 ] if ( len ( i1111ii ) > 0 ) else ''
 OOooO0OOoo . ok ( '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR]' , 'Username:  ' + O0oo0OO0 , 'Email: ' + O0OO , 'Unread Messages: ' + o0OO0o0O00O0O + '/' + Oo0oo0o + '[CR]Posts: ' + OoO0o00O0oOOo )
 if 69 - 69: i1IIi . o0Oo + i11111IIIII
 if 95 - 95: o0Oo - iiIi1i11 . II11iIiIIIiI / O0 + iI1IiiIIIiIi
def OoooOO0 ( url , type ) :
 if type == 'communitybuilds' :
  oOOo00ooO00 = 'grab_builds'
  if url . endswith ( "visibility=premium" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=premium' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=reseller_private" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&reseller=' + urllib . quote ( I1IiiI ) + '&token=' + IIi1IiiiI1Ii + '&visibility=reseller_private' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=public" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=public' , 'manual_search' , '' , '' , '' , '' )
  if url . endswith ( "visibility=private" ) :
   oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , '&visibility=private' , 'manual_search' , '' , '' , '' , '' )
 if type == 'tutorials' :
  oOOo00ooO00 = 'grab_tutorials'
 if type == 'hardware' :
  oOOo00ooO00 = 'grab_hardware'
 if type == 'addons' :
  oOOo00ooO00 = 'grab_addons'
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloads&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
 if type == 'hardware' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]Filter Results[/COLOR]' , url , 'hardware_filter_menu' , '' , '' , '' , '' )
 if type != 'addons' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Most Popular[/COLOR]' , str ( url ) + '&sortx=downloadcount&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
 if type == 'tutorials' or type == 'hardware' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=Added&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
 else :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Newest[/COLOR]' , str ( url ) + '&sortx=created&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Recently Updated[/COLOR]' , str ( url ) + '&sortx=updated&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by A-Z[/COLOR]' , str ( url ) + '&sortx=name&orderx=ASC' , oOOo00ooO00 , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Z-A[/COLOR]' , str ( url ) + '&sortx=name&orderx=DESC' , oOOo00ooO00 , '' , '' , '' , '' )
 if type == 'public_CB' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Genre[/COLOR]' , url , 'genres' , '' , '' , '' , '' )
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue]Sort by Country/Language[/COLOR]' , url , 'countries' , '' , '' , '' , '' )
  if 66 - 66: o00O0OoO + OoooO0Oo0O0 . Iiii1i1
  if 35 - 35: Iiii1i1 . o00O0OoO . OoooO0Oo0O0
def iIiIiiiI ( ) :
 OOooO0OO0 ( 'Speed Test Instructions' , '[COLOR=blue][B]What file should I use: [/B][/COLOR][CR]This function will download a file and will work out your speed based on how long it took to download. You will then be notified of '
 'what quality streams you can expect to stream without buffering. You can choose to download a 10MB, 16MB, 32MB, 64MB or 128MB file to use with the test. Using the larger files will give you a better '
 'indication of how reliable your speeds are but obviously if you have a limited amount of bandwidth allowance you may want to opt for a smaller file.'
 '[CR][CR][COLOR=blue][B]How accurate is this speed test:[/B][/COLOR][CR]Not very accurate at all! As this test is based on downloading a file from a server it\'s reliant on the server not having a go-slow day '
 'but the servers used should be pretty reliable. The 10MB file is hosted on a different server to the others so if you\'re not getting the results expected please try another file. If you have a fast fiber '
 'connection the chances are your speed will show as considerably slower than your real download speed due to the server not being able to send the file as fast as your download speed allows. Essentially the '
 'test results will be limited by the speed of the server but you will at least be able to see if it\'s your connection that\'s causing buffering or if it\'s the host you\'re trying to stream from'
 '[CR][CR][COLOR=blue][B]What is the differnce between Live Streams and Online Video:[/COLOR][/B][CR]When you run the test you\'ll see results based on your speeds and these let you know the quality you should expect to '
 'be able stream with your connection. Live Streams as the title suggests are like traditional TV channels, they are being streamed live so for example if you wanted to watch CNN this would fall into this category. '
 'Online Videos relates to movies, tv shows, youtube clips etc. Basically anything that isn\'t live - if you\'re new to the world of streaming then think of it as On Demand content, this is content that\'s been recorded and stored on the web.'
 '[CR][CR][COLOR=blue][B]Why am I still getting buffering:[/COLOR][/B][CR]The results you get from this test are strictly based on your download speed, there are many other factors that can cause buffering and contrary to popular belief '
 'having a massively fast internet connection will not make any difference to your buffering issues if the server you\'re trying to get the content from is unable to send it fast enough. This can often happen and is usually '
 'down to heavy traffic (too many users accessing the same server). A 10 Mb/s connection should be plenty fast enough for almost all content as it\'s very rare a server can send it any quicker than that.'
 '[CR][CR][COLOR=blue][B]What\'s the difference between MB/s and Mb/s:[/COLOR][/B][CR]A lot of people think the speed they see advertised by their ISP is Megabytes (MB/S) per second - this is not true. Speeds are usually shown as Mb/s '
 'which is Megabit per second - there are 8 of these to a megabyte so if you want to work out how many megabytes per second you\'re getting you need to divide the speed by 8. It may sound sneaky but really it\'s just the unit that has always been used.'
 '[CR][CR]A direct link to the buffering thread explaining what you can do to improve your viewing experience can be found at [COLOR=yellow]http://bit.ly/bufferingfix[/COLOR]'
 '[CR][CR]Thank you, [COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Team.' )
 if 16 - 16: III1IiiI
 if 66 - 66: o00O0OoO
def iI1I1IIIIIIii ( ) :
 oO00oOOoooO ( '' , '[COLOR=blue]Instructions - Read me first[/COLOR]' , 'none' , 'speed_instructions' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 16MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/16MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 32MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/32MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 64MB file   - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/64MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 128MB file - [COLOR=lime]Server 1[/COLOR]' , 'https://totalrevolution.googlecode.com/svn/trunk/download%20files/128MB.txt' , 'runtest' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Download 10MB file   - [COLOR=yellow]Server 2[/COLOR]' , 'http://www.wswd.net/testdownloadfiles/10MB.zip' , 'runtest' , '' , '' , '' , '' )
 if 50 - 50: III1IiiI . iIii1I11I1II1 % iiIi1i11
def oOO00 ( name ) :
 if 68 - 68: o0oOo0
 iIii1 . create ( 'Creating Profile' , '' , '' , '' )
 iIOoo0ooo0oo = Iii1I11 ( name )
 if 70 - 70: O00OOOoOoo0O - II11iIiIIIiI - Iiii1i1 * iiIi1i11 * iiIi1i11 * o0Oo
 if 12 - 12: iI1IiiIIIiIi
 iIiiiII = [ ]
 for Oooo in os . listdir ( Ooo ) :
  iIiiiII . append ( Oooo )
  if 33 - 33: iiIi1i11 * iI1IiiIIIiIi
  if 64 - 64: i11iIiiIii . iIii1I11I1II1
  III1II1I1iI = open ( os . path . join ( II , name , 'addonlist' ) , mode = 'r' )
  oOOOOOo0OO0o0oOO0 = III1II1I1iI . read ( )
  III1II1I1iI . close ( )
  oOOOOOo0OO0o0oOO0 = oOOOOOo0OO0o0oOO0 . split ( '|' )
  if 48 - 48: o00O0OoO
  if 98 - 98: o0oOo0 - iIii1I11I1II1 + iiIi1i11 - iIii1I11I1II1
 oOoOO ( 'profiles' )
 for Oooo in os . listdir ( OO0o ) :
  if not Oooo in iIiiiII and Oooo != 'plugin.program.totalinstaller' and Oooo != 'script.module.addon.common' and Oooo != 'repository.noobsandnerds' and Oooo != 'packages' :
   try :
    shutil . copytree ( os . path . join ( i1Oo00 , 'addons' , Oooo ) , os . path . join ( II , 'Master' , 'backups' , Oooo ) )
    if o0oO0 == 'true' :
     print "### Successfully copied " + Oooo + " to " + os . path . join ( II , 'Master' , 'backups' , Oooo )
   except :
    print "### Failed to copy " + Oooo + " to backup folder, must already exist"
   if not Oooo in oOOOOOo0OO0o0oOO0 and Oooo != OOOO0OOoO0O0 :
    try :
     os . rename ( os . path . join ( OO0o , Oooo ) , os . path . join ( II , 'Master' , Oooo ) )
    except :
     try :
      shutil . copytree ( os . path . join ( OO0o , Oooo ) , os . path . join ( II , 'Master' , Oooo ) )
     except :
      try :
       shutil . rmtree ( os . path . join ( OO0o , Oooo ) )
      except :
       print "### Unable to move " + Oooo + " as it's currently in use"
 shutil . rmtree ( i1Oo00 )
 if 70 - 70: iiIi1i11 / OoooO0Oo0O0
 if 72 - 72: OoooooooOO + OoooooooOO
 for Oooo in oOOOOOo0OO0o0oOO0 :
  if not Oooo in iIiiiII and not Oooo in OO0o :
   try :
    os . rename ( os . path . join ( II , 'Master' , Oooo ) , os . path . join ( OO0o , Oooo ) )
   except :
    pass
    if 42 - 42: o0oOo0 / i11111IIIII
 OOOOO0OOo ( )
 i11iii1II1I1 ( )
 IiIi11iI1IIi ( IIIi1I1IIii1II )
 print "### WIPE FUNCTIONS COMPLETE"
 if 5 - 5: III1IiiI + O00OOOoOoo0O
 try :
  IiI1i111IiIiIi1 = open ( I1IIiiIiii , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
  print "### original idfile contents: " + o0oO0OoO0
 except :
  print "### original id file does not exist"
  if 94 - 94: oOO00Oo % oOO00Oo % oO0OooOoO * iIii1I11I1II1 / i11111IIIII . OoooO0Oo0O0
 try :
  extract . all ( os . path . join ( II , name , 'build.zip' ) , oOOoO0 , iIii1 )
  ooo000 = 1
  print "### Extraction of build successful"
 except :
  OOooO0OOoo . ok ( 'Error' , "Sorry it wasn't possible to extract your build, there is a problem with your build zip file." )
  ooo000 = 0
 if os . path . exists ( os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'id.xml' ) ) and os . path . exists ( os . path . join ( iiI1IiI , 'ti_id' , 'id.xml' ) ) :
  print "### id.xml and temporary id.xml exists, attempting remove of original and replace with temp"
  os . remove ( os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'id.xml' ) )
  print "### removal ok"
  os . rename ( os . path . join ( iiI1IiI , 'ti_id' , 'id.xml' ) , os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'id.xml' ) )
  print "### rename ok"
 if os . path . exists ( os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'startup.xml' ) ) and os . path . exists ( os . path . join ( iiI1IiI , 'ti_id' , 'startup.xml' ) ) :
  print "### startup.xml and temporary startup.xml exists, attempting remove of original and replace with temp"
  os . remove ( os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'startup.xml' ) )
  print "### removal ok"
  os . rename ( os . path . join ( iiI1IiI , 'ti_id' , 'startup.xml' ) , os . path . join ( iiI1IiI , 'plugin.program.totalinstaller' , 'startup.xml' ) )
  print "### rename ok"
  if 13 - 13: O00OOOoOoo0O . o0Oo . oOO00Oo * III1IiiI / iI1IiiIIIiIi
 IiI1i111IiIiIi1 = open ( I1IIiiIiii , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 if 38 - 38: i11111IIIII - i1IIi . i11iIiiIii
 print "### new idfile contents: " + o0oO0OoO0
 if 28 - 28: Iiii1i1 / III1IiiI . OoooO0Oo0O0
 if ooo000 == 1 :
  Oo0iII ( )
  if 83 - 83: o00O0OoO
  if 36 - 36: iIii1I11I1II1
def o0OOoOO00OO0 ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan]DELETE A BUILD[/COLOR]' , url , 'delete_profile' , '' , '' , '' )
 for i1iIIIi1i in os . listdir ( II ) :
  if i1iIIIi1i != 'Master' and i1iIIIi1i != url . replace ( ' ' , '_' ) . replace ( "'" , '' ) . replace ( ':' , '-' ) :
   oO00oOOoooO ( '' , 'Load Profile: [COLOR=dodgerblue]' + i1iIIIi1i . replace ( '_' , ' ' ) + '[/COLOR]' , i1iIIIi1i , 'switch_profile' , '' , '' , '' , '' )
   if 93 - 93: oO0OooOoO * oO0OooOoO + o0Oo / II11iIiIIIiI
   if 9 - 9: II11iIiIIIiI - i11111IIIII
def OOooO0OO0 ( heading , anounce ) :
 class ii1i1iIiIIi ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try :
    iiI1iii = open ( anounce ) ; iI11I11i = iiI1iii . read ( )
   except :
    iI11I11i = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( iI11I11i ) )
   return
 ii1i1iIiIIi ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  xbmc . sleep ( 500 )
  if 80 - 80: o00O0OoO - OoooO0Oo0O0 * iI1IiiIIIiIi / OoooooooOO * O0 % iiIi1i11
  if 49 - 49: oO0OooOoO . o0Oo * O0 * iI1IiiIIIiIi / Iiii1i1 * OoooooooOO
def OOo00 ( url ) :
 try :
  Oo0OiI1 , iI11I11i = url . split ( '|' )
  OOooO0OO0 ( Oo0OiI1 , iI11I11i )
 except :
  OOooO0OO0 ( '' , url )
  if 22 - 22: i1IIi / O00OOOoOoo0O / iiIi1i11 . ii1ii11IIIiiI % Iiii1i1 + i11iIiiIii
  if 86 - 86: O00OOOoOoo0O
def ooOoOO ( ) :
 O0ooO = time . time ( )
 IiI1oo = time . localtime ( O0ooO )
 return time . strftime ( '%Y%m%d%H%M%S' , IiI1oo )
 if 92 - 92: oOO00Oo . Iiii1i1 + i1Iii1i1I % Iiii1i1 % i11iIiiIii
 if 46 - 46: OoooooooOO
def oo000o0O0o0O ( ) :
 oO00oOOoooO ( '' , '[COLOR=gold]CLEAN MY KODI FOLDERS (Save Space)[/COLOR]' , '' , 'full_clean' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds[/COLOR] Keyword Install' , '' , 'nan_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , '[COLOR=darkcyan][Noobs][/COLOR] Community Portal Folder Check' , 'url' , 'check_storage' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Test My Download Speed' , 'none' , 'speedtest_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=darkcyan][Noobs][/COLOR] Backup/Restore My Content' , 'none' , 'backup_restore' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Nerds][/COLOR] Advanced Options' , '' , 'advanced_tools' , '' , '' , '' , '' )
 if I1IiiiIiI ( ) :
  oO00oOOoooO ( '' , '[COLOR=dodgerblue]Wi-Fi / OpenELEC Settings[/COLOR]' , '' , 'openelec_settings' , '' , '' , '' , '' )
  if 70 - 70: iIii1I11I1II1 / iI1IiiIIIiIi
  if 61 - 61: O0 * oOO00Oo + Iiii1i1 - iiIi1i11 . o0Oo - i11111IIIII
def i1I1I1iiI ( ) :
 oO00oOOoooO ( '' , 'Check For Special Characters In Filenames' , '' , 'ASCII_Check' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Check My IP Address' , 'none' , 'ipcheck' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Check XBMC/Kodi Version' , 'none' , 'xbmcversion' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear All Cache Folders' , 'url' , 'clear_cache' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear Cached Artwork (thumbnails & textures)' , 'none' , 'remove_textures' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Clear Packages Folder' , 'url' , 'remove_packages' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Completely remove an add-on (inc. passwords)' , 'plugin' , 'addon_removal_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Convert Physical Paths To Special' , oOOoO0 , 'fix_special' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Addon_Data' , 'url' , 'remove_addon_data' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Old Builds/Zips From Device' , 'url' , 'remove_build' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Delete Old Crash Logs' , 'url' , 'remove_crash_logs' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Force Close Kodi' , 'url' , 'kill_xbmc' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Make Add-ons Gotham/Helix Compatible' , 'none' , 'gotham' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Make Skins Kodi (Helix) Compatible' , 'none' , 'helix' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Passwords - Hide when typing in' , 'none' , 'hide_passwords' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Passwords - Unhide when typing in' , 'none' , 'unhide_passwords' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Update My Add-ons (Force Refresh)' , 'none' , 'update' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Upload Log' , 'none' , 'uploadlog' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'View My Log' , 'none' , 'log' , '' , '' , '' , '' )
 oO00oOOoooO ( '' , 'Wipe My Install (Fresh Start)' , 'none' , 'wipe_xbmc' , '' , '' , '' , '' )
 if 74 - 74: III1IiiI + iI1IiiIIIiIi + OoooooooOO . O0 . oOO00Oo . o0oOo0
 if 5 - 5: OoooO0Oo0O0 * o00O0OoO % Iiii1i1 . O0 * i11111IIIII
def o00OOOOoOO ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Add-on Maintenance[/COLOR]' , str ( url ) + '&type=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Audio Add-ons' , str ( url ) + '&type=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Picture Add-ons' , str ( url ) + '&type=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Program Add-ons' , str ( url ) + '&type=Programs' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , 'Video Add-ons' , str ( url ) + '&type=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 if 74 - 74: iIii1I11I1II1 . Iiii1i1 / o00O0OoO * OoooO0Oo0O0 / i11iIiiIii / i11111IIIII
 if 15 - 15: OoooooooOO
def O0O00 ( url ) :
 OO00OOoO0o = 'http://noobsandnerds.com/TI/TutorialPortal/downloadcount.php?id=%s' % ( url )
 try :
  i1II1 ( OO00OOoO0o , 5 )
 except :
  pass
 I1II1I11I1I = 'http://noobsandnerds.com/TI/TutorialPortal/tutorialdetails.php?id=%s' % ( url )
 OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oo00oO0o = re . compile ( 'name="(.+?)"' ) . findall ( OoOO0o )
 iIiII = re . compile ( 'author="(.+?)"' ) . findall ( OoOO0o )
 OoOOOOOoOo0 = re . compile ( 'video_guide1="(.+?)"' ) . findall ( OoOO0o )
 iIi = re . compile ( 'video_guide2="(.+?)"' ) . findall ( OoOO0o )
 oOo = re . compile ( 'video_guide3="(.+?)"' ) . findall ( OoOO0o )
 ooOo0o = re . compile ( 'video_guide4="(.+?)"' ) . findall ( OoOO0o )
 III = re . compile ( 'video_guide5="(.+?)"' ) . findall ( OoOO0o )
 IiiI = re . compile ( 'video_label1="(.+?)"' ) . findall ( OoOO0o )
 OoOoO00o00 = re . compile ( 'video_label2="(.+?)"' ) . findall ( OoOO0o )
 OOooooO0o0O0 = re . compile ( 'video_label3="(.+?)"' ) . findall ( OoOO0o )
 oO0ooo00o0o000Oo = re . compile ( 'video_label4="(.+?)"' ) . findall ( OoOO0o )
 Oooo00OOo = re . compile ( 'video_label5="(.+?)"' ) . findall ( OoOO0o )
 oo0oO0oO = re . compile ( 'about="(.+?)"' ) . findall ( OoOO0o )
 Ooooo0OO = re . compile ( 'step1="(.+?)"' ) . findall ( OoOO0o )
 o0o0OO0OO = re . compile ( 'step2="(.+?)"' ) . findall ( OoOO0o )
 Iiii1I1iI = re . compile ( 'step3="(.+?)"' ) . findall ( OoOO0o )
 iIi1iII1iii1 = re . compile ( 'step4="(.+?)"' ) . findall ( OoOO0o )
 Ooo0 = re . compile ( 'step5="(.+?)"' ) . findall ( OoOO0o )
 oO0oO00 = re . compile ( 'step6="(.+?)"' ) . findall ( OoOO0o )
 OOiIIiiiI1 = re . compile ( 'step7="(.+?)"' ) . findall ( OoOO0o )
 i11i1i1i = re . compile ( 'step8="(.+?)"' ) . findall ( OoOO0o )
 OoO00O = re . compile ( 'step9="(.+?)"' ) . findall ( OoOO0o )
 O0oo0ooO = re . compile ( 'step10="(.+?)"' ) . findall ( OoOO0o )
 ii1i1 = re . compile ( 'step11="(.+?)"' ) . findall ( OoOO0o )
 IIII1I11Ii11 = re . compile ( 'step12="(.+?)"' ) . findall ( OoOO0o )
 ooooO0O = re . compile ( 'step13="(.+?)"' ) . findall ( OoOO0o )
 iiiiOo000O00o0O = re . compile ( 'step14="(.+?)"' ) . findall ( OoOO0o )
 o0o0oo0oO = re . compile ( 'step15="(.+?)"' ) . findall ( OoOO0o )
 oo0IiIIiIi11ii = re . compile ( 'screenshot1="(.+?)"' ) . findall ( OoOO0o )
 II11IiIIiiiii = re . compile ( 'screenshot2="(.+?)"' ) . findall ( OoOO0o )
 oooOOo0o0OOO = re . compile ( 'screenshot3="(.+?)"' ) . findall ( OoOO0o )
 IiiiII = re . compile ( 'screenshot4="(.+?)"' ) . findall ( OoOO0o )
 OoOo00OoOO00 = re . compile ( 'screenshot5="(.+?)"' ) . findall ( OoOO0o )
 oO0oOOoOo000O = re . compile ( 'screenshot6="(.+?)"' ) . findall ( OoOO0o )
 II1o0O0OO = re . compile ( 'screenshot7="(.+?)"' ) . findall ( OoOO0o )
 oOoO0o = re . compile ( 'screenshot8="(.+?)"' ) . findall ( OoOO0o )
 i1II = re . compile ( 'screenshot9="(.+?)"' ) . findall ( OoOO0o )
 OOOoooOo00O = re . compile ( 'screenshot10="(.+?)"' ) . findall ( OoOO0o )
 iiIIiI1I = re . compile ( 'screenshot11="(.+?)"' ) . findall ( OoOO0o )
 oOoO0oOO0o = re . compile ( 'screenshot12="(.+?)"' ) . findall ( OoOO0o )
 oO0000oo0o0o0 = re . compile ( 'screenshot13="(.+?)"' ) . findall ( OoOO0o )
 i1I1 = re . compile ( 'screenshot14="(.+?)"' ) . findall ( OoOO0o )
 Ii1iii1 = re . compile ( 'screenshot15="(.+?)"' ) . findall ( OoOO0o )
 if 75 - 75: II11iIiIIIiI / i11iIiiIii * o0Oo - OoooooooOO
 i1iIIIi1i = oo00oO0o [ 0 ] if ( len ( oo00oO0o ) > 0 ) else ''
 O0oIi1iIiIi1I11 = iIiII [ 0 ] if ( len ( iIiII ) > 0 ) else ''
 OooOo00o = OoOOOOOoOo0 [ 0 ] if ( len ( OoOOOOOoOo0 ) > 0 ) else 'None'
 IiI11i1IIiiI = iIi [ 0 ] if ( len ( iIi ) > 0 ) else 'None'
 oOOo000oOoO0 = oOo [ 0 ] if ( len ( oOo ) > 0 ) else 'None'
 OoOo00o0OO = ooOo0o [ 0 ] if ( len ( ooOo0o ) > 0 ) else 'None'
 ii1IIIIiI11 = III [ 0 ] if ( len ( III ) > 0 ) else 'None'
 I1iii = IiiI [ 0 ] if ( len ( IiiI ) > 0 ) else 'None'
 oO0o0O0Ooo0o = OoOoO00o00 [ 0 ] if ( len ( OoOoO00o00 ) > 0 ) else 'None'
 i1Ii11II = OOooooO0o0O0 [ 0 ] if ( len ( OOooooO0o0O0 ) > 0 ) else 'None'
 IioO0oOOO0Ooo = oO0ooo00o0o000Oo [ 0 ] if ( len ( oO0ooo00o0o000Oo ) > 0 ) else 'None'
 i1i1I = Oooo00OOo [ 0 ] if ( len ( Oooo00OOo ) > 0 ) else 'None'
 iIIIi11iIiIii = oo0oO0oO [ 0 ] if ( len ( oo0oO0oO ) > 0 ) else ''
 I11I = '[CR][CR][COLOR=dodgerblue]Step 1:[/COLOR][CR]' + Ooooo0OO [ 0 ] if ( len ( Ooooo0OO ) > 0 ) else ''
 ii11iIII111 = '[CR][CR][COLOR=dodgerblue]Step 2:[/COLOR][CR]' + o0o0OO0OO [ 0 ] if ( len ( o0o0OO0OO ) > 0 ) else ''
 o00O000o = '[CR][CR][COLOR=dodgerblue]Step 3:[/COLOR][CR]' + Iiii1I1iI [ 0 ] if ( len ( Iiii1I1iI ) > 0 ) else ''
 oOO00000oO = '[CR][CR][COLOR=dodgerblue]Step 4:[/COLOR][CR]' + iIi1iII1iii1 [ 0 ] if ( len ( iIi1iII1iii1 ) > 0 ) else ''
 Ii1iI1iiIiII1 = '[CR][CR][COLOR=dodgerblue]Step 5:[/COLOR][CR]' + Ooo0 [ 0 ] if ( len ( Ooo0 ) > 0 ) else ''
 i1iI111i1I = '[CR][CR][COLOR=dodgerblue]Step 6:[/COLOR][CR]' + oO0oO00 [ 0 ] if ( len ( oO0oO00 ) > 0 ) else ''
 IIIIi1I = '[CR][CR][COLOR=dodgerblue]Step 7:[/COLOR][CR]' + OOiIIiiiI1 [ 0 ] if ( len ( OOiIIiiiI1 ) > 0 ) else ''
 I1III = '[CR][CR][COLOR=dodgerblue]Step 8:[/COLOR][CR]' + i11i1i1i [ 0 ] if ( len ( i11i1i1i ) > 0 ) else ''
 ii1I1IIi = '[CR][CR][COLOR=dodgerblue]Step 9:[/COLOR][CR]' + OoO00O [ 0 ] if ( len ( OoO00O ) > 0 ) else ''
 o00oOO0OOo = '[CR][CR][COLOR=dodgerblue]Step 10:[/COLOR][CR]' + O0oo0ooO [ 0 ] if ( len ( O0oo0ooO ) > 0 ) else ''
 OooOooO0OoOoo0o = '[CR][CR][COLOR=dodgerblue]Step 11:[/COLOR][CR]' + ii1i1 [ 0 ] if ( len ( ii1i1 ) > 0 ) else ''
 iII1iIIIIII = '[CR][CR][COLOR=dodgerblue]Step 12:[/COLOR][CR]' + IIII1I11Ii11 [ 0 ] if ( len ( IIII1I11Ii11 ) > 0 ) else ''
 IIIIII11iIiI1III = '[CR][CR][COLOR=dodgerblue]Step 13:[/COLOR][CR]' + ooooO0O [ 0 ] if ( len ( ooooO0O ) > 0 ) else ''
 o0Ooo0 = '[CR][CR][COLOR=dodgerblue]Step 14:[/COLOR][CR]' + iiiiOo000O00o0O [ 0 ] if ( len ( iiiiOo000O00o0O ) > 0 ) else ''
 I1ii11iiIIi = '[CR][CR][COLOR=dodgerblue]Step 15:[/COLOR][CR]' + o0o0oo0oO [ 0 ] if ( len ( o0o0oo0oO ) > 0 ) else ''
 oOOo0OOOOo0o = oo0IiIIiIi11ii [ 0 ] if ( len ( oo0IiIIiIi11ii ) > 0 ) else ''
 I1i1iiii = II11IiIIiiiii [ 0 ] if ( len ( II11IiIIiiiii ) > 0 ) else ''
 O00OIIIIIi1 = oooOOo0o0OOO [ 0 ] if ( len ( oooOOo0o0OOO ) > 0 ) else ''
 o0oIi1iiiii = IiiiII [ 0 ] if ( len ( IiiiII ) > 0 ) else ''
 O00o0 = OoOo00OoOO00 [ 0 ] if ( len ( OoOo00OoOO00 ) > 0 ) else ''
 IIiIiIi1II = oO0oOOoOo000O [ 0 ] if ( len ( oO0oOOoOo000O ) > 0 ) else ''
 oO00 = II1o0O0OO [ 0 ] if ( len ( II1o0O0OO ) > 0 ) else ''
 IiiIIiii = oOoO0o [ 0 ] if ( len ( oOoO0o ) > 0 ) else ''
 iIIIii111 = i1II [ 0 ] if ( len ( i1II ) > 0 ) else ''
 I1111IiII1 = OOOoooOo00O [ 0 ] if ( len ( OOOoooOo00O ) > 0 ) else ''
 IiiII = iiIIiI1I [ 0 ] if ( len ( iiIIiI1I ) > 0 ) else ''
 OO00OO0 = oOoO0oOO0o [ 0 ] if ( len ( oOoO0oOO0o ) > 0 ) else ''
 Ooii = oO0000oo0o0o0 [ 0 ] if ( len ( oO0000oo0o0o0 ) > 0 ) else ''
 i11iII1 = i1I1 [ 0 ] if ( len ( i1I1 ) > 0 ) else ''
 ooOoO0o0OoOo = Ii1iii1 [ 0 ] if ( len ( Ii1iii1 ) > 0 ) else ''
 O0oii111 = str ( '[COLOR=orange]Author: [/COLOR]' + O0oIi1iIiIi1I11 + '[CR][CR][COLOR=lime]About: [/COLOR]' + iIIIi11iIiIii + I11I + ii11iIII111 + o00O000o + oOO00000oO + Ii1iI1iiIiII1 + i1iI111i1I + IIIIi1I + I1III + ii1I1IIi + o00oOO0OOo + OooOooO0OoOoo0o + iII1iIIIIII + IIIIII11iIiI1III + o0Ooo0 + I1ii11iiIIi )
 if 49 - 49: i1IIi - O00OOOoOoo0O - o00O0OoO * o0Oo . o0oOo0
 if I11I != '' :
  oO00oOOoooO ( '' , '[COLOR=yellow][Text Guide][/COLOR]  ' + i1iIIIi1i , O0oii111 , 'text_guide' , '' , Oo00OOOOO , iIIIi11iIiIii , '' )
 if OooOo00o != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + I1iii , OooOo00o , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if IiI11i1IIiiI != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + oO0o0O0Ooo0o , IiI11i1IIiiI , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if oOOo000oOoO0 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1Ii11II , oOOo000oOoO0 , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if OoOo00o0OO != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + IioO0oOOO0Ooo , OoOo00o0OO , 'play_video' , '' , Oo00OOOOO , '' , '' )
 if ii1IIIIiI11 != 'None' :
  oO00oOOoooO ( '' , '[COLOR=lime][VIDEO][/COLOR]  ' + i1i1I , ii1IIIIiI11 , 'play_video' , '' , Oo00OOOOO , '' , '' )
  if 24 - 24: o0oOo0
  if 79 - 79: i1IIi . o00O0OoO % ii1ii11IIIiiI % i11111IIIII - III1IiiI - i11iIiiIii
def oO0oO ( ) :
 if i1IiI1I11 . getSetting ( 'tutorial_manual_search' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=yellow]Manual Search[/COLOR]' , 'tutorials' , 'manual_search' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_all' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]All Guides[/COLOR] Everything in one place' , '' , 'grab_tutorials' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_kodi' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]XBMC / Kodi[/COLOR] Specific' , '' , 'xbmc_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_xbmc4xbox' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=lime]XBMC4Xbox[/COLOR] Specific' , '&platform=XBMC4Xbox' , 'xbmc_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_android' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Android' , '&platform=Android' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_atv' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Apple TV' , '&platform=ATV' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_ios' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] ATV2 & iOS' , '&platform=iOS' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_linux' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Linux' , '&platform=Linux' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_pure_linux' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Pure Linux' , '&platform=Custom_Linux' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_openelec' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OpenELEC' , '&platform=OpenELEC' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_osmc' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSMC' , '&platform=OSMC' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_osx' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] OSX' , '&platform=OSX' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_raspbmc' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Raspbmc' , '&platform=Raspbmc' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_windows' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=orange][Platform][/COLOR] Windows' , '&platform=Windows' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_allwinner' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Allwinner Devices' , '&hardware=Allwinner' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_aftv' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Amazon Fire TV' , '&hardware=AFTV' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_amlogic' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] AMLogic Devices' , '&hardware=AMLogic' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_boxee' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Boxee' , '&hardware=Boxee' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_intel' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Intel Devices' , '&hardware=Intel' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_rpi' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Raspberry Pi' , '&hardware=RaspberryPi' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_rockchip' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Rockchip Devices' , '&hardware=Rockchip' , 'platform_menu' , '' , '' , '' , '' )
 if i1IiI1I11 . getSetting ( 'tutorial_xbox' ) == 'true' :
  oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][Hardware][/COLOR] Xbox' , '&hardware=Xbox' , 'platform_menu' , '' , '' , '' , '' )
  if 55 - 55: ii1ii11IIIiiI * oOO00Oo - o00O0OoO + iIii1I11I1II1 . ii1ii11IIIiiI + III1IiiI
  if 4 - 4: iI1IiiIIIiIi
def Ii1IIiII11Iiii1i1II ( ) :
 OOooO0OOoo = xbmcgui . Dialog ( )
 if OOooO0OOoo . yesno ( "Make Add-on Passwords Visible?" , "This will make all your add-on passwords visible in the add-on settings. Are you sure you wish to continue?" ) :
  for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( OO0o ) :
   for iiI1iii in I1iiIi111I :
    if iiI1iii == 'settings.xml' :
     III1I1I1iiIi = open ( os . path . join ( oO0000O0Oo00O , iiI1iii ) ) . read ( )
     I11iIiII = re . compile ( '<setting id=(.+?)>' ) . findall ( III1I1I1iiIi )
     for iIi1i1I1I in I11iIiII :
      if 'pass' in iIi1i1I1I :
       if 'option="hidden"' in iIi1i1I1I :
        try :
         i11iiiI = iIi1i1I1I . replace ( ' option="hidden"' , '' )
         iiI1iii = open ( os . path . join ( oO0000O0Oo00O , iiI1iii ) , mode = 'w' )
         iiI1iii . write ( str ( III1I1I1iiIi ) . replace ( iIi1i1I1I , i11iiiI ) )
         iiI1iii . close ( )
        except :
         pass
  OOooO0OOoo . ok ( "Passwords Are now visible" , "Your passwords will now be visible in your add-on settings. If you want to undo this please use the option to hide passwords." )
  if 48 - 48: OoooooooOO + Iiii1i1
  if 19 - 19: i1IIi / iiIi1i11 - i11iIiiIii + O00OOOoOoo0O
def i1iIIii1 ( name , url , video , description , skins , guisettingslink , artpack ) :
 iIii1 . create ( "Backing Up Important Data" , 'Please wait...' , '' , '' )
 if 24 - 24: i1Iii1i1I . o0oOo0
 if 29 - 29: OoooooooOO / i11111IIIII % o00O0OoO . iiIi1i11 + Iiii1i1
 oO0OOOo0OO = open ( I1IIiiIiii , mode = 'r' )
 i1IiI = oO0OOOo0OO . read ( )
 oO0OOOo0OO . close ( )
 if 31 - 31: o00O0OoO + ii1ii11IIIiiI / o0Oo * O0 + O0
 iiiiIiI1IIiI = re . compile ( 'gui="(.+?)"' ) . findall ( i1IiI )
 Oo0OOo0Ooo = iiiiIiI1IIiI [ 0 ] if ( len ( iiiiIiI1IIiI ) > 0 ) else '0'
 if 91 - 91: O00OOOoOoo0O + oOO00Oo
 if 23 - 23: i1IIi
 if o0OOO == 'true' :
  try :
   IiI11IiIIi = open ( IIIII , mode = 'r' )
   oOOo0OoooOo = IiI11IiIIi . read ( )
   IiI11IiIIi . close ( )
   if 33 - 33: o00O0OoO * i1Iii1i1I + iIii1I11I1II1 - OoooO0Oo0O0
  except :
   print "### No favourites file to copy"
   if 11 - 11: oO0OooOoO + O00OOOoOoo0O * o00O0OoO
 if iIiiiI == 'true' :
  try :
   i1I = open ( ooooooO0oo , mode = 'r' )
   iIII = i1I . read ( )
   i1I . close ( )
   if 89 - 89: o0oOo0 + III1IiiI + iI1IiiIIIiIi - iiIi1i11
  except :
   print "### No sources file to copy"
   if 12 - 12: O00OOOoOoo0O - oOO00Oo - Iiii1i1 / o00O0OoO
 o0OOoo = 1
 oOiI111I1III ( )
 if 17 - 17: ii1ii11IIIiiI - Iiii1i1 - oO0OooOoO / Iiii1i1 / iI1IiiIIIiIi
 if 30 - 30: iiIi1i11 * OoooO0Oo0O0 % OoooO0Oo0O0 + i1Iii1i1I * i11111IIIII
 if os . path . exists ( Oo0OoO00oOO0o ) :
  if 33 - 33: oOO00Oo + o00O0OoO * O0 * ii1ii11IIIiiI . OoooO0Oo0O0
  if os . path . exists ( I11i1 ) :
   os . remove ( Oo0OoO00oOO0o )
   if 74 - 74: i1Iii1i1I * i1Iii1i1I * oOO00Oo / III1IiiI
  else :
   os . rename ( Oo0OoO00oOO0o , I11i1 )
   if 91 - 91: i11iIiiIii . OoooO0Oo0O0 / oO0OooOoO
 if os . path . exists ( iIi1ii1I1 ) :
  os . remove ( iIi1ii1I1 )
  if 97 - 97: iI1IiiIIIiIi % i1IIi % i11111IIIII + II11iIiIIIiI - O0 - o00O0OoO
  if 64 - 64: iI1IiiIIIiIi - i1Iii1i1I
 if not os . path . exists ( I11iii1Ii ) :
  IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'w+' )
  IiI1i111IiIiIi1 . close ( )
  if 12 - 12: i1IIi
 iIii1 . close ( )
 iIii1 . create ( "Downloading Skin Fix" , "Downloading guisettings.xml" , '' , 'Please Wait' )
 oOOOOOoOOoo0 = os . path . join ( OOO00 , 'guifix.zip' )
 if 99 - 99: oO0OooOoO - OoooO0Oo0O0 * i11111IIIII
 if 3 - 3: i11111IIIII - OoooO0Oo0O0 * i1Iii1i1I * OoooO0Oo0O0 + II11iIiIIIiI
 try :
  print "### attempting to download guisettings.xml"
  downloader . download ( guisettingslink , oOOOOOoOOoo0 , iIii1 )
  iIii1 . close ( )
 except :
  OOooO0OOoo . ok ( 'Problem Detected' , 'Sorry there was a problem downloading the guisettings file. Please check your storage location, if you\'re certain that\'s ok please notify the build author on the relevant support thread.' )
  print "### FAILED to download " + guisettingslink
  if 15 - 15: OoooO0Oo0O0 * iI1IiiIIIiIi / i1Iii1i1I . oOO00Oo / iI1IiiIIIiIi % O00OOOoOoo0O
 if zipfile . is_zipfile ( oOOOOOoOOoo0 ) :
  I1iI1 = str ( os . path . getsize ( oOOOOOoOOoo0 ) )
  if 75 - 75: OoooooooOO % i11iIiiIii % iIii1I11I1II1 % OoooO0Oo0O0 / i11iIiiIii
 else :
  I1iI1 = Oo0OOo0Ooo
  if 96 - 96: o0oOo0 * III1IiiI / iIii1I11I1II1 / o00O0OoO
  if 5 - 5: oOO00Oo
 IiI1i111IiIiIi1 = open ( I11iii1Ii , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 if 83 - 83: o00O0OoO * o0Oo . oO0OooOoO * i1IIi % O0
 OO0oOo = re . compile ( 'id="(.+?)"' ) . findall ( o0oO0OoO0 )
 IIiIi1II1IiI = re . compile ( 'name="(.+?)"' ) . findall ( o0oO0OoO0 )
 oo0OoO = re . compile ( 'version="(.+?)"' ) . findall ( o0oO0OoO0 )
 if 35 - 35: O00OOOoOoo0O % ii1ii11IIIiiI + O0 * oOO00Oo % OoooO0Oo0O0
 I11iIiiI = OO0oOo [ 0 ] if ( len ( OO0oOo ) > 0 ) else ''
 OO000oo0o = IIiIi1II1IiI [ 0 ] if ( len ( IIiIi1II1IiI ) > 0 ) else ''
 ooO0o0oo = oo0OoO [ 0 ] if ( len ( oo0OoO ) > 0 ) else ''
 if 57 - 57: III1IiiI / o00O0OoO
 if os . path . exists ( OOO00O ) :
  os . removedirs ( OOO00O )
  if 63 - 63: o0oOo0 * ii1ii11IIIiiI * o0oOo0 + O00OOOoOoo0O
  if 25 - 25: i1Iii1i1I * O00OOOoOoo0O / o0Oo / i11111IIIII
 if Oo0OOo0Ooo != I1iI1 :
  try :
   os . rename ( I11i1 , Oo0OoO00oOO0o )
   if 11 - 11: iiIi1i11 + i11iIiiIii
  except :
   OOooO0OOoo . ok ( "NO GUISETTINGS!" , 'No guisettings.xml file has been found.' , 'Please exit Kodi and try again' , '' )
   return
   if 14 - 14: O00OOOoOoo0O / i11111IIIII + ii1ii11IIIiiI - iI1IiiIIIiIi
   if 38 - 38: Iiii1i1
 if video != 'fresh' :
  oo0O0oo = xbmcgui . Dialog ( ) . yesno ( name , 'We highly recommend backing up your existing build before installing any community builds. Would you like to perform a backup first?' , nolabel = 'Backup' , yeslabel = 'Install' )
  if 30 - 30: oO0OooOoO + o00O0OoO . i11iIiiIii + iIii1I11I1II1
  if oo0O0oo == 0 :
   oOoOo00o00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
   if 100 - 100: III1IiiI * oOO00Oo / i1Iii1i1I
   if not os . path . exists ( oOoOo00o00 ) :
    os . makedirs ( oOoOo00o00 )
    if 92 - 92: o0oOo0 / i11iIiiIii * iiIi1i11
   o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
   if 55 - 55: o0oOo0
   if ( not o0OoOoooo0 ) :
    return False , 0
    if 1 - 1: ii1ii11IIIiiI
   o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
   ooO0 = xbmc . translatePath ( os . path . join ( oOoOo00o00 , o0OOoOo0oo + '.zip' ) )
   o0Iiii = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
   I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , 'Thumbs.db' , '.gitignore' ]
   o0OO0OOO0O = "Creating full backup of existing build"
   Iii1I = "Archiving..."
   oOoOOOOoOO0o = ""
   iiI1i1I1II = "Please Wait"
   OooOOOO0O0 ( oOOoO0 , ooO0 , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
   if 43 - 43: iIii1I11I1II1 - iiIi1i11 - oOO00Oo + OoooO0Oo0O0 - Iiii1i1 % OoooO0Oo0O0
 I1iI1I1 = open ( I1IIiiIiii , mode = 'w+' )
 if 58 - 58: O00OOOoOoo0O
 if Oo0OOo0Ooo != I1iI1 :
  I1iI1I1 . write ( 'id="' + str ( I11iIiiI ) + '"\nname="' + OO000oo0o + ' [COLOR=yellow](Partially installed)[/COLOR]"\nversion="' + ooO0o0oo + '"\ngui="' + I1iI1 + '"' )
  if 27 - 27: i11111IIIII * iiIi1i11 - OoooooooOO . iI1IiiIIIiIi - oO0OooOoO
 else :
  I1iI1I1 . write ( 'id="' + str ( I11iIiiI ) + '"\nname="' + OO000oo0o + '"\nversion="' + ooO0o0oo + '"\ngui="' + I1iI1 + '"' )
 I1iI1I1 . close ( )
 if 62 - 62: o0Oo / iIii1I11I1II1 * o00O0OoO
 if 84 - 84: i11111IIIII - O00OOOoOoo0O . i11111IIIII + o0oOo0 . i1Iii1i1I
 if video == 'libprofile' or video == 'library' or video == 'updatelibprofile' or video == 'updatelibrary' :
  try :
   shutil . copytree ( OooO0 , O0o0O00Oo0o0 , symlinks = False , ignore = shutil . ignore_patterns ( "Textures13.db" , "Addons16.db" , "Addons15.db" , "saltscache.db-wal" , "saltscache.db-shm" , "saltscache.db" , "onechannelcache.db" ) )
   if 96 - 96: iI1IiiIIIiIi % i1Iii1i1I * iI1IiiIIIiIi % o0Oo . oOO00Oo / oOO00Oo
  except :
   o0OOoo = xbmcgui . Dialog ( ) . yesno ( name , 'There was an error trying to backup some databases. Continuing may wipe your existing library. Do you wish to continue?' , nolabel = 'No, cancel' , yeslabel = 'Yes, overwrite' )
   if 7 - 7: ii1ii11IIIiiI - o0oOo0 % i1IIi
   if o0OOoo == 0 :
    return
    if 24 - 24: ii1ii11IIIiiI % O0 % o00O0OoO
  ooO0 = xbmc . translatePath ( os . path . join ( OOO00 , 'Database.zip' ) )
  Ii1ii11IIIi ( O0o0O00Oo0o0 , ooO0 )
  if 61 - 61: o0oOo0 . i1Iii1i1I / o0oOo0 * OoooooooOO
 if o0OOoo == 0 :
  return
  if 13 - 13: oO0OooOoO
 time . sleep ( 1 )
 if 17 - 17: oO0OooOoO
 if 66 - 66: i11111IIIII * III1IiiI
 oo0oo00 = xbmc . translatePath ( os . path . join ( oOOoO0 , '..' , 'koditemp.zip' ) )
 time . sleep ( 2 )
 iIii1 . create ( "Community Builds" , "Downloading " + description + " build." , '' , 'Please Wait' )
 O000OOOoOooO = description . replace ( ' ' , '_' ) . replace ( ':' , '-' ) . replace ( "'" , '' )
 oOOOOOoOOoo0 = os . path . join ( iiiiiIIii , O000OOOoOooO + '.zip' )
 if 84 - 84: OoooooooOO - II11iIiIIIiI
 if not os . path . exists ( iiiiiIIii ) :
  os . makedirs ( iiiiiIIii )
  if 79 - 79: O0 - III1IiiI + III1IiiI . iI1IiiIIIiIi . O00OOOoOoo0O - OoooO0Oo0O0
 downloader . download ( url , oOOOOOoOOoo0 , iIii1 )
 if 74 - 74: o0oOo0 % OoooO0Oo0O0 * i1IIi
 if 18 - 18: O00OOOoOoo0O
 try :
  ii1Ii = open ( I1IIIii , mode = 'r' )
  iiiII1iIiI1 = ii1Ii . read ( )
  ii1Ii . close ( )
 except :
  print "### No profiles detected, most likely a fresh wipe performed"
  if 17 - 17: i11iIiiIii . iI1IiiIIIiIi - i11111IIIII / iIii1I11I1II1 + OoooooooOO - o0oOo0
 iIii1 . close ( )
 iIii1 . create ( "Community Builds" , "Checking " , '' , 'Please Wait' )
 if 59 - 59: O00OOOoOoo0O
 if 61 - 61: O0
 if zipfile . is_zipfile ( oOOOOOoOOoo0 ) :
  iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
  extract . all ( oOOOOOoOOoo0 , oOOoO0 , iIii1 )
  if 25 - 25: o0oOo0 % O00OOOoOoo0O . III1IiiI
 else :
  OOooO0OOoo . ok ( 'Not a valid zip file' , 'This file is not a valid zip file, please let the build author know on their support thread so they can amend the download path. It\'s most likely just a simple typo on their behalf.' )
  return
  if 9 - 9: O00OOOoOoo0O . iIii1I11I1II1 . II11iIiIIIiI - oOO00Oo . i11111IIIII
 iIii1 . create ( "Restoring Dependencies" , "Checking " , '' , 'Please Wait' )
 iIii1 . update ( 0 , "" , "Extracting Zip Please Wait" )
 if 66 - 66: i11iIiiIii / o0Oo % Iiii1i1
 if o0OOO == 'true' :
  try :
   print "### Attempting to add back favourites ###"
   I1iI1I1 = open ( IIIII , mode = 'w+' )
   I1iI1I1 . write ( oOOo0OoooOo )
   I1iI1I1 . close ( )
   iIii1 . update ( 0 , "" , "Copying Favourites" )
  except :
   print "### Failed to copy back favourites"
   if 78 - 78: o0oOo0 % OoooooooOO . o0oOo0 % i11iIiiIii + oO0OooOoO
 if iIiiiI == 'true' :
  try :
   print "### Attempting to add back sources ###"
   I1iI1I1 = open ( ooooooO0oo , mode = 'w+' )
   I1iI1I1 . write ( iIII )
   I1iI1I1 . close ( )
   iIii1 . update ( 0 , "" , "Copying Sources" )
   if 25 - 25: o0oOo0
  except :
   print "### Failed to copy back sources"
   if 83 - 83: iI1IiiIIIiIi / OoooooooOO * III1IiiI . o0Oo . i1IIi
 time . sleep ( 1 )
 if os . path . exists ( O0o0O00Oo0o0 ) :
  shutil . rmtree ( O0o0O00Oo0o0 )
  if 59 - 59: o00O0OoO . o00O0OoO * o0Oo - iI1IiiIIIiIi % O00OOOoOoo0O
  if 19 - 19: OoooooooOO / II11iIiIIIiI - Iiii1i1 . O00OOOoOoo0O
 if os . path . exists ( O000OO0 ) :
  IiI1i111IiIiIi1 = open ( O000OO0 , mode = 'r' )
  o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
  IiI1i111IiIiIi1 . close ( )
  O0O0O = re . compile ( 'version="[\s\S]*?"' ) . findall ( o0oO0OoO0 )
  I1I1IiI1 = O0O0O [ 0 ] if ( len ( O0O0O ) > 0 ) else ''
  II1i11i1iIi11 = o0oO0OoO0 . replace ( I1I1IiI1 , 'version="' + ooO0o0oo + '"' )
  I1iI1I1 = open ( O000OO0 , mode = 'w' )
  I1iI1I1 . write ( str ( II1i11i1iIi11 ) )
  I1iI1I1 . close ( )
  if 8 - 8: o00O0OoO % o0oOo0 . iIii1I11I1II1
 else :
  I1iI1I1 = open ( O000OO0 , mode = 'w+' )
  I1iI1I1 . write ( 'date="01011001"\nversion="' + ooO0o0oo + '"' )
  I1iI1I1 . close ( )
  if 95 - 95: oOO00Oo + i11iIiiIii . OoooO0Oo0O0 . o0oOo0 . oOO00Oo
  if 93 - 93: i1Iii1i1I
 if IIiIiII11i == 'false' :
  os . remove ( oOOOOOoOOoo0 )
  if 55 - 55: oO0OooOoO % oOO00Oo - ii1ii11IIIiiI
  if 48 - 48: o0oOo0 * iIii1I11I1II1 % O00OOOoOoo0O
 if 'prof' in video :
  try :
   OoOo0OO0 = open ( I1IIIii , mode = 'w+' )
   OoOo0OO0 . write ( iiiII1iIiI1 )
   OoOo0OO0 . close ( )
  except :
   print "### Failed to write existing profile info back into profiles.xml"
   if 98 - 98: i11iIiiIii
   if 30 - 30: ii1ii11IIIiiI . ii1ii11IIIiiI . iI1IiiIIIiIi % iI1IiiIIIiIi * i1IIi * III1IiiI
 if video == 'library' or video == 'libprofile' or video == 'updatelibprofile' or video == 'updatelibrary' :
  extract . all ( ooO0 , OooO0 , iIii1 )
  if 74 - 74: OoooooooOO
  if 33 - 33: oOO00Oo - oO0OooOoO
  if o0OOoo != 1 :
   shutil . rmtree ( O0o0O00Oo0o0 )
 try :
  iIii1 . close ( )
 except :
  pass
  if 95 - 95: OoooooooOO
  if 23 - 23: oO0OooOoO + o00O0OoO / O0 . o00O0OoO . Iiii1i1 + iIii1I11I1II1
 if os . path . exists ( i1i ) :
  Oo00O0OO ( description )
  if 2 - 2: i1IIi . O0 / oOO00Oo . oO0OooOoO / ii1ii11IIIiiI % i1IIi
  try :
   os . remove ( i1i )
   if 12 - 12: oOO00Oo
  except :
   print "###' Failed to remove: " + i1i
   if 58 - 58: iIii1I11I1II1 * iI1IiiIIIiIi . o0oOo0 . II11iIiIIIiI * iI1IiiIIIiIi
  try :
   shutil . rmtree ( i1Oo00 )
   if 63 - 63: O00OOOoOoo0O . o00O0OoO * oOO00Oo - o00O0OoO % o00O0OoO
  except :
   print "###' Failed to remove: " + i1Oo00
   if 62 - 62: o00O0OoO - o0oOo0 / o0oOo0
 else :
  print "### Community Builds - using an old build"
  if 95 - 95: O00OOOoOoo0O - i1IIi / Iiii1i1 . o0oOo0 % iiIi1i11 - i1IIi
  if 12 - 12: i1Iii1i1I
 if Oo0OOo0Ooo != I1iI1 :
  print "### GUI SIZE DIFFERENT ATTEMPTING MERGE ###"
  o0oOoO00oo0oOo = os . path . join ( oOOoO0 , 'newbuild' )
  if 24 - 24: o0Oo . III1IiiI * oO0OooOoO
  if not os . path . exists ( o0oOoO00oo0oOo ) :
   os . makedirs ( o0oOoO00oo0oOo )
   if 59 - 59: ii1ii11IIIiiI * O0 . iIii1I11I1II1 . o00O0OoO * i1Iii1i1I
  os . makedirs ( OOO00O )
  time . sleep ( 1 )
  i1iiiI1I ( guisettingslink , video )
  time . sleep ( 1 )
  Oo0iII ( )
  OOooO0OOoo . ok ( "Force Close Required" , "If you\'re seeing this message it means the force close was unsuccessful. Please close XBMC/Kodi via your operating system or pull the power." )
  if 71 - 71: oOO00Oo . iiIi1i11 * OoooO0Oo0O0 - iI1IiiIIIiIi
 if Oo0OOo0Ooo == I1iI1 :
  OOooO0OOoo . ok ( 'Successfully Updated' , 'Congratulations the following build:[COLOR=dodgerblue]' , description , '[/COLOR]has been successfully updated!' )
  if 97 - 97: i11111IIIII
  if 15 - 15: O0 - o0Oo / i1IIi . Iiii1i1
def o0o0o ( ) :
 if i1IiI1I11 . getSetting ( 'email' ) == '' :
  OOooO0OOoo = xbmcgui . Dialog ( )
  OOooO0OOoo . ok ( "No Email Address Set" , "A new window will Now open for you to enter your Email address. The logfile will be sent here" )
  i1IiI1I11 . openSettings ( )
 xbmc . executebuiltin ( 'XBMC.RunScript(special://home/addons/' + o0OO00 + '/uploadLog.py)' )
 if 30 - 30: O0
 if 78 - 78: o0Oo - iiIi1i11 - III1IiiI * o0oOo0 % i11iIiiIii + iiIi1i11
def oOiiiIIIi ( localbuildcheck , localversioncheck , localidcheck ) :
 print "### USER_INFO CHECK"
 if oo00 == 'true' :
  try :
   I1II1I11I1I = 'http://noobsandnerds.com/TI/login/login_details.php?user=%s&pass=%s' % ( O0oo0OO0 , I1i1iiI1 )
   OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
   O0o0 = re . compile ( 'login_msg="(.+?)"' ) . findall ( OoOO0o )
   ooOoOOii1111i11ii = O0o0 [ 0 ] if ( len ( O0o0 ) > 0 ) else ''
  except :
   ooOoOOii1111i11ii = '[COLOR=lime]UNABLE TO VERIFY LOGIN[/COLOR]'
   if 15 - 15: i11111IIIII * i1Iii1i1I / i11iIiiIii
 else :
  ooOoOOii1111i11ii = '[COLOR=lime]REGISTER FOR FREE TO UNLOCK FEATURES[/COLOR]'
  if 63 - 63: O00OOOoOoo0O . o00O0OoO
 print "### WELCOMETEXT: " + ooOoOOii1111i11ii
 if 63 - 63: O00OOOoOoo0O % iIii1I11I1II1
 I1II1I11I1I = 'http://noobsandnerds.com/TI/menu_check'
 try :
  OoOO0o = i1II1 ( I1II1I11I1I , 10 ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  i1iI1i = re . compile ( 'd="(.+?)"' ) . findall ( OoOO0o )
  o0o0OoO0OOO0 = i1iI1i [ 0 ] if ( len ( i1iI1i ) > 0 ) else 'none'
 except :
  o0o0OoO0OOO0 = 'none'
  if 24 - 24: O00OOOoOoo0O + OoooooooOO + iI1IiiIIIiIi * o00O0OoO
 print "### MENU: " + o0o0OoO0OOO0
 if 13 - 13: II11iIiIIIiI * oOO00Oo * i1Iii1i1I
 if 71 - 71: iiIi1i11 + OoooooooOO + iIii1I11I1II1
 if not 'REGISTER FOR FREE' in ooOoOOii1111i11ii and not 'UNABLE TO VERIFY' in ooOoOOii1111i11ii :
  print "### ATTEMPTING TO WRITE COOKIE "
  I1iI1I1 = open ( oo0OooOOo0 , mode = 'w+' )
  I1iI1I1 . write ( 'd="' + binascii . hexlify ( ooOoOO ( ) ) + '"\nl="' + binascii . hexlify ( ooOoOOii1111i11ii ) + '"\nm="' + binascii . hexlify ( o0o0OoO0OOO0 ) + '"' )
  I1iI1I1 . close ( )
  if 99 - 99: ii1ii11IIIiiI - i11111IIIII * i11111IIIII + III1IiiI / i1Iii1i1I + iiIi1i11
 oo000oO ( localbuildcheck , localversioncheck , localidcheck , ooOoOOii1111i11ii , o0o0OoO0OOO0 )
 if 58 - 58: i11iIiiIii + iIii1I11I1II1 * oOO00Oo - O00OOOoOoo0O
 if 31 - 31: i1IIi
def i1i1iI1iiiI ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 xbmcgui . Dialog ( ) . ok ( 'Force Refresh Started Successfully' , 'Depending on the speed of your device it could take a few minutes for the update to take effect.' )
 return
 if 87 - 87: o0Oo / o00O0OoO + OoooooooOO + O0 . iI1IiiIIIiIi
 if 44 - 44: II11iIiIIIiI % II11iIiIIIiI
def oOoo00o0OoOOO ( ) :
 Ii11 = 1
 try :
  i1II1 ( 'http://google.com' , 5 )
 except :
  try :
   i1II1 ( 'http://google.com' , 5 )
  except :
   try :
    i1II1 ( 'http://google.com' , 5 )
   except :
    try :
     i1II1 ( 'http://google.cn' , 5 )
    except :
     try :
      i1II1 ( 'http://google.cn' , 5 )
     except :
      OOooO0OOoo . ok ( "NO INTERNET CONNECTION" , 'It looks like this device isn\'t connected to the internet. Only some of the maintenance options will work until you fix the connectivity problem.' )
      oo000oO ( '' , '' , '' , '[COLOR=orange]NO INTERNET CONNECTION[/COLOR]' )
      Ii11 = 0
 if Ii11 == 1 :
  O0Oo0O0O0o0 ( )
  if 82 - 82: OoooooooOO / o0Oo * oO0OooOoO - OoooooooOO % iIii1I11I1II1 * ii1ii11IIIiiI
  if 32 - 32: i11iIiiIii - O00OOOoOoo0O * o00O0OoO . II11iIiIIIiI * o0oOo0
def O0Oo0O0O0o0 ( ) :
 oOooOOOOo0o = 'None'
 oO0I1I1i1I1I1I1 = '0'
 if 21 - 21: iiIi1i11
 if 11 - 11: III1IiiI % i11iIiiIii * O0
 IiI1i111IiIiIi1 = open ( O000OO0 , mode = 'r' )
 o0oO0OoO0 = IiI1i111IiIiIi1 . read ( )
 IiI1i111IiIiIi1 . close ( )
 if 28 - 28: Iiii1i1 / iIii1I11I1II1 + iiIi1i11 . OoooO0Oo0O0 % iiIi1i11 + ii1ii11IIIiiI
 oO0000O0o = re . compile ( 'date="(.+?)"' ) . findall ( o0oO0OoO0 )
 o0O0oOooo = oO0000O0o [ 0 ] if ( len ( oO0000O0o ) > 0 ) else ''
 O0O0O = re . compile ( 'version="(.+?)"' ) . findall ( o0oO0OoO0 )
 I1I1IiI1 = O0O0O [ 0 ] if ( len ( O0O0O ) > 0 ) else ''
 if 44 - 44: o00O0OoO - i11iIiiIii
 oOoO0Iii1II1ii = open ( I1IIiiIiii , mode = 'r' )
 ooOo00 = oOoO0Iii1II1ii . read ( )
 oOoO0Iii1II1ii . close ( )
 if 93 - 93: i1Iii1i1I % i11iIiiIii - O00OOOoOoo0O . iI1IiiIIIiIi
 i1oo00OoO = re . compile ( 'id="(.+?)"' ) . findall ( ooOo00 )
 Ii1 = re . compile ( 'name="(.+?)"' ) . findall ( ooOo00 )
 oO0I1I1i1I1I1I1 = i1oo00OoO [ 0 ] if ( len ( i1oo00OoO ) > 0 ) else 'None'
 oOooOOOOo0o = Ii1 [ 0 ] if ( len ( Ii1 ) > 0 ) else ''
 if 72 - 72: iIii1I11I1II1 * iiIi1i11 . iIii1I11I1II1
 if 62 - 62: i11111IIIII . i11111IIIII % o0oOo0 - O00OOOoOoo0O / OoooooooOO . o0Oo
 if 23 - 23: i11111IIIII + i11iIiiIii * iI1IiiIIIiIi
 if 55 - 55: II11iIiIIIiI % i11111IIIII + i11iIiiIii - iiIi1i11 - oO0OooOoO
 if 80 - 80: i11111IIIII
 if 97 - 97: i1Iii1i1I
 if 40 - 40: o0oOo0
 if 61 - 61: i1Iii1i1I - iiIi1i11 / i1Iii1i1I . II11iIiIIIiI % ii1ii11IIIiiI
 if 70 - 70: Iiii1i1 * II11iIiIIIiI
 if 75 - 75: o0Oo . i1Iii1i1I % i1Iii1i1I * i11iIiiIii + i1IIi * II11iIiIIIiI
 if 98 - 98: iI1IiiIIIiIi - OoooooooOO * o00O0OoO * III1IiiI % OoooO0Oo0O0 * oO0OooOoO
 if 86 - 86: i11iIiiIii / o00O0OoO * i1Iii1i1I - i1Iii1i1I
 if 32 - 32: II11iIiIIIiI . O0
 if 48 - 48: OoooO0Oo0O0 % oO0OooOoO + o00O0OoO
 if 25 - 25: i11111IIIII * oOO00Oo / o0Oo . i11111IIIII % oO0OooOoO
 if 50 - 50: O00OOOoOoo0O * i1Iii1i1I
 if 59 - 59: o0Oo * o0Oo / o00O0OoO
 if 92 - 92: oOO00Oo
 if 8 - 8: i1Iii1i1I + OoooO0Oo0O0 . iI1IiiIIIiIi
 if 50 - 50: II11iIiIIIiI
 if 16 - 16: iI1IiiIIIiIi - O00OOOoOoo0O % II11iIiIIIiI / iI1IiiIIIiIi . o00O0OoO + o0oOo0
 if 78 - 78: iIii1I11I1II1 + ii1ii11IIIiiI + i11iIiiIii
 if 21 - 21: II11iIiIIIiI + iI1IiiIIIiIi % o0oOo0 + O00OOOoOoo0O % o00O0OoO
 if not os . path . exists ( oo0OooOOo0 ) :
  print "### First login check ###"
  oOiiiIIIi ( oOooOOOOo0o , I1I1IiI1 , oO0I1I1i1I1I1I1 )
  if 22 - 22: i1IIi / OoooooooOO . ii1ii11IIIiiI
  if 83 - 83: o0Oo - OoooooooOO + OoooO0Oo0O0 . iI1IiiIIIiIi / oOO00Oo + o0oOo0
 else :
  try :
   oooOooOO = open ( oo0OooOOo0 , mode = 'r' )
   i1i1IIiIiI11 = oooOooOO . read ( )
   oooOooOO . close ( )
   if 61 - 61: i11iIiiIii % Iiii1i1 / oOO00Oo
   I111 = re . compile ( 'd="(.+?)"' ) . findall ( i1i1IIiIiI11 )
   iIOO00o0O = re . compile ( 'l="(.+?)"' ) . findall ( i1i1IIiIiI11 )
   iIiI = re . compile ( 'm="(.+?)"' ) . findall ( i1i1IIiIiI11 )
   oO0O0oO = I111 [ 0 ] if ( len ( I111 ) > 0 ) else '0'
   if 74 - 74: O00OOOoOoo0O * oO0OooOoO + O0 + o00O0OoO
   if oO0O0oO != '0' :
    oO0O0oO = binascii . unhexlify ( oO0O0oO )
    if 3 - 3: iIii1I11I1II1 - i1IIi / i1Iii1i1I + i1IIi + O0
   ooOoOOii1111i11ii = iIOO00o0O [ 0 ] if ( len ( iIOO00o0O ) > 0 ) else ''
   ooOoOOii1111i11ii = binascii . unhexlify ( ooOoOOii1111i11ii )
   Ii1OOO0oo0o0 = iIiI [ 0 ] if ( len ( iIiI ) > 0 ) else ''
   Ii1OOO0oo0o0 = binascii . unhexlify ( Ii1OOO0oo0o0 )
  except :
   os . remove ( oo0OooOOo0 )
  if int ( oO0O0oO ) + 2000000 > int ( ooOoOO ( ) ) :
   print "### Login successful ###"
   oo000oO ( oOooOOOOo0o , I1I1IiI1 , oO0I1I1i1I1I1I1 , ooOoOOii1111i11ii , Ii1OOO0oo0o0 )
  else :
   print "### Checking login ###"
   oOiiiIIIi ( oOooOOOOo0o , I1I1IiI1 , oO0I1I1i1I1I1I1 )
   if 38 - 38: ii1ii11IIIiiI * OoooO0Oo0O0
   if 4 - 4: ii1ii11IIIiiI . OoooO0Oo0O0
def II1iII1i1i ( ) :
 IiiIOo0o0o0o = os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' ) ) )
 if 55 - 55: i11111IIIII + Iiii1i1 % O0 % ii1ii11IIIiiI * i11111IIIII % iiIi1i11
 oo0o = [
 ( IiiIOo0o0o0o ) ,
 ( iiI1IiI ) ,
 ( os . path . join ( oOOoO0 , 'cache' ) ) ,
 ( os . path . join ( oOOoO0 , 'temp' ) ) ,
 ( os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' ) ) ,
 ( os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' ) ) ,
 ( os . path . join ( iiI1IiI , 'script.module.simple.downloader' ) ) ,
 ( os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' , 'script.module.simple.downloader' ) ) ) ) ,
 ( os . path . join ( iiI1IiI , 'plugin.video.itv' , 'Images' ) ) ,
 ( os . path . join ( xbmc . translatePath ( os . path . join ( 'special://profile' , 'addon_data' , 'plugin.video.itv' , 'Images' ) ) ) ) ]
 if 92 - 92: iIii1I11I1II1 / OoooooooOO % oO0OooOoO
 for Oooo in oo0o :
  if os . path . exists ( Oooo ) and Oooo != iiI1IiI and Oooo != IiiIOo0o0o0o :
   for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Oooo ) :
    IiIIIi1i1I1Ii1IIii = 0
    IiIIIi1i1I1Ii1IIii += len ( I1iiIi111I )
    if IiIIIi1i1I1Ii1IIii > 0 :
     for iiI1iii in I1iiIi111I :
      try :
       os . unlink ( os . path . join ( oO0000O0Oo00O , iiI1iii ) )
      except :
       pass
     for I1III111i in OoOOOO :
      try :
       shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
       print "### Successfully cleared " + str ( IiIIIi1i1I1Ii1IIii ) + " files from " + os . path . join ( Oooo , I1III111i )
      except :
       print "### Failed to wipe cache in: " + os . path . join ( Oooo , I1III111i )
  else :
   for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( Oooo ) :
    for I1III111i in OoOOOO :
     if 'Cache' in I1III111i or 'cache' in I1III111i or 'CACHE' in I1III111i :
      try :
       shutil . rmtree ( os . path . join ( oO0000O0Oo00O , I1III111i ) )
       print "### Successfully wiped " + os . path . join ( Oooo , I1III111i )
      except :
       print "### Failed to wipe cache in: " + os . path . join ( Oooo , I1III111i )
       if 45 - 45: i11iIiiIii * OoooO0Oo0O0 / iI1IiiIIIiIi % O0 / III1IiiI * III1IiiI
       if 99 - 99: i1IIi % III1IiiI
 try :
  Ii1iii11I = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  i1iii1I1I = database . connect ( Ii1iii11I )
  Oo0O0o0Oo0Oo = i1iii1I1I . cursor ( )
  Oo0O0o0Oo0Oo . execute ( "DROP TABLE IF EXISTS rel_list" )
  Oo0O0o0Oo0Oo . execute ( "VACUUM" )
  i1iii1I1I . commit ( )
  Oo0O0o0Oo0Oo . execute ( "DROP TABLE IF EXISTS rel_lib" )
  Oo0O0o0Oo0Oo . execute ( "VACUUM" )
  i1iii1I1I . commit ( )
 except :
  pass
  if 13 - 13: O00OOOoOoo0O * O0 - iIii1I11I1II1 * o0Oo + i11iIiiIii
  if 98 - 98: iIii1I11I1II1 + ii1ii11IIIiiI + o0Oo + OoooooooOO
def O0Oo0oOOoo0000o ( mode ) :
 if zip == '' :
  OOooO0OOoo . ok ( 'Please set your backup location before proceeding' , 'You have not set your backup storage folder.\nPlease update the addon settings and try again.' )
  i1IiI1I11 . openSettings ( sys . argv [ 0 ] )
  ii11Ii1111 = i1IiI1I11 . getSetting ( 'zip' )
  if ii11Ii1111 == '' :
   O0Oo0oOOoo0000o ( mode )
 oOoOo00o00 = xbmc . translatePath ( os . path . join ( OOO00 , 'Community_Builds' , 'My_Builds' ) )
 if not os . path . exists ( oOoOo00o00 ) :
  os . makedirs ( oOoOo00o00 )
 oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "ABSOLUTELY CERTAIN?!!!" , 'Are you absolutely certain you want to wipe?' , '' , 'All addons and settings will be completely wiped!' , yeslabel = 'Yes' , nolabel = 'No' )
 if 89 - 89: oO0OooOoO . OoooO0Oo0O0
 if oo0O0oo == 1 :
  if OOOO0OOoO0O0 != "skin.confluence" :
   OOooO0OOoo . ok ( 'Default Confluence Skin Required' , 'Please switch to the default Confluence skin before performing a wipe.' )
   xbmc . executebuiltin ( "ActivateWindow(appearancesettings,return)" )
   return
  else :
   if 4 - 4: o0Oo * OoooooooOO
   oo0O0oo = xbmcgui . Dialog ( ) . yesno ( "VERY IMPORTANT" , 'This will completely wipe your install.' , 'Would you like to create a backup before proceeding?' , '' , yeslabel = 'No' , nolabel = 'Yes' )
   if oo0O0oo == 0 :
    if not os . path . exists ( oOoOo00o00 ) :
     os . makedirs ( oOoOo00o00 )
    o0OoOoooo0 = OooO0O0Ooo ( heading = "Enter a name for this backup" )
    if ( not o0OoOoooo0 ) : return False , 0
    o0OOoOo0oo = urllib . quote_plus ( o0OoOoooo0 )
    ooO0 = xbmc . translatePath ( os . path . join ( oOoOo00o00 , o0OOoOo0oo + '.zip' ) )
    o0Iiii = [ 'plugin.program.totalinstaller' , 'plugin.program.tbs' ]
    I1i1I = [ "xbmc.log" , "xbmc.old.log" , "kodi.log" , "kodi.old.log" , '.DS_Store' , '.setup_complete' , 'XBMCHelper.conf' , '.gitignore' ]
    o0OO0OOO0O = "Creating full backup of existing build"
    Iii1I = "Archiving..."
    oOoOOOOoOO0o = ""
    iiI1i1I1II = "Please Wait"
    OooOOOO0O0 ( oOOoO0 , ooO0 , o0OO0OOO0O , Iii1I , oOoOOOOoOO0o , iiI1i1I1II , o0Iiii , I1i1I )
   iIi1 ( iiI111I1iIiI )
   OOOOO0OOo ( )
   O0o0oO ( )
   i11iii1II1I1 ( )
   IiIi11iI1IIi ( iiI111I1iIiI )
   if os . path . exists ( O000OO0 ) :
    os . remove ( O000OO0 )
   if os . path . exists ( I11iii1Ii ) :
    os . remove ( I11iii1Ii )
   if os . path . exists ( I1IIiiIiii ) :
    os . remove ( I1IIiiIiii )
  if mode != 'CB' :
   Oo0iII ( )
  try :
   os . remove ( O000OO0 )
  except :
   print "### Failed to remove startup.xml"
  try :
   os . remove ( I1IIiiIiii )
  except :
   print "### Failed to remove id.xml"
 else :
  return
  if 33 - 33: i1IIi * oOO00Oo + OoooO0Oo0O0 - i1IIi % OoooooooOO
  if 78 - 78: i1Iii1i1I . II11iIiIIIiI
def iIi1 ( excludefiles ) :
 iIii1 . create ( "Wiping Existing Content" , '' , 'Please wait...' , '' )
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( oOOoO0 , topdown = True ) :
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in iiI111I1iIiI ]
  for i1iIIIi1i in I1iiIi111I :
   try :
    iIii1 . update ( 0 , "Removing [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    os . unlink ( os . path . join ( oO0000O0Oo00O , i1iIIIi1i ) )
    os . remove ( os . path . join ( oO0000O0Oo00O , i1iIIIi1i ) )
    os . rmdir ( os . path . join ( oO0000O0Oo00O , i1iIIIi1i ) )
   except :
    print "Failed to remove file: " + i1iIIIi1i
    if 17 - 17: oOO00Oo . o00O0OoO + oOO00Oo
    if 65 - 65: i1Iii1i1I
def OOOOO0OOo ( ) :
 O0oO0OO0o = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( O0OoO000O0OO ) if os . path . isdir ( os . path . join ( O0OoO000O0OO , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in O0oO0OO0o :
   try :
    if i1iIIIi1i not in iiI111I1iIiI :
     iIii1 . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( O0OoO000O0OO , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 25 - 25: O00OOOoOoo0O / II11iIiIIIiI / OoooooooOO
  if 91 - 91: i11111IIIII - OoooO0Oo0O0 - Iiii1i1
 for oO0000O0Oo00O , OoOOOO , I1iiIi111I in os . walk ( O0OoO000O0OO , topdown = True ) :
  OoOOOO [ : ] = [ I1III111i for I1III111i in OoOOOO if I1III111i not in iiI111I1iIiI ]
  for i1iIIIi1i in I1iiIi111I :
   try :
    iIii1 . update ( 0 , "Removing [COLOR=yellow]" + i1iIIIi1i + '[/COLOR]' , '' , 'Please wait...' )
    os . unlink ( os . path . join ( oO0000O0Oo00O , i1iIIIi1i ) )
    os . remove ( os . path . join ( oO0000O0Oo00O , i1iIIIi1i ) )
   except :
    print "Failed to remove file: " + i1iIIIi1i
    if 35 - 35: iIii1I11I1II1 . O0 + O00OOOoOoo0O / ii1ii11IIIiiI / i11111IIIII * oO0OooOoO
    if 32 - 32: Iiii1i1 - iIii1I11I1II1 / o00O0OoO * ii1ii11IIIiiI * ii1ii11IIIiiI
def O0o0oO ( ) :
 oo0Oo0oo = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( OO0o ) if os . path . isdir ( os . path . join ( OO0o , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in oo0Oo0oo :
   try :
    if Iii1ii1II11i == 'true' :
     if i1iIIIi1i not in iiI111I1iIiI and not 'repo' in i1iIIIi1i :
      iIii1 . update ( 0 , "Removing Add-on: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
      shutil . rmtree ( os . path . join ( OO0o , i1iIIIi1i ) )
    else :
     if i1iIIIi1i not in iiI111I1iIiI :
      iIii1 . update ( 0 , "Removing Add-on: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
      shutil . rmtree ( os . path . join ( OO0o , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 71 - 71: iiIi1i11
  if 87 - 87: oO0OooOoO / iIii1I11I1II1 % OoooO0Oo0O0
def i11iii1II1I1 ( ) :
 iII1IiI1I11i = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( iiI1IiI ) if os . path . isdir ( os . path . join ( iiI1IiI , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in iII1IiI1I11i :
   try :
    if i1iIIIi1i not in iiI111I1iIiI :
     iIii1 . update ( 0 , "Removing Add-on Data: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( iiI1IiI , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 10 - 10: oO0OooOoO % o0Oo % iI1IiiIIIiIi * OoooO0Oo0O0
  if 74 - 74: oOO00Oo / ii1ii11IIIiiI + i1Iii1i1I - i1IIi / OoooooooOO / OoooO0Oo0O0
def IiIi11iI1IIi ( excludefiles ) :
 oOoO0O = [ i1iIIIi1i for i1iIIIi1i in os . listdir ( oOOoO0 ) if os . path . isdir ( os . path . join ( oOOoO0 , i1iIIIi1i ) ) ]
 try :
  for i1iIIIi1i in oOoO0O :
   try :
    if i1iIIIi1i not in excludefiles :
     iIii1 . update ( 0 , "Cleaning Directory: [COLOR=yellow]" + i1iIIIi1i + ' [/COLOR]' , '' , 'Please wait...' )
     shutil . rmtree ( os . path . join ( oOOoO0 , i1iIIIi1i ) )
   except :
    print "Failed to remove: " + i1iIIIi1i
 except :
  pass
  if 97 - 97: o0Oo * oOO00Oo
  if 79 - 79: i1Iii1i1I - o0oOo0 - ii1ii11IIIiiI / iIii1I11I1II1 % iI1IiiIIIiIi
def IiIiii ( url ) :
 oO00oOOoooO ( 'folder' , '[COLOR=yellow]1. Install[/COLOR]' , str ( url ) + '&tags=Install&XBMC=1' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=lime]2. Settings[/COLOR]' , str ( url ) + '&tags=Settings' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=orange]3. Add-ons[/COLOR]' , str ( url ) , 'tutorial_addon_menu' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Audio' , str ( url ) + '&tags=Audio' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Errors' , str ( url ) + '&tags=Errors' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Gaming' , str ( url ) + '&tags=Gaming' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  LiveTV' , str ( url ) + '&tags=LiveTV' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Maintenance' , str ( url ) + '&tags=Maintenance' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Pictures' , str ( url ) + '&tags=Pictures' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Profiles' , str ( url ) + '&tags=Profiles' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Skins' , str ( url ) + '&tags=Skins' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Video' , str ( url ) + '&tags=Video' , 'grab_tutorials' , '' , '' , '' , '' )
 oO00oOOoooO ( 'folder' , '[COLOR=dodgerblue][XBMC/Kodi][/COLOR]  Weather' , str ( url ) + '&tags=Weather' , 'grab_tutorials' , '' , '' , '' , '' )
 if 79 - 79: O0 % OoooooooOO - OoooooooOO . iI1IiiIIIiIi + II11iIiIIIiI - iI1IiiIIIiIi
 if 94 - 94: o0oOo0 % OoooO0Oo0O0 + OoooooooOO
def Oo00oooOO ( url ) :
 oO000o = xbmc . getInfoLabel ( "System.BuildVersion" )
 ii11I1 = float ( oO000o [ : 4 ] )
 if ii11I1 < 14 :
  OO0OoOo0O = 'You are running XBMC'
 else :
  OO0OoOo0O = 'You are running Kodi'
 OOooO0OOoo = xbmcgui . Dialog ( )
 OOooO0OOoo . ok ( OO0OoOo0O , "Your version is: %s" % ii11I1 )
 if 84 - 84: OoooooooOO + i1Iii1i1I . i11iIiiIii - O0 / O0 % i1IIi
 if 38 - 38: iIii1I11I1II1 - oO0OooOoO
 if 47 - 47: OoooO0Oo0O0
 if 39 - 39: i11iIiiIii
 if 97 - 97: O00OOOoOoo0O . II11iIiIIIiI . Iiii1i1 + i1Iii1i1I % o0oOo0 . i11111IIIII
 if 40 - 40: Iiii1i1 - i11iIiiIii
 if 58 - 58: oO0OooOoO / O0
 if 83 - 83: iiIi1i11 * i11111IIIII / ii1ii11IIIiiI / i11iIiiIii
 if 94 - 94: O0 / iIii1I11I1II1 + O0 / o0Oo
 if 90 - 90: OoooooooOO * OoooooooOO
 if 47 - 47: O00OOOoOoo0O - Iiii1i1 + i11111IIIII . oO0OooOoO / III1IiiI / i11iIiiIii
 if 28 - 28: o0Oo . oOO00Oo + ii1ii11IIIiiI
 if 100 - 100: III1IiiI + oO0OooOoO / i11111IIIII / i1IIi / iI1IiiIIIiIi / O0
 if 50 - 50: iI1IiiIIIiIi + iI1IiiIIIiIi
 if 51 - 51: OoooO0Oo0O0 / OoooooooOO * i11111IIIII
 if 78 - 78: i1Iii1i1I / OoooO0Oo0O0 . i11iIiiIii
 if 69 - 69: o00O0OoO - oO0OooOoO
 if 66 - 66: o0Oo . o0Oo - O00OOOoOoo0O * OoooooooOO * oO0OooOoO + o0Oo
 if 59 - 59: iI1IiiIIIiIi
 if 59 - 59: oO0OooOoO - ii1ii11IIIiiI
 if 31 - 31: o00O0OoO - O00OOOoOoo0O / oOO00Oo * O00OOOoOoo0O / II11iIiIIIiI + oOO00Oo
 if 46 - 46: i11111IIIII * ii1ii11IIIiiI / iiIi1i11 + II11iIiIIIiI
I1ii1i11iI1 = i1iI11Ii1i ( )
O0iIiIIIIIii = None
oOOoooo = None
O0oo0oOoO00 = None
O0oIi1iIiIi1I11 = None
iIOoo0ooo0oo = None
Oo00oOOO0 = None
O0oii111 = None
O0OO = None
OO0oIiII1iiI = None
O0000OOO0 = None
oo0O0o = None
OoOO0o = None
O0oIIiIiiiii11 = None
Oo0oo0o = None
I1iI1iIIIii = None
i1iIIIi1i = None
OoO0o00O0oOOo = None
i1ii1iIi = None
OOo0 = None
oO000oOo00o0o = None
I1iI = None
OOO0 = None
iI1IIII1 = None
o0OOoOo0oo = None
IIIIIo0ooOoO000oO = None
o0OO0o0O00O0O = None
I1IiiI1i1 = None
ii11I1 = None
I111iI = None
I1Ii1 = None
ooOoOOii1111i11ii = None
iIIiI = None
OOO0o = 'maintenance'
if 19 - 19: Iiii1i1 * iI1IiiIIIiIi - III1IiiI
try :
 O0iIiIIIIIii = urllib . unquote_plus ( I1ii1i11iI1 [ "addon_id" ] )
except :
 pass
try :
 Oo0o = urllib . unquote_plus ( I1ii1i11iI1 [ "adult" ] )
except :
 pass
try :
 oOOoooo = urllib . unquote_plus ( I1ii1i11iI1 [ "artpack" ] )
except :
 pass
try :
 O0oo0oOoO00 = urllib . unquote_plus ( I1ii1i11iI1 [ "audioaddons" ] )
except :
 pass
try :
 O0oIi1iIiIi1I11 = urllib . unquote_plus ( I1ii1i11iI1 [ "author" ] )
except :
 pass
try :
 iIOoo0ooo0oo = urllib . unquote_plus ( I1ii1i11iI1 [ "buildname" ] )
except :
 pass
try :
 Oo00oOOO0 = urllib . unquote_plus ( I1ii1i11iI1 [ "data_path" ] )
except :
 pass
try :
 O0oii111 = urllib . unquote_plus ( I1ii1i11iI1 [ "description" ] )
except :
 pass
try :
 O0OO = urllib . unquote_plus ( I1ii1i11iI1 [ "email" ] )
except :
 pass
try :
 OO0oIiII1iiI = urllib . unquote_plus ( I1ii1i11iI1 [ "fanart" ] )
except :
 pass
try :
 O0000OOO0 = urllib . unquote_plus ( I1ii1i11iI1 [ "forum" ] )
except :
 pass
try :
 OoO000oo000o0 = urllib . unquote_plus ( I1ii1i11iI1 [ "guisettingslink" ] )
except :
 pass
try :
 oo0O0o = urllib . unquote_plus ( I1ii1i11iI1 [ "iconimage" ] )
except :
 pass
try :
 OoOO0o = urllib . unquote_plus ( I1ii1i11iI1 [ "link" ] )
except :
 pass
try :
 O0oIIiIiiiii11 = urllib . unquote_plus ( I1ii1i11iI1 [ "local" ] )
except :
 pass
try :
 Oo0oo0o = urllib . unquote_plus ( I1ii1i11iI1 [ "messages" ] )
except :
 pass
try :
 I1iI1iIIIii = str ( I1ii1i11iI1 [ "mode" ] )
except :
 pass
try :
 i1iIIIi1i = urllib . unquote_plus ( I1ii1i11iI1 [ "name" ] )
except :
 pass
try :
 I1I1Ii = urllib . unquote_plus ( I1ii1i11iI1 [ "pictureaddons" ] )
except :
 pass
try :
 OoO0o00O0oOOo = urllib . unquote_plus ( I1ii1i11iI1 [ "posts" ] )
except :
 pass
try :
 i1ii1iIi = urllib . unquote_plus ( I1ii1i11iI1 [ "programaddons" ] )
except :
 pass
try :
 OOo0 = urllib . unquote_plus ( I1ii1i11iI1 [ "provider_name" ] )
except :
 pass
try :
 I1iI = urllib . unquote_plus ( I1ii1i11iI1 [ "repo_link" ] )
except :
 pass
try :
 oO000oOo00o0o = urllib . unquote_plus ( I1ii1i11iI1 [ "repo_id" ] )
except :
 pass
try :
 OOO0 = urllib . unquote_plus ( I1ii1i11iI1 [ "skins" ] )
except :
 pass
try :
 iI1IIII1 = urllib . unquote_plus ( I1ii1i11iI1 [ "sources" ] )
except :
 pass
try :
 o0OOoOo0oo = urllib . unquote_plus ( I1ii1i11iI1 [ "title" ] )
except :
 pass
try :
 IIIIIo0ooOoO000oO = urllib . unquote_plus ( I1ii1i11iI1 [ "updated" ] )
except :
 pass
try :
 o0OO0o0O00O0O = urllib . unquote_plus ( I1ii1i11iI1 [ "unread" ] )
except :
 pass
try :
 I1IiiI1i1 = urllib . unquote_plus ( I1ii1i11iI1 [ "url" ] )
except :
 pass
try :
 ii11I1 = urllib . unquote_plus ( I1ii1i11iI1 [ "version" ] )
except :
 pass
try :
 I111iI = urllib . unquote_plus ( I1ii1i11iI1 [ "video" ] )
except :
 pass
try :
 I1Ii1 = urllib . unquote_plus ( I1ii1i11iI1 [ "videoaddons" ] )
except :
 pass
try :
 ooOoOOii1111i11ii = urllib . unquote_plus ( I1ii1i11iI1 [ "welcometext" ] )
except :
 pass
try :
 iIIiI = urllib . unquote_plus ( I1ii1i11iI1 [ "zip_link" ] )
except :
 pass
 if 78 - 78: ii1ii11IIIiiI - iI1IiiIIIiIi / iiIi1i11
if not os . path . exists ( Oo0oOOo ) :
 os . makedirs ( Oo0oOOo )
 if 81 - 81: O00OOOoOoo0O
if not os . path . exists ( O000OO0 ) :
 IiI1i111IiIiIi1 = open ( O000OO0 , mode = 'w+' )
 IiI1i111IiIiIi1 . write ( 'date="01011001"\nversion="0.0"' )
 IiI1i111IiIiIi1 . close ( )
 if 21 - 21: i1Iii1i1I / iiIi1i11 % i11111IIIII
if not os . path . exists ( I1IIiiIiii ) :
 IiI1i111IiIiIi1 = open ( I1IIiiIiii , mode = 'w+' )
 IiI1i111IiIiIi1 . write ( 'id="None"\nname="None"' )
 IiI1i111IiIiIi1 . close ( )
 if 51 - 51: o00O0OoO + o0oOo0 / o0Oo
if os . path . exists ( O000oo0O ) :
 try :
  shutil . rmtree ( O000oo0O )
 except :
  pass
  if 3 - 3: iIii1I11I1II1 / iiIi1i11 % III1IiiI . iI1IiiIIIiIi - iI1IiiIIIiIi
if os . path . exists ( OOOOi11i1 ) :
 try :
  shutil . rmtree ( OOOOi11i1 )
 except :
  pass
  if 55 - 55: i11iIiiIii % OoooooooOO + O0
if os . path . exists ( IIIii1II1II ) :
 try :
  shutil . rmtree ( IIIii1II1II )
 except :
  pass
  if 7 - 7: o0oOo0 - i11iIiiIii * i1Iii1i1I / iI1IiiIIIiIi - oOO00Oo
OOooo000 = binascii . unhexlify ( '6164646f6e2e786d6c' )
iI1iIIiiii = xbmc . translatePath ( os . path . join ( OO0o , o0OO00 , OOooo000 ) )
o00OoOoo = open ( iI1iIIiiii , mode = 'r' )
o0oO0OoO0 = file . read ( o00OoOoo )
file . close ( o00OoOoo )
OO0o00o0Oo = re . compile ( '<ref>(.+?)</ref>' ) . findall ( o0oO0OoO0 )
IIiIiI1Ii = OO0o00o0Oo [ 0 ] if ( len ( OO0o00o0Oo ) > 0 ) else ''
I1i = hashlib . md5 ( open ( o00OO00OoO , 'rb' ) . read ( ) ) . hexdigest ( )
if IIiIiI1Ii != I1i :
 ooo0o0OOo0O = open ( O00o0OO , mode = 'r' )
 o0oO0OoO0 = file . read ( ooo0o0OOo0O )
 file . close ( ooo0o0OOo0O )
 I1iI1I1 = open ( o00OO00OoO , mode = 'w+' )
 I1iI1I1 . write ( o0oO0OoO0 )
 I1iI1I1 . close ( )
 if 92 - 92: iI1IiiIIIiIi / iiIi1i11 % iiIi1i11 % O0 % o00O0OoO
print "### SKIN: " + OOOO0OOoO0O0
if 12 - 12: i11iIiiIii * o0oOo0 - oO0OooOoO
if I1iI1iIIIii == None : O0Oo0O0O0o0 ( )
elif I1iI1iIIIii == 'ASCII_Check' : OOoOoo00Oo ( )
elif I1iI1iIIIii == 'addon_final_menu' : o0OoOo00o0o ( I1IiiI1i1 )
elif I1iI1iIIIii == 'addon_categories' : I1II1 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'addon_countries' : iiIiIIIiiI ( I1IiiI1i1 )
elif I1iI1iIIIii == 'addon_genres' : OOO0ooo ( I1IiiI1i1 )
elif I1iI1iIIIii == 'addon_install' : iiI1i1Iii111 ( i1iIIIi1i , iIIiI , I1iI , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , O0000OOO0 , Oo00oOOO0 )
elif I1iI1iIIIii == 'addon_install_badzip' : ooOoO ( i1iIIIi1i , iIIiI , I1iI , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , O0000OOO0 , Oo00oOOO0 )
elif I1iI1iIIIii == 'addon_install_na' : o0OooooOoOO ( i1iIIIi1i , iIIiI , I1iI , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , O0000OOO0 , Oo00oOOO0 )
elif I1iI1iIIIii == 'addon_install_zero' : ii111Ii11iii ( i1iIIIi1i , iIIiI , I1iI , oO000oOo00o0o , O0iIiIIIIIii , OOo0 , O0000OOO0 , Oo00oOOO0 )
elif I1iI1iIIIii == 'addon_loop' : iiiiI1IiI1I1 ( )
elif I1iI1iIIIii == 'addon_removal_menu' : oOooo0Oo ( )
elif I1iI1iIIIii == 'addonmenu' : iiIiI1ii ( I1IiiI1i1 )
elif I1iI1iIIIii == 'addon_settings' : iIiI1IIiii11 ( )
elif I1iI1iIIIii == 'advanced_tools' : i1I1I1iiI ( )
elif I1iI1iIIIii == 'backup' : BACKUP ( )
elif I1iI1iIIIii == 'backup_option' : OOOOOo ( )
elif I1iI1iIIIii == 'backup_restore' : oO0O ( )
elif I1iI1iIIIii == 'browse_repos' : OOoo0oOO00 ( )
elif I1iI1iIIIii == 'cb_test_loop' : iiiiI1IiI1I1 ( )
elif I1iI1iIIIii == 'CB_Menu' : I11I1ii1i ( I1IiiI1i1 )
elif I1iI1iIIIii == 'check_storage' : checkPath . check ( OOO0o )
elif I1iI1iIIIii == 'check_updates' : ooo ( )
elif I1iI1iIIIii == 'clear_cache' : iI11II1i1I1 ( )
elif I1iI1iIIIii == 'create_keyword' : oOoOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'community' : ooOoo0OoOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'community_backup' : ooOO ( )
elif I1iI1iIIIii == 'community_backup_2' : OOooo000OooO ( )
elif I1iI1iIIIii == 'community_menu' : o0OO0OO000OO ( I1IiiI1i1 , I111iI )
elif I1iI1iIIIii == 'countries' : ii1i11ii ( I1IiiI1i1 )
elif I1iI1iIIIii == 'description' : o0oo00O ( i1iIIIi1i , I1IiiI1i1 , iIOoo0ooo0oo , O0oIi1iIiIi1I11 , ii11I1 , O0oii111 , IIIIIo0ooOoO000oO , OOO0 , I1Ii1 , O0oo0oOoO00 , i1ii1iIi , I1I1Ii , iI1IIII1 , Oo0o )
elif I1iI1iIIIii == 'delete_path' : O0oO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'delete_profile' : oOo0ooo0O ( I1IiiI1i1 )
elif I1iI1iIIIii == 'fix_special' : OO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'full_backup' : Oo00O ( )
elif I1iI1iIIIii == 'full_clean' : I11i1I11 ( )
elif I1iI1iIIIii == 'genres' : I1I11 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'gotham' : o0oOO0 ( )
elif I1iI1iIIIii == 'grab_addons' : i1IIII1111 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'grab_builds' : o0OOo0Ooo0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'grab_builds_premium' : Grab_Builds_Premium ( I1IiiI1i1 )
elif I1iI1iIIIii == 'grab_hardware' : o0OoOo0o0OOoO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'grab_news' : i11ii ( I1IiiI1i1 )
elif I1iI1iIIIii == 'grab_tutorials' : Oo00o0OOo0OO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'guisettingsfix' : oOO0O0O ( I1IiiI1i1 , O0oIIiIiiiii11 )
elif I1iI1iIIIii == 'hardware_filter_menu' : oooOo ( I1IiiI1i1 )
elif I1iI1iIIIii == 'hardware_final_menu' : oOOo00OOOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'hardware_root_menu' : III11i ( )
elif I1iI1iIIIii == 'helix' : OO0oOOo0o ( )
elif I1iI1iIIIii == 'hide_passwords' : oOOo0O0Oo ( )
elif I1iI1iIIIii == 'ipcheck' : OO000oOO0o00 ( )
elif I1iI1iIIIii == 'install_content' : II11IIOOOOO0oOOoO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'install_from_zip' : IIIII11 ( )
elif I1iI1iIIIii == 'instructions' : OOo0O0 ( )
elif I1iI1iIIIii == 'instructions_1' : oooooo0 ( )
elif I1iI1iIIIii == 'instructions_2' : iI1i11II1i1i ( )
elif I1iI1iIIIii == 'instructions_3' : O0OOO00O0OO0 ( )
elif I1iI1iIIIii == 'instructions_4' : oOo0Oi1i1III11IiIi ( )
elif I1iI1iIIIii == 'instructions_5' : II1iii1iII ( )
elif I1iI1iIIIii == 'instructions_6' : Instructions_6 ( )
elif I1iI1iIIIii == 'keywords' : iiiii1i1 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'kill_xbmc' : Oo0iII ( )
elif I1iI1iIIIii == 'kodi_settings' : II11IIII1 ( )
elif I1iI1iIIIii == 'local_backup' : iI1IiiiiI ( )
elif I1iI1iIIIii == 'LocalGUIDialog' : o00o ( )
elif I1iI1iIIIii == 'log' : oooo0O ( )
elif I1iI1iIIIii == 'login_check' : oOoo00o0OoOOO ( )
elif I1iI1iIIIii == 'manual_search' : oOOoO00OoooOo0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'manual_search_builds' : Manual_Search_Builds ( )
elif I1iI1iIIIii == 'nan_menu' : iI11Ii1Ii ( )
elif I1iI1iIIIii == 'news_root_menu' : I1I1i1 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'news_menu' : IIII1i1I ( I1IiiI1i1 )
elif I1iI1iIIIii == 'notify_msg' : IiI ( I1IiiI1i1 )
elif I1iI1iIIIii == 'open_system_info' : OOoOo00O0 ( )
elif I1iI1iIIIii == 'open_filemanager' : OooO00Oo ( )
elif I1iI1iIIIii == 'openelec_backup' : O00 ( )
elif I1iI1iIIIii == 'openelec_settings' : OOo0iIiiI11II11 ( )
elif I1iI1iIIIii == 'play_video' : yt . PlayVideo ( I1IiiI1i1 )
elif I1iI1iIIIii == 'platform_menu' : o00O00o ( I1IiiI1i1 )
elif I1iI1iIIIii == 'pop' : II111 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'register' : iI11IiiI1 ( )
elif I1iI1iIIIii == 'remove_addon_data' : Oo0oo ( )
elif I1iI1iIIIii == 'remove_addons' : ooO00O00oOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'remove_build' : i1I1I111iiII ( )
elif I1iI1iIIIii == 'remove_crash_logs' : Ii1I11Ii1iI ( )
elif I1iI1iIIIii == 'remove_packages' : o00Oo0O ( )
elif I1iI1iIIIii == 'remove_textures' : o00oO0O0oo0o ( )
elif I1iI1iIIIii == 'restore' : RESTORE ( )
elif I1iI1iIIIii == 'restore_backup' : o0O0ooooO0 ( i1iIIIi1i , I1IiiI1i1 , O0oii111 )
elif I1iI1iIIIii == 'restore_community' : oOoooOOO0 ( i1iIIIi1i , I1IiiI1i1 , I111iI , O0oii111 , OOO0 , OoO000oo000o0 , oOOoooo )
elif I1iI1iIIIii == 'restore_local_CB' : o000oO0oOOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'restore_local_gui' : IiIiIiiI ( )
elif I1iI1iIIIii == 'restore_local_OE' : o00O00O0O0 ( )
elif I1iI1iIIIii == 'restore_openelec' : IiI11i1IiI1 ( i1iIIIi1i , I1IiiI1i1 , I111iI )
elif I1iI1iIIIii == 'restore_option' : ii11iI11I111I ( )
elif I1iI1iIIIii == 'restore_zip' : I1IIoooooOO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'run_addon' : iiI ( I1IiiI1i1 )
elif I1iI1iIIIii == 'runtest' : speedtest . runtest ( I1IiiI1i1 )
elif I1iI1iIIIii == 'search_addons' : i1III1II11Ii ( I1IiiI1i1 )
elif I1iI1iIIIii == 'search_builds' : II1o0o00O ( I1IiiI1i1 )
elif I1iI1iIIIii == 'Search_Private' : Private_Search ( I1IiiI1i1 )
elif I1iI1iIIIii == 'showinfo' : o0o0O0oOOoO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'showinfo2' : O0O0o0OOOooo0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'SortBy' : OoooOO0 ( BuildURL , type )
elif I1iI1iIIIii == 'speed_instructions' : iIiIiiiI ( )
elif I1iI1iIIIii == 'speedtest_menu' : iI1I1IIIIIIii ( )
elif I1iI1iIIIii == 'switch_profile_menu' : o0OOoOO00OO0 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'switch_profile' : oOO00 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'text_guide' : OOo00 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'tools' : oo000o0O0o0O ( )
elif I1iI1iIIIii == 'tutorial_final_menu' : O0O00 ( I1IiiI1i1 )
elif I1iI1iIIIii == 'tutorial_addon_menu' : o00OOOOoOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'tutorial_root_menu' : oO0oO ( )
elif I1iI1iIIIii == 'unhide_passwords' : Ii1IIiII11Iiii1i1II ( )
elif I1iI1iIIIii == 'update' : i1i1iI1iiiI ( )
elif I1iI1iIIIii == 'update_community' : i1iIIii1 ( i1iIIIi1i , I1IiiI1i1 , I111iI , O0oii111 , OOO0 , OoO000oo000o0 , oOOoooo )
elif I1iI1iIIIii == 'uploadlog' : o0o0o ( )
elif I1iI1iIIIii == 'user_info' : oOoooO0O0oOO ( )
elif I1iI1iIIIii == 'xbmc_menu' : IiIiii ( I1IiiI1i1 )
elif I1iI1iIIIii == 'xbmcversion' : Oo00oooOO ( I1IiiI1i1 )
elif I1iI1iIIIii == 'wipe_xbmc' : O0Oo0oOOoo0000o ( I1iI1iIIIii )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
